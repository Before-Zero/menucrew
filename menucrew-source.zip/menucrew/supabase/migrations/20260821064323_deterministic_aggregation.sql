alter table public.rooms
add column selection_status text not null default 'open',
add column selection_status_changed_at timestamptz not null default now(),
add column selection_revision bigint not null default 0;

alter table public.rooms
add constraint rooms_selection_status_valid
check (selection_status in ('open', 'reviewing')),
add constraint rooms_selection_revision_valid
check (selection_revision >= 0);

grant select (
  selection_status,
  selection_status_changed_at,
  selection_revision
)
on public.rooms to authenticated;

create function private.can_read_member_submission(
  candidate_submission_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.member_submissions as submission
    where submission.id = candidate_submission_id
      and (
        submission.user_id = (select auth.uid())
        or (select private.is_room_organizer(submission.room_id))
      )
  );
$$;

revoke all on function private.can_read_member_submission(uuid)
from public, anon;
grant execute on function private.can_read_member_submission(uuid)
to authenticated;

drop policy "Members can read their own submission"
on public.member_submissions;

create policy "Members and organizers can read allowed submissions"
on public.member_submissions
for select
to authenticated
using (
  user_id = (select auth.uid())
  or (select private.is_room_organizer(room_id))
);

drop policy "Members can read their own selections"
on public.member_selections;

create policy "Members and organizers can read allowed selections"
on public.member_selections
for select
to authenticated
using ((select private.can_read_member_submission(submission_id)));

create function public.set_selection_collection_status(
  candidate_room_id uuid,
  candidate_status text
)
returns table (new_status text, new_revision bigint)
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_status text;
  current_revision bigint;
begin
  if current_user_id is null then
    raise exception using
      errcode = '28000',
      message = 'authentication_required';
  end if;

  if candidate_status not in ('open', 'reviewing') then
    raise exception using errcode = '22023', message = 'invalid_status';
  end if;

  select room.selection_status, room.selection_revision
  into current_status, current_revision
  from public.rooms as room
  where room.id = candidate_room_id
  for update;

  if current_status is null or not exists (
    select 1
    from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
      and membership.role = 'organizer'
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  if current_status = candidate_status then
    return query select current_status, current_revision;
    return;
  end if;

  update public.rooms as room
  set
    selection_status = candidate_status,
    selection_status_changed_at = now(),
    selection_revision = room.selection_revision + 1
  where room.id = candidate_room_id
  returning room.selection_status, room.selection_revision
  into current_status, current_revision;

  return query select current_status, current_revision;
end;
$$;

revoke all on function public.set_selection_collection_status(uuid, text)
from public, anon;
grant execute on function public.set_selection_collection_status(uuid, text)
to authenticated;

create or replace function public.save_my_selection(
  candidate_room_id uuid,
  candidate_dietary_restrictions text,
  candidate_allergy_info text,
  candidate_selections jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_collection_status text;
  current_menu_id uuid;
  current_submission_id uuid;
  normalized_dietary_restrictions text := btrim(
    coalesce(candidate_dietary_restrictions, '')
  );
  normalized_allergy_info text := btrim(coalesce(candidate_allergy_info, ''));
  selection_entry jsonb;
  selection_item_id uuid;
  selection_item_id_text text;
  selection_quantity smallint;
  selection_quantity_text text;
  selection_note text;
  seen_item_ids uuid[] := array[]::uuid[];
  uuid_pattern constant text :=
    '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';
begin
  if current_user_id is null then
    raise exception using
      errcode = '28000',
      message = 'authentication_required';
  end if;

  select room.selection_status
  into current_collection_status
  from public.rooms as room
  where room.id = candidate_room_id
  for update;

  if current_collection_status is null or not exists (
    select 1
    from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  if current_collection_status <> 'open' then
    raise exception using errcode = '55000', message = 'collection_closed';
  end if;

  if char_length(normalized_dietary_restrictions) > 500 then
    raise exception using
      errcode = '22023',
      message = 'dietary_restrictions_too_long';
  end if;

  if char_length(normalized_allergy_info) > 500 then
    raise exception using errcode = '22023', message = 'allergy_info_too_long';
  end if;

  if candidate_selections is null
    or jsonb_typeof(candidate_selections) <> 'array'
    or jsonb_array_length(candidate_selections) > 200
  then
    raise exception using errcode = '22023', message = 'invalid_selections';
  end if;

  select menu.id
  into current_menu_id
  from public.menus as menu
  where menu.room_id = candidate_room_id
    and menu.status = 'published'
  for update;

  if current_menu_id is null then
    raise exception using errcode = '55000', message = 'menu_not_published';
  end if;

  for selection_entry in
    select value from jsonb_array_elements(candidate_selections)
  loop
    if jsonb_typeof(selection_entry) <> 'object'
      or jsonb_typeof(selection_entry -> 'menuItemId') <> 'string'
      or jsonb_typeof(selection_entry -> 'quantity') <> 'number'
      or (
        selection_entry ? 'note'
        and jsonb_typeof(selection_entry -> 'note') <> 'string'
      )
    then
      raise exception using errcode = '22023', message = 'invalid_selection';
    end if;

    selection_item_id_text := selection_entry ->> 'menuItemId';
    selection_quantity_text := selection_entry ->> 'quantity';
    selection_note := btrim(coalesce(selection_entry ->> 'note', ''));

    if selection_item_id_text !~* uuid_pattern
      or selection_quantity_text !~ '^(0|[1-9]|1[0-9]|20)$'
      or char_length(selection_note) > 240
    then
      raise exception using errcode = '22023', message = 'invalid_selection';
    end if;

    selection_item_id := selection_item_id_text::uuid;
    selection_quantity := selection_quantity_text::smallint;

    if selection_item_id = any(seen_item_ids) then
      raise exception using errcode = '22023', message = 'duplicate_menu_item';
    end if;

    if not exists (
      select 1
      from public.menu_items as item
      where item.id = selection_item_id
        and item.menu_id = current_menu_id
    ) then
      raise exception using errcode = '22023', message = 'invalid_menu_item';
    end if;

    seen_item_ids := array_append(seen_item_ids, selection_item_id);
  end loop;

  insert into public.member_submissions (
    room_id,
    user_id,
    dietary_restrictions,
    allergy_info,
    submitted_at
  )
  values (
    candidate_room_id,
    current_user_id,
    normalized_dietary_restrictions,
    normalized_allergy_info,
    now()
  )
  on conflict (room_id, user_id) do update
  set
    dietary_restrictions = excluded.dietary_restrictions,
    allergy_info = excluded.allergy_info,
    submitted_at = excluded.submitted_at,
    updated_at = now()
  returning id into current_submission_id;

  delete from public.member_selections
  where submission_id = current_submission_id;

  insert into public.member_selections (
    submission_id,
    menu_item_id,
    quantity,
    note
  )
  select
    current_submission_id,
    (entry ->> 'menuItemId')::uuid,
    (entry ->> 'quantity')::smallint,
    btrim(coalesce(entry ->> 'note', ''))
  from jsonb_array_elements(candidate_selections) as entries(entry)
  where (entry ->> 'quantity')::smallint > 0;

  update public.rooms as room
  set selection_revision = room.selection_revision + 1
  where room.id = candidate_room_id;

  return current_submission_id;
end;
$$;
