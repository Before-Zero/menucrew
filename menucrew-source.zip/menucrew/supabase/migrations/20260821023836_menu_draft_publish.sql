insert into storage.buckets (
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
)
values (
  'menu-images',
  'menu-images',
  false,
  6291456,
  array['image/jpeg', 'image/png', 'image/webp']::text[]
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create table public.menus (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  status text not null default 'draft',
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint menus_room_id_unique unique (room_id),
  constraint menus_status_valid check (status in ('draft', 'published')),
  constraint menus_publication_state_valid check (
    (status = 'draft' and published_at is null)
    or (status = 'published' and published_at is not null)
  )
);

create table public.menu_images (
  id uuid primary key default gen_random_uuid(),
  menu_id uuid not null references public.menus (id) on delete cascade,
  storage_path text not null,
  original_name text not null,
  mime_type text not null,
  byte_size bigint not null,
  position integer not null,
  created_at timestamptz not null default now(),
  constraint menu_images_storage_path_unique unique (storage_path),
  constraint menu_images_storage_path_valid check (
    storage_path = btrim(storage_path)
    and char_length(storage_path) between 1 and 500
  ),
  constraint menu_images_original_name_valid check (
    original_name = btrim(original_name)
    and char_length(original_name) between 1 and 255
  ),
  constraint menu_images_mime_type_valid check (
    mime_type in ('image/jpeg', 'image/png', 'image/webp')
  ),
  constraint menu_images_byte_size_valid check (
    byte_size between 1 and 6291456
  ),
  constraint menu_images_position_valid check (position >= 0)
);

create index menu_images_menu_order_idx
on public.menu_images (menu_id, position, id);

create table public.menu_items (
  id uuid primary key default gen_random_uuid(),
  menu_id uuid not null references public.menus (id) on delete cascade,
  original_name text not null,
  zh_name text not null,
  description text not null,
  position integer not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint menu_items_original_name_valid check (
    original_name = btrim(original_name)
    and char_length(original_name) between 1 and 120
  ),
  constraint menu_items_zh_name_valid check (
    zh_name = btrim(zh_name)
    and char_length(zh_name) between 1 and 120
  ),
  constraint menu_items_description_valid check (
    description = btrim(description)
    and char_length(description) between 1 and 240
  ),
  constraint menu_items_position_valid check (position >= 0)
);

create index menu_items_menu_order_idx
on public.menu_items (menu_id, position, id);

create function private.is_room_organizer(candidate_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.room_members
    where room_id = candidate_room_id
      and user_id = (select auth.uid())
      and role = 'organizer'
  );
$$;

create function private.can_manage_menu(candidate_menu_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.menus
    join public.room_members
      on room_members.room_id = menus.room_id
    where menus.id = candidate_menu_id
      and room_members.user_id = (select auth.uid())
      and room_members.role = 'organizer'
  );
$$;

create function private.can_edit_menu(candidate_menu_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.menus
    join public.room_members
      on room_members.room_id = menus.room_id
    where menus.id = candidate_menu_id
      and menus.status = 'draft'
      and room_members.user_id = (select auth.uid())
      and room_members.role = 'organizer'
  );
$$;

create function private.can_read_menu(candidate_menu_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.menus
    join public.room_members
      on room_members.room_id = menus.room_id
    where menus.id = candidate_menu_id
      and room_members.user_id = (select auth.uid())
      and (
        room_members.role = 'organizer'
        or menus.status = 'published'
      )
  );
$$;

create function private.can_manage_menu_object(
  object_name text,
  require_draft boolean
)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  folders text[] := storage.foldername(object_name);
  candidate_room_id uuid;
  candidate_menu_id uuid;
  uuid_pattern constant text :=
    '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';
begin
  if coalesce(array_length(folders, 1), 0) <> 2
    or folders[1] !~* uuid_pattern
    or folders[2] !~* uuid_pattern
  then
    return false;
  end if;

  candidate_room_id := folders[1]::uuid;
  candidate_menu_id := folders[2]::uuid;

  return exists (
    select 1
    from public.menus
    join public.room_members
      on room_members.room_id = menus.room_id
    where menus.id = candidate_menu_id
      and menus.room_id = candidate_room_id
      and room_members.user_id = (select auth.uid())
      and room_members.role = 'organizer'
      and (not require_draft or menus.status = 'draft')
  );
end;
$$;

revoke all on function private.is_room_organizer(uuid)
from public, anon;
revoke all on function private.can_manage_menu(uuid)
from public, anon;
revoke all on function private.can_edit_menu(uuid)
from public, anon;
revoke all on function private.can_read_menu(uuid)
from public, anon;
revoke all on function private.can_manage_menu_object(text, boolean)
from public, anon;

grant execute on function private.is_room_organizer(uuid) to authenticated;
grant execute on function private.can_manage_menu(uuid) to authenticated;
grant execute on function private.can_edit_menu(uuid) to authenticated;
grant execute on function private.can_read_menu(uuid) to authenticated;
grant execute on function private.can_manage_menu_object(text, boolean)
to authenticated;

create function private.prepare_menu_status_transition()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();

  if new.status = old.status then
    new.published_at := old.published_at;
    return new;
  end if;

  if old.status = 'draft' and new.status = 'published' then
    if not exists (
      select 1 from public.menu_images where menu_id = old.id
    ) or not exists (
      select 1 from public.menu_items where menu_id = old.id
    ) then
      raise exception using
        errcode = '23514',
        message = 'menu_publish_requirements_not_met';
    end if;

    new.published_at := now();
    return new;
  end if;

  if old.status = 'published' and new.status = 'draft' then
    new.published_at := null;
    return new;
  end if;

  raise exception using errcode = '23514', message = 'invalid_menu_transition';
end;
$$;

create trigger menus_prepare_status_transition
before update on public.menus
for each row execute function private.prepare_menu_status_transition();

create function private.prepare_menu_image_insert()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  target_room_id uuid;
  expected_prefix text;
begin
  select room_id
  into target_room_id
  from public.menus
  where id = new.menu_id
  for update;

  if target_room_id is null then
    raise exception using errcode = '23503', message = 'menu_not_found';
  end if;

  expected_prefix := target_room_id::text || '/' || new.menu_id::text || '/';

  if left(new.storage_path, char_length(expected_prefix)) <> expected_prefix then
    raise exception using errcode = '23514', message = 'invalid_menu_image_path';
  end if;

  if (
    select count(*) from public.menu_images where menu_id = new.menu_id
  ) >= 4 then
    raise exception using errcode = '23514', message = 'menu_image_limit_reached';
  end if;

  return new;
end;
$$;

create trigger menu_images_prepare_insert
before insert on public.menu_images
for each row execute function private.prepare_menu_image_insert();

create function private.touch_menu_item()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger menu_items_touch_updated_at
before update on public.menu_items
for each row execute function private.touch_menu_item();

create function private.touch_parent_menu()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_menu_id uuid;
begin
  if tg_op = 'DELETE' then
    target_menu_id := old.menu_id;
  else
    target_menu_id := new.menu_id;
  end if;

  update public.menus
  set updated_at = now()
  where id = target_menu_id;

  if tg_op = 'DELETE' then
    return old;
  end if;

  return new;
end;
$$;

revoke all on function private.prepare_menu_status_transition()
from public, anon, authenticated;
revoke all on function private.prepare_menu_image_insert()
from public, anon, authenticated;
revoke all on function private.touch_menu_item()
from public, anon, authenticated;
revoke all on function private.touch_parent_menu()
from public, anon, authenticated;

create trigger menu_images_touch_parent
after insert or update or delete on public.menu_images
for each row execute function private.touch_parent_menu();

create trigger menu_items_touch_parent
after insert or update or delete on public.menu_items
for each row execute function private.touch_parent_menu();

alter table public.menus enable row level security;
alter table public.menus force row level security;
alter table public.menu_images enable row level security;
alter table public.menu_images force row level security;
alter table public.menu_items enable row level security;
alter table public.menu_items force row level security;

create policy "Room members can read available menus"
on public.menus
for select
to authenticated
using ((select private.can_read_menu(id)));

create policy "Organizers can create room menus"
on public.menus
for insert
to authenticated
with check (
  status = 'draft'
  and published_at is null
  and (select private.is_room_organizer(room_id))
);

create policy "Organizers can change menu status"
on public.menus
for update
to authenticated
using ((select private.can_manage_menu(id)))
with check ((select private.can_manage_menu(id)));

create policy "Organizers can read menu images"
on public.menu_images
for select
to authenticated
using ((select private.can_manage_menu(menu_id)));

create policy "Organizers can add draft menu images"
on public.menu_images
for insert
to authenticated
with check ((select private.can_edit_menu(menu_id)));

create policy "Organizers can delete draft menu images"
on public.menu_images
for delete
to authenticated
using ((select private.can_edit_menu(menu_id)));

create policy "Room members can read available menu items"
on public.menu_items
for select
to authenticated
using ((select private.can_read_menu(menu_id)));

create policy "Organizers can add draft menu items"
on public.menu_items
for insert
to authenticated
with check ((select private.can_edit_menu(menu_id)));

create policy "Organizers can update draft menu items"
on public.menu_items
for update
to authenticated
using ((select private.can_edit_menu(menu_id)))
with check ((select private.can_edit_menu(menu_id)));

create policy "Organizers can delete draft menu items"
on public.menu_items
for delete
to authenticated
using ((select private.can_edit_menu(menu_id)));

create policy "Organizers can upload menu image objects"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'menu-images'
  and (select private.can_manage_menu_object(name, true))
);

create policy "Organizers can read menu image objects"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'menu-images'
  and (select private.can_manage_menu_object(name, false))
);

create policy "Organizers can delete draft menu image objects"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'menu-images'
  and (select private.can_manage_menu_object(name, true))
);

revoke all on table public.menus from anon, authenticated;
revoke all on table public.menu_images from anon, authenticated;
revoke all on table public.menu_items from anon, authenticated;

grant select (id, room_id, status, published_at, created_at, updated_at)
on public.menus to authenticated;
grant insert (room_id) on public.menus to authenticated;
grant update (status) on public.menus to authenticated;

grant select (
  id,
  menu_id,
  storage_path,
  original_name,
  mime_type,
  byte_size,
  position,
  created_at
)
on public.menu_images to authenticated;
grant insert (
  menu_id,
  storage_path,
  original_name,
  mime_type,
  byte_size,
  position
)
on public.menu_images to authenticated;
grant delete on public.menu_images to authenticated;

grant select (
  id,
  menu_id,
  original_name,
  zh_name,
  description,
  position,
  created_at,
  updated_at
)
on public.menu_items to authenticated;
grant insert (menu_id, original_name, zh_name, description, position)
on public.menu_items to authenticated;
grant update (original_name, zh_name, description, position)
on public.menu_items to authenticated;
grant delete on public.menu_items to authenticated;
