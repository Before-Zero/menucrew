create function public.get_room_submission_progress(
  candidate_room_id uuid
)
returns table (
  member_count bigint,
  submitted_count bigint,
  my_submitted boolean
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null
    or not (select private.is_room_member(candidate_room_id))
  then
    raise exception using
      errcode = 'P0001',
      message = 'room_access_denied';
  end if;

  return query
  select
    (
      select count(*)
      from public.room_members
      where room_id = candidate_room_id
    ),
    (
      select count(*)
      from public.member_submissions
      where room_id = candidate_room_id
    ),
    exists (
      select 1
      from public.member_submissions
      where room_id = candidate_room_id
        and user_id = (select auth.uid())
    );
end;
$$;

revoke all on function public.get_room_submission_progress(uuid)
from public, anon;

grant execute on function public.get_room_submission_progress(uuid)
to authenticated;
