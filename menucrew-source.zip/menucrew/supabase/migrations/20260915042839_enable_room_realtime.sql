-- Room members already have a narrowed RLS SELECT policy on public.rooms.
-- Publishing this table exposes only changes the connected member may read and
-- lets clients react to the existing selection_revision coordination signal.
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'rooms'
  ) then
    alter publication supabase_realtime add table public.rooms;
  end if;
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'menus'
  ) then
    alter publication supabase_realtime add table public.menus;
  end if;
end
$$;
