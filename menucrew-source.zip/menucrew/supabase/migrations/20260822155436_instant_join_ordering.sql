alter table public.menu_items
add column en_name text,
add column description_en text;

update public.menu_items
set
  en_name = original_name,
  description_en = description
where en_name is null or description_en is null;

alter table public.menu_items
alter column en_name set not null,
alter column en_name set default '',
alter column description_en set not null,
alter column description_en set default '';

alter table public.menu_items
add constraint menu_items_en_name_valid check (
  en_name = btrim(en_name) and char_length(en_name) between 1 and 120
),
add constraint menu_items_description_en_valid check (
  description_en = btrim(description_en) and char_length(description_en) <= 240
);

grant select (en_name, description_en) on public.menu_items to authenticated;
grant insert (en_name, description_en) on public.menu_items to authenticated;
grant update (en_name, description_en) on public.menu_items to authenticated;

create function private.fill_menu_item_english()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.en_name := coalesce(nullif(btrim(new.en_name), ''), new.original_name);
  new.description_en := coalesce(
    nullif(btrim(new.description_en), ''),
    new.description
  );
  return new;
end;
$$;

revoke all on function private.fill_menu_item_english()
from public, anon, authenticated;

create trigger menu_items_fill_english
before insert on public.menu_items
for each row execute function private.fill_menu_item_english();

alter table public.order_items add column en_name text not null default '';

update public.order_items as order_item
set en_name = coalesce(nullif(menu_item.en_name, ''), order_item.original_name)
from public.menu_items as menu_item
where menu_item.id = order_item.menu_item_id
  and order_item.en_name = '';

alter table public.order_items
add constraint order_items_en_name_valid check (
  en_name = btrim(en_name) and char_length(en_name) between 1 and 300
);

grant select (en_name) on public.order_items to authenticated;

create function private.fill_order_item_english_name()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if nullif(btrim(new.en_name), '') is null then
    select coalesce(nullif(item.en_name, ''), new.original_name)
    into new.en_name
    from public.menu_items as item
    where item.id = new.menu_item_id;
    new.en_name := coalesce(nullif(new.en_name, ''), new.original_name);
  end if;
  return new;
end;
$$;

revoke all on function private.fill_order_item_english_name()
from public, anon, authenticated;

create trigger order_items_fill_english_name
before insert on public.order_items
for each row execute function private.fill_order_item_english_name();

create function public.get_member_receipt(candidate_room_id uuid)
returns table (
  revision bigint,
  order_confirmed boolean,
  menu_item_id uuid,
  original_name text,
  zh_name text,
  en_name text,
  total_quantity integer,
  my_quantity integer,
  item_position integer
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
begin
  if current_user_id is null or not exists (
    select 1 from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  if not exists (
    select 1 from public.member_submissions as submission
    where submission.room_id = candidate_room_id
      and submission.user_id = current_user_id
  ) then
    raise exception using errcode = '42501', message = 'submission_required';
  end if;

  return query
  select
    room.selection_revision,
    exists (
      select 1 from public.orders as final_order
      where final_order.room_id = candidate_room_id
    ),
    item.id,
    item.original_name,
    item.zh_name,
    item.en_name,
    sum(selection.quantity)::integer,
    coalesce(sum(selection.quantity) filter (
      where submission.user_id = current_user_id
    ), 0)::integer,
    item.position
  from public.rooms as room
  join public.menus as menu
    on menu.room_id = room.id and menu.status = 'published'
  join public.menu_items as item on item.menu_id = menu.id
  join public.member_selections as selection on selection.menu_item_id = item.id
  join public.member_submissions as submission
    on submission.id = selection.submission_id
   and submission.room_id = room.id
  where room.id = candidate_room_id
    and selection.quantity > 0
  group by
    room.selection_revision,
    item.id,
    item.original_name,
    item.zh_name,
    item.en_name,
    item.position
  having sum(selection.quantity) > 0
  order by item.position, item.id;
end;
$$;

revoke all on function public.get_member_receipt(uuid) from public, anon;
grant execute on function public.get_member_receipt(uuid) to authenticated;

create function public.confirm_final_order_direct(
  candidate_room_id uuid,
  candidate_source_revision bigint,
  candidate_items jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_status text;
  current_revision bigint;
  existing_order_id uuid;
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;

  select room.selection_status, room.selection_revision
  into current_status, current_revision
  from public.rooms as room
  where room.id = candidate_room_id
  for update;

  if current_status is null or not exists (
    select 1 from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
      and membership.role = 'organizer'
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  select final_order.id into existing_order_id
  from public.orders as final_order
  where final_order.room_id = candidate_room_id;
  if existing_order_id is not null then return existing_order_id; end if;

  if current_status <> 'open' then
    raise exception using errcode = '55000', message = 'collection_closed';
  end if;
  if current_revision <> candidate_source_revision then
    raise exception using errcode = '40001', message = 'stale_revision';
  end if;

  update public.rooms as room
  set
    selection_status = 'reviewing',
    selection_status_changed_at = now(),
    selection_revision = room.selection_revision + 1
  where room.id = candidate_room_id
  returning room.selection_revision into current_revision;

  return public.confirm_final_order(
    candidate_room_id,
    current_revision,
    candidate_items
  );
end;
$$;

revoke all on function public.confirm_final_order_direct(uuid, bigint, jsonb)
from public, anon;
grant execute on function public.confirm_final_order_direct(uuid, bigint, jsonb)
to authenticated;

create function public.confirm_menu_ai_run_and_publish(candidate_run_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_room_id uuid;
  selected_menu_id uuid;
  item_count integer;
begin
  select run.room_id, run.menu_id
  into selected_room_id, selected_menu_id
  from public.menu_ai_runs as run
  where run.id = candidate_run_id
  for update;

  if selected_room_id is null
    or auth.uid() is null
    or not private.is_room_organizer(selected_room_id)
  then
    raise exception 'menu_ai_access_denied';
  end if;

  item_count := public.apply_menu_ai_run(candidate_run_id);

  update public.menu_items
  set
    en_name = coalesce(nullif(en_name, ''), original_name),
    description_en = coalesce(nullif(description_en, ''), description)
  where menu_id = selected_menu_id;

  update public.menus
  set status = 'published'
  where id = selected_menu_id and status = 'draft';

  return item_count;
end;
$$;

revoke all on function public.confirm_menu_ai_run_and_publish(uuid)
from public, anon;
grant execute on function public.confirm_menu_ai_run_and_publish(uuid)
to authenticated;

create table public.menu_assistant_runs (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  menu_id uuid not null references public.menus (id) on delete cascade,
  requested_by uuid not null,
  input_digest text not null check (input_digest ~ '^[0-9a-f]{64}$'),
  status text not null default 'processing'
    check (status in ('processing', 'succeeded', 'failed')),
  model text not null check (
    model = btrim(model) and char_length(model) between 1 and 100
  ),
  result jsonb,
  error_code text,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  constraint menu_assistant_runs_requester_fkey
    foreign key (room_id, requested_by)
    references public.room_members (room_id, user_id)
);

create index menu_assistant_runs_room_created_idx
on public.menu_assistant_runs (room_id, created_at desc);
create unique index menu_assistant_runs_success_digest_unique
on public.menu_assistant_runs (requested_by, menu_id, input_digest)
where status = 'succeeded';

alter table public.menu_assistant_runs enable row level security;
alter table public.menu_assistant_runs force row level security;
revoke all on table public.menu_assistant_runs from public, anon, authenticated;

create function private.is_valid_menu_assistant_result(candidate_result jsonb)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select jsonb_typeof(candidate_result) = 'object'
    and jsonb_typeof(candidate_result -> 'answer') = 'string'
    and char_length(btrim(candidate_result ->> 'answer')) between 1 and 1200
    and jsonb_typeof(candidate_result -> 'referencedItems') = 'array'
    and jsonb_array_length(candidate_result -> 'referencedItems') <= 8
    and jsonb_typeof(candidate_result -> 'caution') = 'string'
    and char_length(btrim(candidate_result ->> 'caution')) <= 300;
$$;

revoke all on function private.is_valid_menu_assistant_result(jsonb)
from public, anon, authenticated;

create function public.start_menu_assistant_run(
  candidate_room_id uuid,
  candidate_input_digest text,
  candidate_model text
)
returns table (run_id uuid, reused boolean, reused_result jsonb)
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  selected_menu_id uuid;
  existing_run public.menu_assistant_runs%rowtype;
  recent_count integer;
begin
  if current_user_id is null
    or candidate_input_digest !~ '^[0-9a-f]{64}$'
    or candidate_model <> btrim(candidate_model)
    or char_length(candidate_model) not between 1 and 100
  then raise exception 'invalid_menu_assistant_request'; end if;

  perform 1 from public.rooms where id = candidate_room_id for update;
  if not exists (
    select 1 from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
  ) then raise exception 'menu_assistant_access_denied'; end if;

  select menu.id into selected_menu_id
  from public.menus as menu
  where menu.room_id = candidate_room_id and menu.status = 'published';
  if selected_menu_id is null then raise exception 'menu_not_published'; end if;
  if exists (
    select 1 from public.orders where room_id = candidate_room_id
  ) then raise exception 'order_already_confirmed'; end if;

  select * into existing_run
  from public.menu_assistant_runs as run
  where run.requested_by = current_user_id
    and run.menu_id = selected_menu_id
    and run.input_digest = candidate_input_digest
    and run.status = 'succeeded'
  order by run.created_at desc limit 1;
  if found then
    return query select existing_run.id, true, existing_run.result;
    return;
  end if;

  select count(*) into recent_count
  from public.menu_assistant_runs as run
  where run.room_id = candidate_room_id
    and run.created_at > now() - interval '24 hours'
    and run.status in ('processing', 'succeeded');
  if recent_count >= 10 then raise exception 'menu_assistant_rate_limited'; end if;

  insert into public.menu_assistant_runs (
    room_id, menu_id, requested_by, input_digest, model
  ) values (
    candidate_room_id, selected_menu_id, current_user_id,
    candidate_input_digest, candidate_model
  ) returning id into run_id;
  reused := false;
  reused_result := null;
  return next;
end;
$$;

revoke all on function public.start_menu_assistant_run(uuid, text, text)
from public, anon;
grant execute on function public.start_menu_assistant_run(uuid, text, text)
to authenticated;

create function public.finish_menu_assistant_run(
  candidate_run_id uuid,
  candidate_status text,
  candidate_result jsonb,
  candidate_error_code text,
  candidate_error_message text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_run public.menu_assistant_runs%rowtype;
begin
  select * into selected_run
  from public.menu_assistant_runs where id = candidate_run_id for update;
  if not found or auth.uid() is null or selected_run.requested_by <> auth.uid()
  then raise exception 'menu_assistant_access_denied'; end if;
  if selected_run.status <> 'processing' then return; end if;

  if candidate_status = 'succeeded' then
    if not private.is_valid_menu_assistant_result(candidate_result)
    then raise exception 'invalid_menu_assistant_result'; end if;
    update public.menu_assistant_runs set
      status = 'succeeded', result = candidate_result, completed_at = now()
    where id = candidate_run_id;
  elsif candidate_status = 'failed' then
    update public.menu_assistant_runs set
      status = 'failed',
      error_code = left(coalesce(nullif(btrim(candidate_error_code), ''), 'failed'), 80),
      error_message = left(coalesce(nullif(btrim(candidate_error_message), ''), 'AI request failed'), 300),
      completed_at = now()
    where id = candidate_run_id;
  else raise exception 'invalid_menu_assistant_status'; end if;
end;
$$;

revoke all on function public.finish_menu_assistant_run(uuid, text, jsonb, text, text)
from public, anon;
grant execute on function public.finish_menu_assistant_run(uuid, text, jsonb, text, text)
to authenticated;
