create table public.member_submissions (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null,
  user_id uuid not null,
  dietary_restrictions text not null default '',
  allergy_info text not null default '',
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint member_submissions_room_user_unique unique (room_id, user_id),
  constraint member_submissions_member_fkey foreign key (room_id, user_id)
    references public.room_members (room_id, user_id) on delete cascade,
  constraint member_submissions_dietary_restrictions_valid check (
    dietary_restrictions = btrim(dietary_restrictions)
    and char_length(dietary_restrictions) <= 500
  ),
  constraint member_submissions_allergy_info_valid check (
    allergy_info = btrim(allergy_info)
    and char_length(allergy_info) <= 500
  )
);

create index member_submissions_user_room_idx
on public.member_submissions (user_id, room_id);

create table public.member_selections (
  id uuid primary key default gen_random_uuid(),
  submission_id uuid not null references public.member_submissions (id)
    on delete cascade,
  menu_item_id uuid not null references public.menu_items (id)
    on delete cascade,
  quantity smallint not null,
  note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint member_selections_submission_item_unique unique (
    submission_id,
    menu_item_id
  ),
  constraint member_selections_quantity_valid check (quantity between 1 and 20),
  constraint member_selections_note_valid check (
    note = btrim(note)
    and char_length(note) <= 240
  )
);

create index member_selections_menu_item_submission_idx
on public.member_selections (menu_item_id, submission_id);

create function private.owns_member_submission(candidate_submission_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.member_submissions
    where id = candidate_submission_id
      and user_id = (select auth.uid())
  );
$$;

revoke all on function private.owns_member_submission(uuid)
from public, anon;
grant execute on function private.owns_member_submission(uuid)
to authenticated;

alter table public.member_submissions enable row level security;
alter table public.member_submissions force row level security;
alter table public.member_selections enable row level security;
alter table public.member_selections force row level security;

create policy "Members can read their own submission"
on public.member_submissions
for select
to authenticated
using (user_id = (select auth.uid()));

create policy "Members can read their own selections"
on public.member_selections
for select
to authenticated
using ((select private.owns_member_submission(submission_id)));

revoke all on table public.member_submissions from anon, authenticated;
revoke all on table public.member_selections from anon, authenticated;

grant select (
  id,
  room_id,
  user_id,
  dietary_restrictions,
  allergy_info,
  submitted_at,
  created_at,
  updated_at
)
on public.member_submissions to authenticated;

grant select (
  id,
  submission_id,
  menu_item_id,
  quantity,
  note,
  created_at,
  updated_at
)
on public.member_selections to authenticated;

create function public.save_my_selection(
  candidate_room_id uuid,
  candidate_dietary_restrictions text,
  candidate_allergy_info text,
  candidate_selections jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_menu_id uuid;
  current_submission_id uuid;
  normalized_dietary_restrictions text := btrim(
    coalesce(candidate_dietary_restrictions, '')
  );
  normalized_allergy_info text := btrim(coalesce(candidate_allergy_info, ''));
  selection_entry jsonb;
  selection_item_id uuid;
  selection_item_id_text text;
  selection_quantity smallint;
  selection_quantity_text text;
  selection_note text;
  seen_item_ids uuid[] := array[]::uuid[];
  uuid_pattern constant text :=
    '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';
begin
  if current_user_id is null then
    raise exception using
      errcode = '28000',
      message = 'authentication_required';
  end if;

  if not exists (
    select 1
    from public.room_members
    where room_id = candidate_room_id
      and user_id = current_user_id
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  if char_length(normalized_dietary_restrictions) > 500 then
    raise exception using
      errcode = '22023',
      message = 'dietary_restrictions_too_long';
  end if;

  if char_length(normalized_allergy_info) > 500 then
    raise exception using errcode = '22023', message = 'allergy_info_too_long';
  end if;

  if candidate_selections is null
    or jsonb_typeof(candidate_selections) <> 'array'
    or jsonb_array_length(candidate_selections) > 200
  then
    raise exception using errcode = '22023', message = 'invalid_selections';
  end if;

  select id
  into current_menu_id
  from public.menus
  where room_id = candidate_room_id
    and status = 'published'
  for update;

  if current_menu_id is null then
    raise exception using errcode = '55000', message = 'menu_not_published';
  end if;

  for selection_entry in
    select value from jsonb_array_elements(candidate_selections)
  loop
    if jsonb_typeof(selection_entry) <> 'object'
      or jsonb_typeof(selection_entry -> 'menuItemId') <> 'string'
      or jsonb_typeof(selection_entry -> 'quantity') <> 'number'
      or (
        selection_entry ? 'note'
        and jsonb_typeof(selection_entry -> 'note') <> 'string'
      )
    then
      raise exception using errcode = '22023', message = 'invalid_selection';
    end if;

    selection_item_id_text := selection_entry ->> 'menuItemId';
    selection_quantity_text := selection_entry ->> 'quantity';
    selection_note := btrim(coalesce(selection_entry ->> 'note', ''));

    if selection_item_id_text !~* uuid_pattern
      or selection_quantity_text !~ '^(0|[1-9]|1[0-9]|20)$'
      or char_length(selection_note) > 240
    then
      raise exception using errcode = '22023', message = 'invalid_selection';
    end if;

    selection_item_id := selection_item_id_text::uuid;
    selection_quantity := selection_quantity_text::smallint;

    if selection_item_id = any(seen_item_ids) then
      raise exception using
        errcode = '22023',
        message = 'duplicate_menu_item';
    end if;

    if not exists (
      select 1
      from public.menu_items
      where id = selection_item_id
        and menu_id = current_menu_id
    ) then
      raise exception using errcode = '22023', message = 'invalid_menu_item';
    end if;

    seen_item_ids := array_append(seen_item_ids, selection_item_id);
  end loop;

  insert into public.member_submissions (
    room_id,
    user_id,
    dietary_restrictions,
    allergy_info,
    submitted_at
  )
  values (
    candidate_room_id,
    current_user_id,
    normalized_dietary_restrictions,
    normalized_allergy_info,
    now()
  )
  on conflict (room_id, user_id) do update
  set
    dietary_restrictions = excluded.dietary_restrictions,
    allergy_info = excluded.allergy_info,
    submitted_at = excluded.submitted_at,
    updated_at = now()
  returning id into current_submission_id;

  delete from public.member_selections
  where submission_id = current_submission_id;

  insert into public.member_selections (
    submission_id,
    menu_item_id,
    quantity,
    note
  )
  select
    current_submission_id,
    (entry ->> 'menuItemId')::uuid,
    (entry ->> 'quantity')::smallint,
    btrim(coalesce(entry ->> 'note', ''))
  from jsonb_array_elements(candidate_selections) as entries(entry)
  where (entry ->> 'quantity')::smallint > 0;

  return current_submission_id;
end;
$$;

revoke all on function public.save_my_selection(uuid, text, text, jsonb)
from public, anon;
grant execute on function public.save_my_selection(uuid, text, text, jsonb)
to authenticated;
