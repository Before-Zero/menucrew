create table public.room_advice (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  requested_by uuid not null,
  source_revision bigint not null,
  input_digest text not null,
  status text not null default 'processing',
  model text not null,
  result jsonb,
  error_code text,
  error_message text,
  provider_response_id text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  constraint room_advice_requester_fkey foreign key (room_id, requested_by)
    references public.room_members (room_id, user_id),
  constraint room_advice_source_revision_valid check (source_revision >= 0),
  constraint room_advice_digest_valid check (
    input_digest ~ '^[0-9a-f]{64}$'
  ),
  constraint room_advice_status_valid check (
    status in ('processing', 'succeeded', 'failed')
  ),
  constraint room_advice_model_valid check (
    model = btrim(model) and char_length(model) between 1 and 100
  ),
  constraint room_advice_error_code_valid check (
    error_code is null
    or (error_code = btrim(error_code) and char_length(error_code) between 1 and 80)
  ),
  constraint room_advice_error_message_valid check (
    error_message is null
    or (
      error_message = btrim(error_message)
      and char_length(error_message) between 1 and 300
    )
  ),
  constraint room_advice_provider_id_valid check (
    provider_response_id is null
    or (
      provider_response_id = btrim(provider_response_id)
      and char_length(provider_response_id) between 1 and 200
    )
  ),
  constraint room_advice_state_valid check (
    (
      status = 'processing'
      and result is null
      and error_code is null
      and error_message is null
      and completed_at is null
    )
    or (
      status = 'succeeded'
      and result is not null
      and error_code is null
      and error_message is null
      and completed_at is not null
    )
    or (
      status = 'failed'
      and result is null
      and error_code is not null
      and error_message is not null
      and completed_at is not null
    )
  )
);

create index room_advice_room_created_idx
on public.room_advice (room_id, created_at desc);

create index room_advice_room_requester_idx
on public.room_advice (room_id, requested_by);

create unique index room_advice_success_digest_unique
on public.room_advice (room_id, input_digest)
where status = 'succeeded';

alter table public.room_advice enable row level security;
alter table public.room_advice force row level security;

create policy "Organizers can read room advice"
on public.room_advice
for select
to authenticated
using ((select private.is_room_organizer(room_id)));

revoke all on table public.room_advice from public, anon, authenticated;
grant select (
  id, room_id, requested_by, source_revision, input_digest, status, model,
  result, error_code, error_message, provider_response_id,
  created_at, completed_at
) on public.room_advice to authenticated;

create function private.is_valid_room_advice_result(candidate_result jsonb)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select
    jsonb_typeof(candidate_result) = 'object'
    and (select count(*) from jsonb_object_keys(candidate_result)) = 1
    and jsonb_typeof(candidate_result -> 'items') = 'array'
    and jsonb_array_length(candidate_result -> 'items') between 1 and 12
    and not exists (
      select 1
      from jsonb_array_elements(candidate_result -> 'items') as item
      where jsonb_typeof(item) <> 'object'
        or not (item ?& array['type', 'risk', 'title', 'detail', 'evidence'])
        or (select count(*) from jsonb_object_keys(item)) <> 5
        or jsonb_typeof(item -> 'type') <> 'string'
        or jsonb_typeof(item -> 'risk') <> 'string'
        or jsonb_typeof(item -> 'title') <> 'string'
        or jsonb_typeof(item -> 'detail') <> 'string'
        or jsonb_typeof(item -> 'evidence') <> 'string'
        or (item ->> 'type') not in (
          'balance', 'duplicate', 'quantity', 'allergy'
        )
        or (item ->> 'risk') not in ('info', 'warning', 'critical')
        or char_length(btrim(item ->> 'title')) not between 1 and 80
        or char_length(btrim(item ->> 'detail')) not between 1 and 300
        or char_length(btrim(item ->> 'evidence')) not between 1 and 240
    );
$$;

revoke all on function private.is_valid_room_advice_result(jsonb)
from public, anon, authenticated;

create function public.start_room_advice(
  candidate_room_id uuid,
  candidate_source_revision bigint,
  candidate_input_digest text,
  candidate_model text
)
returns table (
  advice_id uuid,
  disposition text,
  advice_status text,
  advice_result jsonb
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_room public.rooms%rowtype;
  existing_advice public.room_advice%rowtype;
  recent_count integer;
begin
  if auth.uid() is null
    or candidate_source_revision is null
    or candidate_source_revision < 0
    or candidate_input_digest !~ '^[0-9a-f]{64}$'
    or candidate_model is null
    or candidate_model <> btrim(candidate_model)
    or char_length(candidate_model) not between 1 and 100
  then
    raise exception 'invalid_room_advice_request';
  end if;

  select * into selected_room
  from public.rooms
  where id = candidate_room_id
  for update;

  if not found or not private.is_room_organizer(candidate_room_id) then
    raise exception 'room_advice_access_denied';
  end if;
  if selected_room.selection_revision <> candidate_source_revision then
    raise exception 'room_advice_revision_changed';
  end if;
  if exists (
    select 1 from public.orders where room_id = candidate_room_id
  ) then
    raise exception 'room_advice_order_confirmed';
  end if;
  if not exists (
    select 1
    from public.menus
    where room_id = candidate_room_id and status = 'published'
  ) or not exists (
    select 1
    from public.member_submissions as submission
    join public.member_selections as selection
      on selection.submission_id = submission.id
    where submission.room_id = candidate_room_id
      and selection.quantity > 0
  ) then
    raise exception 'room_advice_data_required';
  end if;

  select * into existing_advice
  from public.room_advice
  where room_id = candidate_room_id
    and input_digest = candidate_input_digest
    and status in ('processing', 'succeeded')
  order by (status = 'succeeded') desc, created_at desc
  limit 1;

  if found then
    return query select
      existing_advice.id,
      'reused'::text,
      existing_advice.status,
      existing_advice.result;
    return;
  end if;

  select count(*) into recent_count
  from public.room_advice
  where room_id = candidate_room_id
    and created_at > now() - interval '24 hours';
  if recent_count >= 5 then
    raise exception 'room_advice_rate_limited';
  end if;

  insert into public.room_advice (
    room_id, requested_by, source_revision, input_digest, model
  )
  values (
    candidate_room_id, auth.uid(), candidate_source_revision,
    candidate_input_digest, candidate_model
  )
  returning id, status, result
  into advice_id, advice_status, advice_result;
  disposition := 'created';
  return next;
end;
$$;

revoke all on function public.start_room_advice(uuid, bigint, text, text)
from public, anon;
grant execute on function public.start_room_advice(uuid, bigint, text, text)
to authenticated;

create function public.finish_room_advice(
  candidate_advice_id uuid,
  candidate_status text,
  candidate_result jsonb,
  candidate_error_code text,
  candidate_error_message text,
  candidate_provider_response_id text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_advice public.room_advice%rowtype;
begin
  select * into selected_advice
  from public.room_advice
  where id = candidate_advice_id
  for update;

  if not found
    or auth.uid() is null
    or selected_advice.requested_by <> auth.uid()
    or not private.is_room_organizer(selected_advice.room_id)
  then
    raise exception 'room_advice_access_denied';
  end if;
  if selected_advice.status <> 'processing' then
    return;
  end if;

  if candidate_status = 'succeeded' then
    if not private.is_valid_room_advice_result(candidate_result) then
      raise exception 'invalid_room_advice_result';
    end if;
    update public.room_advice
    set
      status = 'succeeded',
      result = candidate_result,
      provider_response_id = nullif(btrim(candidate_provider_response_id), ''),
      completed_at = now()
    where id = candidate_advice_id;
  elsif candidate_status = 'failed' then
    if candidate_result is not null
      or candidate_error_code is null
      or char_length(btrim(candidate_error_code)) not between 1 and 80
      or candidate_error_message is null
      or char_length(btrim(candidate_error_message)) not between 1 and 300
    then
      raise exception 'invalid_room_advice_failure';
    end if;
    update public.room_advice
    set
      status = 'failed',
      error_code = btrim(candidate_error_code),
      error_message = btrim(candidate_error_message),
      completed_at = now()
    where id = candidate_advice_id;
  else
    raise exception 'invalid_room_advice_status';
  end if;
end;
$$;

revoke all on function public.finish_room_advice(
  uuid, text, jsonb, text, text, text
) from public, anon;
grant execute on function public.finish_room_advice(
  uuid, text, jsonb, text, text, text
) to authenticated;
