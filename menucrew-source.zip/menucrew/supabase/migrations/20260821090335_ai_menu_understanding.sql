create table public.menu_ai_runs (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms (id) on delete cascade,
  menu_id uuid not null references public.menus (id) on delete cascade,
  requested_by uuid not null,
  input_digest text not null,
  status text not null default 'processing',
  model text not null,
  result jsonb,
  error_code text,
  error_message text,
  provider_response_id text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  applied_at timestamptz,
  constraint menu_ai_runs_requester_fkey foreign key (room_id, requested_by)
    references public.room_members (room_id, user_id),
  constraint menu_ai_runs_digest_valid check (
    input_digest ~ '^[0-9a-f]{64}$'
  ),
  constraint menu_ai_runs_status_valid check (
    status in ('processing', 'succeeded', 'failed')
  ),
  constraint menu_ai_runs_model_valid check (
    model = btrim(model) and char_length(model) between 1 and 100
  ),
  constraint menu_ai_runs_error_code_valid check (
    error_code is null
    or (error_code = btrim(error_code) and char_length(error_code) between 1 and 80)
  ),
  constraint menu_ai_runs_error_message_valid check (
    error_message is null
    or (
      error_message = btrim(error_message)
      and char_length(error_message) between 1 and 300
    )
  ),
  constraint menu_ai_runs_provider_id_valid check (
    provider_response_id is null
    or (
      provider_response_id = btrim(provider_response_id)
      and char_length(provider_response_id) between 1 and 200
    )
  ),
  constraint menu_ai_runs_state_valid check (
    (
      status = 'processing'
      and result is null
      and error_code is null
      and error_message is null
      and completed_at is null
      and applied_at is null
    )
    or (
      status = 'succeeded'
      and result is not null
      and error_code is null
      and error_message is null
      and completed_at is not null
    )
    or (
      status = 'failed'
      and result is null
      and error_code is not null
      and error_message is not null
      and completed_at is not null
      and applied_at is null
    )
  )
);

create index menu_ai_runs_room_created_idx
on public.menu_ai_runs (room_id, created_at desc);

create index menu_ai_runs_menu_digest_idx
on public.menu_ai_runs (menu_id, input_digest, created_at desc);

create index menu_ai_runs_room_requester_idx
on public.menu_ai_runs (room_id, requested_by);

create unique index menu_ai_runs_success_digest_unique
on public.menu_ai_runs (menu_id, input_digest)
where status = 'succeeded';

alter table public.menu_ai_runs enable row level security;
alter table public.menu_ai_runs force row level security;

create policy "Organizers can read their menu AI runs"
on public.menu_ai_runs
for select
to authenticated
using ((select private.is_room_organizer(room_id)));

revoke all on table public.menu_ai_runs from public, anon, authenticated;
grant select (
  id, room_id, menu_id, requested_by, input_digest, status, model,
  result, error_code, error_message, provider_response_id,
  created_at, completed_at, applied_at
) on public.menu_ai_runs to authenticated;

create function private.is_valid_menu_ai_result(candidate_result jsonb)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select
    jsonb_typeof(candidate_result) = 'object'
    and jsonb_typeof(candidate_result -> 'items') = 'array'
    and jsonb_array_length(candidate_result -> 'items') between 1 and 80
    and not exists (
      select 1
      from jsonb_array_elements(candidate_result -> 'items') as item
      where jsonb_typeof(item) <> 'object'
        or not (
          item ?& array[
            'originalName', 'zhName', 'description', 'category', 'uncertainty'
          ]
        )
        or (select count(*) from jsonb_object_keys(item)) <> 5
        or jsonb_typeof(item -> 'originalName') <> 'string'
        or jsonb_typeof(item -> 'zhName') <> 'string'
        or jsonb_typeof(item -> 'description') <> 'string'
        or jsonb_typeof(item -> 'category') <> 'string'
        or jsonb_typeof(item -> 'uncertainty') <> 'string'
        or char_length(btrim(item ->> 'originalName')) not between 1 and 120
        or char_length(btrim(item ->> 'zhName')) not between 1 and 120
        or char_length(btrim(item ->> 'description')) not between 1 and 240
        or char_length(btrim(item ->> 'category')) not between 1 and 60
        or char_length(btrim(item ->> 'uncertainty')) > 240
    );
$$;

revoke all on function private.is_valid_menu_ai_result(jsonb)
from public, anon, authenticated;

create function public.start_menu_ai_run(
  candidate_room_id uuid,
  candidate_input_digest text,
  candidate_model text
)
returns table (run_id uuid, reused boolean)
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_menu public.menus%rowtype;
  existing_run public.menu_ai_runs%rowtype;
  recent_count integer;
  image_count integer;
begin
  if auth.uid() is null
    or candidate_input_digest !~ '^[0-9a-f]{64}$'
    or candidate_model is null
    or candidate_model <> btrim(candidate_model)
    or char_length(candidate_model) not between 1 and 100
  then
    raise exception 'invalid_menu_ai_request';
  end if;

  select * into selected_menu
  from public.menus
  where room_id = candidate_room_id
  for update;

  if not found or not private.is_room_organizer(candidate_room_id) then
    raise exception 'menu_ai_access_denied';
  end if;
  if selected_menu.status <> 'draft' then
    raise exception 'menu_not_draft';
  end if;

  select count(*) into image_count
  from public.menu_images
  where menu_id = selected_menu.id;
  if image_count not between 1 and 4 then
    raise exception 'menu_ai_images_required';
  end if;

  select * into existing_run
  from public.menu_ai_runs
  where menu_id = selected_menu.id
    and input_digest = candidate_input_digest
    and status in ('processing', 'succeeded')
  order by (status = 'succeeded') desc, created_at desc
  limit 1;

  if found then
    return query select existing_run.id, true;
    return;
  end if;

  select count(*) into recent_count
  from public.menu_ai_runs
  where room_id = candidate_room_id
    and created_at > now() - interval '24 hours';
  if recent_count >= 5 then
    raise exception 'menu_ai_rate_limited';
  end if;

  insert into public.menu_ai_runs (
    room_id, menu_id, requested_by, input_digest, model
  )
  values (
    candidate_room_id, selected_menu.id, auth.uid(),
    candidate_input_digest, candidate_model
  )
  returning id into run_id;
  reused := false;
  return next;
end;
$$;

revoke all on function public.start_menu_ai_run(uuid, text, text)
from public, anon;
grant execute on function public.start_menu_ai_run(uuid, text, text)
to authenticated;

create function public.finish_menu_ai_run(
  candidate_run_id uuid,
  candidate_status text,
  candidate_result jsonb,
  candidate_error_code text,
  candidate_error_message text,
  candidate_provider_response_id text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_run public.menu_ai_runs%rowtype;
begin
  select * into selected_run
  from public.menu_ai_runs
  where id = candidate_run_id
  for update;

  if not found
    or auth.uid() is null
    or selected_run.requested_by <> auth.uid()
    or not private.is_room_organizer(selected_run.room_id)
  then
    raise exception 'menu_ai_access_denied';
  end if;
  if selected_run.status <> 'processing' then
    return;
  end if;

  if candidate_status = 'succeeded' then
    if not private.is_valid_menu_ai_result(candidate_result) then
      raise exception 'invalid_menu_ai_result';
    end if;
    update public.menu_ai_runs
    set
      status = 'succeeded',
      result = candidate_result,
      provider_response_id = nullif(btrim(candidate_provider_response_id), ''),
      completed_at = now()
    where id = candidate_run_id;
  elsif candidate_status = 'failed' then
    if candidate_result is not null
      or candidate_error_code is null
      or char_length(btrim(candidate_error_code)) not between 1 and 80
      or candidate_error_message is null
      or char_length(btrim(candidate_error_message)) not between 1 and 300
    then
      raise exception 'invalid_menu_ai_failure';
    end if;
    update public.menu_ai_runs
    set
      status = 'failed',
      error_code = btrim(candidate_error_code),
      error_message = btrim(candidate_error_message),
      completed_at = now()
    where id = candidate_run_id;
  else
    raise exception 'invalid_menu_ai_status';
  end if;
end;
$$;

revoke all on function public.finish_menu_ai_run(
  uuid, text, jsonb, text, text, text
) from public, anon;
grant execute on function public.finish_menu_ai_run(
  uuid, text, jsonb, text, text, text
) to authenticated;

create function public.apply_menu_ai_run(candidate_run_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  selected_run public.menu_ai_runs%rowtype;
  selected_menu public.menus%rowtype;
  inserted_count integer;
begin
  select * into selected_run
  from public.menu_ai_runs
  where id = candidate_run_id
  for update;

  if not found
    or auth.uid() is null
    or not private.is_room_organizer(selected_run.room_id)
  then
    raise exception 'menu_ai_access_denied';
  end if;
  if selected_run.status <> 'succeeded'
    or not private.is_valid_menu_ai_result(selected_run.result)
  then
    raise exception 'menu_ai_result_not_ready';
  end if;
  if selected_run.applied_at is not null then
    select count(*) into inserted_count
    from public.menu_items
    where menu_id = selected_run.menu_id;
    return inserted_count;
  end if;

  select * into selected_menu
  from public.menus
  where id = selected_run.menu_id
  for update;
  if selected_menu.status <> 'draft' then
    raise exception 'menu_not_draft';
  end if;

  delete from public.menu_items where menu_id = selected_menu.id;

  insert into public.menu_items (
    menu_id, original_name, zh_name, description, position
  )
  select
    selected_menu.id,
    btrim(item ->> 'originalName'),
    btrim(item ->> 'zhName'),
    left(
      concat(
        '[', btrim(item ->> 'category'), '] ',
        btrim(item ->> 'description'),
        case
          when btrim(item ->> 'uncertainty') = '' then ''
          else concat(' · 待确认：', btrim(item ->> 'uncertainty'))
        end
      ),
      240
    ),
    (ordinality - 1)::integer * 100
  from jsonb_array_elements(selected_run.result -> 'items')
    with ordinality as generated(item, ordinality);

  get diagnostics inserted_count = row_count;
  update public.menu_ai_runs
  set applied_at = coalesce(applied_at, now())
  where id = candidate_run_id;

  return inserted_count;
end;
$$;

revoke all on function public.apply_menu_ai_run(uuid) from public, anon;
grant execute on function public.apply_menu_ai_run(uuid) to authenticated;
