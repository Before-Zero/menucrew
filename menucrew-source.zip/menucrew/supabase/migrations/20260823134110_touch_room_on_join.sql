create trigger members_touch_room_activity after insert or update on public.room_members
for each row execute function private.touch_room_activity();
