create table public.orders (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null unique references public.rooms (id) on delete cascade,
  source_revision bigint not null check (source_revision >= 0),
  confirmed_by uuid not null,
  confirmed_at timestamptz not null default now(),
  constraint orders_confirmer_fkey foreign key (room_id, confirmed_by)
    references public.room_members (room_id, user_id)
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  menu_item_id uuid not null,
  original_name text not null,
  zh_name text not null,
  requested_quantity integer not null check (requested_quantity >= 0),
  final_quantity integer not null check (final_quantity between 1 and 99),
  member_names text[] not null default array[]::text[],
  note text not null default '',
  position integer not null,
  constraint order_items_order_menu_unique unique (order_id, menu_item_id),
  constraint order_items_original_name_valid check (
    original_name = btrim(original_name) and char_length(original_name) between 1 and 300
  ),
  constraint order_items_zh_name_valid check (
    zh_name = btrim(zh_name) and char_length(zh_name) between 1 and 300
  ),
  constraint order_items_note_valid check (
    note = btrim(note) and char_length(note) <= 500
  )
);

create index orders_room_confirmer_idx
on public.orders (room_id, confirmed_by);

create index order_items_order_position_idx
on public.order_items (order_id, position, id);

create function private.can_read_order_item(candidate_order_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.orders as final_order
    join public.room_members as membership
      on membership.room_id = final_order.room_id
    where final_order.id = candidate_order_id
      and membership.user_id = (select auth.uid())
  );
$$;

revoke all on function private.can_read_order_item(uuid) from public, anon;
grant execute on function private.can_read_order_item(uuid) to authenticated;

alter table public.orders enable row level security;
alter table public.orders force row level security;
alter table public.order_items enable row level security;
alter table public.order_items force row level security;

create policy "Room members can read confirmed orders"
on public.orders for select to authenticated
using (
  exists (
    select 1 from public.room_members as membership
    where membership.room_id = orders.room_id
      and membership.user_id = (select auth.uid())
  )
);

create policy "Room members can read confirmed order items"
on public.order_items for select to authenticated
using ((select private.can_read_order_item(order_id)));

revoke all on table public.orders from anon, authenticated;
revoke all on table public.order_items from anon, authenticated;
grant select (id, room_id, source_revision, confirmed_by, confirmed_at)
on public.orders to authenticated;
grant select (
  id, order_id, menu_item_id, original_name, zh_name,
  requested_quantity, final_quantity, member_names, note, position
) on public.order_items to authenticated;

create function public.confirm_final_order(
  candidate_room_id uuid,
  candidate_source_revision bigint,
  candidate_items jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_status text;
  current_revision bigint;
  current_menu_id uuid;
  current_order_id uuid;
  item_entry jsonb;
  item_id_text text;
  item_id uuid;
  item_quantity_text text;
  item_quantity integer;
  item_note text;
  seen_item_ids uuid[] := array[]::uuid[];
  positive_count integer := 0;
  uuid_pattern constant text :=
    '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;

  select room.selection_status, room.selection_revision
  into current_status, current_revision
  from public.rooms as room
  where room.id = candidate_room_id
  for update;

  if current_status is null or not exists (
    select 1 from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
      and membership.role = 'organizer'
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;

  select final_order.id into current_order_id
  from public.orders as final_order
  where final_order.room_id = candidate_room_id;
  if current_order_id is not null then
    return current_order_id;
  end if;

  if current_status <> 'reviewing' then
    raise exception using errcode = '55000', message = 'collection_not_reviewing';
  end if;
  if current_revision <> candidate_source_revision then
    raise exception using errcode = '40001', message = 'stale_revision';
  end if;
  if candidate_items is null
    or jsonb_typeof(candidate_items) <> 'array'
    or jsonb_array_length(candidate_items) > 200
  then
    raise exception using errcode = '22023', message = 'invalid_items';
  end if;

  select menu.id into current_menu_id
  from public.menus as menu where menu.room_id = candidate_room_id;
  if current_menu_id is null then
    raise exception using errcode = '55000', message = 'menu_missing';
  end if;

  for item_entry in select value from jsonb_array_elements(candidate_items)
  loop
    if jsonb_typeof(item_entry) <> 'object'
      or jsonb_typeof(item_entry -> 'menuItemId') <> 'string'
      or jsonb_typeof(item_entry -> 'finalQuantity') <> 'number'
      or (item_entry ? 'note' and jsonb_typeof(item_entry -> 'note') <> 'string')
    then
      raise exception using errcode = '22023', message = 'invalid_item';
    end if;
    item_id_text := item_entry ->> 'menuItemId';
    item_quantity_text := item_entry ->> 'finalQuantity';
    item_note := btrim(coalesce(item_entry ->> 'note', ''));
    if item_id_text !~* uuid_pattern
      or item_quantity_text !~ '^(0|[1-9][0-9]?)$'
      or char_length(item_note) > 500
    then
      raise exception using errcode = '22023', message = 'invalid_item';
    end if;
    item_id := item_id_text::uuid;
    item_quantity := item_quantity_text::integer;
    if item_id = any(seen_item_ids) then
      raise exception using errcode = '22023', message = 'duplicate_menu_item';
    end if;
    if not exists (
      select 1 from public.menu_items as menu_item
      where menu_item.id = item_id and menu_item.menu_id = current_menu_id
    ) then
      raise exception using errcode = '22023', message = 'invalid_menu_item';
    end if;
    seen_item_ids := array_append(seen_item_ids, item_id);
    if item_quantity > 0 then positive_count := positive_count + 1; end if;
  end loop;

  if positive_count = 0 then
    raise exception using errcode = '22023', message = 'empty_order';
  end if;

  insert into public.orders (room_id, source_revision, confirmed_by)
  values (candidate_room_id, current_revision, current_user_id)
  returning id into current_order_id;

  insert into public.order_items (
    order_id, menu_item_id, original_name, zh_name, requested_quantity,
    final_quantity, member_names, note, position
  )
  select
    current_order_id,
    menu_item.id,
    menu_item.original_name,
    menu_item.zh_name,
    coalesce((
      select sum(selection.quantity)::integer
      from public.member_selections as selection
      join public.member_submissions as submission
        on submission.id = selection.submission_id
      where selection.menu_item_id = menu_item.id
        and submission.room_id = candidate_room_id
    ), 0),
    (entry ->> 'finalQuantity')::integer,
    array(
      select membership.display_name
      from public.member_selections as selection
      join public.member_submissions as submission
        on submission.id = selection.submission_id
      join public.room_members as membership
        on membership.room_id = submission.room_id
       and membership.user_id = submission.user_id
      where selection.menu_item_id = menu_item.id
        and submission.room_id = candidate_room_id
      order by membership.joined_at, membership.user_id
    ),
    btrim(coalesce(entry ->> 'note', '')),
    menu_item.position
  from jsonb_array_elements(candidate_items) as entries(entry)
  join public.menu_items as menu_item
    on menu_item.id = (entry ->> 'menuItemId')::uuid
   and menu_item.menu_id = current_menu_id
  where (entry ->> 'finalQuantity')::integer > 0;

  return current_order_id;
end;
$$;

revoke all on function public.confirm_final_order(uuid, bigint, jsonb)
from public, anon;
grant execute on function public.confirm_final_order(uuid, bigint, jsonb)
to authenticated;

create or replace function public.set_selection_collection_status(
  candidate_room_id uuid,
  candidate_status text
)
returns table (new_status text, new_revision bigint)
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  current_status text;
  current_revision bigint;
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;
  if candidate_status not in ('open', 'reviewing') then
    raise exception using errcode = '22023', message = 'invalid_status';
  end if;
  select room.selection_status, room.selection_revision
  into current_status, current_revision
  from public.rooms as room where room.id = candidate_room_id for update;
  if current_status is null or not exists (
    select 1 from public.room_members as membership
    where membership.room_id = candidate_room_id
      and membership.user_id = current_user_id
      and membership.role = 'organizer'
  ) then
    raise exception using errcode = '42501', message = 'room_access_denied';
  end if;
  if candidate_status = 'open' and exists (
    select 1 from public.orders as final_order
    where final_order.room_id = candidate_room_id
  ) then
    raise exception using errcode = '55000', message = 'order_already_confirmed';
  end if;
  if current_status = candidate_status then
    return query select current_status, current_revision;
    return;
  end if;
  update public.rooms as room set
    selection_status = candidate_status,
    selection_status_changed_at = now(),
    selection_revision = room.selection_revision + 1
  where room.id = candidate_room_id
  returning room.selection_status, room.selection_revision
  into current_status, current_revision;
  return query select current_status, current_revision;
end;
$$;
