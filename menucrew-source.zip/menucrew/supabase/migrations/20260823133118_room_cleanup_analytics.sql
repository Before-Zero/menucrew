alter table public.rooms
add column last_activity_at timestamptz not null default now();

update public.rooms set last_activity_at = created_at;
create index rooms_last_activity_idx on public.rooms (last_activity_at, id);

create table public.product_events (
  id bigint generated always as identity primary key,
  room_id uuid references public.rooms (id) on delete cascade,
  event_name text not null check (event_name in (
    'room_created', 'room_joined', 'menu_published',
    'selection_saved', 'order_confirmed', 'ai_requested', 'ai_succeeded', 'ai_failed'
  )),
  created_at timestamptz not null default now()
);
create index product_events_name_created_idx
on public.product_events (event_name, created_at desc);
alter table public.product_events enable row level security;
alter table public.product_events force row level security;
revoke all on table public.product_events from public, anon, authenticated;

create function private.touch_room_activity()
returns trigger language plpgsql security definer set search_path = '' as $$
declare target_room_id uuid;
begin
  target_room_id := case when tg_op = 'DELETE' then old.room_id else new.room_id end;
  update public.rooms set last_activity_at = now() where id = target_room_id;
  return case when tg_op = 'DELETE' then old else new end;
end;
$$;
revoke all on function private.touch_room_activity() from public, anon, authenticated;

create trigger menus_touch_room_activity after insert or update on public.menus
for each row execute function private.touch_room_activity();
create trigger submissions_touch_room_activity after insert or update on public.member_submissions
for each row execute function private.touch_room_activity();
create trigger orders_touch_room_activity after insert on public.orders
for each row execute function private.touch_room_activity();

grant select (last_activity_at) on public.rooms to authenticated;
