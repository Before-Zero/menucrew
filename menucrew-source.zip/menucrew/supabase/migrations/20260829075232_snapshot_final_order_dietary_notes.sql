alter table public.orders
add column dietary_notes jsonb not null default '[]'::jsonb;

alter table public.orders
add constraint orders_dietary_notes_valid check (
  jsonb_typeof(dietary_notes) = 'array'
  and jsonb_array_length(dietary_notes) <= 100
);

grant select (dietary_notes) on public.orders to authenticated;

create function private.capture_order_dietary_notes()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'displayName', membership.display_name,
        'dietaryRestrictions', submission.dietary_restrictions,
        'allergyInfo', submission.allergy_info
      ) order by membership.joined_at, membership.user_id
    ) filter (
      where submission.submitted_at is not null
        and (
          nullif(btrim(submission.dietary_restrictions), '') is not null
          or nullif(btrim(submission.allergy_info), '') is not null
        )
    ),
    '[]'::jsonb
  )
  into new.dietary_notes
  from public.member_submissions as submission
  join public.room_members as membership
    on membership.room_id = submission.room_id
   and membership.user_id = submission.user_id
  where submission.room_id = new.room_id;

  return new;
end;
$$;

revoke all on function private.capture_order_dietary_notes()
from public, anon, authenticated;

create trigger orders_capture_dietary_notes
before insert on public.orders
for each row execute function private.capture_order_dietary_notes();

update public.orders as final_order
set dietary_notes = (
  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'displayName', membership.display_name,
        'dietaryRestrictions', submission.dietary_restrictions,
        'allergyInfo', submission.allergy_info
      ) order by membership.joined_at, membership.user_id
    ) filter (
      where submission.submitted_at is not null
        and (
          nullif(btrim(submission.dietary_restrictions), '') is not null
          or nullif(btrim(submission.allergy_info), '') is not null
        )
    ),
    '[]'::jsonb
  ) as notes
  from public.member_submissions as submission
  join public.room_members as membership
    on membership.room_id = submission.room_id
   and membership.user_id = submission.user_id
  where submission.room_id = final_order.room_id
);
