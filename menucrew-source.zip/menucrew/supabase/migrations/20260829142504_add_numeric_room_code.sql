create sequence private.room_join_code_seq
  as bigint
  minvalue 100000
  maxvalue 999999
  start with 100000
  increment by 1
  no cycle;

revoke all on sequence private.room_join_code_seq from public, anon, authenticated;

create function private.next_room_join_code()
returns text
language sql
volatile
security definer
set search_path = ''
as $$
  select lpad(nextval('private.room_join_code_seq')::text, 6, '0');
$$;

revoke all on function private.next_room_join_code() from public, anon, authenticated;

alter table public.rooms add column join_code text;

with numbered as (
  select id, row_number() over (order by created_at, id) - 1 as offset_value
  from public.rooms
)
update public.rooms as room
set join_code = lpad((100000 + numbered.offset_value)::text, 6, '0')
from numbered
where numbered.id = room.id;

select setval(
  'private.room_join_code_seq',
  greatest(100000, 100000 + (select count(*) from public.rooms)),
  false
);

alter table public.rooms
  alter column join_code set default private.next_room_join_code(),
  alter column join_code set not null,
  add constraint rooms_join_code_valid check (join_code ~ '^[0-9]{6}$'),
  add constraint rooms_join_code_unique unique (join_code);

grant select (join_code) on public.rooms to authenticated;

create or replace function public.create_room(
  room_name text,
  display_name text,
  invite_digest text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  normalized_room_name text := btrim(room_name);
  normalized_display_name text := btrim(display_name);
  created_room_id uuid;
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;

  if normalized_room_name is null
    or char_length(normalized_room_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_room_name';
  end if;

  if normalized_display_name is null
    or char_length(normalized_display_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_display_name';
  end if;

  if invite_digest is null or invite_digest !~ '^[0-9a-f]{64}$' then
    raise exception using errcode = '22023', message = 'invalid_invite_digest';
  end if;

  insert into public.rooms (name, invite_token_digest, created_by)
  values (normalized_room_name, invite_digest, current_user_id)
  returning id into created_room_id;

  insert into public.room_members (room_id, user_id, display_name, role)
  values (created_room_id, current_user_id, normalized_display_name, 'organizer');

  return created_room_id;
end;
$$;

create or replace function public.join_room(
  display_name text,
  invite_digest text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  normalized_display_name text := btrim(display_name);
  matched_room_id uuid;
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;

  if normalized_display_name is null
    or char_length(normalized_display_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_display_name';
  end if;

  if invite_digest is null or invite_digest !~ '^[0-9a-f]{64}$' then
    raise exception using errcode = 'P0001', message = 'invite_unavailable';
  end if;

  select id into matched_room_id
  from public.rooms
  where invite_token_digest = invite_digest and invite_active is true;

  if matched_room_id is null then
    raise exception using errcode = 'P0001', message = 'invite_unavailable';
  end if;

  insert into public.room_members (room_id, user_id, display_name, role)
  values (matched_room_id, current_user_id, normalized_display_name, 'member')
  on conflict (room_id, user_id) do nothing;

  return matched_room_id;
end;
$$;

create function public.join_room_by_code(
  display_name text,
  room_code text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  normalized_display_name text := btrim(display_name);
  normalized_code text := regexp_replace(coalesce(room_code, ''), '[^0-9]', '', 'g');
  matched_room_id uuid;
begin
  if current_user_id is null then
    raise exception using errcode = '28000', message = 'authentication_required';
  end if;

  if normalized_display_name is null
    or char_length(normalized_display_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_display_name';
  end if;

  if normalized_code !~ '^[0-9]{6}$' then
    raise exception using errcode = 'P0001', message = 'room_code_unavailable';
  end if;

  select id into matched_room_id
  from public.rooms
  where join_code = normalized_code and invite_active is true;

  if matched_room_id is null then
    raise exception using errcode = 'P0001', message = 'room_code_unavailable';
  end if;

  insert into public.room_members (room_id, user_id, display_name, role)
  values (matched_room_id, current_user_id, normalized_display_name, 'member')
  on conflict (room_id, user_id) do nothing;

  return matched_room_id;
end;
$$;

revoke all on function public.join_room_by_code(text, text) from public, anon;
grant execute on function public.join_room_by_code(text, text) to authenticated;
