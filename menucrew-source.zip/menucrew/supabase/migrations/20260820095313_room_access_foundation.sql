create schema if not exists private;

revoke all on schema private from public;
grant usage on schema private to authenticated;

create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  invite_token_digest text not null,
  invite_active boolean not null default true,
  created_by uuid not null references auth.users (id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint rooms_name_valid check (
    name = btrim(name)
    and char_length(name) between 1 and 60
  ),
  constraint rooms_invite_token_digest_valid check (
    invite_token_digest ~ '^[0-9a-f]{64}$'
  ),
  constraint rooms_invite_token_digest_unique unique (invite_token_digest)
);

create index rooms_created_by_idx on public.rooms (created_by);

create table public.room_members (
  room_id uuid not null references public.rooms (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  display_name text not null,
  role text not null,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id),
  constraint room_members_display_name_valid check (
    display_name = btrim(display_name)
    and char_length(display_name) between 1 and 60
  ),
  constraint room_members_role_valid check (role in ('organizer', 'member'))
);

create index room_members_user_id_idx on public.room_members (user_id);

create unique index room_members_single_organizer_idx
on public.room_members (room_id)
where role = 'organizer';

create function private.is_room_member(candidate_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.room_members
    where room_id = candidate_room_id
      and user_id = (select auth.uid())
  );
$$;

revoke all on function private.is_room_member(uuid) from public, anon;
grant execute on function private.is_room_member(uuid) to authenticated;

alter table public.rooms enable row level security;
alter table public.rooms force row level security;
alter table public.room_members enable row level security;
alter table public.room_members force row level security;

create policy "Room members can read their rooms"
on public.rooms
for select
to authenticated
using ((select private.is_room_member(id)));

create policy "Room members can read their member list"
on public.room_members
for select
to authenticated
using ((select private.is_room_member(room_id)));

revoke all on table public.rooms from anon, authenticated;
revoke all on table public.room_members from anon, authenticated;

grant select (id, name, invite_active, created_by, created_at)
on public.rooms to authenticated;

grant select (room_id, user_id, display_name, role, joined_at)
on public.room_members to authenticated;

create function public.create_room(
  room_name text,
  display_name text,
  invite_digest text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  normalized_room_name text := btrim(room_name);
  normalized_display_name text := btrim(display_name);
  created_room_id uuid;
begin
  if current_user_id is null
    or coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true'
  then
    raise exception using
      errcode = '28000',
      message = 'anonymous_authentication_required';
  end if;

  if normalized_room_name is null
    or char_length(normalized_room_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_room_name';
  end if;

  if normalized_display_name is null
    or char_length(normalized_display_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_display_name';
  end if;

  if invite_digest is null or invite_digest !~ '^[0-9a-f]{64}$' then
    raise exception using errcode = '22023', message = 'invalid_invite_digest';
  end if;

  insert into public.rooms (name, invite_token_digest, created_by)
  values (normalized_room_name, invite_digest, current_user_id)
  returning id into created_room_id;

  insert into public.room_members (room_id, user_id, display_name, role)
  values (
    created_room_id,
    current_user_id,
    normalized_display_name,
    'organizer'
  );

  return created_room_id;
end;
$$;

create function public.join_room(
  display_name text,
  invite_digest text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_user_id uuid := auth.uid();
  normalized_display_name text := btrim(display_name);
  matched_room_id uuid;
begin
  if current_user_id is null
    or coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true'
  then
    raise exception using
      errcode = '28000',
      message = 'anonymous_authentication_required';
  end if;

  if normalized_display_name is null
    or char_length(normalized_display_name) not between 1 and 60
  then
    raise exception using errcode = '22023', message = 'invalid_display_name';
  end if;

  if invite_digest is null or invite_digest !~ '^[0-9a-f]{64}$' then
    raise exception using errcode = 'P0001', message = 'invite_unavailable';
  end if;

  select id
  into matched_room_id
  from public.rooms
  where invite_token_digest = invite_digest
    and invite_active is true;

  if matched_room_id is null then
    raise exception using errcode = 'P0001', message = 'invite_unavailable';
  end if;

  insert into public.room_members (room_id, user_id, display_name, role)
  values (matched_room_id, current_user_id, normalized_display_name, 'member')
  on conflict (room_id, user_id) do nothing;

  return matched_room_id;
end;
$$;

revoke all on function public.create_room(text, text, text) from public, anon;
revoke all on function public.join_room(text, text) from public, anon;

grant execute on function public.create_room(text, text, text) to authenticated;
grant execute on function public.join_room(text, text) to authenticated;
