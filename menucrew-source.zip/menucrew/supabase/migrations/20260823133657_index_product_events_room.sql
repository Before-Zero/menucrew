create index product_events_room_idx on public.product_events (room_id);
