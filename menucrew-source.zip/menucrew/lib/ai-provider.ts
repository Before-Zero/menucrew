import "server-only";

import { APICallError, generateText } from "ai";

export const DEFAULT_TEXT_AI_MODEL = "deepseek-v4-flash";
export const DEFAULT_VISION_AI_MODEL = "deepseek-v4-flash-vision-exp";

const DEFAULT_GATEWAY_TEXT_MODEL = "openai/gpt-5.4-nano";
const DEFAULT_GATEWAY_VISION_MODEL = "alibaba/qwen3-vl-instruct";

const DEFAULT_TEXT_FALLBACKS = [
  "meta/llama-4-scout",
  "google/gemini-3.1-flash-lite-preview",
];
const DEFAULT_VISION_FALLBACKS = ["openai/gpt-5.4-mini", "meta/llama-4-scout"];

export class AiProviderError extends Error {
  constructor(
    public readonly code:
      | "invalid_auth"
      | "limited"
      | "timeout"
      | "unavailable",
    public readonly status?: number,
  ) {
    super(code);
    this.name = "AiProviderError";
  }
}

function parseFallbacks(value: string | undefined, defaults: string[]) {
  const configured = value
    ?.split(",")
    .map((model) => model.trim())
    .filter(Boolean);
  return configured?.length ? configured : defaults;
}

function classifyProviderError(error: unknown) {
  if (error instanceof AiProviderError) return error;
  if (error instanceof Error && error.name === "AbortError") {
    return new AiProviderError("timeout");
  }
  if (APICallError.isInstance(error)) {
    const status = error.statusCode;
    if (status === 401 || status === 403) {
      return new AiProviderError("invalid_auth", status);
    }
    if (status === 402 || status === 429) {
      return new AiProviderError("limited", status);
    }
    return new AiProviderError("unavailable", status);
  }
  return new AiProviderError("unavailable");
}

async function generateWithDeepSeek(input: {
  feature:
    | "menu-recognition"
    | "menu-assistant"
    | "table-advice"
    | "translation";
  images?: Array<{ data: string; mimeType: string }>;
  maxOutputTokens: number;
  prompt: string;
  signal: AbortSignal;
}) {
  const apiKey = process.env.DEEPSEEK_API_KEY?.trim();
  if (!apiKey) throw new AiProviderError("invalid_auth");
  const usesVision = Boolean(input.images?.length);
  const model = usesVision
    ? process.env.DEEPSEEK_VISION_MODEL?.trim() || DEFAULT_VISION_AI_MODEL
    : process.env.DEEPSEEK_TEXT_MODEL?.trim() || DEFAULT_TEXT_AI_MODEL;
  const content = usesVision
    ? [
        { type: "text", text: input.prompt },
        ...(input.images ?? []).map((image) => ({
          type: "image_url",
          image_url: {
            detail: "original",
            url: `data:${image.mimeType};base64,${image.data}`,
          },
        })),
      ]
    : input.prompt;
  const response = await fetch("https://api.deepseek.com/chat/completions", {
    body: JSON.stringify({
      max_tokens: input.maxOutputTokens,
      messages: [{ content, role: "user" }],
      model,
      response_format: { type: "json_object" },
      stream: false,
      temperature: 0.1,
      thinking: { type: "disabled" },
    }),
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    method: "POST",
    signal: input.signal,
  });
  const body = (await response.json().catch(() => null)) as {
    choices?: Array<{ message?: { content?: string } }>;
    id?: string;
    model?: string;
  } | null;
  if (!response.ok) {
    if (response.status === 401 || response.status === 403)
      throw new AiProviderError("invalid_auth", response.status);
    if (response.status === 402 || response.status === 429)
      throw new AiProviderError("limited", response.status);
    throw new AiProviderError("unavailable", response.status);
  }
  const text = body?.choices?.[0]?.message?.content?.trim();
  if (!text) throw new AiProviderError("unavailable");
  return {
    model: body?.model || model,
    providerResponseId: body?.id ?? null,
    text,
  };
}

async function generateWithGateway(input: {
  feature:
    | "menu-recognition"
    | "menu-assistant"
    | "table-advice"
    | "translation";
  images?: Array<{ data: string; mimeType: string }>;
  maxOutputTokens: number;
  prompt: string;
  signal: AbortSignal;
}) {
  const usesVision = Boolean(input.images?.length);
  const model = usesVision
    ? process.env.AI_VISION_MODEL?.trim() || DEFAULT_GATEWAY_VISION_MODEL
    : process.env.AI_TEXT_MODEL?.trim() || DEFAULT_GATEWAY_TEXT_MODEL;
  const fallbacks = parseFallbacks(
    usesVision
      ? process.env.AI_VISION_FALLBACK_MODELS
      : process.env.AI_TEXT_FALLBACK_MODELS,
    usesVision ? DEFAULT_VISION_FALLBACKS : DEFAULT_TEXT_FALLBACKS,
  ).filter((candidate) => candidate !== model);
  const result = await generateText({
    abortSignal: input.signal,
    maxOutputTokens: input.maxOutputTokens,
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: input.prompt },
          ...(input.images ?? []).map((image) => ({
            type: "image" as const,
            image: Buffer.from(image.data, "base64"),
            mediaType: image.mimeType,
          })),
        ],
      },
    ],
    model,
    providerOptions: {
      gateway: {
        models: fallbacks,
        tags: ["app:menu-crew", `feature:${input.feature}`],
      },
    },
    temperature: 0.1,
  });
  return {
    model: result.response.modelId,
    providerResponseId: result.response.id || null,
    text: result.text,
  };
}

export async function generateAiText(input: {
  feature:
    | "menu-recognition"
    | "menu-assistant"
    | "table-advice"
    | "translation";
  images?: Array<{ data: string; mimeType: string }>;
  maxOutputTokens: number;
  prompt: string;
  timeoutMs: number;
}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), input.timeoutMs);

  try {
    const result =
      process.env.AI_PROVIDER?.trim().toLowerCase() === "gateway"
        ? await generateWithGateway({ ...input, signal: controller.signal })
        : await generateWithDeepSeek({ ...input, signal: controller.signal });
    console.info("[ai-provider] completed", {
      feature: input.feature,
      model: result.model,
      responseId: result.providerResponseId,
    });
    return result;
  } catch (error) {
    const classified = classifyProviderError(error);
    console.error("[ai-provider] failed", {
      code: classified.code,
      feature: input.feature,
      status: classified.status,
    });
    throw classified;
  } finally {
    clearTimeout(timeout);
  }
}
