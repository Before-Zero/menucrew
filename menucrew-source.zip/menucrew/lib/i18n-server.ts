import "server-only";

import { cookies, headers } from "next/headers";
import {
  type AppLocale,
  isAppLocale,
  LOCALE_COOKIE,
  localeFromLanguageHeader,
} from "@/lib/i18n";

export async function getAppLocale(): Promise<AppLocale> {
  const cookieValue = (await cookies()).get(LOCALE_COOKIE)?.value;
  if (isAppLocale(cookieValue)) return cookieValue;
  return localeFromLanguageHeader((await headers()).get("accept-language"));
}
