export const NAME_MAX_LENGTH = 60;
export const MENU_DESCRIPTION_MAX_LENGTH = 240;
export const MENU_IMAGE_MAX_BYTES = 6 * 1024 * 1024;
export const MENU_IMAGE_MAX_COUNT = 4;
export const MENU_ITEM_NAME_MAX_LENGTH = 120;
export const SELECTION_QUANTITY_MAX = 20;
export const SELECTION_NOTE_MAX_LENGTH = 240;
export const DIETARY_INFO_MAX_LENGTH = 500;
export const MENU_IMAGE_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
] as const;

const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const INVITE_TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;

export type FieldErrors = Partial<
  Record<"displayName" | "roomCode" | "roomName", string>
>;
export type MenuItemFieldErrors = Partial<
  Record<"description" | "originalName" | "zhName", string>
>;

function normalizeText(value: FormDataEntryValue | null) {
  return typeof value === "string" ? value.trim() : "";
}

export function validateName(value: FormDataEntryValue | null, label: string) {
  const normalized = normalizeText(value);

  if (!normalized) {
    return { error: `请输入${label}。`, value: "" };
  }

  if (normalized.length > NAME_MAX_LENGTH) {
    return {
      error: `${label}不能超过 ${NAME_MAX_LENGTH} 个字符。`,
      value: normalized,
    };
  }

  return { error: null, value: normalized };
}

export function validateCreateRoomInput(formData: FormData) {
  const roomName = validateName(formData.get("roomName"), "房间名称");
  const displayName = validateName(formData.get("displayName"), "你的称呼");
  const fields: FieldErrors = {};

  if (roomName.error) fields.roomName = roomName.error;
  if (displayName.error) fields.displayName = displayName.error;

  return {
    data: {
      displayName: displayName.value,
      roomName: roomName.value,
    },
    fields,
    valid: Object.keys(fields).length === 0,
  };
}

export function validateJoinRoomInput(formData: FormData) {
  const displayName = validateName(formData.get("displayName"), "你的称呼");

  return {
    data: { displayName: displayName.value },
    fields: displayName.error
      ? ({ displayName: displayName.error } satisfies FieldErrors)
      : {},
    valid: !displayName.error,
  };
}

export function validateJoinCodeInput(formData: FormData) {
  const displayName = validateName(formData.get("displayName"), "你的称呼");
  const rawCode = normalizeText(formData.get("roomCode"));
  const roomCode = rawCode.replace(/\D/g, "");
  const fields: FieldErrors = {};

  if (displayName.error) fields.displayName = displayName.error;
  if (!/^\d{6}$/.test(roomCode)) fields.roomCode = "请输入 6 位入席码。";

  return {
    data: { displayName: displayName.value, roomCode },
    fields,
    valid: Object.keys(fields).length === 0,
  };
}

function validateRequiredText(
  value: FormDataEntryValue | null,
  label: string,
  maxLength: number,
) {
  const normalized = normalizeText(value);

  if (!normalized) {
    return { error: `请输入${label}。`, value: "" };
  }

  if (normalized.length > maxLength) {
    return {
      error: `${label}不能超过 ${maxLength} 个字符。`,
      value: normalized,
    };
  }

  return { error: null, value: normalized };
}

export function validateMenuItemInput(formData: FormData) {
  const originalName = validateRequiredText(
    formData.get("originalName"),
    "菜单原文",
    MENU_ITEM_NAME_MAX_LENGTH,
  );
  const zhName = validateRequiredText(
    formData.get("zhName"),
    "简体中文名",
    MENU_ITEM_NAME_MAX_LENGTH,
  );
  const description = validateRequiredText(
    formData.get("description"),
    "简短解释",
    MENU_DESCRIPTION_MAX_LENGTH,
  );
  const fields: MenuItemFieldErrors = {};

  if (originalName.error) fields.originalName = originalName.error;
  if (zhName.error) fields.zhName = zhName.error;
  if (description.error) fields.description = description.error;

  return {
    data: {
      description: description.value,
      originalName: originalName.value,
      zhName: zhName.value,
    },
    fields,
    valid: Object.keys(fields).length === 0,
  };
}

export function validateMenuImage(file: File) {
  if (file.size < 1) return "图片内容不能为空。";

  if (
    !MENU_IMAGE_MIME_TYPES.includes(
      file.type as (typeof MENU_IMAGE_MIME_TYPES)[number],
    )
  ) {
    return "仅支持 JPEG、PNG 或 WebP 图片。";
  }

  if (file.size > MENU_IMAGE_MAX_BYTES) {
    return "单张图片不能超过 6 MB。";
  }

  return null;
}

export function isValidInviteToken(value: string) {
  return INVITE_TOKEN_PATTERN.test(value);
}

export function isValidRoomId(value: string) {
  return UUID_PATTERN.test(value);
}

export function isValidMenuEntityId(value: string) {
  return UUID_PATTERN.test(value);
}

type SelectionMenuItem = { id: string; zh_name: string };

function validateOptionalText(
  value: FormDataEntryValue | null,
  label: string,
  maxLength: number,
) {
  const normalized = normalizeText(value);
  return {
    error:
      normalized.length > maxLength
        ? `${label}不能超过 ${maxLength} 个字符。`
        : null,
    value: normalized,
  };
}

export function validateSelectionInput(
  formData: FormData,
  menuItems: SelectionMenuItem[],
) {
  const fieldErrors: Record<string, string> = {};
  const dietaryRestrictions = validateOptionalText(
    formData.get("dietaryRestrictions"),
    "整体忌口",
    DIETARY_INFO_MAX_LENGTH,
  );
  const allergyInfo = validateOptionalText(
    formData.get("allergyInfo"),
    "过敏信息",
    DIETARY_INFO_MAX_LENGTH,
  );

  if (dietaryRestrictions.error)
    fieldErrors.dietaryRestrictions = dietaryRestrictions.error;
  if (allergyInfo.error) fieldErrors.allergyInfo = allergyInfo.error;

  const selections = menuItems.map((item) => {
    const quantityKey = `quantity:${item.id}`;
    const noteKey = `note:${item.id}`;
    const quantityValue = formData.get(quantityKey);
    const quantityText =
      typeof quantityValue === "string" ? quantityValue.trim() : "";
    const quantity = Number(quantityText);
    const note = validateOptionalText(
      formData.get(noteKey),
      `${item.zh_name}的口味备注`,
      SELECTION_NOTE_MAX_LENGTH,
    );

    if (
      !/^(0|[1-9]|1[0-9]|20)$/.test(quantityText) ||
      !Number.isInteger(quantity) ||
      quantity < 0 ||
      quantity > SELECTION_QUANTITY_MAX
    ) {
      fieldErrors[quantityKey] = "数量必须是 0–20 的整数。";
    }
    if (note.error) fieldErrors[noteKey] = note.error;

    return {
      menuItemId: item.id,
      note: quantity > 0 ? note.value : "",
      quantity: Number.isInteger(quantity) ? quantity : 0,
    };
  });

  return {
    data: {
      allergyInfo: allergyInfo.value,
      dietaryRestrictions: dietaryRestrictions.value,
      selections,
    },
    fieldErrors,
    valid: Object.keys(fieldErrors).length === 0,
  };
}
