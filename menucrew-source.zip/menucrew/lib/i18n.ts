export const SUPPORTED_LOCALES = ["zh-CN", "en"] as const;
export type AppLocale = (typeof SUPPORTED_LOCALES)[number];

import type { RoomJourney } from "@/lib/room-journey";

export const LOCALE_COOKIE = "menucrew_locale";

export function isAppLocale(value: unknown): value is AppLocale {
  return value === "zh-CN" || value === "en";
}

export function localeFromLanguageHeader(value: string | null): AppLocale {
  return value?.toLowerCase().includes("zh") ? "zh-CN" : "en";
}

export function localizedMenuText(
  item: {
    description: string;
    description_en: string;
    en_name: string;
    original_name: string;
    zh_name: string;
  },
  locale: AppLocale,
) {
  if (locale === "en") {
    return {
      description: item.description_en || item.description,
      name: item.en_name || item.zh_name || item.original_name,
    };
  }
  return {
    description: item.description,
    name: item.zh_name || item.original_name,
  };
}

export const UI_TEXT = {
  en: {
    addOrEdit: "Add or edit dishes",
    aiAsk: "Build an order with AI",
    invited: "You're at the table",
    preparing: "The menu is being prepared",
    receipt: "Table order",
  },
  "zh-CN": {
    addOrEdit: "如需添加或修改，返回我的选择",
    aiAsk: "让 AI 搭一份点餐",
    invited: "你已成功入席",
    preparing: "菜单正在准备",
    receipt: "本桌点单",
  },
} as const;

const JOURNEY_EN: Record<string, string> = {
  菜单: "Menu",
  我的选择: "My choices",
  本桌点单: "Table order",
  菜单准备中: "Menu in preparation",
  菜单发布后即可填写: "Available after the menu is published",
  菜单发布后即可查看: "Available after the menu is published",
  查看最终订单: "View final order",
  "发起人已确认，所有房间成员看到同一份双语订单。":
    "The organizer confirmed one bilingual order for everyone.",
  "订单已经确认，内容不会再被修改。":
    "The order is confirmed and can no longer be changed.",
  已完成: "Complete",
  查看本桌已点并确认订单: "Review table order",
  "实时查看大家已经点的菜，并在最后一步调整和确认。":
    "Review everyone's dishes live, then adjust and confirm the final order.",
  "菜单已开放，所有人都可以继续添加或修改。":
    "The menu is open. Everyone can still add or edit choices.",
  点餐中: "Ordering",
  查看本桌已点: "View table order",
  开始点餐: "Start ordering",
  "你已提交；发起人结束收集前仍可修改。":
    "Submitted. You can edit until the organizer begins review.",
  "按本人实际想点的份数填写，保存后发起人才能汇总。":
    "Enter the servings you personally want so the organizer can total them.",
  "菜单已开放，最终订单确认前都可以修改。":
    "The menu is open and choices can change until final confirmation.",
  上传菜单并开始识别: "Upload and recognize menu",
  "先邀请大家入席，再上传菜单图片交给 AI 识别。":
    "Invite diners, then upload menu photos for AI recognition.",
  "菜单还没有发布，成员暂时不能开始选择。":
    "The menu is not published yet, so diners cannot choose dishes.",
  准备中: "Preparing",
  等待菜单发布: "Wait for the menu",
  "你已加入成功，发起人发布菜单后即可开始填写。":
    "You joined successfully. Ordering starts when the organizer publishes the menu.",
  "发起人正在准备菜单，发布后会开放个人选择。":
    "The organizer is preparing the menu. Personal choices open after publishing.",
};

export function localizedRoomJourney(
  journey: RoomJourney,
  locale: AppLocale,
): RoomJourney {
  if (locale !== "en") return journey;
  const translate = (value?: string) =>
    value ? JOURNEY_EN[value] || value : value;
  return {
    ...journey,
    navigationItems: journey.navigationItems.map((item) => ({
      ...item,
      description: translate(item.description),
      label: translate(item.label) || item.label,
    })),
    primaryAction: {
      ...journey.primaryAction,
      description:
        translate(journey.primaryAction.description) ||
        journey.primaryAction.description,
      label:
        translate(journey.primaryAction.label) || journey.primaryAction.label,
    },
    stageDescription:
      translate(journey.stageDescription) || journey.stageDescription,
    stageLabel: translate(journey.stageLabel) || journey.stageLabel,
  };
}
