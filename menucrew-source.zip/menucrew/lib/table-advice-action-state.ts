export type TableAdviceActionState = {
  message: string;
  status: "idle" | "success" | "error";
};

export const initialTableAdviceActionState: TableAdviceActionState = {
  message: "",
  status: "idle",
};
