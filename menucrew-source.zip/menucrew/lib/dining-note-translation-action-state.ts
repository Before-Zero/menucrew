export type DiningNoteTranslation = {
  allergyEn: string;
  allergyZh: string;
  dietaryEn: string;
  dietaryZh: string;
  userId: string;
};

export type DiningNoteTranslationActionState = {
  message: string;
  status: "idle" | "success" | "error";
  translations: DiningNoteTranslation[];
};

export const initialDiningNoteTranslationState: DiningNoteTranslationActionState =
  {
    message: "",
    status: "idle",
    translations: [],
  };
