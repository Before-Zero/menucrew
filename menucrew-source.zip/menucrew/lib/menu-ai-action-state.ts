export type MenuAiActionState = {
  message: string;
  runId?: string;
  status: "idle" | "pending" | "success" | "error";
};

export const initialMenuAiActionState: MenuAiActionState = {
  message: "",
  status: "idle",
};
