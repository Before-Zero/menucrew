export type AggregationActionState = {
  message: string;
  revision: number | null;
  status: "idle" | "success" | "error";
};

export const initialAggregationActionState: AggregationActionState = {
  message: "",
  revision: null,
  status: "idle",
};
