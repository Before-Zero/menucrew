import "server-only";

import QRCode from "qrcode";

export async function createInviteQrDataUrl(inviteUrl: string) {
  return QRCode.toDataURL(inviteUrl, {
    color: { dark: "#172033", light: "#ffffff" },
    errorCorrectionLevel: "M",
    margin: 2,
    width: 320,
  });
}
