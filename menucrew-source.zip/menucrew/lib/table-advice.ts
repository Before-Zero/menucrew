import "server-only";

import { createHash } from "node:crypto";
import type { RoomAggregation } from "@/lib/aggregation";
import {
  AiProviderError,
  DEFAULT_TEXT_AI_MODEL,
  generateAiText,
} from "@/lib/ai-provider";
import type { Json, Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export const DEFAULT_TABLE_ADVICE_MODEL = DEFAULT_TEXT_AI_MODEL;

export type TableAdviceType = "balance" | "duplicate" | "quantity" | "allergy";
export type TableAdviceRisk = "info" | "warning" | "critical";
export type TableAdviceItem = {
  type: TableAdviceType;
  risk: TableAdviceRisk;
  title: string;
  detail: string;
  evidence: string;
};
export type TableAdviceResult = { items: TableAdviceItem[] };
export type TableAdviceRecord = Omit<Tables<"room_advice">, "result"> & {
  result: TableAdviceResult | null;
};

type AnonymousSnapshot = {
  dishes: Array<{
    contributors: Array<{ member: string; note: string; quantity: number }>;
    description: string;
    originalName: string;
    totalQuantity: number;
    zhName: string;
  }>;
  members: Array<{
    allergyInfo: string;
    dietaryRestrictions: string;
    member: string;
    submitted: boolean;
  }>;
  metrics: RoomAggregation["metrics"];
};

export class TableAdviceError extends Error {
  constructor(
    public readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

function cleanText(value: unknown, maxLength: number) {
  if (typeof value !== "string") return null;
  const cleaned = value.trim();
  return cleaned.length >= 1 && cleaned.length <= maxLength ? cleaned : null;
}

export function parseTableAdviceResult(
  value: unknown,
): TableAdviceResult | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const root = value as Record<string, unknown>;
  if (Object.keys(root).length !== 1 || !Array.isArray(root.items)) return null;
  if (root.items.length < 1 || root.items.length > 12) return null;

  const types: TableAdviceType[] = [
    "balance",
    "duplicate",
    "quantity",
    "allergy",
  ];
  const risks: TableAdviceRisk[] = ["info", "warning", "critical"];
  const parsed: TableAdviceItem[] = [];
  for (const candidate of root.items) {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate))
      return null;
    const row = candidate as Record<string, unknown>;
    const expected = ["type", "risk", "title", "detail", "evidence"];
    if (
      Object.keys(row).length !== expected.length ||
      expected.some((key) => !(key in row)) ||
      !types.includes(row.type as TableAdviceType) ||
      !risks.includes(row.risk as TableAdviceRisk)
    )
      return null;
    const title = cleanText(row.title, 80);
    const detail = cleanText(row.detail, 300);
    const evidence = cleanText(row.evidence, 240);
    if (!title || !detail || !evidence) return null;
    parsed.push({
      detail,
      evidence,
      risk: row.risk as TableAdviceRisk,
      title,
      type: row.type as TableAdviceType,
    });
  }
  return { items: parsed };
}

export function buildTableAdviceInput(aggregation: RoomAggregation) {
  const memberCodes = new Map(
    aggregation.members.map((member, index) => [
      member.userId,
      `M${index + 1}`,
    ]),
  );
  const snapshot: AnonymousSnapshot = {
    dishes: aggregation.dishes.map((dish) => ({
      contributors: dish.contributors
        .map((contributor) => ({
          member: memberCodes.get(contributor.userId) ?? "M?",
          note: contributor.note,
          quantity: contributor.quantity,
        }))
        .sort((a, b) => a.member.localeCompare(b.member)),
      description: dish.description,
      originalName: dish.originalName,
      totalQuantity: dish.totalQuantity,
      zhName: dish.zhName,
    })),
    members: aggregation.members.map((member) => ({
      allergyInfo: member.allergyInfo,
      dietaryRestrictions: member.dietaryRestrictions,
      member: memberCodes.get(member.userId) ?? "M?",
      submitted: Boolean(member.submittedAt),
    })),
    metrics: aggregation.metrics,
  };
  const serialized = JSON.stringify(snapshot);
  return {
    digest: createHash("sha256").update(serialized).digest("hex"),
    snapshot,
  };
}

export async function getRoomAdviceHistory(
  roomId: string,
): Promise<TableAdviceRecord[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("room_advice")
    .select(
      "id,room_id,requested_by,source_revision,input_digest,status,model,result,error_code,error_message,provider_response_id,created_at,completed_at",
    )
    .eq("room_id", roomId)
    .order("created_at", { ascending: false })
    .limit(5);
  if (error) throw new Error("读取整桌建议失败。", { cause: error });
  return (data ?? []).map((record) => ({
    ...record,
    result: parseTableAdviceResult(record.result),
  }));
}

const responseSchema = {
  properties: {
    items: {
      items: {
        properties: {
          detail: { type: "string" },
          evidence: { type: "string" },
          risk: {
            enum: ["info", "warning", "critical"],
            type: "string",
          },
          title: { type: "string" },
          type: {
            enum: ["balance", "duplicate", "quantity", "allergy"],
            type: "string",
          },
        },
        required: ["type", "risk", "title", "detail", "evidence"],
        type: "object",
      },
      type: "array",
    },
  },
  required: ["items"],
  type: "object",
} as const;

export async function generateTableAdvice(
  snapshot: AnonymousSnapshot,
): Promise<{ providerResponseId: string | null; result: TableAdviceResult }> {
  try {
    const { providerResponseId, text } = await generateAiText({
      feature: "table-advice",
      maxOutputTokens: 4_000,
      prompt: [
        "你是多人点餐的只读核对助手。分析下方由普通程序精确汇总的数据。",
        "只提示菜单结构遗漏、相似重复、份数值得复核、过敏或忌口风险。",
        "绝对不要重新计算或建议自动修改数量；不要声称确认了食材或医疗安全。",
        "过敏冲突应引用临时编号和菜名，并要求向餐厅确认。",
        "返回 1–12 条简体中文提示。未发现明显问题时返回一条 info 提示。",
        "字段长度：标题 80 字以内，说明 300 字以内，依据 240 字以内。",
        "只返回符合下方 JSON Schema 的 JSON，不要 Markdown 代码块。",
        `JSON Schema：${JSON.stringify(responseSchema)}`,
        `匿名汇总：${JSON.stringify(snapshot)}`,
      ].join("\n"),
      timeoutMs: 20_000,
    });
    if (!text) {
      throw new TableAdviceError(
        "incomplete_response",
        "AI 没有完成建议；你仍可继续人工核对。",
      );
    }
    let json: unknown;
    try {
      json = JSON.parse(
        text
          .trim()
          .replace(/^```(?:json)?\s*/i, "")
          .replace(/\s*```$/, ""),
      );
    } catch {
      throw new TableAdviceError(
        "invalid_output",
        "AI 返回的建议结构无效；你仍可继续人工核对。",
      );
    }
    const parsed = parseTableAdviceResult(json);
    if (!parsed) {
      throw new TableAdviceError(
        "invalid_output",
        "AI 返回的建议结构无效；你仍可继续人工核对。",
      );
    }
    return { providerResponseId, result: parsed };
  } catch (error) {
    if (error instanceof TableAdviceError) throw error;
    if (error instanceof AiProviderError && error.code === "timeout") {
      throw new TableAdviceError(
        "provider_timeout",
        "AI 建议超时；你仍可继续人工核对和确认订单。",
      );
    }
    if (error instanceof AiProviderError && error.code === "limited") {
      throw new TableAdviceError(
        "provider_rate_limited",
        "AI 免费额度或频率暂时受限；你仍可继续人工核对和确认订单。",
      );
    }
    throw new TableAdviceError(
      "provider_failed",
      "AI 服务暂时不可用；你仍可继续人工核对和确认订单。",
    );
  }
}

export function tableAdviceToJson(result: TableAdviceResult): Json {
  return result as unknown as Json;
}
