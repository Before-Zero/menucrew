import "server-only";

import { getRoomAccess } from "@/lib/rooms";
import { createClient } from "@/lib/supabase/server";

export type ReceiptItem = {
  enName: string;
  id: string;
  myQuantity: number;
  originalName: string;
  position: number;
  totalQuantity: number;
  zhName: string;
};

export type MemberReceipt = {
  items: ReceiptItem[];
  orderConfirmed: boolean;
  revision: number;
  roomId: string;
  roomName: string;
};

export async function getMemberReceipt(
  roomId: string,
): Promise<MemberReceipt | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_member_receipt", {
    candidate_room_id: roomId,
  });
  if (error) return null;
  const rows = data ?? [];
  return {
    items: rows.map((row) => ({
      enName: row.en_name,
      id: row.menu_item_id,
      myQuantity: row.my_quantity,
      originalName: row.original_name,
      position: row.item_position,
      totalQuantity: row.total_quantity,
      zhName: row.zh_name,
    })),
    orderConfirmed: rows[0]?.order_confirmed ?? false,
    revision: rows[0]?.revision ?? access.room.selection_revision,
    roomId,
    roomName: access.room.name,
  };
}
