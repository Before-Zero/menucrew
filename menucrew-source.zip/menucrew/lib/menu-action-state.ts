export type MenuItemFieldErrors = Partial<
  Record<"description" | "originalName" | "zhName", string>
>;

export type MenuActionState = {
  fields?: MenuItemFieldErrors;
  message: string;
  status: "error" | "idle" | "success";
};

export const initialMenuActionState: MenuActionState = {
  message: "",
  status: "idle",
};
