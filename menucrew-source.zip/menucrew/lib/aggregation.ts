import "server-only";

import { getRoomAccess, type RoomAccess } from "@/lib/rooms";
import type { Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export type AggregationContributor = {
  displayName: string;
  note: string;
  quantity: number;
  userId: string;
};

export type AggregatedDish = {
  contributors: AggregationContributor[];
  description: string;
  descriptionEn: string;
  enName: string;
  id: string;
  originalName: string;
  totalQuantity: number;
  zhName: string;
};

export type AggregationMember = {
  allergyInfo: string;
  dietaryRestrictions: string;
  displayName: string;
  role: string;
  submittedAt: string | null;
  userId: string;
};

export type RoomAggregation = {
  access: RoomAccess;
  dishes: AggregatedDish[];
  members: AggregationMember[];
  menuItemCount: number;
  metrics: {
    dishCount: number;
    memberCount: number;
    submittedCount: number;
    totalQuantity: number;
  };
};

export async function getRoomAggregation(
  roomId: string,
): Promise<RoomAggregation | null> {
  const access = await getRoomAccess(roomId);
  if (!access || access.currentMember.role !== "organizer") return null;

  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id,status")
    .eq("room_id", roomId)
    .maybeSingle();

  if (menuError) throw new Error("读取汇总菜单失败。", { cause: menuError });

  const [itemsResult, submissionsResult] = await Promise.all([
    menu
      ? supabase
          .from("menu_items")
          .select(
            "id,original_name,zh_name,en_name,description,description_en,position",
          )
          .eq("menu_id", menu.id)
          .order("position", { ascending: true })
          .order("id", { ascending: true })
      : Promise.resolve({ data: [], error: null }),
    supabase
      .from("member_submissions")
      .select(
        "id,user_id,dietary_restrictions,allergy_info,submitted_at,updated_at",
      )
      .eq("room_id", roomId),
  ]);

  if (itemsResult.error || submissionsResult.error) {
    throw new Error("读取汇总数据失败。", {
      cause: itemsResult.error ?? submissionsResult.error,
    });
  }

  const items = itemsResult.data ?? [];
  const submissions = submissionsResult.data ?? [];
  const submissionIds = submissions.map((submission) => submission.id);
  const selectionsResult = submissionIds.length
    ? await supabase
        .from("member_selections")
        .select("submission_id,menu_item_id,quantity,note")
        .in("submission_id", submissionIds)
    : { data: [], error: null };

  if (selectionsResult.error) {
    throw new Error("读取汇总明细失败。", { cause: selectionsResult.error });
  }

  const submissionByUserId = new Map(
    submissions.map((submission) => [submission.user_id, submission]),
  );
  const memberBySubmissionId = new Map(
    submissions.map((submission) => [
      submission.id,
      access.members.find((member) => member.user_id === submission.user_id),
    ]),
  );
  const selectionsByItemId = new Map<string, Tables<"member_selections">[]>();

  for (const selection of selectionsResult.data ?? []) {
    if (selection.quantity <= 0) continue;
    const existing = selectionsByItemId.get(selection.menu_item_id) ?? [];
    existing.push(selection as Tables<"member_selections">);
    selectionsByItemId.set(selection.menu_item_id, existing);
  }

  const dishes = items.flatMap((item) => {
    const selections = selectionsByItemId.get(item.id) ?? [];
    if (!selections.length) return [];
    const contributors = selections.flatMap((selection) => {
      const member = memberBySubmissionId.get(selection.submission_id);
      if (!member) return [];
      return [
        {
          displayName: member.display_name,
          note: selection.note,
          quantity: selection.quantity,
          userId: member.user_id,
        },
      ];
    });
    return [
      {
        contributors,
        description: item.description,
        descriptionEn: item.description_en,
        enName: item.en_name,
        id: item.id,
        originalName: item.original_name,
        totalQuantity: contributors.reduce(
          (sum, contributor) => sum + contributor.quantity,
          0,
        ),
        zhName: item.zh_name,
      },
    ];
  });

  const members = access.members.map((member) => {
    const submission = submissionByUserId.get(member.user_id);
    return {
      allergyInfo: submission?.allergy_info ?? "",
      dietaryRestrictions: submission?.dietary_restrictions ?? "",
      displayName: member.display_name,
      role: member.role,
      submittedAt: submission?.submitted_at ?? null,
      userId: member.user_id,
    };
  });

  return {
    access,
    dishes,
    members,
    menuItemCount: items.length,
    metrics: {
      dishCount: dishes.length,
      memberCount: members.length,
      submittedCount: submissions.length,
      totalQuantity: dishes.reduce((sum, dish) => sum + dish.totalQuantity, 0),
    },
  };
}
