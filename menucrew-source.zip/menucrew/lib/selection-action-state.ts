export type SelectionActionState = {
  fieldErrors: Record<string, string>;
  message: string;
  savedAt: string | null;
  status: "idle" | "error" | "success";
};

export const initialSelectionActionState: SelectionActionState = {
  fieldErrors: {},
  message: "",
  savedAt: null,
  status: "idle",
};
