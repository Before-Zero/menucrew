import "server-only";

import { createHash } from "node:crypto";
import {
  AiProviderError,
  DEFAULT_VISION_AI_MODEL,
  generateAiText,
} from "@/lib/ai-provider";
import type { Json, Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export const DEFAULT_MENU_AI_MODEL = DEFAULT_VISION_AI_MODEL;
const MENU_IMAGES_BUCKET = "menu-images";
const MAX_INLINE_IMAGE_BYTES = 12 * 1024 * 1024;

export type MenuAiItem = {
  category: string;
  description: string;
  originalName: string;
  uncertainty: string;
  zhName: string;
};

export type MenuAiResult = { items: MenuAiItem[] };
export type MenuAiRun = Omit<Tables<"menu_ai_runs">, "result"> & {
  result: MenuAiResult | null;
};

type ImageRow = {
  byte_size: number;
  created_at: string;
  id: string;
  mime_type: string;
  position: number;
  storage_path: string;
};

export class MenuAiError extends Error {
  constructor(
    public readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

function cleanText(value: unknown, maxLength: number, allowEmpty = false) {
  if (typeof value !== "string") return null;
  const cleaned = value.trim();
  if ((!allowEmpty && cleaned.length === 0) || cleaned.length > maxLength) {
    return null;
  }
  return cleaned;
}

export function parseMenuAiResult(value: unknown): MenuAiResult | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const items = (value as { items?: unknown }).items;
  if (!Array.isArray(items) || items.length < 1 || items.length > 80)
    return null;

  const parsed: MenuAiItem[] = [];
  for (const candidate of items) {
    if (
      !candidate ||
      typeof candidate !== "object" ||
      Array.isArray(candidate)
    ) {
      return null;
    }
    const keys = Object.keys(candidate);
    const expected = [
      "category",
      "description",
      "originalName",
      "uncertainty",
      "zhName",
    ];
    if (
      keys.length !== expected.length ||
      expected.some((key) => !keys.includes(key))
    ) {
      return null;
    }
    const row = candidate as Record<string, unknown>;
    const originalName = cleanText(row.originalName, 120);
    const zhName = cleanText(row.zhName, 120);
    const description = cleanText(row.description, 240);
    const category = cleanText(row.category, 60);
    const uncertainty = cleanText(row.uncertainty, 240, true);
    if (
      originalName === null ||
      zhName === null ||
      description === null ||
      category === null ||
      uncertainty === null
    ) {
      return null;
    }
    parsed.push({
      category,
      description,
      originalName,
      uncertainty,
      zhName,
    });
  }
  return { items: parsed };
}

export function computeMenuImageDigest(images: ImageRow[]) {
  const stable = [...images]
    .sort((a, b) => a.position - b.position || a.id.localeCompare(b.id))
    .map((image) => ({
      byteSize: image.byte_size,
      createdAt: image.created_at,
      id: image.id,
      position: image.position,
      storagePath: image.storage_path,
    }));
  return createHash("sha256").update(JSON.stringify(stable)).digest("hex");
}

export async function getLatestMenuAiRun(
  roomId: string,
  menuId: string,
): Promise<MenuAiRun | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("menu_ai_runs")
    .select(
      "id,room_id,menu_id,requested_by,input_digest,status,model,result,error_code,error_message,provider_response_id,created_at,completed_at,applied_at",
    )
    .eq("room_id", roomId)
    .eq("menu_id", menuId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw new Error("读取 AI 识别记录失败。", { cause: error });
  if (!data) return null;
  return { ...data, result: parseMenuAiResult(data.result) };
}

export async function getMenuAiInput(roomId: string) {
  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id,status")
    .eq("room_id", roomId)
    .maybeSingle();
  if (menuError) throw menuError;
  if (!menu) throw new MenuAiError("menu_missing", "请先建立菜单草稿。");
  if (menu.status !== "draft") {
    throw new MenuAiError("menu_not_draft", "请先把菜单退回草稿再识别。");
  }

  const { data: images, error: imagesError } = await supabase
    .from("menu_images")
    .select("id,storage_path,mime_type,byte_size,position,created_at")
    .eq("menu_id", menu.id)
    .order("position", { ascending: true })
    .order("id", { ascending: true });
  if (imagesError) throw imagesError;
  if (!images || images.length < 1 || images.length > 4) {
    throw new MenuAiError(
      "menu_ai_images_required",
      "请先上传 1–4 张菜单图片。",
    );
  }

  return {
    digest: computeMenuImageDigest(images),
    images,
    menuId: menu.id,
    supabase,
  };
}

const resultSchema = {
  properties: {
    items: {
      items: {
        properties: {
          category: { type: "string" },
          description: { type: "string" },
          originalName: { type: "string" },
          uncertainty: { type: "string" },
          zhName: { type: "string" },
        },
        required: [
          "originalName",
          "zhName",
          "description",
          "category",
          "uncertainty",
        ],
        type: "object",
      },
      type: "array",
    },
  },
  required: ["items"],
  type: "object",
} as const;

export async function understandMenuImages(
  images: ImageRow[],
): Promise<{ providerResponseId: string | null; result: MenuAiResult }> {
  const supabase = await createClient();
  const inlineImages = await Promise.all(
    images.map(async (image) => {
      const { data, error } = await supabase.storage
        .from(MENU_IMAGES_BUCKET)
        .createSignedUrl(image.storage_path, 60 * 10);
      if (error || !data) {
        throw new MenuAiError(
          "image_access_failed",
          "暂时无法安全读取菜单图片，请稍后重试。",
        );
      }
      const response = await fetch(data.signedUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new MenuAiError(
          "image_access_failed",
          "暂时无法安全读取菜单图片，请稍后重试。",
        );
      }
      const bytes = await response.arrayBuffer();
      return {
        data: Buffer.from(bytes).toString("base64"),
        mimeType: image.mime_type,
        size: bytes.byteLength,
      };
    }),
  );
  if (
    inlineImages.reduce((total, image) => total + image.size, 0) >
    MAX_INLINE_IMAGE_BYTES
  ) {
    throw new MenuAiError(
      "images_too_large_for_ai",
      "当前图片总量过大，AI 未收到图片；请压缩或减少图片后重试。",
    );
  }

  try {
    const { providerResponseId, text: outputText } = await generateAiText({
      feature: "menu-recognition",
      images: inlineImages.map((image) => ({
        data: image.data,
        mimeType: image.mimeType,
      })),
      maxOutputTokens: 8_000,
      prompt: [
        "读取这些餐厅菜单图片，按图片和版面顺序提取所有菜品。",
        "保留菜单原文；翻译为简体中文；用简体中文解释主要食材或做法。",
        "给出简短分类。无法确定的文字、食材或翻译写入 uncertainty，确定时传空字符串。",
        "不要提取价格、币种、页眉、地址或餐厅宣传文字。",
        "必须返回 1–80 道菜；各字段长度遵循：原文和中文名 120 字以内，解释和不确定提示 240 字以内，分类 60 字以内。",
        "只返回符合下方 JSON Schema 的 JSON，不要 Markdown 代码块。",
        `JSON Schema：${JSON.stringify(resultSchema)}`,
      ].join("\n"),
      timeoutMs: 55_000,
    });
    if (!outputText) {
      throw new MenuAiError(
        "incomplete_response",
        "AI 没有完成识别，请稍后重试。",
      );
    }
    let json: unknown;
    try {
      json = JSON.parse(
        outputText
          .trim()
          .replace(/^```(?:json)?\s*/i, "")
          .replace(/\s*```$/, ""),
      );
    } catch {
      throw new MenuAiError(
        "invalid_output",
        "AI 返回的菜单结构无效，请重新识别或继续人工录入。",
      );
    }
    const parsed = parseMenuAiResult(json);
    if (!parsed) {
      throw new MenuAiError(
        "invalid_output",
        "AI 返回的菜单结构无效，请重新识别或继续人工录入。",
      );
    }
    return { providerResponseId, result: parsed };
  } catch (error) {
    if (error instanceof MenuAiError) throw error;
    if (error instanceof AiProviderError && error.code === "timeout") {
      throw new MenuAiError(
        "provider_timeout",
        "AI 识别超时，图片和人工草稿没有变化。",
      );
    }
    if (error instanceof AiProviderError && error.code === "limited") {
      throw new MenuAiError(
        "provider_rate_limited",
        "AI 免费额度或频率暂时受限，图片和人工草稿没有变化。",
      );
    }
    throw new MenuAiError(
      "provider_failed",
      "AI 服务暂时不可用，图片和人工草稿没有变化。",
    );
  }
}

export function toJson(result: MenuAiResult): Json {
  return result as unknown as Json;
}
