export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15";
  };
  public: {
    Tables: {
      member_selections: {
        Row: {
          created_at: string;
          id: string;
          menu_item_id: string;
          note: string;
          quantity: number;
          submission_id: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          menu_item_id: string;
          note?: string;
          quantity: number;
          submission_id: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          menu_item_id?: string;
          note?: string;
          quantity?: number;
          submission_id?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_selections_menu_item_id_fkey";
            columns: ["menu_item_id"];
            isOneToOne: false;
            referencedRelation: "menu_items";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "member_selections_submission_id_fkey";
            columns: ["submission_id"];
            isOneToOne: false;
            referencedRelation: "member_submissions";
            referencedColumns: ["id"];
          },
        ];
      };
      member_submissions: {
        Row: {
          allergy_info: string;
          created_at: string;
          dietary_restrictions: string;
          id: string;
          room_id: string;
          submitted_at: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          allergy_info?: string;
          created_at?: string;
          dietary_restrictions?: string;
          id?: string;
          room_id: string;
          submitted_at?: string;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          allergy_info?: string;
          created_at?: string;
          dietary_restrictions?: string;
          id?: string;
          room_id?: string;
          submitted_at?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_submissions_member_fkey";
            columns: ["room_id", "user_id"];
            isOneToOne: true;
            referencedRelation: "room_members";
            referencedColumns: ["room_id", "user_id"];
          },
        ];
      };
      menu_ai_runs: {
        Row: {
          applied_at: string | null;
          completed_at: string | null;
          created_at: string;
          error_code: string | null;
          error_message: string | null;
          id: string;
          input_digest: string;
          menu_id: string;
          model: string;
          provider_response_id: string | null;
          requested_by: string;
          result: Json | null;
          room_id: string;
          status: string;
        };
        Insert: {
          applied_at?: string | null;
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest: string;
          menu_id: string;
          model: string;
          provider_response_id?: string | null;
          requested_by: string;
          result?: Json | null;
          room_id: string;
          status?: string;
        };
        Update: {
          applied_at?: string | null;
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest?: string;
          menu_id?: string;
          model?: string;
          provider_response_id?: string | null;
          requested_by?: string;
          result?: Json | null;
          room_id?: string;
          status?: string;
        };
        Relationships: [
          {
            foreignKeyName: "menu_ai_runs_menu_id_fkey";
            columns: ["menu_id"];
            isOneToOne: false;
            referencedRelation: "menus";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "menu_ai_runs_requester_fkey";
            columns: ["room_id", "requested_by"];
            isOneToOne: false;
            referencedRelation: "room_members";
            referencedColumns: ["room_id", "user_id"];
          },
          {
            foreignKeyName: "menu_ai_runs_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: false;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      menu_assistant_runs: {
        Row: {
          completed_at: string | null;
          created_at: string;
          error_code: string | null;
          error_message: string | null;
          id: string;
          input_digest: string;
          menu_id: string;
          model: string;
          requested_by: string;
          result: Json | null;
          room_id: string;
          status: string;
        };
        Insert: {
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest: string;
          menu_id: string;
          model: string;
          requested_by: string;
          result?: Json | null;
          room_id: string;
          status?: string;
        };
        Update: {
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest?: string;
          menu_id?: string;
          model?: string;
          requested_by?: string;
          result?: Json | null;
          room_id?: string;
          status?: string;
        };
        Relationships: [];
      };
      menu_images: {
        Row: {
          byte_size: number;
          created_at: string;
          id: string;
          menu_id: string;
          mime_type: string;
          original_name: string;
          position: number;
          storage_path: string;
        };
        Insert: {
          byte_size: number;
          created_at?: string;
          id?: string;
          menu_id: string;
          mime_type: string;
          original_name: string;
          position: number;
          storage_path: string;
        };
        Update: {
          byte_size?: number;
          created_at?: string;
          id?: string;
          menu_id?: string;
          mime_type?: string;
          original_name?: string;
          position?: number;
          storage_path?: string;
        };
        Relationships: [
          {
            foreignKeyName: "menu_images_menu_id_fkey";
            columns: ["menu_id"];
            isOneToOne: false;
            referencedRelation: "menus";
            referencedColumns: ["id"];
          },
        ];
      };
      menu_items: {
        Row: {
          created_at: string;
          description: string;
          description_en: string;
          en_name: string;
          id: string;
          menu_id: string;
          original_name: string;
          position: number;
          updated_at: string;
          zh_name: string;
        };
        Insert: {
          created_at?: string;
          description: string;
          description_en?: string;
          en_name?: string;
          id?: string;
          menu_id: string;
          original_name: string;
          position: number;
          updated_at?: string;
          zh_name: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          description_en?: string;
          en_name?: string;
          id?: string;
          menu_id?: string;
          original_name?: string;
          position?: number;
          updated_at?: string;
          zh_name?: string;
        };
        Relationships: [
          {
            foreignKeyName: "menu_items_menu_id_fkey";
            columns: ["menu_id"];
            isOneToOne: false;
            referencedRelation: "menus";
            referencedColumns: ["id"];
          },
        ];
      };
      menus: {
        Row: {
          created_at: string;
          id: string;
          published_at: string | null;
          room_id: string;
          status: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          published_at?: string | null;
          room_id: string;
          status?: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          published_at?: string | null;
          room_id?: string;
          status?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "menus_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: true;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      order_items: {
        Row: {
          en_name: string;
          final_quantity: number;
          id: string;
          member_names: string[];
          menu_item_id: string;
          note: string;
          order_id: string;
          original_name: string;
          position: number;
          requested_quantity: number;
          zh_name: string;
        };
        Insert: {
          en_name?: string;
          final_quantity: number;
          id?: string;
          member_names?: string[];
          menu_item_id: string;
          note?: string;
          order_id: string;
          original_name: string;
          position: number;
          requested_quantity: number;
          zh_name: string;
        };
        Update: {
          en_name?: string;
          final_quantity?: number;
          id?: string;
          member_names?: string[];
          menu_item_id?: string;
          note?: string;
          order_id?: string;
          original_name?: string;
          position?: number;
          requested_quantity?: number;
          zh_name?: string;
        };
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey";
            columns: ["order_id"];
            isOneToOne: false;
            referencedRelation: "orders";
            referencedColumns: ["id"];
          },
        ];
      };
      orders: {
        Row: {
          confirmed_at: string;
          confirmed_by: string;
          dietary_notes: Json;
          id: string;
          room_id: string;
          source_revision: number;
        };
        Insert: {
          confirmed_at?: string;
          confirmed_by: string;
          dietary_notes?: Json;
          id?: string;
          room_id: string;
          source_revision: number;
        };
        Update: {
          confirmed_at?: string;
          confirmed_by?: string;
          dietary_notes?: Json;
          id?: string;
          room_id?: string;
          source_revision?: number;
        };
        Relationships: [
          {
            foreignKeyName: "orders_confirmer_fkey";
            columns: ["room_id", "confirmed_by"];
            isOneToOne: false;
            referencedRelation: "room_members";
            referencedColumns: ["room_id", "user_id"];
          },
          {
            foreignKeyName: "orders_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: true;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      room_advice: {
        Row: {
          completed_at: string | null;
          created_at: string;
          error_code: string | null;
          error_message: string | null;
          id: string;
          input_digest: string;
          model: string;
          provider_response_id: string | null;
          requested_by: string;
          result: Json | null;
          room_id: string;
          source_revision: number;
          status: string;
        };
        Insert: {
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest: string;
          model: string;
          provider_response_id?: string | null;
          requested_by: string;
          result?: Json | null;
          room_id: string;
          source_revision: number;
          status?: string;
        };
        Update: {
          completed_at?: string | null;
          created_at?: string;
          error_code?: string | null;
          error_message?: string | null;
          id?: string;
          input_digest?: string;
          model?: string;
          provider_response_id?: string | null;
          requested_by?: string;
          result?: Json | null;
          room_id?: string;
          source_revision?: number;
          status?: string;
        };
        Relationships: [
          {
            foreignKeyName: "room_advice_requester_fkey";
            columns: ["room_id", "requested_by"];
            isOneToOne: false;
            referencedRelation: "room_members";
            referencedColumns: ["room_id", "user_id"];
          },
          {
            foreignKeyName: "room_advice_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: false;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      room_members: {
        Row: {
          display_name: string;
          joined_at: string;
          role: string;
          room_id: string;
          user_id: string;
        };
        Insert: {
          display_name: string;
          joined_at?: string;
          role: string;
          room_id: string;
          user_id: string;
        };
        Update: {
          display_name?: string;
          joined_at?: string;
          role?: string;
          room_id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "room_members_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: false;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      product_events: {
        Row: {
          created_at: string;
          event_name: string;
          id: number;
          room_id: string | null;
        };
        Insert: {
          created_at?: string;
          event_name: string;
          id?: never;
          room_id?: string | null;
        };
        Update: {
          created_at?: string;
          event_name?: string;
          id?: never;
          room_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "product_events_room_id_fkey";
            columns: ["room_id"];
            isOneToOne: false;
            referencedRelation: "rooms";
            referencedColumns: ["id"];
          },
        ];
      };
      rooms: {
        Row: {
          created_at: string;
          created_by: string;
          id: string;
          invite_active: boolean;
          invite_token_digest: string;
          join_code: string;
          last_activity_at: string;
          name: string;
          selection_revision: number;
          selection_status: string;
          selection_status_changed_at: string;
        };
        Insert: {
          created_at?: string;
          created_by: string;
          id?: string;
          invite_active?: boolean;
          invite_token_digest: string;
          join_code?: string;
          last_activity_at?: string;
          name: string;
          selection_revision?: number;
          selection_status?: string;
          selection_status_changed_at?: string;
        };
        Update: {
          created_at?: string;
          created_by?: string;
          id?: string;
          invite_active?: boolean;
          invite_token_digest?: string;
          join_code?: string;
          last_activity_at?: string;
          name?: string;
          selection_revision?: number;
          selection_status?: string;
          selection_status_changed_at?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      apply_menu_ai_run: {
        Args: { candidate_run_id: string };
        Returns: number;
      };
      confirm_final_order: {
        Args: {
          candidate_items: Json;
          candidate_room_id: string;
          candidate_source_revision: number;
        };
        Returns: string;
      };
      confirm_final_order_direct: {
        Args: {
          candidate_items: Json;
          candidate_room_id: string;
          candidate_source_revision: number;
        };
        Returns: string;
      };
      confirm_menu_ai_run_and_publish: {
        Args: { candidate_run_id: string };
        Returns: number;
      };
      create_room: {
        Args: {
          display_name: string;
          invite_digest: string;
          room_name: string;
        };
        Returns: string;
      };
      finish_menu_ai_run: {
        Args: {
          candidate_error_code: string | null;
          candidate_error_message: string | null;
          candidate_provider_response_id: string | null;
          candidate_result: Json | null;
          candidate_run_id: string;
          candidate_status: string;
        };
        Returns: undefined;
      };
      finish_room_advice: {
        Args: {
          candidate_advice_id: string;
          candidate_error_code: string | null;
          candidate_error_message: string | null;
          candidate_provider_response_id: string | null;
          candidate_result: Json | null;
          candidate_status: string;
        };
        Returns: undefined;
      };
      get_room_submission_progress: {
        Args: { candidate_room_id: string };
        Returns: {
          member_count: number;
          my_submitted: boolean;
          submitted_count: number;
        }[];
      };
      get_member_receipt: {
        Args: { candidate_room_id: string };
        Returns: {
          en_name: string;
          menu_item_id: string;
          my_quantity: number;
          order_confirmed: boolean;
          original_name: string;
          item_position: number;
          revision: number;
          total_quantity: number;
          zh_name: string;
        }[];
      };
      join_room: {
        Args: { display_name: string; invite_digest: string };
        Returns: string;
      };
      join_room_by_code: {
        Args: { display_name: string; room_code: string };
        Returns: string;
      };
      save_my_selection: {
        Args: {
          candidate_allergy_info: string;
          candidate_dietary_restrictions: string;
          candidate_room_id: string;
          candidate_selections: Json;
        };
        Returns: string;
      };
      set_selection_collection_status: {
        Args: { candidate_room_id: string; candidate_status: string };
        Returns: {
          new_revision: number;
          new_status: string;
        }[];
      };
      start_menu_ai_run: {
        Args: {
          candidate_input_digest: string;
          candidate_model: string;
          candidate_room_id: string;
        };
        Returns: {
          reused: boolean;
          run_id: string;
        }[];
      };
      start_menu_assistant_run: {
        Args: {
          candidate_input_digest: string;
          candidate_model: string;
          candidate_room_id: string;
        };
        Returns: {
          reused: boolean;
          reused_result: Json | null;
          run_id: string;
        }[];
      };
      finish_menu_assistant_run: {
        Args: {
          candidate_error_code: string | null;
          candidate_error_message: string | null;
          candidate_result: Json | null;
          candidate_run_id: string;
          candidate_status: string;
        };
        Returns: undefined;
      };
      start_room_advice: {
        Args: {
          candidate_input_digest: string;
          candidate_model: string;
          candidate_room_id: string;
          candidate_source_revision: number;
        };
        Returns: {
          advice_id: string;
          advice_result: Json;
          advice_status: string;
          disposition: string;
        }[];
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<
  keyof Database,
  "public"
>];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {},
  },
} as const;
