import type { MenuAssistantResult } from "@/lib/menu-assistant";

export type MenuAssistantActionState = {
  message: string;
  result: MenuAssistantResult | null;
  status: "idle" | "error" | "limited" | "success";
};

export const initialMenuAssistantActionState: MenuAssistantActionState = {
  message: "",
  result: null,
  status: "idle",
};
