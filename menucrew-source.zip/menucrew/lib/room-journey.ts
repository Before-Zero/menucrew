import type { MenuSummary } from "@/lib/menus";

export type RoomJourneyStage = "preparing" | "collecting" | "completed";

export type RoomJourneyPrimaryAction =
  | {
      description: string;
      href: string;
      kind: "link";
      label: string;
    }
  | {
      description: string;
      kind: "waiting";
      label: string;
    };

export type RoomJourneyNavigationItem = {
  description?: string;
  href?: string;
  label: string;
  status: "available" | "waiting";
};

export type RoomJourney = {
  navigationItems: RoomJourneyNavigationItem[];
  primaryAction: RoomJourneyPrimaryAction;
  stage: RoomJourneyStage;
  stageDescription: string;
  stageLabel: string;
};

type RoomJourneyInput = {
  menu: MenuSummary | null;
  mySubmitted: boolean;
  orderConfirmed: boolean;
  role: "member" | "organizer";
  roomId: string;
  selectionStatus: string;
};

function stageFrom({
  menu,
  orderConfirmed,
}: Pick<RoomJourneyInput, "menu" | "orderConfirmed">): RoomJourneyStage {
  if (orderConfirmed) return "completed";
  if (menu?.status === "published") return "collecting";
  return "preparing";
}

function navigationFor({
  menu,
  roomId,
}: RoomJourneyInput): RoomJourneyNavigationItem[] {
  const selectionAvailable = menu?.status === "published";
  return [
    selectionAvailable
      ? { href: `/rooms/${roomId}/menu`, label: "菜单", status: "available" }
      : { description: "菜单准备中", label: "菜单", status: "waiting" },
    selectionAvailable
      ? {
          href: `/rooms/${roomId}/selection`,
          label: "我的选择",
          status: "available",
        }
      : {
          description: "菜单发布后即可填写",
          label: "我的选择",
          status: "waiting",
        },
    selectionAvailable
      ? {
          href: `/rooms/${roomId}/summary`,
          label: "本桌点单",
          status: "available",
        }
      : {
          description: "菜单发布后即可查看",
          label: "本桌点单",
          status: "waiting",
        },
  ];
}

export function getRoomJourney(input: RoomJourneyInput): RoomJourney {
  const stage = stageFrom(input);
  const navigationItems = navigationFor(input);

  if (stage === "completed") {
    return {
      navigationItems,
      primaryAction: {
        description: "发起人已确认，所有房间成员看到同一份双语订单。",
        href: `/rooms/${input.roomId}/summary`,
        kind: "link",
        label: "查看最终订单",
      },
      stage,
      stageDescription: "订单已经确认，内容不会再被修改。",
      stageLabel: "已完成",
    };
  }

  if (stage === "collecting") {
    if (input.role === "organizer") {
      return {
        navigationItems,
        primaryAction: {
          description: "实时查看大家已经点的菜，并在最后一步调整和确认。",
          href: `/rooms/${input.roomId}/summary`,
          kind: "link",
          label: "查看本桌已点并确认订单",
        },
        stage,
        stageDescription: "菜单已开放，所有人都可以继续添加或修改。",
        stageLabel: "点餐中",
      };
    }
    return {
      navigationItems,
      primaryAction: {
        description: input.mySubmitted
          ? "你已提交；发起人结束收集前仍可修改。"
          : "按本人实际想点的份数填写，保存后发起人才能汇总。",
        href: input.mySubmitted
          ? `/rooms/${input.roomId}/summary`
          : `/rooms/${input.roomId}/selection`,
        kind: "link",
        label: input.mySubmitted ? "查看本桌已点" : "开始点餐",
      },
      stage,
      stageDescription: "菜单已开放，最终订单确认前都可以修改。",
      stageLabel: "点餐中",
    };
  }

  if (input.role === "organizer") {
    return {
      navigationItems,
      primaryAction: {
        description: "先邀请大家入席，再上传菜单图片交给 AI 识别。",
        href: `/rooms/${input.roomId}/menu`,
        kind: "link",
        label: "上传菜单并开始识别",
      },
      stage,
      stageDescription: "菜单还没有发布，成员暂时不能开始选择。",
      stageLabel: "准备中",
    };
  }

  return {
    navigationItems,
    primaryAction: {
      description: "你已加入成功，发起人发布菜单后即可开始填写。",
      kind: "waiting",
      label: "等待菜单发布",
    },
    stage,
    stageDescription: "发起人正在准备菜单，发布后会开放个人选择。",
    stageLabel: "准备中",
  };
}
