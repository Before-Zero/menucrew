import "server-only";

import { getRoomAccess, type RoomAccess } from "@/lib/rooms";
import type { Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export const MENU_IMAGES_BUCKET = "menu-images";

export type Menu = Tables<"menus">;
export type MenuImage = Tables<"menu_images"> & { previewUrl: string };
export type MenuItem = Tables<"menu_items">;

export type RoomMenu = {
  access: RoomAccess;
  images: MenuImage[];
  items: MenuItem[];
  menu: Menu | null;
};

export type MenuSummary = {
  itemCount: number;
  menuId: string;
  status: Menu["status"];
};

export async function getRoomMenu(roomId: string): Promise<RoomMenu | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;

  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id,room_id,status,published_at,created_at,updated_at")
    .eq("room_id", roomId)
    .maybeSingle();

  if (menuError) {
    throw new Error("读取菜单状态失败。", { cause: menuError });
  }

  if (!menu) {
    return { access, images: [], items: [], menu: null };
  }

  const { data: items, error: itemsError } = await supabase
    .from("menu_items")
    .select(
      "id,menu_id,original_name,zh_name,en_name,description,description_en,position,created_at,updated_at",
    )
    .eq("menu_id", menu.id)
    .order("position", { ascending: true })
    .order("id", { ascending: true });

  if (itemsError) {
    throw new Error("读取菜单菜品失败。", { cause: itemsError });
  }

  if (access.currentMember.role !== "organizer") {
    return { access, images: [], items: items ?? [], menu };
  }

  const { data: imageRows, error: imagesError } = await supabase
    .from("menu_images")
    .select(
      "id,menu_id,storage_path,original_name,mime_type,byte_size,position,created_at",
    )
    .eq("menu_id", menu.id)
    .order("position", { ascending: true })
    .order("id", { ascending: true });

  if (imagesError) {
    throw new Error("读取菜单图片失败。", { cause: imagesError });
  }

  const images = await Promise.all(
    (imageRows ?? []).map(async (image) => {
      const { data, error } = await supabase.storage
        .from(MENU_IMAGES_BUCKET)
        .createSignedUrl(image.storage_path, 60 * 10);

      if (error || !data) {
        throw new Error("生成菜单图片预览失败。", { cause: error });
      }

      return { ...image, previewUrl: data.signedUrl };
    }),
  );

  return { access, images, items: items ?? [], menu };
}

export async function getRoomMenuSummary(
  roomId: string,
): Promise<MenuSummary | null> {
  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id,status")
    .eq("room_id", roomId)
    .maybeSingle();

  if (menuError) {
    throw new Error("读取菜单摘要失败。", { cause: menuError });
  }

  if (!menu) return null;

  const { count, error: countError } = await supabase
    .from("menu_items")
    .select("id", { count: "exact", head: true })
    .eq("menu_id", menu.id);

  if (countError) {
    throw new Error("读取菜品数量失败。", { cause: countError });
  }

  return {
    itemCount: count ?? 0,
    menuId: menu.id,
    status: menu.status,
  };
}
