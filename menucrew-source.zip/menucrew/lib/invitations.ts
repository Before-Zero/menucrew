import "server-only";

import { createHash, randomBytes } from "node:crypto";

export function createInviteToken() {
  return randomBytes(32).toString("base64url");
}

export function digestInviteToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function inviteCookieName(roomId: string) {
  return `menucrew-invite-${roomId}`;
}
