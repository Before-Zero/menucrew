import "server-only";

import { getRoomMenuSummary, type MenuSummary } from "@/lib/menus";
import { hasFinalOrder } from "@/lib/orders";
import { getRoomJourney, type RoomJourney } from "@/lib/room-journey";
import { getRoomAccess, type RoomAccess } from "@/lib/rooms";
import { getMySelectionSummary } from "@/lib/selections";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

export type RoomSubmissionProgress = {
  memberCount: number;
  mySubmitted: boolean;
  submittedCount: number;
};

export type RoomJourneySnapshot = {
  access: RoomAccess;
  journey: RoomJourney;
  menu: MenuSummary | null;
  orderConfirmed: boolean;
  progress: RoomSubmissionProgress;
};

export async function getRoomSubmissionProgress(
  roomId: string,
): Promise<RoomSubmissionProgress | null> {
  if (!isValidRoomId(roomId)) return null;

  const access = await getRoomAccess(roomId);
  if (!access) return null;

  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_room_submission_progress", {
    candidate_room_id: roomId,
  });

  if (error) {
    throw new Error("读取提交进度失败。", { cause: error });
  }

  const progress = data?.[0];
  if (!progress) {
    throw new Error("读取提交进度失败。", {
      cause: new Error("room_submission_progress_missing"),
    });
  }

  return {
    memberCount: progress.member_count,
    mySubmitted: progress.my_submitted,
    submittedCount: progress.submitted_count,
  };
}

export async function getRoomJourneySnapshot(
  roomId: string,
): Promise<RoomJourneySnapshot | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;

  const [menu, mySelection, orderConfirmed, progress] = await Promise.all([
    getRoomMenuSummary(roomId),
    getMySelectionSummary(roomId),
    hasFinalOrder(roomId),
    getRoomSubmissionProgress(roomId),
  ]);

  if (!progress) return null;

  return {
    access,
    journey: getRoomJourney({
      menu,
      mySubmitted: mySelection !== null,
      orderConfirmed,
      role: access.currentMember.role === "organizer" ? "organizer" : "member",
      roomId,
      selectionStatus: access.room.selection_status,
    }),
    menu,
    orderConfirmed,
    progress,
  };
}
