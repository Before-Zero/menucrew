import "server-only";

import type { Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

type Member = Tables<"room_members">;
type Room = Pick<
  Tables<"rooms">,
  | "created_at"
  | "created_by"
  | "id"
  | "invite_active"
  | "join_code"
  | "name"
  | "selection_revision"
  | "selection_status"
  | "selection_status_changed_at"
>;

export type RoomAccess = {
  currentMember: Member;
  members: Member[];
  room: Room;
};

export async function getRoomAccess(
  roomId: string,
): Promise<RoomAccess | null> {
  if (!isValidRoomId(roomId)) return null;

  const supabase = await createClient();
  const { data: claimsData, error: claimsError } =
    await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;

  if (claimsError || typeof userId !== "string") return null;

  const { data: currentMember, error: membershipError } = await supabase
    .from("room_members")
    .select("room_id,user_id,display_name,role,joined_at")
    .eq("room_id", roomId)
    .eq("user_id", userId)
    .maybeSingle();

  if (membershipError) {
    throw new Error("读取房间身份失败。", { cause: membershipError });
  }

  if (!currentMember) return null;

  const [roomResult, membersResult] = await Promise.all([
    supabase
      .from("rooms")
      .select(
        "id,name,invite_active,join_code,created_by,created_at,selection_status,selection_status_changed_at,selection_revision",
      )
      .eq("id", roomId)
      .maybeSingle(),
    supabase
      .from("room_members")
      .select("room_id,user_id,display_name,role,joined_at")
      .eq("room_id", roomId)
      .order("joined_at", { ascending: true }),
  ]);

  if (roomResult.error || membersResult.error) {
    throw new Error("读取房间数据失败。", {
      cause: roomResult.error ?? membersResult.error,
    });
  }

  if (!roomResult.data) return null;

  return {
    currentMember,
    members: membersResult.data ?? [],
    room: roomResult.data,
  };
}
