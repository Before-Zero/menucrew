import "server-only";

import { getRoomAccess, type RoomAccess } from "@/lib/rooms";
import type { Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export type MySelection = {
  access: RoomAccess;
  items: Tables<"menu_items">[];
  menu: Pick<Tables<"menus">, "id" | "room_id" | "status"> | null;
  selectionByItemId: Record<
    string,
    Pick<Tables<"member_selections">, "note" | "quantity">
  >;
  submission: Tables<"member_submissions"> | null;
};

export type MySelectionSummary = {
  dishCount: number;
  submittedAt: string;
  totalQuantity: number;
};

export async function getMySelection(
  roomId: string,
): Promise<MySelection | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;

  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id,room_id,status")
    .eq("room_id", roomId)
    .maybeSingle();

  if (menuError) {
    throw new Error("读取选择菜单失败。", { cause: menuError });
  }

  const published = menu?.status === "published";
  const itemsResult = published
    ? await supabase
        .from("menu_items")
        .select(
          "id,menu_id,original_name,zh_name,en_name,description,description_en,position,created_at,updated_at",
        )
        .eq("menu_id", menu.id)
        .order("position", { ascending: true })
        .order("id", { ascending: true })
    : { data: [], error: null };

  if (itemsResult.error) {
    throw new Error("读取可选菜品失败。", { cause: itemsResult.error });
  }

  const { data: submission, error: submissionError } = await supabase
    .from("member_submissions")
    .select(
      "id,room_id,user_id,dietary_restrictions,allergy_info,submitted_at,created_at,updated_at",
    )
    .eq("room_id", roomId)
    .eq("user_id", access.currentMember.user_id)
    .maybeSingle();

  if (submissionError) {
    throw new Error("读取本人提交失败。", { cause: submissionError });
  }

  const selectionsResult = submission
    ? await supabase
        .from("member_selections")
        .select("menu_item_id,quantity,note")
        .eq("submission_id", submission.id)
    : { data: [], error: null };

  if (selectionsResult.error) {
    throw new Error("读取本人菜品选择失败。", {
      cause: selectionsResult.error,
    });
  }

  const currentItemIds = new Set(
    (itemsResult.data ?? []).map((item) => item.id),
  );
  const selectionByItemId = Object.fromEntries(
    (selectionsResult.data ?? [])
      .filter((selection) => currentItemIds.has(selection.menu_item_id))
      .map((selection) => [
        selection.menu_item_id,
        { note: selection.note, quantity: selection.quantity },
      ]),
  );

  return {
    access,
    items: itemsResult.data ?? [],
    menu: menu ?? null,
    selectionByItemId,
    submission: submission ?? null,
  };
}

export async function getMySelectionSummary(
  roomId: string,
): Promise<MySelectionSummary | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;

  const supabase = await createClient();
  const { data: submission, error } = await supabase
    .from("member_submissions")
    .select("id,submitted_at")
    .eq("room_id", roomId)
    .eq("user_id", access.currentMember.user_id)
    .maybeSingle();

  if (error) throw new Error("读取本人选择状态失败。", { cause: error });
  if (!submission) return null;

  const { data: selections, error: selectionsError } = await supabase
    .from("member_selections")
    .select("quantity")
    .eq("submission_id", submission.id);

  if (selectionsError) {
    throw new Error("读取本人选择摘要失败。", { cause: selectionsError });
  }

  return {
    dishCount: selections?.length ?? 0,
    submittedAt: submission.submitted_at,
    totalQuantity: (selections ?? []).reduce(
      (sum, selection) => sum + selection.quantity,
      0,
    ),
  };
}
