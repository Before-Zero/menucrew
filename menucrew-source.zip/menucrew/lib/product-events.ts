import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

export type ProductEvent =
  | "room_created"
  | "room_joined"
  | "menu_published"
  | "selection_saved"
  | "order_confirmed"
  | "ai_requested"
  | "ai_succeeded"
  | "ai_failed";

export async function recordProductEvent(
  event_name: ProductEvent,
  room_id: string,
) {
  const { error } = await createAdminClient()
    .from("product_events")
    .insert({ event_name, room_id });
  if (error)
    console.error("product event failed", { event_name, code: error.code });
}
