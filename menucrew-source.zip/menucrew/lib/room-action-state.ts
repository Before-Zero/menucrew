import type { FieldErrors } from "@/lib/validation";

export type RoomActionState = {
  fields?: FieldErrors;
  message?: string;
  status: "error" | "idle";
};

export const INITIAL_ROOM_ACTION_STATE: RoomActionState = { status: "idle" };
