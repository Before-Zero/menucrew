import "server-only";

import { getRoomAggregation } from "@/lib/aggregation";
import { getRoomAccess, type RoomAccess } from "@/lib/rooms";
import type { Tables } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";

export type FinalOrderItem = Tables<"order_items">;
export type FinalOrderDietaryNote = {
  allergyEn: string;
  allergyInfo: string;
  allergyZh: string;
  dietaryEn: string;
  dietaryRestrictions: string;
  dietaryZh: string;
  displayName: string;
};
export type FinalOrder = {
  access: RoomAccess;
  items: FinalOrderItem[];
  order: Omit<Tables<"orders">, "dietary_notes"> & {
    dietary_notes: FinalOrderDietaryNote[];
  };
};
export type OrderCandidate = {
  contributors: string[];
  description: string;
  descriptionEn: string;
  enName: string;
  id: string;
  originalName: string;
  position: number;
  requestedQuantity: number;
  zhName: string;
};
export type OrderPageData = {
  access: RoomAccess;
  candidates: OrderCandidate[];
  dietaryNotes: FinalOrderDietaryNote[];
  finalOrder: FinalOrder | null;
};

function parseDietaryNotes(value: unknown): FinalOrderDietaryNote[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const candidate = entry as Record<string, unknown>;
    if (
      typeof candidate.displayName !== "string" ||
      typeof candidate.dietaryRestrictions !== "string" ||
      typeof candidate.allergyInfo !== "string"
    )
      return [];
    return [
      {
        allergyEn:
          typeof candidate.allergyEn === "string" ? candidate.allergyEn : "",
        allergyInfo: candidate.allergyInfo,
        allergyZh:
          typeof candidate.allergyZh === "string" ? candidate.allergyZh : "",
        dietaryEn:
          typeof candidate.dietaryEn === "string" ? candidate.dietaryEn : "",
        dietaryRestrictions: candidate.dietaryRestrictions,
        dietaryZh:
          typeof candidate.dietaryZh === "string" ? candidate.dietaryZh : "",
        displayName: candidate.displayName,
      },
    ];
  });
}

async function readOrder(access: RoomAccess): Promise<FinalOrder | null> {
  const supabase = await createClient();
  const { data: order, error } = await supabase
    .from("orders")
    .select(
      "id,room_id,source_revision,confirmed_by,confirmed_at,dietary_notes",
    )
    .eq("room_id", access.room.id)
    .maybeSingle();
  if (error) throw new Error("读取最终订单失败。", { cause: error });
  if (!order) return null;
  const { data: items, error: itemsError } = await supabase
    .from("order_items")
    .select(
      "id,order_id,menu_item_id,original_name,zh_name,en_name,requested_quantity,final_quantity,member_names,note,position",
    )
    .eq("order_id", order.id)
    .order("position")
    .order("id");
  if (itemsError) throw new Error("读取订单菜品失败。", { cause: itemsError });
  return {
    access,
    items: items ?? [],
    order: { ...order, dietary_notes: parseDietaryNotes(order.dietary_notes) },
  };
}

export async function getFinalOrder(
  roomId: string,
): Promise<FinalOrder | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;
  return readOrder(access);
}

export async function getOrderPageData(
  roomId: string,
): Promise<OrderPageData | null> {
  const access = await getRoomAccess(roomId);
  if (!access) return null;
  const finalOrder = await readOrder(access);
  if (finalOrder || access.currentMember.role !== "organizer") {
    return {
      access,
      candidates: [],
      dietaryNotes: finalOrder?.order.dietary_notes ?? [],
      finalOrder,
    };
  }

  const aggregation = await getRoomAggregation(roomId);
  if (!aggregation) return null;
  const supabase = await createClient();
  const { data: menu, error: menuError } = await supabase
    .from("menus")
    .select("id")
    .eq("room_id", roomId)
    .maybeSingle();
  if (menuError) throw new Error("读取订单菜单失败。", { cause: menuError });
  const { data: items, error: itemsError } = menu
    ? await supabase
        .from("menu_items")
        .select(
          "id,original_name,zh_name,en_name,description,description_en,position",
        )
        .eq("menu_id", menu.id)
        .order("position")
        .order("id")
    : { data: [], error: null };
  if (itemsError)
    throw new Error("读取订单候选菜品失败。", { cause: itemsError });
  const dishById = new Map(aggregation.dishes.map((dish) => [dish.id, dish]));
  return {
    access,
    candidates: (items ?? []).map((item) => {
      const dish = dishById.get(item.id);
      return {
        contributors:
          dish?.contributors.map((person) => person.displayName) ?? [],
        description: item.description,
        descriptionEn: item.description_en,
        enName: item.en_name,
        id: item.id,
        originalName: item.original_name,
        position: item.position,
        requestedQuantity: dish?.totalQuantity ?? 0,
        zhName: item.zh_name,
      };
    }),
    dietaryNotes: aggregation.members.flatMap((member) =>
      member.submittedAt && (member.dietaryRestrictions || member.allergyInfo)
        ? [
            {
              allergyEn: "",
              allergyInfo: member.allergyInfo,
              allergyZh: "",
              dietaryEn: "",
              dietaryRestrictions: member.dietaryRestrictions,
              dietaryZh: "",
              displayName: member.displayName,
            },
          ]
        : [],
    ),
    finalOrder: null,
  };
}

export async function hasFinalOrder(roomId: string): Promise<boolean> {
  const access = await getRoomAccess(roomId);
  if (!access) return false;
  const supabase = await createClient();
  const { data } = await supabase
    .from("orders")
    .select("id")
    .eq("room_id", roomId)
    .maybeSingle();
  return Boolean(data);
}
