export type OrderActionState = {
  message: string;
  orderId: string | null;
  status: "idle" | "success" | "error";
};

export const initialOrderActionState: OrderActionState = {
  message: "",
  orderId: null,
  status: "idle",
};
