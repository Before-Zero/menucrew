# 项目协作指南

> 本文件是后续开发的文档起点。任何影响架构、依赖、目录、命令或协作约定的变更，都必须随开发进度实时更新到这里。

项目开发的最高级别约束见[项目宪章](.specify/memory/constitution.md)，规格、计划、任务和实现均须遵守。

## 技术栈

- Next.js 16（App Router）与 React 19
- TypeScript 5、Tailwind CSS 4
- shadcn/ui（Radix）与 lucide-react
- Biome 2（格式化、Lint 与安全自动修复）
- Husky、lint-staged（提交前卡控）
- GitHub Spec Kit（规格驱动开发）
- Supabase（`@supabase/supabase-js` 与 `@supabase/ssr`）
- `qrcode` 1.5.4（只在服务端生成房间邀请二维码）

## 项目速览

- `app/`：路由、布局与全局样式。
- `app/flat-lab/`：不影响正式流程的扁平视觉实验页；用可切换的餐桌几何场景比较首页、菜单、选菜与汇总落单的新美学表达。
- `app/demo/`：无需注册或创建测试数据的一键只读演示；先用“看懂菜单、各自选择、一起落单”解释产品问题与三步流程，再展示三人选择汇成双语最终订单的结果，并保留餐厅/中文切换与复制能力。
- `app/opengraph-image.tsx`、`app/layout.tsx`：生成 1200×630 的品牌分享卡片，并补齐 Open Graph 与大图分享元数据。
- `app/actions.ts`：创建房间与加入房间的 Server Actions。
- `app/join/[token]/`：不预先泄露房间信息的邀请加入页。
- `app/join/`：无需扫码的六位数字入席页；与链接、二维码并存，验证成功前不展示房间信息。
- `app/rooms/[roomId]/`：按房间成员关系区分的房间、个人选择、确定性汇总与最终订单页面。
- `app/rooms/[roomId]/`：房间根页是按发起人/参与者和当前阶段派生的工作台，不再是功能目录；创建、发布、加入、进入核对与确认订单会连续进入下一任务。
- `app/rooms/[roomId]/order/`：组织者调整最终数量并确认快照；确认后全体成员读取同一订单，并在精简餐厅视图与中文核对视图间切换。
- `app/rooms/[roomId]/menu/`：组织者私密菜单工作区与成员已发布菜单视图。
- `app/rooms/[roomId]/menu/ai-actions.ts`：组织者启动 AI 识别及明确应用候选的 Server Actions。
- `app/rooms/[roomId]/selection/`：组织者与成员共用的本人实际数量、备注和饮食限制页面及原子保存 Action。
- `app/rooms/[roomId]/summary/`：全体成员共用的“本桌点单”入口；确认前展示成员安全实时汇总，组织者在同页获得私有核对层，确认后展示稳定最终订单。
- `app/rooms/[roomId]/receipt/`、`app/api/rooms/[roomId]/receipt/`：旧页面安全转向“本桌点单”；原 no-store 成员安全 API 继续作为共享页内部轮询边界，只返回正数量汇总与本人数量。
- `app/rooms/[roomId]/selection/assistant-actions.ts`：点餐内的个人 AI 搭配与次要单菜说明；结构化推荐只使用已发布菜单和本人上下文，应用后仍须用户主动保存。
- `components/menu-assistant-sheet.tsx`：在个人 AI 点餐搭配中提供浏览器语音转文字入口；Chrome/Edge 等支持 Web Speech API 的环境可直接说出想吃什么，不支持或拒绝麦克风权限时完整保留文字输入兜底。
- `app/rooms/[roomId]/summary/advice-actions.ts`：组织者进入汇总后自动生成、复用或安全结束整桌建议的 Server Action。
- `app/rooms/[roomId]/summary/translation-actions.ts`、`components/dietary-translation-panel.tsx`、`lib/dining-note-translation.ts`：组织者明确点击后，将已提交的忌口与过敏原文生成餐厅英文和简体中文对照；只发送匿名编号与备注内容，不发送显示名或用户 ID，不覆盖或持久化翻译。
- `app/loading.tsx`、`app/error.tsx`、`app/global-error.tsx`：全应用路由加载、可重试异常和根布局故障兜底；加载态明确说明正在读取菜单与最新选择，海外网络可能需要数秒且页面会自动进入，不人为增加等待时间。
- `app/account/`、`app/auth/callback/`、`components/account-panel.tsx`：可选账户入口；游客可通过邮箱安全链接原地保存当前匿名身份，返回用户可找回自己发起和参与过的餐桌，未注册用户的核心点餐流程保持不变。
- `app/api/rooms/[roomId]/menu-images/`：签发私有图片直传 token、登记对象元数据和精确删除图片。
- `components/dining-route-transition.tsx`：只在“准备菜单 / 各自选菜 / 汇总落单”跨阶段时用控制点扩张和收束完成约 1.1 秒的章节转场；抵达阶段会等待新页面左上角主步骤控制点稳定后精确收束，同阶段路由使用约 420ms 的细墨线过渡。
- `components/room-ambient-words.tsx`：按菜单、选菜、汇总阶段切换低对比多语言短句，延续首页语言地形；不接收交互，移动端减少数量，减少动态时停止漂移。
- `components/home-cover.tsx`、`components/home-cover.module.css`：首页语言引力场在桌面根据指针距离产生分层避让与中心景深，触屏保持自动漂移；首个控制点作为进入三阶段路线的视觉起点。
- `components/menu-image-uploader.tsx`、`components/menu-ai-panel.tsx`：实现菜单显影台的等待、已选、处理中、完成与失败五态；真实原图、扫描线、墨点路线和双语候选共享同一工作区，减少动态时保留静态状态。
- `components/dynamic-receipt.tsx`、`components/final-order-view.tsx`、`components/final-order-dietary-notes.tsx`：实时点单以桌面记录纸呈现，最终确认时三路选择收束为双语订单小票；落单时固化的忌口/过敏快照同步进入餐厅视图、中文核对和复制文本。
- `components/room-realtime-refresh.tsx`、`components/dynamic-receipt.tsx`、`components/wait-for-menu-refresh.tsx`：通过仅发布成员可读的 `rooms`/`menus` 变更即时触发安全重读；房间版本变化后约 120ms 合并刷新，同时保留 15 秒低频轮询与回到前台刷新作为断线兜底。
- `components/menu-assistant-sheet.tsx`、`components/selection-item-card.tsx`：AI 以桌边侍者批注纸即时展开；个人数量变化通过路线点填墨、数字翻页和“已选”批注反馈，所有操作保持可键盘访问与 reduced-motion 静态方案。
- `components/ui/`：由 shadcn/ui 管理的基础组件源码。
- `components/organizer-room-dashboard.tsx`、`components/member-room-dashboard.tsx`、`components/room-journey-nav.tsx`：分别呈现两种角色的当前进度、唯一主要操作和角色收窄导航。
- `lib/`：共享工具函数。
- `lib/rooms.ts`：使用当前匿名身份和 RLS 读取房间、本人角色及成员列表。
- `lib/room-journey.ts`：从已有菜单、收集和订单事实派生“准备中、收集中、核对中、已完成”及角色主操作，不保存第二份业务状态。
- `lib/i18n.ts`、`lib/i18n-server.ts`：每个浏览器独立的简体中文/English 偏好、房间旅程文案和菜品安全回退；首页、加入、房间、菜单、个人选择、汇总与最终订单主流程均跟随切换。
- `lib/member-receipt.ts`：调用收窄 RPC 读取成员安全的实时小票。
- `lib/menu-assistant.ts`：构建最小化菜单问答输入，通过统一 AI 供应商边界生成建议，兼容安全 JSON 包装并严格校验单轮结构化回答。
- `lib/room-progress.ts`：读取成员安全的提交人数摘要并组合房间旅程快照；普通成员只能得到计数和本人状态。
- `lib/menus.ts`：按角色读取草稿/已发布菜单，并仅为组织者生成私有图片短时预览。
- `lib/menu-ai.ts`：在服务端摘要并读取私有图片，通过统一 AI 供应商边界调用视觉模型，严格校验并读取识别候选。
- `lib/ai-provider.ts`：四项 AI 能力共用的服务端供应商边界；默认使用 DeepSeek V4 Flash 与 V4 Flash Vision，统一超时、JSON 输出、匿名功能标签与不含用户内容的错误日志，并可通过 `AI_PROVIDER=gateway` 切到 Vercel AI Gateway 多模型路由。
- `lib/selections.ts`：通过本人 RLS 读取当前身份的唯一提交、有效菜品选择和本人摘要。
- `lib/aggregation.ts`：仅供组织者读取本房间全员提交，并用 Map 与整数加法构建即时确定性汇总。
- `lib/orders.ts`：构建组织者确认候选，或通过成员 RLS 读取唯一、不可变的最终订单快照。
- `lib/table-advice.ts`：构建匿名确定性汇总快照、计算输入摘要，通过统一 AI 供应商边界生成并严格校验整桌建议。
- `app/api/maintenance/rooms/`、`vercel.json`：每天分批清理连续 30 天无活动的房间；先通过 Storage API 删除私有图片，再级联删除房间数据。
- `lib/product-events.ts`：服务端写入不含用户正文和身份信息的核心流程事件，普通客户端无读写权限。
- `specs/013-fast-ai-waiter-order/`：收紧个人与整桌 AI 建议的等待和输出边界，并定义同一最终订单的餐厅/中文双视图。
- `specs/016-optional-table-identity/`：定义“游客始终可用、账户只提供沉淀价值”的可选身份升级、我的餐桌和后续待接受快捷邀请。
- `lib/supabase/client.ts`：浏览器端 Supabase client。
- `components/room-form.tsx`：创建和加入房间前优先在访客浏览器建立匿名会话；Server Action 先复用刚写入的 Cookie 会话，再在确无会话时自行鉴权，既保留无需注册的流程，也避免重复匿名登录和共享部署服务器出口的限额。
- `app/actions.ts`：创建和两种加入路径在业务完成后使用 Next.js `after` 记录匿名产品事件，分析写入失败不再阻塞房间跳转。
- `lib/supabase/server.ts`：Server Component、Server Action 与 Route Handler 使用的请求级 Supabase client。
- `lib/supabase/admin.ts`：仅服务端使用 secret key 的高权限 Supabase client。
- `lib/supabase/database.types.ts`：从云项目生成的数据库 TypeScript 类型。
- `proxy.ts`、`lib/supabase/proxy.ts`：Next.js 16 请求入口与 Supabase SSR 会话刷新。
- `supabase/migrations/`：可追踪数据库迁移；`001`–`010` 覆盖房间、菜单、提交、汇总、订单和 AI 边界；`011` 在最终订单中固化成员忌口/过敏快照，保持确认后全员一致且不可修改。
- `supabase/migrations/20260829142504_add_numeric_room_code.sql`：为每间房补齐唯一六位入席码，允许游客与已保存账户通过链接或数字码加入同一房间。
- `supabase/migrations/20260915042839_enable_room_realtime.sql`：把 `rooms` 与 `menus` 纳入 Supabase Realtime publication；浏览器仍受既有成员关系 RLS 与列级授权约束，不广播选择正文、备注或身份数据。
- `scripts/create-test-room.mjs`：通过正式匿名认证和 RPC 建立隔离测试房间与成员。
- `scripts/create-test-menu.mjs`：创建隔离房间、私有图片、8 道菜和已发布菜单，并断言成员可见性。
- `scripts/create-test-selections.mjs`：创建 3 个隔离成员提交并断言固定数量、零数量移除、本人读取、直接写入拒绝和原子回滚。
- `scripts/create-test-aggregation.mjs`：创建 5 名成员和 8 道菜，断言固定人工总数、组织者全员读取、成员隔离、关闭/重开和跨房间拒绝。
- `scripts/create-test-order.mjs`：创建固定汇总并断言最终调整、5 次幂等确认、成员一致读取、快照不可变与越权拒绝。
- `scripts/create-test-menu-ai.mjs`：断言候选隐私、相同输入复用、24 小时限额、失败保护、原子应用和人工修正保护。
- `scripts/create-test-table-advice.mjs`：断言建议前后业务数据不变、结构化过敏冲突、成员隔离、相同输入复用、修订过期和 24 小时限额。
- `scripts/create-demo-room.mjs`：通过正式匿名认证与 RLS 创建三名合成成员、8 道双语菜、提交与已确认订单的完整演示房间。
- `.specify/`：Spec Kit 模板与 PowerShell 自动化脚本。
- `.husky/pre-commit`：提交前执行暂存文件检查与全量类型检查。

## 常用命令

- `npm run dev`：启动本地开发服务器。
- `npm run check:fix`：格式化并执行 Biome 安全修复。
- `npm run seed:room`：使用 `.env.local` 的公开 Supabase 变量创建一间真实测试房间和两个匿名测试身份。
- `npm run seed:menu`：使用公开变量创建并验证一套真实 002 菜单数据。
- `npm run seed:selection`：使用公开变量创建并验证一套真实 003 三身份个人选择数据。
- `npm run seed:aggregation`：使用公开变量创建并验证一套真实 004 精确汇总和收集控制数据。
- `npm run seed:order`：使用公开变量创建并验证一套真实 005 最终订单快照和权限数据。
- `npm run seed:menu-ai`：使用公开变量创建并验证 006 AI 候选的数据边界，不消耗 Gemini 调用。
- `npm run seed:advice`：使用公开变量创建并验证 007 整桌建议的数据边界，不消耗 Gemini 调用。
- `npm run seed:demo`：创建一套不含真实个人数据的完整 Demo 房间、菜单、提交与最终订单。
- `npm run typecheck`：执行 TypeScript 类型检查。
- `npm run verify`：执行只读 Biome 检查和类型检查。
- `npm run build`：创建生产构建。

## 提交卡控

提交时，lint-staged 会对暂存的代码、JSON 与 CSS 运行 `biome check --write`；Biome 默认只应用安全修复。随后执行 `tsc --noEmit`。任一步失败都会阻止提交，不要使用 `--no-verify` 绕过。

## Vercel 发布

- Vercel 项目：`david-ac9d/menucrew-demo`；Production：`https://menucrew-demo.vercel.app`。
- 当前 Production V13：`dpl_7mu74kxQNupFocvP7CizKCTKTJaw`（`https://menucrew-demo.vercel.app`）；首页游客账户入口统一为“登录 / 注册”，邮箱页同步为无密码登录/新邮箱注册语义；一键 Demo 先解释海外多人点餐问题及“看懂菜单、各自选择、一起落单”三步，再明确衔接最终双语订单；全局真实加载态改为克制的中英等待提示，不人为增加停留时间；本地/云端构建、桌面/手机视觉、正式 Demo 响应及生产错误扫描通过。
- 当前 V13 Preview：`dpl_4L7eUX8yGsGcDA6SsVNrw688w3ec`（`https://menucrew-demo-a1yskqccg-david-ac9d.vercel.app`）；与 Production V13 同源并完成 Deployment Protection 下的 Demo 响应检查。
- 当前 Production V12：`dpl_DqT9rhfRry3GCryNVYwBNqgS6AUB`（`https://menucrew-demo.vercel.app`）；首页新增无需注册的一键完整示例，房间版本与菜单发布改用 Supabase Realtime 即时触发安全重读并保留 15 秒兜底刷新，补齐 Open Graph/Twitter 大图分享卡片；本地/云端构建、桌面/手机视觉、正式 Demo 与分享图片响应及生产错误扫描已通过。
- 当前 V12 Preview：`dpl_Eyyv8h2mpv3VHffhiEmfbwMwjNTg`（`https://menucrew-demo-676zu01wt-david-ac9d.vercel.app`）；与 Production V12 同源并完成 Deployment Protection 下的 Demo 与分享图片响应检查。
- 当前 Production V11：`dpl_GWaKo1TtaEVnYtMPt21qKhMvSAgm`（`https://menucrew-demo.vercel.app`）；菜单识别、个人推荐、整桌建议和忌口翻译改为统一服务端 AI 供应商边界，默认使用 DeepSeek V4 Flash 与 V4 Flash Vision，密钥仅存在 Vercel Secret，保留可选 AI Gateway 路由；本地/云端构建与正式域名响应已通过，供应商真实内容调用待从正式业务页面触发确认。
- 当前 V11 Preview：`dpl_E38NufHHu4mdnu9zmiRtDDk9rSSG`（`https://menucrew-demo-rlu6e6kkz-david-ac9d.vercel.app`）；与 Production V11 同源并完成构建、类型、Biome 和受保护首页响应检查。
- 当前 Production V10：`dpl_Gvhvm5Tf2o1cgzo3uyDxTQ2ktS6E`（`https://menucrew-demo.vercel.app`）；移除最终确认区误显的内部“7”控制点，个人 AI 助手改为 35 秒总上限、低推理强度和一次后端退避重试，补齐语言切换、退出登录及菜单图片异常后的 loading 复位；Impeccable sidecar 已与三步对外旅程及当前动效规范同步。
- 当前 V10 Preview：`dpl_BxcXDuTaYeAQzuh2F7r6uN3MiZ4x`（`https://menucrew-demo-ceg6o94ny-david-ac9d.vercel.app`）；与 Production V10 同源并完成本地/云端构建、正式域名响应和生产错误扫描。
- 当前 Production V9：`dpl_HC7ZqwGNY5hatR9Ua6ZuoGrQgQwf`（`https://menucrew-demo.vercel.app`）；菜单识别成功后移除重复确认勾选和冗长说明，改为单一全宽“发布菜单”动作，AI 发布与手动发布入口不再同时出现；缺少菜品时发布区会直接引导到已展开的编辑入口。
- 当前 V9 Preview：`dpl_FCMx7EJVZXm8Nzkdi97xFktarnr4`（`https://menucrew-demo-fij89m28v-david-ac9d.vercel.app`）；与 Production V9 同源并完成本地/云端构建、首页响应及生产错误扫描。
- 当前 Production V8：`dpl_A3862yeuo3hnjCFvhm1iCMKap3y9`（`https://menucrew-demo.vercel.app`）；增加可选邮箱身份、我的餐桌、首页账户入口与六位数字入席，二维码和邀请链接继续保留；房间事件改为响应后记录。
- 上一份 Production V7：`dpl_AmXCaFiEmLN8EdwUrE2wDh2p54pZ`；最终订单自动补齐餐厅英文与中文核对译文，整桌 AI 超时或失败记录不再留在用户页面。
- 当前 V8 Preview：`dpl_FswMcpCfc1qfUk2ZD9KEgiTtoG3D`（`https://menucrew-demo-o6czg6pgc-david-ac9d.vercel.app`）；可选账户与六位入席码视觉、路由和构建验收通过。
- 上一份 Production V6：`dpl_7nrRk75T7w9pzfFU6apVfN42xq6J`；首页改为地图标注式中英文切换，章节转场收束到左上角主步骤控制点，最终确认使用正数量菜品种类，并把忌口/过敏快照带入最终订单双视图与复制文本。
- 当前 V6 Preview：`dpl_Ccnby1qg22wnWpCmvUU6wizn1RNc`（`https://menucrew-demo-h4tezd28p-david-ac9d.vercel.app`）；与 Production V6 同源并完成构建、桌面/手机首页和正式域名响应检查。
- 上一份 Voice + Translation + English Preview：`dpl_8WY4KLvmCMrSsEULSupsWBRUAdJL`（`https://menucrew-demo-aff4xtf65-david-ac9d.vercel.app`）。
- 上一份 Production V3：`dpl_BkhtzVDkRZDZ3F292V5JLBbRjWsd`；浏览器优先匿名入席与第一版从容动效节奏已上线。
- 上一份已知可用 Production 010：`dpl_DvBBYBmQYiGzebYVh5JrD1m7Wa6V`；上一份已知可用 009：`dpl_89yEdvdzmyv68WJQ5nzvrN4Hr5xr`。
- 当前 Color Lab Preview：`dpl_BTBmLYF6MyUA6TnLbYomZtBG2o13`（`https://menucrew-demo-k2vbc1g44-david-ac9d.vercel.app/color-lab`）；本地实验新增默认“夜航青”，并保留“青花护照”与“午夜餐桌”作为对照，覆盖首页、菜单识别、选菜、最终落单及桌面/手机预览，未替换正式页面。
- 当前 V5.2 Preview：`dpl_HA54ucy32jDeLTfv9f32j634gjmj`（`https://menucrew-demo-qd6wqsxgb-david-ac9d.vercel.app`）；浏览器原生最终确认框已替换为 Menu Crew 收据纸式落单确认，汇总直提与人工调量两条路径统一使用，Production 尚未替换。
- 上一份 V5.1 Preview：`dpl_69qg3v4PDDt8rCmfuUjPqHHLy6So`（`https://menucrew-demo-b0piq3vfw-david-ac9d.vercel.app`）；动效节奏放缓版本，已从同一构建提升为 Production V5。
- 上一份 V5 Preview：`dpl_5okRQRqwtkBsxUrz78dzQ9kEq2NT`（`https://menucrew-demo-pix6s52oq-david-ac9d.vercel.app`）；首页创建房间会先播放语言退场与按钮起点餐桌路线，再进入房间并补播抵达反馈，同时修复浏览器匿名会话复用。
- 上一份 V4 Preview：`dpl_fEAgzESXeFjCW2L1LmKVnvWDcCU7`（`https://menucrew-demo-4nl3ty5x8-david-ac9d.vercel.app`）；三阶段分层转场、阶段化多语言背景、菜单墨迹显影、选菜填墨反馈、侍者批注式 AI、汇流轨道和小票纸品升级已加入。
- 上一份流程统一 Preview：`dpl_3NaKMA1gfH7UzoxPhu5yyBFX5MjQ`（`https://menucrew-demo-oqz6zuwf6-david-ac9d.vercel.app`）。
- 上一份 V3 Preview：`dpl_8jVW2A7HB9JbbSVNa23QgzUTxj8B`（`https://menucrew-demo-rerj2ucxn-david-ac9d.vercel.app`）。
- 当前仓库没有 Git 远端；008 使用固定版本 `npx vercel@59.3.0` 在单根目录显式绑定并直连发布。
- 先执行 Preview 部署、`vercel inspect` 与 `vercel curl`；Preview 通过后使用 `vercel promote <preview-url> --yes` 提升同一构建。
- Preview 保持 Deployment Protection 开启，不为自动化验收关闭保护；完整双浏览器链路在 Production 执行。
- Production 发布后使用 `vercel logs --environment production --level error` 扫描运行错误；详细步骤、环境变量名称和回退锚点见 `specs/008-online-demo-release/release-runbook.md`。
- 客户端会参与渲染的日期文字必须指定明确 `timeZone`，避免 Vercel 服务器与浏览器默认时区不同导致 hydration mismatch；当前发布界面统一显示 UTC 并显式标注。

## Supabase

- 云项目：`vibe-coding-course`（项目 ref：`xxbuibqbcqfozifrwors`，区域：`ap-southeast-1`）。
- 001 依赖 Dashboard 的 **Authentication > Sign In / Providers > Anonymous Sign-Ins** 开关；未开启时创建和加入会返回 `Anonymous sign-ins are disabled`。
- 016 依赖 Email 登录、匿名用户手动身份链接和正式回调地址 `https://menucrew-demo.vercel.app/auth/callback`；游客通过邮箱升级时必须保留同一 `auth.users.id`，不得用重新注册替换当前匿名身份。
- 本地运行所需变量放在不会提交的 `.env.local`；可提交的变量模板见 `.env.example`。
- 浏览器端和普通 SSR 请求只使用 `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`。
- `SUPABASE_SECRET_KEY` 拥有绕过 RLS 的高权限，只允许由 `lib/supabase/admin.ts` 在可信服务端代码中使用，严禁添加 `NEXT_PUBLIC_` 前缀或提交真实值。
- 首次使用管理 client 前，到 Supabase Dashboard 的 **Settings > API Keys** 复制 `sb_secret_...`，手动填入 `.env.local` 的 `SUPABASE_SECRET_KEY=` 后面，然后重启开发服务器。
- 新建暴露给 Data API 的表时必须显式授权并启用 RLS；不要假设 `public` schema 中的新表会自动暴露。
- `rooms` 与 `room_members` 的业务读取由房间成员关系 RLS 控制；浏览器不能直接写表，创建/加入只通过验证 `auth.uid()` 的收窄 RPC。
- 组织者/成员角色只保存在 `room_members.role`，严禁使用显示名或用户可编辑 metadata 授权。
- 房间邀请使用 32 字节随机 token；数据库只保存 SHA-256 摘要，组织者浏览器以 HttpOnly Cookie 保存原值，成员加入成功后地址不得继续包含 token。
- `menu-images` 始终为私有桶：仅组织者在草稿期获得随机路径的短时上传 token；原图和元数据永不向成员开放。
- 每房间唯一菜单；只有草稿可改图片和菜品，至少 1 张图片和 1 道完整菜才能发布，已发布菜单必须先退回草稿再编辑。
- 菜品发布顺序由 `position`、`id` 稳定排序；菜单原文、简体中文名与解释均由组织者人工维护，002 不包含 AI、价格或自动发布。
- `member_submissions` 每名成员每房间唯一，保存整体忌口、过敏信息和最近提交时间；`member_selections` 只保存 1–20 的正数量与单菜备注，数量 0 必须删除明细。
- 普通成员始终只能读取本人提交；004 起组织者可通过房间角色 RLS 只读本房间全员提交与明细。客户端没有两张选择表的直接写权限。
- 009 的 `get_room_submission_progress` 仅允许本房间成员调用，使用收窄 security-definer 边界返回成员总数、已提交数和本人是否提交；不得返回用户 ID、显示名、选择、备注、忌口、过敏信息或提交时间。
- 010 的 `get_member_receipt` 只向已提交成员返回菜品和数量；不返回他人身份、备注、忌口、过敏或提交时间。
- 010 的 `confirm_final_order_direct` 在同一事务中锁住房间、更新修订并确认快照；界面不再提供“关闭点餐”作为必经阶段。
- 010 菜单助手不读取私有图片和他人提交，不保存明文问题、饮食上下文或对话历史；相同摘要复用，每房间滚动 24 小时最多 10 次新请求。
- 邀请二维码在服务端直接由完整邀请 URL 生成 data URL；禁止把 token 发给外部二维码服务。
- 房间收集状态只有 `open` 与 `reviewing`；组织者通过收窄 RPC 切换。状态切换与 `save_my_selection` 都先锁同一房间行，核对中数据层整次拒绝保存；成功保存和有效状态切换递增 `selection_revision`。
- 004 汇总不保存副本、不调用 AI：服务端只纳入当前菜单有效菜品和正数量，用普通整数加法即时重建；005 才负责最终订单快照。
- 每房间最多一份最终订单；组织者只能在 `reviewing` 状态按当前修订原子确认。快照由数据库从真实菜单和成员提交派生，确认后不可修改、不可重开，房间成员只读同一份双语结果。
- 006 的菜单图片识别使用 DeepSeek Chat Completions 的内联图片与 JSON 输出；默认视觉模型 `deepseek-v4-flash-vision-exp`，可用仅服务端 `DEEPSEEK_VISION_MODEL` 覆盖。
- `DEEPSEEK_API_KEY` 只允许存在于本地或 Vercel 服务端环境；不得使用 `NEXT_PUBLIC_` 前缀、写入客户端资源、日志或仓库。`AI_PROVIDER=gateway` 是可选备用模式，只有 Vercel AI Gateway 完成账户验证后才启用。
- Gemini 免费层提交的内容可能用于改进 Google 产品；UI 必须明确提示，只使用适合演示的菜单图片。免费层额度以 Google AI Studio 当前显示的项目限额为准。
- AI 结果先写入仅组织者可读的 `menu_ai_runs`，相同图片摘要复用，每房间滚动 24 小时最多 5 次新记录；只有明确应用才替换草稿菜品，仍需人工修正和主动发布。
- 菜单图片签名链接只在单次服务端请求内存活，不保存 URL 或 Base64；AI 失败只完成识别记录，不得修改图片、人工菜品、成员选择、汇总或订单。
- 007 只把 004 的确定性汇总交给 DeepSeek：显示名和用户 ID 在服务端替换为 `M1`、`M2`，房间名与邀请信息不发送；默认文字模型 `deepseek-v4-flash`，可用仅服务端 `DEEPSEEK_TEXT_MODEL` 覆盖。
- 整桌建议只保存到组织者可读的 `room_advice`，来源版本使用 `selection_revision`；不同版本必须显示已过期，相同匿名摘要复用，每房间滚动 24 小时最多 5 次新建议。
- 建议生成、失败和读取不得写选择、菜单、收集状态或订单；页面必须持续提醒 AI 可能出错且食材与过敏原须向餐厅确认，最终订单确认后只能读取历史建议。
- 013 的个人 AI 助手采用 35 秒总等待上限、低推理强度和至多一次针对 408/429/5xx 的后端退避重试；整桌建议仍在 15 秒后结束纯等待状态。两者都允许用户继续手动流程，相同摘要仍优先复用，提速不得取消结构校验、过敏提醒或人工确认。
- 语音点餐只在浏览器明确授权麦克风后把语音转成当前输入框文字，再沿用 013 的结构化 AI 推荐边界；Web Speech API 不可用、拒绝权限或识别失败均不得阻止手动输入和点餐。
- 忌口翻译仅由组织者在核对页主动触发，向当前服务端 AI 供应商发送临时成员编号及对应的过敏/忌口原文，不发送姓名、用户 ID、房间名或其他选择；结果只在当前页面展示，原文始终保留，并持续提示向餐厅人工确认。
- 013 最终订单仍只有一份不可变快照；“给餐厅看”默认突出菜单原文、数量和餐厅备注并隐藏成员内部信息，“中文核对”只改变展示与复制文本，不保存第二份订单。
- 015 使用 `rooms.last_activity_at` 保护活跃房间，清理阈值为连续 30 天无活动且每次最多 25 间；Storage 删除失败时必须保留数据库记录等待重试。
- 015 匿名流程事件只允许服务端写入固定事件名、房间关联和时间，不记录姓名、菜品、备注、忌口、AI 问题或回答。

## 外部文档检索

1. 优先使用本地 skill 和仓库内文档。Next.js 当前版本文档位于 `node_modules/next/dist/docs/`。
2. 本地资料不足时使用 Context7；常用库采用过的 library ID 必须补充到下表。
3. 两者均无结果时，才使用网络搜索，并优先官方来源。

当前 Context7 library ID：

- Next.js：`/vercel/next.js`
- Next.js 16 版本查询：`/vercel/next.js/v16.2.9`（具体实现以本地 16.3.1 文档为准）
- React 19：`/react/react/v19.2.7`
- Biome：`/biomejs/website`
- Husky：`/typicode/husky`
- lint-staged：`/lint-staged/lint-staged`
- GitHub Spec Kit：`/github/spec-kit`
- Supabase：`/supabase/supabase`
- Supabase SSR：`/supabase/ssr`
- Gemini API：`/websites/ai_google_dev_gemini-api`

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
