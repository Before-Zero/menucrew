# Vibe Coding 课程项目

基于 Next.js App Router、TypeScript、Biome、Tailwind CSS 与 shadcn/ui 的空白起始项目。

## 开始开发

```bash
npm install
npm run dev
```

浏览器访问 `http://localhost:3000`。

## 质量检查

```bash
npm run verify
npm run build
```

提交前钩子会自动格式化暂存文件、执行 Biome 安全修复，并运行 TypeScript 类型检查。开发约定与项目结构以 `AGENTS.md` 为准。
