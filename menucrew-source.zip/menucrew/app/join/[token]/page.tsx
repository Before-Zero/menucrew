import { Link2Off, UsersRound } from "lucide-react";
import Link from "next/link";
import { joinRoomAction } from "@/app/actions";
import { RoomForm } from "@/components/room-form";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import { getAppLocale } from "@/lib/i18n-server";
import { isValidInviteToken } from "@/lib/validation";

export default async function JoinRoomPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const locale = await getAppLocale();

  if (!isValidInviteToken(token)) {
    return (
      <RoomShell
        locale={locale}
        description={
          locale === "en"
            ? "This link is incomplete, altered, or no longer valid. We hide all room details to protect the table."
            : "这条链接不完整、已被改动，或已经不能使用。为了保护房间信息，我们不会显示任何房间内容。"
        }
        eyebrow={locale === "en" ? "Invite unavailable" : "邀请不可用"}
        title={
          locale === "en" ? "This invitation is invalid." : "这张入席券无效。"
        }
      >
        <div className="grid place-items-center py-8 text-center">
          <span className="grid size-14 place-items-center rounded-full bg-destructive/10 text-destructive">
            <Link2Off aria-hidden="true" className="size-6" />
          </span>
          <h2 className="mt-5 text-xl font-bold">
            {locale === "en"
              ? "Ask the organizer for a new link"
              : "请向组织者获取新链接"}
          </h2>
          <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "You can also return home and create your own table."
              : "也可以先回到首页，创建一间自己的房间。"}
          </p>
          <Button asChild className="mt-6 h-11 rounded-xl px-5">
            <Link href="/">{locale === "en" ? "Back home" : "返回首页"}</Link>
          </Button>
        </div>
      </RoomShell>
    );
  }

  const action = joinRoomAction.bind(null, token);

  return (
    <RoomShell
      locale={locale}
      aside={
        <div className="flex max-w-xl items-start gap-4 rounded-2xl border border-[#d8d7d2] bg-[#fffefb]/80 p-5">
          <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#ddf5e7] text-[#16724a]">
            <UsersRound aria-hidden="true" className="size-5" />
          </span>
          <div>
            <p className="font-semibold">
              {locale === "en" ? "Confirm your name first" : "先确认你的称呼"}
            </p>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              {locale === "en"
                ? "The room name appears only after you join. Names may repeat; access never depends on a display name."
                : "加入成功后才会显示房间名称。你的称呼可以和别人相同，权限不会靠名字判断。"}
            </p>
          </div>
        </div>
      }
      description={
        locale === "en"
          ? "Enter a name your table recognizes. The invite token disappears from the address after you join."
          : "输入一个同桌的人认得出的称呼。加入后，邀请凭证会从浏览器地址里自动移除。"
      }
      eyebrow={
        locale === "en" ? "You received an invitation" : "收到一张入席券"
      }
      title={
        locale === "en"
          ? "Leave your name before taking a seat."
          : "入席前，先留个名字。"
      }
    >
      <div className="mb-7">
        <p className="font-mono text-[11px] font-semibold tracking-[0.16em] text-[#d95d45] uppercase">
          {locale === "en" ? "Join the table" : "加入聚餐"}
        </p>
        <h2 className="mt-2 text-2xl font-bold tracking-[-0.035em]">
          {locale === "en" ? "Join room" : "加入房间"}
        </h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          {locale === "en"
            ? "Room details appear only after the invitation is verified."
            : "只有验证邀请成功后，系统才会让你看到这间房。"}
        </p>
      </div>
      <RoomForm action={action} locale={locale} mode="join" />
    </RoomShell>
  );
}
