import { Hash, UsersRound } from "lucide-react";
import { joinRoomByCodeAction } from "@/app/actions";
import { RoomForm } from "@/components/room-form";
import { RoomShell } from "@/components/room-shell";
import { getAppLocale } from "@/lib/i18n-server";

export default async function JoinByCodePage() {
  const locale = await getAppLocale();
  return (
    <RoomShell
      activeControl={1}
      aside={
        <div className="border-y border-[#24322d]/15 py-5">
          <div className="flex items-start gap-4">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-[#efe3ce] text-[#9a5e0b]">
              <UsersRound aria-hidden="true" className="size-5" />
            </span>
            <p className="max-w-md text-sm leading-7 text-muted-foreground">
              {locale === "en"
                ? "Everyone can type the same code. You still choose your own table name, and the room stays hidden until the code is verified."
                : "大家输入同一段数字即可入席。你仍可留下自己的称呼，验证码通过前不会显示房间内容。"}
            </p>
          </div>
        </div>
      }
      description={
        locale === "en"
          ? "Use the six digits shown on the organizer's table map. No account is required."
          : "输入发起人餐桌地图上的六位数字，无需注册账户。"
      }
      eyebrow={locale === "en" ? "Meet at the same table" : "输入同一段数字"}
      title={
        locale === "en" ? "Join without scanning." : "不用扫码，也能入席。"
      }
    >
      <div className="mb-7 flex items-start gap-4">
        <span className="grid size-12 shrink-0 place-items-center rounded-full bg-[#fff0eb] text-[#b9433c]">
          <Hash aria-hidden="true" className="size-5" />
        </span>
        <div>
          <h2 className="text-2xl font-bold tracking-[-0.035em]">
            {locale === "en" ? "Enter the table code" : "输入餐桌入席码"}
          </h2>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Six digits lead to one shared table."
              : "六个数字，抵达同一张桌子。"}
          </p>
        </div>
      </div>
      <RoomForm action={joinRoomByCodeAction} locale={locale} mode="code" />
    </RoomShell>
  );
}
