import {
  ArrowLeft,
  BookOpenText,
  LockKeyhole,
  ShieldCheck,
} from "lucide-react";
import Link from "next/link";
import { MemberSelectionForm } from "@/components/member-selection-form";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import { getAppLocale } from "@/lib/i18n-server";
import { getRoomJourneySnapshot } from "@/lib/room-progress";
import { getMySelection } from "@/lib/selections";
import { saveMySelectionAction } from "./actions";
import { askMenuAssistantAction } from "./assistant-actions";

function Denied({ locale }: { locale: AppLocale }) {
  return (
    <RoomShell
      description={
        locale === "en"
          ? "Open this page in the browser that joined the table."
          : "请在已经加入房间的浏览器中打开这个页面。"
      }
      eyebrow={locale === "en" ? "Selection unavailable" : "无法访问个人选择"}
      locale={locale}
      title={
        locale === "en"
          ? "This selection does not belong to this session."
          : "这张选择单不属于当前身份。"
      }
    >
      <div className="grid place-items-center py-8 text-center">
        <LockKeyhole className="size-7 text-primary" />
        <p className="mt-4 text-sm text-muted-foreground">
          {locale === "en"
            ? "We do not reveal the room, menu, or other diners' choices."
            : "我们不会透露房间、菜单或其他成员的选择。"}
        </p>
        <Button asChild className="mt-6">
          <Link href="/">{locale === "en" ? "Back home" : "返回首页"}</Link>
        </Button>
      </div>
    </RoomShell>
  );
}

export default async function SelectionPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  const locale = await getAppLocale();
  const data = await getMySelection(roomId);
  if (!data) return <Denied locale={locale} />;
  const snapshot = await getRoomJourneySnapshot(roomId);
  if (!snapshot) return <Denied locale={locale} />;

  const published = data.menu?.status === "published";
  const readOnly = data.access.room.selection_status === "reviewing";

  return (
    <RoomShell
      journey={snapshot.journey}
      locale={locale}
      roomId={roomId}
      aside={
        <div className="flex flex-wrap items-center gap-3">
          <Button asChild variant="outline">
            <Link href={`/rooms/${roomId}`}>
              <ArrowLeft aria-hidden="true" />
              {locale === "en" ? "Back to room" : "返回房间"}
            </Link>
          </Button>
          <span className="inline-flex items-center gap-2 rounded-full bg-[#fff0eb] px-3 py-2 text-xs font-semibold text-primary">
            <ShieldCheck aria-hidden="true" className="size-4" />
            {locale === "en" ? "Only visible to you" : "仅本人可见"}
          </span>
        </div>
      }
      description={
        published
          ? readOnly
            ? locale === "en"
              ? "The organizer is reviewing. Your saved choices are visible but cannot be changed."
              : "组织者已进入核对。你的提交会完整恢复，但当前不能修改或保存。"
            : locale === "en"
              ? "Choose the servings you personally want. The organizer will review quantities, notes, and dietary information."
              : "按你本人实际想点的份数填写。组织者会在汇总中核对数量、备注和饮食信息。"
          : locale === "en"
            ? "The organizer is preparing the menu. You can save choices after it is published."
            : "组织者正在准备菜单。只有重新发布后，你才能确认并保存当前菜品。"
      }
      eyebrow={locale === "en" ? "My personal choices" : "我的个人选择"}
      title={
        published
          ? locale === "en"
            ? "This time, I'd like these."
            : "这次，我想吃这些。"
          : locale === "en"
            ? "The menu isn't ready yet."
            : "菜单还没上桌。"
      }
      wide
    >
      {published && data.items.length ? (
        <div className="mx-auto max-w-4xl">
          <MemberSelectionForm
            action={saveMySelectionAction.bind(null, roomId)}
            assistantAction={askMenuAssistantAction.bind(null, roomId)}
            initialAllergyInfo={data.submission?.allergy_info ?? ""}
            initialDietaryRestrictions={
              data.submission?.dietary_restrictions ?? ""
            }
            initialSavedAt={data.submission?.submitted_at ?? null}
            initialSelections={data.selectionByItemId}
            items={data.items}
            locale={locale}
            readOnly={readOnly}
            roomId={roomId}
          />
        </div>
      ) : (
        <div className="grid place-items-center py-14 text-center">
          <span className="grid size-14 place-items-center rounded-full bg-[#fff0eb] text-primary">
            <BookOpenText aria-hidden="true" />
          </span>
          <h2 className="mt-5 text-xl font-bold">
            {locale === "en"
              ? "Choose after the menu is published"
              : "发布后才能开始选择"}
          </h2>
          <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "The old menu no longer accepts choices. Refresh later or return to the room for its status."
              : "旧菜单不会继续接受提交。稍后刷新，或返回房间查看菜单状态。"}
          </p>
        </div>
      )}
    </RoomShell>
  );
}
