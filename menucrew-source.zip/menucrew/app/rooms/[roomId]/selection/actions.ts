"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { recordProductEvent } from "@/lib/product-events";
import type { SelectionActionState } from "@/lib/selection-action-state";
import { getMySelection } from "@/lib/selections";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId, validateSelectionInput } from "@/lib/validation";

function errorResult(
  message: string,
  fieldErrors: Record<string, string> = {},
): SelectionActionState {
  return { fieldErrors, message, savedAt: null, status: "error" };
}

export async function saveMySelectionAction(
  roomId: string,
  _previousState: SelectionActionState,
  formData: FormData,
): Promise<SelectionActionState> {
  if (!isValidRoomId(roomId)) return errorResult("这个房间地址无效。");

  try {
    const context = await getMySelection(roomId);
    if (!context) return errorResult("当前身份不能访问这个房间。");
    if (context.menu?.status !== "published") {
      return errorResult("菜单目前没有发布，请返回房间稍后再试。");
    }
    if (context.access.room.selection_status !== "open") {
      return errorResult("组织者正在核对，本次没有覆盖之前的选择。");
    }

    const input = validateSelectionInput(formData, context.items);
    if (!input.valid) {
      return errorResult("请修正标出的内容后再保存。", input.fieldErrors);
    }

    const supabase = await createClient();
    const { error } = await supabase.rpc("save_my_selection", {
      candidate_allergy_info: input.data.allergyInfo,
      candidate_dietary_restrictions: input.data.dietaryRestrictions,
      candidate_room_id: roomId,
      candidate_selections: input.data.selections,
    });

    if (error) {
      if (error.message.includes("collection_closed")) {
        return errorResult("组织者刚刚进入核对，本次没有覆盖之前的选择。");
      }
      if (error.message.includes("menu_not_published")) {
        return errorResult("菜单刚刚回到草稿，本次没有覆盖之前的选择。");
      }
      if (
        error.message.includes("invalid_menu_item") ||
        error.message.includes("duplicate_menu_item")
      ) {
        return errorResult("菜单内容已经变化，请刷新后重新确认。");
      }
      if (error.message.includes("room_access_denied")) {
        return errorResult("当前身份已经不能访问这个房间。");
      }
      throw error;
    }

    revalidatePath(`/rooms/${roomId}`);
    revalidatePath(`/rooms/${roomId}/selection`);
    revalidatePath(`/rooms/${roomId}/summary`);
    await recordProductEvent("selection_saved", roomId);
  } catch (error) {
    console.error("saveMySelectionAction failed", error);
    return errorResult("暂时无法保存。你的页面输入仍在，可以稍后重试。");
  }

  redirect(`/rooms/${roomId}/summary`);
}
