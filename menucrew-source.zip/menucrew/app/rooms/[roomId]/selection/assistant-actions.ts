"use server";

import type { AppLocale } from "@/lib/i18n";
import {
  askMenuAssistant,
  DEFAULT_MENU_ASSISTANT_MODEL,
  MenuAssistantError,
  menuAssistantDigest,
  parseMenuAssistantResult,
} from "@/lib/menu-assistant";
import type { MenuAssistantActionState } from "@/lib/menu-assistant-action-state";
import { getRoomMenu } from "@/lib/menus";
import { recordProductEvent } from "@/lib/product-events";
import type { Json } from "@/lib/supabase/database.types";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

export async function askMenuAssistantAction(
  roomId: string,
  _state: MenuAssistantActionState,
  formData: FormData,
): Promise<MenuAssistantActionState> {
  if (!isValidRoomId(roomId))
    return { message: "房间无效。", result: null, status: "error" };
  const question = String(formData.get("question") ?? "").trim();
  const intent =
    formData.get("intent") === "recommendation"
      ? "recommendation"
      : "explanation";
  const locale: AppLocale = formData.get("locale") === "en" ? "en" : "zh-CN";
  const dietaryRestrictions = String(formData.get("dietaryRestrictions") ?? "")
    .trim()
    .slice(0, 500);
  const allergyInfo = String(formData.get("allergyInfo") ?? "")
    .trim()
    .slice(0, 500);
  const menuItemId =
    String(formData.get("menuItemId") ?? "").trim() || undefined;
  if (!question || question.length > 240)
    return {
      message: "问题需要在 1–240 字以内。",
      result: null,
      status: "error",
    };

  let runId: string | null = null;
  try {
    await recordProductEvent("ai_requested", roomId);
    const menu = await getRoomMenu(roomId);
    if (!menu || menu.menu?.status !== "published")
      throw new Error("menu_not_published");
    if (menuItemId && !menu.items.some((item) => item.id === menuItemId))
      throw new Error("invalid_menu_item");
    let currentSelections: Array<{ menuItemId: string; quantity: number }> = [];
    try {
      const raw = JSON.parse(String(formData.get("currentSelections") ?? "[]"));
      if (Array.isArray(raw))
        currentSelections = raw.slice(0, 80).flatMap((entry) =>
          entry &&
          typeof entry.menuItemId === "string" &&
          Number.isInteger(entry.quantity)
            ? [
                {
                  menuItemId: entry.menuItemId,
                  quantity: Math.max(0, Math.min(20, entry.quantity)),
                },
              ]
            : [],
        );
    } catch {
      currentSelections = [];
    }
    const digest = menuAssistantDigest({
      allergyInfo,
      currentSelections,
      dietaryRestrictions,
      locale,
      menu: menu.items.map((item) => [item.id, item.updated_at]),
      menuItemId,
      question,
      intent,
    });
    const supabase = await createClient();
    const model =
      process.env.DEEPSEEK_TEXT_MODEL?.trim() || DEFAULT_MENU_ASSISTANT_MODEL;
    const { data: started, error: startError } = await supabase
      .rpc("start_menu_assistant_run", {
        candidate_input_digest: digest,
        candidate_model: model,
        candidate_room_id: roomId,
      })
      .single();
    if (startError?.message.includes("menu_assistant_rate_limited")) {
      return {
        message: "这间房今天的 AI 问答次数已用完，你仍可继续正常点餐。",
        result: null,
        status: "limited",
      };
    }
    if (startError || !started) throw startError ?? new Error("start_failed");
    runId = started.run_id;
    if (started.reused) {
      const reused = parseMenuAssistantResult(started.reused_result);
      if (reused)
        return {
          message: "已立即复用适用于当前选择的建议。",
          result: reused,
          status: "success",
        };
    }
    const result = await askMenuAssistant({
      allergyInfo,
      currentSelections,
      dietaryRestrictions,
      items: menu.items,
      locale,
      menuItemId,
      question,
      intent,
    });
    const { error: finishError } = await supabase.rpc(
      "finish_menu_assistant_run",
      {
        candidate_error_code: null,
        candidate_error_message: null,
        candidate_result: result as unknown as Json,
        candidate_run_id: runId,
        candidate_status: "succeeded",
      },
    );
    if (finishError) throw finishError;
    await recordProductEvent("ai_succeeded", roomId);
    return { message: "", result, status: "success" };
  } catch (error) {
    const safeError =
      error instanceof MenuAssistantError
        ? error
        : new MenuAssistantError("unexpected_failure");
    if (runId) {
      const supabase = await createClient();
      await supabase.rpc("finish_menu_assistant_run", {
        candidate_error_code: safeError.code,
        candidate_error_message: safeError.message.slice(0, 120),
        candidate_result: null,
        candidate_run_id: runId,
        candidate_status: "failed",
      });
    }
    console.error("askMenuAssistantAction failed", {
      code: safeError.code,
      cause:
        error instanceof Error
          ? { message: error.message.slice(0, 200), name: error.name }
          : undefined,
      ...safeError.details,
    });
    await recordProductEvent("ai_failed", roomId);
    return {
      message:
        safeError.code === "provider_timeout"
          ? locale === "en"
            ? "AI took longer than 35 seconds. Your choices are safe; keep ordering or try once more later."
            : "AI 超过 35 秒仍未完成。你的选择已经保留，可以继续点餐或稍后再试一次。"
          : safeError.code === "provider_rate_limited"
            ? locale === "en"
              ? "AI service is temporarily busy. Your choices are safe; please wait a moment before trying again."
              : "AI 服务暂时繁忙。你的选择已经保留，请稍等一会儿再试。"
            : locale === "en"
              ? "AI couldn't finish this request. Your choices are safe and manual ordering still works."
              : "AI 暂时没有完成这次请求。你的选择已经保留，仍可继续手动点餐。",
      result: null,
      status: "error",
    };
  }
}
