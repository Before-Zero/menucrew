"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { MenuActionState } from "@/lib/menu-action-state";
import { recordProductEvent } from "@/lib/product-events";
import { getRoomAccess } from "@/lib/rooms";
import { createClient } from "@/lib/supabase/server";
import {
  isValidMenuEntityId,
  isValidRoomId,
  validateMenuItemInput,
} from "@/lib/validation";

function result(message: string, status: "error" | "success"): MenuActionState {
  return { message, status };
}

function refresh(roomId: string) {
  revalidatePath(`/rooms/${roomId}`);
  revalidatePath(`/rooms/${roomId}/menu`);
}

async function organizerMenu(roomId: string) {
  if (!isValidRoomId(roomId)) return null;
  const access = await getRoomAccess(roomId);
  if (!access || access.currentMember.role !== "organizer") return null;

  const supabase = await createClient();
  const { data: menu, error } = await supabase
    .from("menus")
    .select("id,room_id,status,published_at,created_at,updated_at")
    .eq("room_id", roomId)
    .maybeSingle();

  if (error) throw error;
  return { menu, supabase };
}

export async function createMenuAction(
  roomId: string,
  _previousState: MenuActionState,
  _formData: FormData,
): Promise<MenuActionState> {
  try {
    const context = await organizerMenu(roomId);
    if (!context) return result("只有房间组织者可以准备菜单。", "error");
    if (context.menu) return result("菜单草稿已经准备好了。", "success");

    const { error } = await context.supabase
      .from("menus")
      .insert({ room_id: roomId });
    if (error && error.code !== "23505") throw error;
    refresh(roomId);
    return result("菜单草稿已建立。", "success");
  } catch (error) {
    console.error("createMenuAction failed", error);
    return result("暂时无法建立菜单草稿，请稍后重试。", "error");
  }
}

export async function saveMenuItemAction(
  roomId: string,
  itemId: string | null,
  _previousState: MenuActionState,
  formData: FormData,
): Promise<MenuActionState> {
  const input = validateMenuItemInput(formData);
  if (!input.valid) {
    return {
      fields: input.fields,
      message: "请检查标出的内容。",
      status: "error",
    };
  }
  if (itemId && !isValidMenuEntityId(itemId))
    return result("这道菜不存在。", "error");

  try {
    const context = await organizerMenu(roomId);
    if (!context?.menu || context.menu.status !== "draft") {
      return result("菜单不在可编辑的草稿状态。", "error");
    }

    if (itemId) {
      const { error } = await context.supabase
        .from("menu_items")
        .update({
          description: input.data.description,
          original_name: input.data.originalName,
          zh_name: input.data.zhName,
        })
        .eq("id", itemId)
        .eq("menu_id", context.menu.id);
      if (error) throw error;
    } else {
      const { data: last } = await context.supabase
        .from("menu_items")
        .select("position")
        .eq("menu_id", context.menu.id)
        .order("position", { ascending: false })
        .limit(1)
        .maybeSingle();
      const { error } = await context.supabase.from("menu_items").insert({
        description: input.data.description,
        menu_id: context.menu.id,
        original_name: input.data.originalName,
        position: (last?.position ?? -100) + 100,
        zh_name: input.data.zhName,
      });
      if (error) throw error;
    }

    refresh(roomId);
    return result(itemId ? "菜品已更新。" : "菜品已加入草稿。", "success");
  } catch (error) {
    console.error("saveMenuItemAction failed", error);
    return result("暂时无法保存这道菜，请稍后重试。", "error");
  }
}

export async function deleteMenuItemAction(
  roomId: string,
  itemId: string,
  _previousState: MenuActionState,
  _formData: FormData,
): Promise<MenuActionState> {
  if (!isValidMenuEntityId(itemId)) return result("这道菜不存在。", "error");
  try {
    const context = await organizerMenu(roomId);
    if (!context?.menu || context.menu.status !== "draft")
      return result("菜单不在可编辑的草稿状态。", "error");
    const { error } = await context.supabase
      .from("menu_items")
      .delete()
      .eq("id", itemId)
      .eq("menu_id", context.menu.id);
    if (error) throw error;
    refresh(roomId);
    return result("菜品已删除。", "success");
  } catch (error) {
    console.error("deleteMenuItemAction failed", error);
    return result("暂时无法删除这道菜。", "error");
  }
}

export async function moveMenuItemAction(
  roomId: string,
  itemId: string,
  direction: "up" | "down",
  _previousState: MenuActionState,
  _formData: FormData,
): Promise<MenuActionState> {
  if (!isValidMenuEntityId(itemId)) return result("这道菜不存在。", "error");
  try {
    const context = await organizerMenu(roomId);
    if (!context?.menu || context.menu.status !== "draft")
      return result("菜单不在可编辑的草稿状态。", "error");
    const { data: items, error } = await context.supabase
      .from("menu_items")
      .select("id,position")
      .eq("menu_id", context.menu.id)
      .order("position", { ascending: true })
      .order("id", { ascending: true });
    if (error) throw error;
    const index = items.findIndex((item) => item.id === itemId);
    const otherIndex = direction === "up" ? index - 1 : index + 1;
    if (index < 0 || otherIndex < 0 || otherIndex >= items.length)
      return result("菜品已经在这个方向的边界。", "error");
    const current = items[index];
    const other = items[otherIndex];
    const first = await context.supabase
      .from("menu_items")
      .update({ position: other.position })
      .eq("id", current.id)
      .eq("menu_id", context.menu.id);
    if (first.error) throw first.error;
    const second = await context.supabase
      .from("menu_items")
      .update({ position: current.position })
      .eq("id", other.id)
      .eq("menu_id", context.menu.id);
    if (second.error) throw second.error;
    refresh(roomId);
    return result("菜品顺序已调整。", "success");
  } catch (error) {
    console.error("moveMenuItemAction failed", error);
    return result("暂时无法调整顺序。", "error");
  }
}

async function changeStatus(roomId: string, status: "draft" | "published") {
  try {
    const context = await organizerMenu(roomId);
    if (!context?.menu) return result("菜单还没有建立。", "error");
    if (context.menu.status === status)
      return result(
        status === "draft" ? "菜单已经是草稿。" : "菜单已经发布。",
        "success",
      );
    const { error } = await context.supabase
      .from("menus")
      .update({ status })
      .eq("id", context.menu.id);
    if (error) {
      if (error.message.includes("menu_publish_requirements_not_met"))
        return result("至少上传 1 张菜单图并添加 1 道菜后才能发布。", "error");
      throw error;
    }
    refresh(roomId);
    return result(
      status === "draft"
        ? "菜单已退回草稿，成员暂时看不到菜品。"
        : "菜单已发布，成员现在可以查看。",
      "success",
    );
  } catch (error) {
    console.error("changeMenuStatus failed", error);
    return result("暂时无法更改菜单状态。", "error");
  }
}

export async function publishMenuAction(
  roomId: string,
  _state: MenuActionState,
  _formData: FormData,
) {
  const actionState = await changeStatus(roomId, "published");
  if (actionState.status === "success") {
    await recordProductEvent("menu_published", roomId);
    redirect(`/rooms/${roomId}/selection`);
  }
  return actionState;
}

export async function reopenMenuDraftAction(
  roomId: string,
  _state: MenuActionState,
  _formData: FormData,
) {
  return changeStatus(roomId, "draft");
}
