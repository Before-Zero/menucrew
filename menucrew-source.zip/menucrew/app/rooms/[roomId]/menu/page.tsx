import {
  ArrowLeft,
  BookOpenText,
  CheckCircle2,
  LockKeyhole,
  Sparkles,
} from "lucide-react";
import Link from "next/link";
import { MenuAiPanel } from "@/components/menu-ai-panel";
import { MenuImageUploader } from "@/components/menu-image-uploader";
import { MenuItemForm } from "@/components/menu-item-form";
import { MenuItemList } from "@/components/menu-item-list";
import { MenuStatusActions } from "@/components/menu-status-actions";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import { getAppLocale } from "@/lib/i18n-server";
import { getLatestMenuAiRun } from "@/lib/menu-ai";
import { getRoomMenu } from "@/lib/menus";
import { getRoomJourneySnapshot } from "@/lib/room-progress";
import {
  createMenuAction,
  publishMenuAction,
  reopenMenuDraftAction,
  saveMenuItemAction,
} from "./actions";
import {
  confirmMenuAiRunAndPublishAction,
  recognizeMenuAction,
} from "./ai-actions";

function Denied({ locale }: { locale: AppLocale }) {
  return (
    <RoomShell
      description={
        locale === "en"
          ? "Open this page in the browser that joined the room."
          : "请在已经加入房间的浏览器中打开这个页面。"
      }
      eyebrow={locale === "en" ? "Menu unavailable" : "无法访问菜单"}
      locale={locale}
      title={
        locale === "en"
          ? "This menu does not belong to this session."
          : "这份菜单不属于当前身份。"
      }
    >
      <div className="grid place-items-center py-8 text-center">
        <LockKeyhole className="size-7 text-primary" />
        <p className="mt-4 text-sm text-muted-foreground">
          {locale === "en"
            ? "We do not reveal whether this room or menu exists."
            : "我们不会透露房间或菜单是否存在。"}
        </p>
        <Button asChild className="mt-6">
          <Link href="/">{locale === "en" ? "Back home" : "返回首页"}</Link>
        </Button>
      </div>
    </RoomShell>
  );
}

export default async function MenuPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  const locale = await getAppLocale();
  const data = await getRoomMenu(roomId);
  if (!data) return <Denied locale={locale} />;
  const snapshot = await getRoomJourneySnapshot(roomId);
  if (!snapshot) return <Denied locale={locale} />;

  const organizer = data.access.currentMember.role === "organizer";
  const published = data.menu?.status === "published";
  const aiRun =
    organizer && data.menu
      ? await getLatestMenuAiRun(roomId, data.menu.id)
      : null;
  const createAction = createMenuAction.bind(null, roomId);
  const saveNewAction = saveMenuItemAction.bind(null, roomId, null);
  const publishAction = publishMenuAction.bind(null, roomId);
  const reopenAction = reopenMenuDraftAction.bind(null, roomId);
  const menuControl = published ? 4 : data.images.length || aiRun ? 3 : 2;
  const recognitionStatus =
    aiRun?.status === "processing" ||
    aiRun?.status === "succeeded" ||
    aiRun?.status === "failed"
      ? aiRun.status
      : "idle";

  if (!organizer) {
    return (
      <RoomShell
        locale={locale}
        journey={snapshot.journey}
        roomId={roomId}
        aside={
          <Button asChild variant="outline">
            <Link href={`/rooms/${roomId}`}>
              <ArrowLeft aria-hidden="true" />
              {locale === "en" ? "Back to room" : "返回房间"}
            </Link>
          </Button>
        }
        description={
          published
            ? locale === "en"
              ? "The organizer published one bilingual menu in a fixed order."
              : "组织者已经发布菜单。你看到的是同一份双语菜品和固定顺序。"
            : locale === "en"
              ? "The organizer is preparing the menu. Drafts and original images stay private until publishing."
              : "组织者正在准备菜单。发布前，草稿内容与原图都不会出现在成员页面。"
        }
        eyebrow={locale === "en" ? "Diner menu" : "成员菜单"}
        title={
          published
            ? locale === "en"
              ? "The menu is served."
              : "菜单上桌了。"
            : locale === "en"
              ? "The menu is still in the kitchen."
              : "菜单还在厨房里。"
        }
        wide
      >
        {published ? (
          <div className="mx-auto max-w-3xl space-y-6">
            <div className="flex items-center justify-between border-b pb-5">
              <div>
                <p className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground uppercase">
                  {locale === "en" ? "Published menu" : "已发布菜单"}
                </p>
                <p className="mt-2 flex items-center gap-2 font-semibold">
                  <CheckCircle2 className="size-4 text-[#168252]" />
                  {locale === "en" ? "Published" : "已发布"}
                </p>
              </div>
              <span className="font-mono text-sm">
                {data.items.length} {locale === "en" ? "dishes" : "道"}
              </span>
            </div>
            <MenuItemList items={data.items} locale={locale} />
          </div>
        ) : (
          <div className="grid place-items-center py-14 text-center">
            <span className="grid size-14 place-items-center rounded-full bg-[#fff0eb] text-primary">
              <BookOpenText />
            </span>
            <h2 className="mt-5 text-xl font-bold">
              {locale === "en"
                ? "The menu appears here after publishing"
                : "发布后会在这里出现"}
            </h2>
            <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
              {locale === "en"
                ? "No need to repeat any action. Refresh later to check."
                : "你不需要反复尝试操作，稍后刷新即可查看。"}
            </p>
          </div>
        )}
      </RoomShell>
    );
  }

  return (
    <RoomShell
      activeControl={menuControl}
      locale={locale}
      journey={snapshot.journey}
      roomId={roomId}
      aside={
        <div className="flex flex-wrap items-center gap-3">
          <Button asChild variant="outline">
            <Link href={`/rooms/${roomId}`}>
              <ArrowLeft aria-hidden="true" />
              {locale === "en" ? "Back to room" : "返回房间"}
            </Link>
          </Button>
          <span
            className={`rounded-full px-3 py-2 text-xs font-semibold ${published ? "bg-[#ddf5e7] text-[#16724a]" : "bg-[#fff0d8] text-[#8b5812]"}`}
          >
            {published
              ? locale === "en"
                ? "Visible to diners"
                : "成员可见"
              : locale === "en"
                ? "Organizer only"
                : "仅组织者可见"}
          </span>
        </div>
      }
      description={
        published
          ? locale === "en"
            ? "This version is visible to diners. Return to draft before editing images, dishes, or order."
            : "当前版本已对房间成员可见。退回草稿后才能修改图片、菜品和顺序。"
          : locale === "en"
            ? "Upload menu photos for automatic recognition. Usually you only need to review and publish."
            : "上传菜单原图后会自动识别。通常只需确认发布，识别有误时再展开修改。"
      }
      eyebrow={
        locale === "en" ? "Organizer menu workspace" : "组织者菜单工作区"
      }
      title={data.access.room.name}
      wide
    >
      {!data.menu ? (
        <div className="grid place-items-center py-12 text-center">
          <span className="grid size-14 place-items-center rounded-full bg-[#fff0eb] text-primary">
            <Sparkles />
          </span>
          <h2 className="mt-5 text-xl font-bold">
            {locale === "en"
              ? "Create the first menu draft"
              : "建立第一份菜单草稿"}
          </h2>
          <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Each room has one menu. Edit it privately, then publish when ready."
              : "每个房间只有一份菜单。建立后先私下编辑，准备好再发布。"}
          </p>
          <div className="mt-6 w-full max-w-xs">
            <MenuStatusActions
              action={createAction}
              locale={locale}
              mode="create"
            />
          </div>
        </div>
      ) : published ? (
        <div className="mx-auto max-w-3xl space-y-7">
          <div className="border-y border-[#4f7c70]/35 bg-[#4f7c70]/10 p-5">
            <p className="flex items-center gap-2 font-semibold text-[#146b45]">
              <CheckCircle2 className="size-5" />
              {locale === "en" ? "Menu published" : "菜单已发布"}
            </p>
            <p className="mt-2 text-sm leading-6 text-[#416454]">
              {locale === "en"
                ? `${data.items.length} dishes are shown to diners in this order. Original images remain private to you.`
                : `${data.items.length} 道菜正按下方顺序展示给成员。原始图片仍然只有你能看到。`}
            </p>
          </div>
          <MenuItemList items={data.items} locale={locale} />
          <div className="border-t pt-6">
            <MenuStatusActions
              action={reopenAction}
              locale={locale}
              mode="reopen"
            />
          </div>
        </div>
      ) : (
        <div className="mc-menu-workbench">
          <div
            className="mc-map-window mc-menu-capture p-5 sm:p-6"
            id="menu-image-uploader"
          >
            <MenuImageUploader
              images={data.images}
              locale={locale}
              recognitionStatus={recognitionStatus}
              recognizeAction={recognizeMenuAction.bind(null, roomId)}
              roomId={roomId}
            />
          </div>
          <div className="mc-menu-processing min-w-0 space-y-7">
            <MenuAiPanel
              applyAction={
                aiRun?.status === "succeeded"
                  ? confirmMenuAiRunAndPublishAction.bind(
                      null,
                      roomId,
                      aiRun.id,
                    )
                  : null
              }
              imageCount={data.images.length}
              itemCount={data.items.length}
              locale={locale}
              recognizeAction={recognizeMenuAction.bind(null, roomId)}
              run={aiRun}
            />
            <details
              className="border-y border-[#24322d]/20 bg-[#fbf9f2]/60 p-4 sm:p-5"
              id="manual-menu-editor"
              open={data.items.length === 0}
            >
              <summary className="cursor-pointer text-sm font-semibold">
                {locale === "en"
                  ? "Recognition needs changes? Edit the menu here"
                  : "识别有误？点这里修改菜单"}
              </summary>
              <div className="mt-5 space-y-7 border-t pt-5">
                <MenuItemForm action={saveNewAction} locale={locale} />
                <section className="space-y-4">
                  <div className="flex items-end justify-between gap-4">
                    <div>
                      <h2 className="text-lg font-bold">
                        {locale === "en" ? "Current dishes" : "当前菜品"}
                      </h2>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {locale === "en"
                          ? "Edit text, reorder dishes, or add another dish."
                          : "可以修改文字、顺序或补充菜品。"}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {data.items.length} {locale === "en" ? "dishes" : "道"}
                    </span>
                  </div>
                  <MenuItemList
                    editable
                    items={data.items}
                    locale={locale}
                    roomId={roomId}
                  />
                </section>
              </div>
            </details>
            {aiRun?.status === "succeeded" ? null : (
              <section className="border-y-2 border-primary/45 bg-primary/5 p-5">
                <h2 className="font-bold">
                  {locale === "en" ? "Publish checklist" : "发布检查"}
                </h2>
                <p className="mt-1 mb-5 text-sm leading-6 text-muted-foreground">
                  {data.images.length
                    ? locale === "en"
                      ? `${data.images.length} source images`
                      : `已有 ${data.images.length} 张原图`
                    : locale === "en"
                      ? "menu image missing"
                      : "还缺菜单原图"}
                  ；
                  {data.items.length
                    ? locale === "en"
                      ? `${data.items.length} dishes`
                      : `已有 ${data.items.length} 道菜`
                    : locale === "en"
                      ? "dishes missing"
                      : "还缺菜品"}
                  。
                </p>
                {data.images.length > 0 && data.items.length > 0 ? (
                  <MenuStatusActions
                    action={publishAction}
                    locale={locale}
                    mode="publish"
                  />
                ) : (
                  <div className="space-y-3">
                    <Button asChild className="h-12 w-full rounded-xl">
                      <Link
                        href={
                          data.images.length === 0
                            ? "#menu-image-uploader"
                            : "#manual-menu-editor"
                        }
                      >
                        <BookOpenText aria-hidden="true" />
                        {data.images.length === 0
                          ? locale === "en"
                            ? "Add a menu image first"
                            : "先上传菜单原图"
                          : locale === "en"
                            ? "Add dishes before publishing"
                            : "先添加菜品，再发布"}
                      </Link>
                    </Button>
                    <p className="text-xs leading-5 text-muted-foreground">
                      {locale === "en"
                        ? "Once the checklist is complete, this becomes the publish action."
                        : "补齐发布条件后，这里会自动变为正式发布按钮。"}
                    </p>
                  </div>
                )}
              </section>
            )}
          </div>
        </div>
      )}
    </RoomShell>
  );
}
