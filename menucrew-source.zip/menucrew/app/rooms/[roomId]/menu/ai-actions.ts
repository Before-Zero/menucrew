"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import {
  DEFAULT_MENU_AI_MODEL,
  getMenuAiInput,
  MenuAiError,
  toJson,
  understandMenuImages,
} from "@/lib/menu-ai";
import type { MenuAiActionState } from "@/lib/menu-ai-action-state";
import { getRoomAccess } from "@/lib/rooms";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

function result(
  message: string,
  status: "error" | "success",
  runId?: string,
): MenuAiActionState {
  return { message, runId, status };
}

function refresh(roomId: string) {
  revalidatePath(`/rooms/${roomId}`);
  revalidatePath(`/rooms/${roomId}/menu`);
}

function databaseMessage(message: string) {
  if (message.includes("menu_ai_rate_limited")) {
    return "这间房过去 24 小时已进行 5 次新识别，请稍后再试。";
  }
  if (message.includes("menu_ai_images_required")) {
    return "请先上传 1–4 张菜单图片。";
  }
  if (message.includes("menu_not_draft")) {
    return "请先把菜单退回草稿再使用 AI。";
  }
  if (message.includes("menu_ai_access_denied")) {
    return "只有房间组织者可以使用菜单识别。";
  }
  return "暂时无法处理菜单识别，请稍后重试。";
}

export async function recognizeMenuAction(
  roomId: string,
  _previousState: MenuAiActionState,
  formData: FormData,
): Promise<MenuAiActionState> {
  if (!isValidRoomId(roomId) || formData.get("confirmation") !== "recognize") {
    return result("请先确认要用当前图片重新识别。", "error");
  }

  let runId: string | null = null;
  try {
    const access = await getRoomAccess(roomId);
    if (!access || access.currentMember.role !== "organizer") {
      return result("只有房间组织者可以使用菜单识别。", "error");
    }

    const input = await getMenuAiInput(roomId);
    const model =
      process.env.DEEPSEEK_VISION_MODEL?.trim() || DEFAULT_MENU_AI_MODEL;
    const { data: started, error: startError } = await input.supabase
      .rpc("start_menu_ai_run", {
        candidate_input_digest: input.digest,
        candidate_model: model,
        candidate_room_id: roomId,
      })
      .single();
    if (startError || !started) {
      return result(databaseMessage(startError?.message ?? ""), "error");
    }
    runId = started.run_id;
    if (started.reused) {
      refresh(roomId);
      return result(
        "已复用相同图片的识别记录，没有消耗新的识别次数。",
        "success",
        runId,
      );
    }

    const understood = await understandMenuImages(input.images);
    const { error: finishError } = await input.supabase.rpc(
      "finish_menu_ai_run",
      {
        candidate_error_code: null,
        candidate_error_message: null,
        candidate_provider_response_id: understood.providerResponseId,
        candidate_result: toJson(understood.result),
        candidate_run_id: runId,
        candidate_status: "succeeded",
      },
    );
    if (finishError) throw finishError;
    refresh(roomId);
    return result(
      `已识别 ${understood.result.items.length} 道候选，请先人工审阅。`,
      "success",
      runId,
    );
  } catch (error) {
    const aiError =
      error instanceof MenuAiError
        ? error
        : new MenuAiError(
            "unexpected_failure",
            "AI 识别失败，图片和人工草稿没有变化。",
          );
    if (runId) {
      try {
        const supabase = await createClient();
        await supabase.rpc("finish_menu_ai_run", {
          candidate_error_code: aiError.code,
          candidate_error_message: aiError.message.slice(0, 300),
          candidate_provider_response_id: null,
          candidate_result: null,
          candidate_run_id: runId,
          candidate_status: "failed",
        });
      } catch {
        // The original safe error remains the useful response.
      }
    }
    refresh(roomId);
    return result(aiError.message, "error", runId ?? undefined);
  }
}

export async function applyMenuAiRunAction(
  roomId: string,
  runId: string,
  _previousState: MenuAiActionState,
  formData: FormData,
): Promise<MenuAiActionState> {
  if (
    !isValidRoomId(roomId) ||
    !/^[0-9a-f-]{36}$/i.test(runId) ||
    formData.get("confirmation") !== "replace"
  ) {
    return result("请确认用 AI 候选替换当前草稿菜品。", "error");
  }
  try {
    const access = await getRoomAccess(roomId);
    if (!access || access.currentMember.role !== "organizer") {
      return result("只有房间组织者可以应用识别结果。", "error");
    }
    const supabase = await createClient();
    const { data: count, error } = await supabase.rpc("apply_menu_ai_run", {
      candidate_run_id: runId,
    });
    if (error) return result(databaseMessage(error.message), "error");
    refresh(roomId);
    return result(
      `已把 ${count} 道候选应用到草稿。请人工修正后再发布。`,
      "success",
      runId,
    );
  } catch {
    return result("暂时无法应用识别结果，当前草稿没有变化。", "error");
  }
}

export async function confirmMenuAiRunAndPublishAction(
  roomId: string,
  runId: string,
  _previousState: MenuAiActionState,
  formData: FormData,
): Promise<MenuAiActionState> {
  if (
    !isValidRoomId(roomId) ||
    !/^[0-9a-f-]{36}$/i.test(runId) ||
    formData.get("confirmation") !== "publish"
  ) {
    return result("请先确认这份 AI 识别结果可以开放给成员。", "error");
  }
  let success = false;
  let count = 0;
  try {
    const access = await getRoomAccess(roomId);
    if (!access || access.currentMember.role !== "organizer") {
      return result("只有房间发起人可以确认并开放菜单。", "error");
    }
    const supabase = await createClient();
    const { data: confirmedCount, error } = await supabase.rpc(
      "confirm_menu_ai_run_and_publish",
      { candidate_run_id: runId },
    );
    if (error) return result(databaseMessage(error.message), "error");
    count = confirmedCount ?? 0;
    refresh(roomId);
    success = true;
  } catch {
    return result("暂时无法开放菜单，草稿和识别结果都没有变化。", "error");
  }
  if (success) redirect(`/rooms/${roomId}/selection`);
  return result(`已确认 ${count} 道菜，菜单现在可以点了。`, "success", runId);
}
