import { redirect } from "next/navigation";

export default async function ReceiptPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  redirect(`/rooms/${roomId}/summary`);
}
