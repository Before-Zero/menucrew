"use server";

import { getRoomAggregation } from "@/lib/aggregation";
import { translateDiningNotes } from "@/lib/dining-note-translation";
import type { DiningNoteTranslationActionState } from "@/lib/dining-note-translation-action-state";

export async function translateDiningNotesAction(
  roomId: string,
  _state: DiningNoteTranslationActionState,
  formData: FormData,
): Promise<DiningNoteTranslationActionState> {
  const english = formData.get("locale") === "en";
  try {
    const aggregation = await getRoomAggregation(roomId);
    if (!aggregation)
      return {
        message: english
          ? "This session cannot translate dietary notes for this room."
          : "当前身份不能翻译这间房的饮食信息。",
        status: "error",
        translations: [],
      };
    const members = aggregation.members.filter(
      (member) =>
        member.submittedAt &&
        (member.allergyInfo || member.dietaryRestrictions),
    );
    const keyToUserId = new Map<string, string>();
    const notes = members.map((member, index) => {
      const key = `M${index + 1}`;
      keyToUserId.set(key, member.userId);
      return {
        allergyInfo: member.allergyInfo,
        dietaryRestrictions: member.dietaryRestrictions,
        key,
      };
    });
    const translated = await translateDiningNotes(notes);
    return {
      message: english
        ? "Restaurant English and Simplified Chinese translations are ready."
        : "已生成餐厅英文与简体中文翻译。",
      status: "success",
      translations: translated.flatMap((item) => {
        const userId = keyToUserId.get(item.key);
        return userId ? [{ ...item, userId }] : [];
      }),
    };
  } catch {
    return {
      message: english
        ? "Translation is temporarily unavailable. Original notes are preserved; please try again."
        : "暂时无法翻译；原始备注仍完整保留，请稍后重试。",
      status: "error",
      translations: [],
    };
  }
}
