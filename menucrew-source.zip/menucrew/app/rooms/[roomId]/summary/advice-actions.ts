"use server";

import { revalidatePath } from "next/cache";
import { getRoomAggregation } from "@/lib/aggregation";
import { hasFinalOrder } from "@/lib/orders";
import { createClient } from "@/lib/supabase/server";
import {
  buildTableAdviceInput,
  DEFAULT_TABLE_ADVICE_MODEL,
  generateTableAdvice,
  TableAdviceError,
  tableAdviceToJson,
} from "@/lib/table-advice";
import type { TableAdviceActionState } from "@/lib/table-advice-action-state";
import { isValidRoomId } from "@/lib/validation";

function state(
  message: string,
  status: "success" | "error",
): TableAdviceActionState {
  return { message, status };
}

function databaseMessage(message: string) {
  if (message.includes("room_advice_rate_limited"))
    return "这间房过去 24 小时已生成 5 次新建议，请稍后再试。";
  if (message.includes("room_advice_data_required"))
    return "请先发布菜单并收集至少一份有正数量的选择。";
  if (message.includes("room_advice_order_confirmed"))
    return "最终订单已经确认，历史建议仍可查看，但不能再新生成。";
  if (message.includes("room_advice_revision_changed"))
    return "汇总刚刚发生变化，请刷新后再生成建议。";
  if (message.includes("room_advice_access_denied"))
    return "只有房间组织者可以生成整桌建议。";
  return "暂时无法生成整桌建议；你仍可继续人工核对。";
}

export async function generateTableAdviceAction(
  roomId: string,
  _previousState: TableAdviceActionState,
  formData: FormData,
): Promise<TableAdviceActionState> {
  if (!isValidRoomId(roomId) || formData.get("confirmation") !== "generate")
    return state("请先确认使用当前汇总生成建议。", "error");

  let adviceId: string | null = null;
  try {
    const aggregation = await getRoomAggregation(roomId);
    if (!aggregation) return state("只有房间组织者可以生成整桌建议。", "error");
    if (aggregation.metrics.submittedCount < 1 || aggregation.dishes.length < 1)
      return state("请先收集至少一份有正数量的选择。", "error");
    if (await hasFinalOrder(roomId))
      return state(
        "最终订单已经确认，历史建议仍可查看，但不能再新生成。",
        "error",
      );

    const input = buildTableAdviceInput(aggregation);
    const model =
      process.env.DEEPSEEK_TEXT_MODEL?.trim() || DEFAULT_TABLE_ADVICE_MODEL;
    const supabase = await createClient();
    const { data: started, error: startError } = await supabase
      .rpc("start_room_advice", {
        candidate_input_digest: input.digest,
        candidate_model: model,
        candidate_room_id: roomId,
        candidate_source_revision: aggregation.access.room.selection_revision,
      })
      .single();
    if (startError || !started)
      return state(databaseMessage(startError?.message ?? ""), "error");
    adviceId = started.advice_id;
    if (started.disposition === "reused") {
      revalidatePath(`/rooms/${roomId}/summary`);
      return state(
        started.advice_status === "succeeded"
          ? "已复用当前汇总的建议，没有消耗新的调用次数。"
          : "当前汇总的建议正在生成，请稍后刷新。",
        "success",
      );
    }

    const generated = await generateTableAdvice(input.snapshot);
    const { error: finishError } = await supabase.rpc("finish_room_advice", {
      candidate_advice_id: adviceId,
      candidate_error_code: null,
      candidate_error_message: null,
      candidate_provider_response_id: generated.providerResponseId,
      candidate_result: tableAdviceToJson(generated.result),
      candidate_status: "succeeded",
    });
    if (finishError) throw finishError;
    revalidatePath(`/rooms/${roomId}/summary`);
    return state(
      `已生成 ${generated.result.items.length} 条只读建议，请逐条人工核对。`,
      "success",
    );
  } catch (error) {
    const safeError =
      error instanceof TableAdviceError
        ? error
        : new TableAdviceError(
            "unexpected_failure",
            "AI 建议未完成；汇总和订单没有变化。",
          );
    if (adviceId) {
      try {
        const supabase = await createClient();
        await supabase.rpc("finish_room_advice", {
          candidate_advice_id: adviceId,
          candidate_error_code: safeError.code,
          candidate_error_message: safeError.message.slice(0, 300),
          candidate_provider_response_id: null,
          candidate_result: null,
          candidate_status: "failed",
        });
      } catch {
        // Keep the original safe failure as the useful response.
      }
    }
    revalidatePath(`/rooms/${roomId}/summary`);
    return state(safeError.message, "error");
  }
}
