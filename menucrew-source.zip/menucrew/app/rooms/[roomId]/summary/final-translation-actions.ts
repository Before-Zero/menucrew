"use server";

import { revalidatePath } from "next/cache";
import { translateDiningNotes } from "@/lib/dining-note-translation";
import type { FinalOrderDietaryNote } from "@/lib/orders";
import { getFinalOrder } from "@/lib/orders";
import { createAdminClient } from "@/lib/supabase/admin";
import type { Json } from "@/lib/supabase/database.types";
import { isValidRoomId } from "@/lib/validation";

export type FinalDietaryTranslationResult =
  | { status: "error" }
  | { status: "noop" }
  | { status: "updated" };

function hasCompleteTranslation(note: FinalOrderDietaryNote) {
  return (
    (!note.allergyInfo || (note.allergyEn && note.allergyZh)) &&
    (!note.dietaryRestrictions || (note.dietaryEn && note.dietaryZh))
  );
}

export async function hydrateFinalOrderDietaryNotesAction(
  roomId: string,
): Promise<FinalDietaryTranslationResult> {
  if (!isValidRoomId(roomId)) return { status: "error" };
  try {
    const finalOrder = await getFinalOrder(roomId);
    if (
      !finalOrder ||
      finalOrder.access.currentMember.role !== "organizer" ||
      !finalOrder.order.dietary_notes.length
    )
      return { status: "noop" };
    if (finalOrder.order.dietary_notes.every(hasCompleteTranslation))
      return { status: "noop" };

    const translated = await translateDiningNotes(
      finalOrder.order.dietary_notes.map((note, index) => ({
        allergyInfo: note.allergyInfo,
        dietaryRestrictions: note.dietaryRestrictions,
        key: String(index),
      })),
    );
    const byKey = new Map(translated.map((note) => [note.key, note]));
    if (translated.length !== finalOrder.order.dietary_notes.length)
      return { status: "error" };

    const dietaryNotes = finalOrder.order.dietary_notes.map((note, index) => {
      const translation = byKey.get(String(index));
      if (!translation) return note;
      return {
        ...note,
        allergyEn: translation.allergyEn,
        allergyZh: translation.allergyZh,
        dietaryEn: translation.dietaryEn,
        dietaryZh: translation.dietaryZh,
      };
    });
    const admin = createAdminClient();
    const { error } = await admin
      .from("orders")
      .update({ dietary_notes: dietaryNotes as unknown as Json })
      .eq("id", finalOrder.order.id)
      .eq("room_id", roomId);
    if (error) throw error;

    revalidatePath(`/rooms/${roomId}/summary`);
    revalidatePath(`/rooms/${roomId}/order`);
    return { status: "updated" };
  } catch (error) {
    console.error("hydrateFinalOrderDietaryNotesAction failed", error);
    return { status: "error" };
  }
}
