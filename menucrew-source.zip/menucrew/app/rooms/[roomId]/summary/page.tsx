import { ArrowLeft, LockKeyhole, Stamp, Users } from "lucide-react";
import Link from "next/link";
import { AggregationMemberStatus } from "@/components/aggregation-member-status";
import { AutoTableAdvice } from "@/components/auto-table-advice";
import { DietaryTranslationPanel } from "@/components/dietary-translation-panel";
import { DynamicReceipt } from "@/components/dynamic-receipt";
import { FinalOrderView } from "@/components/final-order-view";
import { RoomShell } from "@/components/room-shell";
import { SummaryFinalDecision } from "@/components/summary-final-decision";
import { TableAdvicePanel } from "@/components/table-advice-panel";
import { Button } from "@/components/ui/button";
import { getRoomAggregation } from "@/lib/aggregation";
import { getAppLocale } from "@/lib/i18n-server";
import { getMemberReceipt } from "@/lib/member-receipt";
import { getFinalOrder, getOrderPageData } from "@/lib/orders";
import { getRoomJourneySnapshot } from "@/lib/room-progress";
import { getRoomAdviceHistory } from "@/lib/table-advice";
import { confirmFinalOrderAction } from "../order/actions";
import { generateTableAdviceAction } from "./advice-actions";
import { hydrateFinalOrderDietaryNotesAction } from "./final-translation-actions";
import { translateDiningNotesAction } from "./translation-actions";

export default async function SummaryPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  const [snapshot, receipt, finalOrder, locale] = await Promise.all([
    getRoomJourneySnapshot(roomId),
    getMemberReceipt(roomId),
    getFinalOrder(roomId),
    getAppLocale(),
  ]);

  if (!snapshot) {
    return (
      <RoomShell
        description={
          locale === "en"
            ? "Open the table order in the browser that joined this room."
            : "请在已经加入房间的浏览器中打开本桌点单。"
        }
        eyebrow={locale === "en" ? "Access denied" : "无法访问"}
        locale={locale}
        title={
          locale === "en"
            ? "This page is not available to this session."
            : "这里不对当前身份开放。"
        }
      >
        <div className="grid place-items-center py-10 text-center">
          <LockKeyhole className="size-8 text-primary" />
          <Button asChild className="mt-6">
            <Link href="/">{locale === "en" ? "Back home" : "返回首页"}</Link>
          </Button>
        </div>
      </RoomShell>
    );
  }

  if (finalOrder) {
    return (
      <RoomShell
        description={
          locale === "en"
            ? "The order is confirmed. Everyone at the table sees the same final result here."
            : "订单已经确认，房间里的每个人都会在这里看到同一份稳定结果。"
        }
        eyebrow={
          locale === "en" ? "Table order · Confirmed" : "本桌点单 · 已确认"
        }
        journey={snapshot.journey}
        locale={locale}
        roomId={roomId}
        title={snapshot.access.room.name}
        wide
      >
        <FinalOrderView
          data={finalOrder}
          locale={locale}
          translationAction={
            snapshot.access.currentMember.role === "organizer"
              ? hydrateFinalOrderDietaryNotesAction.bind(null, roomId)
              : undefined
          }
        />
      </RoomShell>
    );
  }

  if (snapshot.access.currentMember.role !== "organizer") {
    return (
      <RoomShell
        description={
          locale === "en"
            ? "This page shows dishes actually selected and their combined quantities. You can return to edit your choices."
            : "这里只显示大家实际点过的菜和合并数量；你可以随时返回修改自己的选择。"
        }
        eyebrow={locale === "en" ? "Table order · Live" : "本桌点单 · 实时"}
        journey={snapshot.journey}
        locale={locale}
        roomId={roomId}
        title={
          locale === "en" ? "Here's what the table ordered." : "大家点了这些。"
        }
      >
        {receipt ? (
          <DynamicReceipt
            initialReceipt={receipt}
            locale={locale}
            memberCount={snapshot.progress.memberCount}
            submittedCount={snapshot.progress.submittedCount}
          />
        ) : (
          <div className="grid gap-4 text-center">
            <p className="text-sm text-muted-foreground">
              {locale === "en"
                ? "Save your choices once to see the live table order here."
                : "保存一次你的选择后，这里会显示本桌实时点单。"}
            </p>
            <Button asChild>
              <Link href={`/rooms/${roomId}/selection`}>
                {locale === "en" ? "Choose dishes" : "去点餐"}
              </Link>
            </Button>
          </div>
        )}
      </RoomShell>
    );
  }

  const aggregation = await getRoomAggregation(roomId);
  if (!aggregation) return null;

  const { access, dishes, members, menuItemCount, metrics } = aggregation;
  const dietaryMembers = members.filter(
    (member) =>
      member.submittedAt && (member.dietaryRestrictions || member.allergyInfo),
  );
  const [orderData, adviceRecords] = await Promise.all([
    getOrderPageData(roomId),
    getRoomAdviceHistory(roomId),
  ]);
  const confirmed = Boolean(orderData?.finalOrder);
  const currentAdvice = adviceRecords.find(
    (record) => record.source_revision === access.room.selection_revision,
  );

  return (
    <RoomShell
      journey={snapshot.journey}
      locale={locale}
      roomId={roomId}
      aside={
        <Button asChild variant="outline">
          <Link href={`/rooms/${roomId}`}>
            <ArrowLeft />
            {locale === "en" ? "Back to room" : "返回房间"}
          </Link>
        </Button>
      }
      description={
        locale === "en"
          ? "Every number is recalculated from current submissions. This is a review sheet, not the final order."
          : "所有数字都从当前真实提交重新计算；这是一张核对夹板，不是最终订单。"
      }
      eyebrow={
        locale === "en" ? "Organizer · Exact summary" : "组织者 · 精确汇总"
      }
      title={access.room.name}
      wide
    >
      <div className="grid gap-6">
        {receipt ? (
          <section className="grid gap-4 border-y border-[#24322d]/20 bg-[#fbf9f2]/65 p-5 sm:p-6">
            <div>
              <p className="text-xs font-semibold text-primary">
                {locale === "en" ? "Visible to everyone" : "全员共同看到的内容"}
              </p>
              <h2 className="mt-1 text-xl font-black">
                {locale === "en" ? "Table order" : "本桌点单"}
              </h2>
            </div>
            <DynamicReceipt
              initialReceipt={receipt}
              locale={locale}
              memberCount={snapshot.progress.memberCount}
              submittedCount={snapshot.progress.submittedCount}
            />
          </section>
        ) : null}
        <p className="border-t pt-6 text-xs font-semibold tracking-[0.14em] text-muted-foreground uppercase">
          {locale === "en"
            ? "ORGANIZER ONLY · REVIEW & CONFIRM"
            : "以下仅发起者可见 · 核对与确认"}
        </p>
        <section className="grid gap-5 border-y-2 border-[#4f7c70] bg-[#4f7c70]/10 p-5 sm:p-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
          <div className="flex items-start gap-4">
            <span className="grid size-12 shrink-0 place-items-center rounded-full bg-[#dff5e8] text-[#146b45]">
              <Stamp />
            </span>
            <div>
              <h2 className="mt-2 text-xl font-black">
                {locale === "en"
                  ? "Ordering is open · totals may change"
                  : "点餐中 · 数字会继续变化"}
              </h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                {locale === "en"
                  ? "New submissions appear automatically. Review quantities once more before confirming."
                  : "新的提交会自动计入这里，确认前请再看一遍数量。"}
              </p>
            </div>
          </div>
          {confirmed ? (
            <Button asChild className="h-12 rounded-xl font-bold">
              <Link href={`/rooms/${roomId}/order`}>
                <Stamp />
                {locale === "en" ? "View confirmed order" : "查看已确认订单"}
              </Link>
            </Button>
          ) : null}
        </section>

        <section className="grid gap-3 sm:grid-cols-3">
          {[
            {
              hint:
                locale === "en"
                  ? `${metrics.memberCount - metrics.submittedCount} diners remaining`
                  : `${metrics.memberCount - metrics.submittedCount} 人待提交`,
              label: locale === "en" ? "Submitted diners" : "已提交成员",
              value: `${metrics.submittedCount}/${metrics.memberCount}`,
            },
            {
              hint:
                locale === "en"
                  ? `${Math.max(0, menuItemCount - metrics.dishCount)} dishes unselected`
                  : `${Math.max(0, menuItemCount - metrics.dishCount)} 道未选择`,
              label: locale === "en" ? "Dishes selected" : "本桌已选",
              value: metrics.dishCount,
            },
            {
              hint:
                locale === "en" ? "Positive quantities only" : "只相加正数量",
              label: locale === "en" ? "Total servings" : "全部总份数",
              value: metrics.totalQuantity,
            },
          ].map((metric) => (
            <article
              className="border-b border-[#24322d]/20 p-5"
              key={metric.label}
            >
              <p className="font-mono text-[10px] font-semibold tracking-[0.14em] text-muted-foreground uppercase">
                {metric.label}
              </p>
              <p className="mt-3 font-mono text-4xl font-black tabular-nums text-[#24322d]">
                {metric.value}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                {metric.hint}
              </p>
            </article>
          ))}
        </section>

        <TableAdvicePanel
          confirmed={confirmed}
          currentRevision={access.room.selection_revision}
          locale={locale}
          records={adviceRecords}
        />

        {!confirmed &&
        metrics.submittedCount > 0 &&
        dishes.length > 0 &&
        !currentAdvice ? (
          <AutoTableAdvice
            action={generateTableAdviceAction.bind(null, roomId)}
          />
        ) : null}

        {!confirmed && orderData ? (
          <SummaryFinalDecision
            action={confirmFinalOrderAction.bind(
              null,
              roomId,
              access.room.selection_revision,
            )}
            adjustHref={`/rooms/${roomId}/selection`}
            candidates={orderData.candidates}
            locale={locale}
          />
        ) : null}

        <section className="grid gap-6 lg:grid-cols-2 lg:items-start">
          <div className="grid gap-6">
            <AggregationMemberStatus locale={locale} members={members} />
            <p className="flex items-start gap-2 px-1 text-xs leading-5 text-muted-foreground">
              <Users className="mt-0.5 size-3.5 shrink-0" />
              {locale === "en"
                ? "Display names are only for human review; permissions always come from room identity."
                : "显示名只用于人工核对，权限始终来自房间身份。"}
            </p>
          </div>
          <div>
            <DietaryTranslationPanel
              action={translateDiningNotesAction.bind(null, roomId)}
              locale={locale}
              members={dietaryMembers}
            />
          </div>
        </section>
      </div>
    </RoomShell>
  );
}
