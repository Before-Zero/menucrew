"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { AggregationActionState } from "@/lib/aggregation-action-state";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

export async function setCollectionStatusAction(
  roomId: string,
  targetStatus: "open" | "reviewing",
  _previousState: AggregationActionState,
): Promise<AggregationActionState> {
  if (!isValidRoomId(roomId)) {
    return { message: "这个房间地址无效。", revision: null, status: "error" };
  }

  let result: AggregationActionState;

  try {
    const supabase = await createClient();
    const { data, error } = await supabase.rpc(
      "set_selection_collection_status",
      { candidate_room_id: roomId, candidate_status: targetStatus },
    );

    if (error) {
      if (error.message.includes("order_already_confirmed")) {
        return {
          message: "最终订单已经确认，收集不能重新开放。",
          revision: null,
          status: "error",
        };
      }
      if (error.message.includes("room_access_denied")) {
        return {
          message: "只有这间房的组织者可以切换收集状态。",
          revision: null,
          status: "error",
        };
      }
      throw error;
    }

    revalidatePath(`/rooms/${roomId}`);
    revalidatePath(`/rooms/${roomId}/summary`);
    revalidatePath(`/rooms/${roomId}/selection`);
    result = {
      message:
        targetStatus === "reviewing"
          ? "已进入核对，成员保存现已锁定。"
          : "已重新开放，成员可以继续修改。",
      revision: data?.[0]?.new_revision ?? null,
      status: "success",
    };
  } catch (error) {
    console.error("setCollectionStatusAction failed", error);
    return {
      message: "状态暂时没有改变，请稍后重试。",
      revision: null,
      status: "error",
    };
  }

  if (targetStatus === "reviewing") redirect(`/rooms/${roomId}/summary`);
  return result;
}
