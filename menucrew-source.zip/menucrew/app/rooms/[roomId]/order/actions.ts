"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { OrderActionState } from "@/lib/order-action-state";
import { getOrderPageData } from "@/lib/orders";
import { recordProductEvent } from "@/lib/product-events";
import { createClient } from "@/lib/supabase/server";
import { isValidRoomId } from "@/lib/validation";

function failure(message: string): OrderActionState {
  return { message, orderId: null, status: "error" };
}

export async function confirmFinalOrderAction(
  roomId: string,
  sourceRevision: number,
  _previousState: OrderActionState,
  formData: FormData,
): Promise<OrderActionState> {
  if (!isValidRoomId(roomId)) return failure("这个房间地址无效。");
  try {
    const context = await getOrderPageData(roomId);
    if (!context || context.access.currentMember.role !== "organizer") {
      return failure("只有这间房的组织者可以确认订单。");
    }
    if (!context.finalOrder) {
      const items = context.candidates.map((item) => {
        const quantity = String(formData.get(`quantity:${item.id}`) ?? "");
        const note = String(formData.get(`note:${item.id}`) ?? "").trim();
        if (!/^(0|[1-9][0-9]?)$/.test(quantity) || note.length > 500) {
          throw new Error("invalid_form");
        }
        return { finalQuantity: Number(quantity), menuItemId: item.id, note };
      });
      if (!items.some((item) => item.finalQuantity > 0)) {
        return failure("最终订单至少需要保留一道正数量菜品。");
      }
      const supabase = await createClient();
      const { error } = await supabase.rpc("confirm_final_order_direct", {
        candidate_items: items,
        candidate_room_id: roomId,
        candidate_source_revision: sourceRevision,
      });
      if (error) {
        if (error.message.includes("stale_revision"))
          return failure("成员数据已经变化，请刷新后重新核对。");
        if (error.message.includes("collection_closed"))
          return failure("订单正在被确认或已经锁定，请刷新查看结果。");
        if (error.message.includes("room_access_denied"))
          return failure("当前身份没有确认权限。");
        if (error.message.includes("empty_order"))
          return failure("最终订单不能为空。");
        throw error;
      }
    }
    revalidatePath(`/rooms/${roomId}`);
    revalidatePath(`/rooms/${roomId}/summary`);
    revalidatePath(`/rooms/${roomId}/order`);
    await recordProductEvent("order_confirmed", roomId);
  } catch (error) {
    if (error instanceof Error && error.message === "invalid_form") {
      return failure("数量必须是 0–99 的整数，备注不能超过 500 字。");
    }
    console.error("confirmFinalOrderAction failed", error);
    return failure("暂时无法确认，当前订单尚未改变。");
  }

  redirect(`/rooms/${roomId}/summary`);
}
