import { ArrowLeft, Clock3, LockKeyhole } from "lucide-react";
import Link from "next/link";
import { FinalOrderForm } from "@/components/final-order-form";
import { FinalOrderView } from "@/components/final-order-view";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import { getAppLocale } from "@/lib/i18n-server";
import { getOrderPageData } from "@/lib/orders";
import { getRoomJourneySnapshot } from "@/lib/room-progress";
import { hydrateFinalOrderDietaryNotesAction } from "../summary/final-translation-actions";
import { confirmFinalOrderAction } from "./actions";

export default async function OrderPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  const data = await getOrderPageData(roomId);
  const locale = await getAppLocale();
  if (!data)
    return (
      <RoomShell
        description={
          locale === "en"
            ? "Orders are available only to members of this room."
            : "订单只向这间房的成员开放。"
        }
        eyebrow={locale === "en" ? "Order unavailable" : "无法访问订单"}
        locale={locale}
        title={
          locale === "en"
            ? "This session has no seat at this table."
            : "这里没有当前身份的座位。"
        }
      >
        <div className="grid place-items-center py-10 text-center">
          <LockKeyhole className="size-8 text-primary" />
          <Button asChild className="mt-6">
            <Link href="/">{locale === "en" ? "Back home" : "返回首页"}</Link>
          </Button>
        </div>
      </RoomShell>
    );
  const snapshot = await getRoomJourneySnapshot(roomId);
  if (!snapshot) return null;
  if (data.finalOrder)
    return (
      <RoomShell
        journey={snapshot.journey}
        locale={locale}
        roomId={roomId}
        aside={
          <Button asChild variant="outline">
            <Link href={`/rooms/${roomId}`}>
              <ArrowLeft />
              {locale === "en" ? "Back to room" : "返回房间"}
            </Link>
          </Button>
        }
        description={
          locale === "en"
            ? "Everyone sees the same confirmed result. Switch between a restaurant order and a Chinese checklist."
            : "所有成员看到同一份确认结果；可切换为给餐厅看的精简订单或中文核对清单。"
        }
        eyebrow={locale === "en" ? "Confirmed order" : "已确认订单"}
        title={data.access.room.name}
        wide
      >
        <FinalOrderView
          data={data.finalOrder}
          locale={locale}
          translationAction={
            data.access.currentMember.role === "organizer"
              ? hydrateFinalOrderDietaryNotesAction.bind(null, roomId)
              : undefined
          }
        />
      </RoomShell>
    );
  if (data.access.currentMember.role !== "organizer")
    return (
      <RoomShell
        journey={snapshot.journey}
        locale={locale}
        roomId={roomId}
        aside={
          <Button asChild variant="outline">
            <Link href={`/rooms/${roomId}`}>
              <ArrowLeft />
              {locale === "en" ? "Back to room" : "返回房间"}
            </Link>
          </Button>
        }
        description={
          locale === "en"
            ? "One bilingual order appears here after the organizer confirms it."
            : "组织者确认后，这里会出现全员一致的双语订单。"
        }
        eyebrow={
          locale === "en" ? "Waiting for final confirmation" : "等待最终确认"
        }
        title={data.access.room.name}
      >
        <div className="grid place-items-center py-12 text-center">
          <span className="grid size-14 place-items-center rounded-full bg-[#fff5e5] text-[#9a5e0b]">
            <Clock3 />
          </span>
          <h2 className="mt-5 text-xl font-black">
            {locale === "en" ? "The order is under review" : "订单还在核对"}
          </h2>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "You cannot see the organizer's unconfirmed adjustments."
              : "你不会看到组织者尚未确认的调整内容。"}
          </p>
        </div>
      </RoomShell>
    );
  return (
    <RoomShell
      journey={snapshot.journey}
      locale={locale}
      roomId={roomId}
      aside={
        <Button asChild variant="outline">
          <Link href={`/rooms/${roomId}/summary`}>
            <ArrowLeft />
            {locale === "en" ? "Back to exact summary" : "返回精确汇总"}
          </Link>
        </Button>
      }
      description={
        locale === "en"
          ? "Set the quantity the restaurant should receive. This is the only locking step and creates an immutable bilingual snapshot."
          : "逐道决定实际向餐厅点多少；这一步是唯一锁定动作，确认后生成不可变双语快照。"
      }
      eyebrow={
        locale === "en"
          ? "Organizer · Manual confirmation"
          : "组织者 · 人工确认"
      }
      title={data.access.room.name}
      wide
    >
      <FinalOrderForm
        action={confirmFinalOrderAction.bind(
          null,
          roomId,
          data.access.room.selection_revision,
        )}
        candidates={data.candidates}
        dietaryNotes={data.dietaryNotes}
        locale={locale}
      />
    </RoomShell>
  );
}
