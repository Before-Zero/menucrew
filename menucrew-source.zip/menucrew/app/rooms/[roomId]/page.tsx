import { LockKeyhole, UserRound } from "lucide-react";
import { cookies, headers } from "next/headers";
import Link from "next/link";
import { MemberRoomDashboard } from "@/components/member-room-dashboard";
import { OrganizerRoomDashboard } from "@/components/organizer-room-dashboard";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import { localizedRoomJourney } from "@/lib/i18n";
import { getAppLocale } from "@/lib/i18n-server";
import { inviteCookieName } from "@/lib/invitations";
import { createInviteQrDataUrl } from "@/lib/invite-qr";
import { getRoomJourneySnapshot } from "@/lib/room-progress";

function AccessDenied() {
  return (
    <RoomShell
      description="这个地址本身不能证明你属于房间。请在保留原身份的浏览器中打开，或向组织者获取有效邀请。"
      eyebrow="无法访问房间"
      title="这张桌子没有你的座位。"
    >
      <div className="grid place-items-center py-8 text-center">
        <span className="grid size-14 place-items-center rounded-full bg-[#fff0eb] text-primary">
          <LockKeyhole aria-hidden="true" className="size-6" />
        </span>
        <h2 className="mt-5 text-xl font-bold">需要有效的房间身份</h2>
        <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
          为了保护房间，我们不会确认这个房间是否存在，也不会展示任何成员信息。
        </p>
        <Button asChild className="mt-6 h-11 rounded-xl px-5">
          <Link href="/">返回首页</Link>
        </Button>
      </div>
    </RoomShell>
  );
}

export default async function RoomPage({
  params,
}: {
  params: Promise<{ roomId: string }>;
}) {
  const { roomId } = await params;
  const locale = await getAppLocale();
  const snapshot = await getRoomJourneySnapshot(roomId);

  if (!snapshot) return <AccessDenied />;

  const { access, journey, progress } = snapshot;
  const displayJourney = localizedRoomJourney(journey, locale);
  const organizer = access.currentMember.role === "organizer";
  const inviteToken = organizer
    ? (await cookies()).get(inviteCookieName(roomId))?.value
    : undefined;
  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host");
  const protocol = requestHeaders.get("x-forwarded-proto") ?? "http";
  const inviteUrl =
    inviteToken && host ? `${protocol}://${host}/join/${inviteToken}` : null;
  const qrDataUrl = inviteUrl
    ? await createInviteQrDataUrl(inviteUrl)
    : undefined;

  return (
    <RoomShell
      locale={locale}
      aside={
        <div className="flex items-center gap-3 rounded-2xl border border-[#d8d7d2] bg-[#fffefb]/80 p-4">
          <span className="grid size-10 place-items-center rounded-full bg-[#fff0eb] text-primary">
            <UserRound aria-hidden="true" className="size-5" />
          </span>
          <div>
            <p className="font-semibold">{access.currentMember.display_name}</p>
            <p className="text-sm text-muted-foreground">
              {organizer
                ? locale === "en"
                  ? "Organizer"
                  : "发起人"
                : locale === "en"
                  ? "Diner"
                  : "参与者"}{" "}
              · {displayJourney.stageLabel}
            </p>
          </div>
        </div>
      }
      description={
        organizer
          ? locale === "en"
            ? "Follow the next step. Everyone sees the same table stage in their own browser."
            : "根据当前进度完成下一步，成员会在各自的浏览器中看到同一阶段。"
          : locale === "en"
            ? "See where the table is now and what you need to do next."
            : "这里会告诉你现在进行到哪里，以及你接下来需要做什么。"
      }
      eyebrow={
        organizer
          ? locale === "en"
            ? "Organizer workspace"
            : "发起人工作台"
          : locale === "en"
            ? "Table progress"
            : "聚餐进度"
      }
      journey={journey}
      roomId={roomId}
      title={access.room.name}
      wide
    >
      {organizer ? (
        <OrganizerRoomDashboard
          inviteToken={inviteToken}
          joinCode={access.room.join_code}
          journey={displayJourney}
          locale={locale}
          memberCount={progress.memberCount}
          qrDataUrl={qrDataUrl}
          submittedCount={progress.submittedCount}
        />
      ) : (
        <MemberRoomDashboard
          journey={displayJourney}
          locale={locale}
          memberCount={progress.memberCount}
          roomId={roomId}
          submittedCount={progress.submittedCount}
        />
      )}
    </RoomShell>
  );
}
