import {
  ArrowDown,
  ArrowLeft,
  ClipboardCheck,
  ScanLine,
  UsersRound,
} from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { FinalOrderView } from "@/components/final-order-view";
import { RoomShell } from "@/components/room-shell";
import { Button } from "@/components/ui/button";
import type { FinalOrder } from "@/lib/orders";

export const metadata: Metadata = {
  title: "完整示例",
  description: "无需注册，直接查看 MenuCrew 如何把多人选择汇成一份双语订单。",
};

const demoOrder: FinalOrder = {
  access: {
    currentMember: {
      display_name: "演示组织者",
      joined_at: "2026-09-15T10:00:00.000Z",
      role: "organizer",
      room_id: "00000000-0000-4000-8000-000000000001",
      user_id: "00000000-0000-4000-8000-000000000002",
    },
    members: [],
    room: {
      created_at: "2026-09-15T10:00:00.000Z",
      created_by: "00000000-0000-4000-8000-000000000002",
      id: "00000000-0000-4000-8000-000000000001",
      invite_active: false,
      join_code: "246810",
      name: "巴塞罗那的周末晚餐",
      selection_revision: 4,
      selection_status: "reviewing",
      selection_status_changed_at: "2026-09-15T10:08:00.000Z",
    },
  },
  items: [
    [
      "Paella de verduras",
      "蔬菜西班牙饭",
      "Vegetable paella",
      2,
      "三人分享，少盐",
    ],
    ["Pollo al ajillo", "蒜香鸡", "Garlic chicken", 1, ""],
    ["Ensalada de tomate", "番茄沙拉", "Tomato salad", 1, "酱汁另放"],
    ["Patatas bravas", "辣味炸土豆", "Patatas bravas", 1, "少辣"],
    ["Crema catalana", "加泰罗尼亚焦糖布丁", "Catalan cream", 1, ""],
  ].map(([originalName, zhName, enName, quantity, note], index) => ({
    en_name: String(enName),
    final_quantity: Number(quantity),
    id: `00000000-0000-4000-8000-${String(index + 10).padStart(12, "0")}`,
    member_names: [],
    menu_item_id: `00000000-0000-4000-8000-${String(index + 20).padStart(12, "0")}`,
    note: String(note),
    order_id: "00000000-0000-4000-8000-000000000003",
    original_name: String(originalName),
    position: index * 100,
    requested_quantity: Number(quantity),
    zh_name: String(zhName),
  })),
  order: {
    confirmed_at: "2026-09-15T10:12:00.000Z",
    confirmed_by: "00000000-0000-4000-8000-000000000002",
    dietary_notes: [
      {
        allergyEn: "Peanut allergy. Please confirm there is no cross-contact.",
        allergyInfo: "花生过敏，请确认没有交叉接触",
        allergyZh: "花生过敏，请确认没有交叉接触。",
        dietaryEn: "No cilantro.",
        dietaryRestrictions: "不吃香菜",
        dietaryZh: "不吃香菜。",
        displayName: "成员 B",
      },
    ],
    id: "00000000-0000-4000-8000-000000000003",
    room_id: "00000000-0000-4000-8000-000000000001",
    source_revision: 4,
  },
};

export default function DemoPage() {
  const story = [
    {
      copy: "拍下看不懂的外语菜单，AI 辅助整理原文、中文名和菜品说明。",
      icon: ScanLine,
      label: "看懂菜单",
    },
    {
      copy: "每个人在自己手机上选菜，数量变化会实时汇到组织者页面。",
      icon: UsersRound,
      label: "各自选择",
    },
    {
      copy: "系统合并重复菜品、数量、备注和过敏信息，生成一张双语订单。",
      icon: ClipboardCheck,
      label: "一起落单",
    },
  ];

  return (
    <RoomShell
      activeControl={7}
      aside={
        <Button asChild variant="outline">
          <Link href="/">
            <ArrowLeft /> 返回首页
          </Link>
        </Button>
      }
      description="朋友在国外餐厅看不懂菜单、又要分别记住每个人点了什么。MenuCrew 把这段混乱流程收拢成一张可以直接给餐厅看的订单。"
      eyebrow="2 分钟看懂 · 产品示例"
      title="它解决的是：一桌人怎么点同一份外语菜单"
      wide
    >
      <section className="mb-10 border-y border-[#24322d]/20 bg-[#fbf9f2]/72 p-5 sm:p-7">
        <p className="font-mono text-[10px] font-bold tracking-[0.16em] text-primary uppercase">
          How it works · 从问题到结果
        </p>
        <div className="mt-6 grid gap-6 md:grid-cols-3 md:gap-0">
          {story.map((item, index) => {
            const Icon = item.icon;
            return (
              <article
                className="relative border-[#24322d]/15 md:border-l md:px-6 md:first:border-l-0 md:first:pl-0"
                key={item.label}
              >
                <div className="flex items-center gap-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-full border border-[#b9433c]/40 text-[#b9433c]">
                    <Icon className="size-[18px]" />
                  </span>
                  <p className="font-mono text-xs font-bold text-primary">
                    0{index + 1}
                  </p>
                </div>
                <h2 className="mt-4 text-lg font-black">{item.label}</h2>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  {item.copy}
                </p>
              </article>
            );
          })}
        </div>
      </section>

      <div className="mb-7 flex flex-col items-center text-center">
        <span className="grid size-9 place-items-center rounded-full bg-[#b9433c] text-white">
          <ArrowDown className="size-4" />
        </span>
        <p className="mt-3 font-mono text-[10px] font-bold tracking-[0.16em] text-primary uppercase">
          You are viewing step 03
        </p>
        <h2 className="mt-2 text-2xl font-black">下面就是最终生成的双语订单</h2>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
          示例：西班牙语菜单 · 3 位同桌 · 5 道菜 · 6 份 · 1
          条过敏提醒。试着切换“给餐厅看 / 中文核对”。
        </p>
      </div>
      <FinalOrderView data={demoOrder} />
    </RoomShell>
  );
}
