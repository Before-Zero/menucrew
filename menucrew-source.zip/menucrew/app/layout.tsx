import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { DiningRouteTransition } from "@/components/dining-route-transition";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? "https://menucrew-demo.vercel.app",
  ),
  title: {
    default: "合点 MenuCrew",
    template: "%s · 合点 MenuCrew",
  },
  description:
    "Menu Crew · 海外餐厅多人协作点餐，从一条房间邀请开始。 Collaborative bilingual ordering for one table.",
  openGraph: {
    description:
      "上传菜单、邀请同桌、各自选菜，最后汇成一份全桌都看得懂的双语订单。",
    locale: "zh_CN",
    siteName: "合点 MenuCrew",
    title: "语言虽异，心意同桌。",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    description: "多人协作点餐，汇成一份双语订单。",
    title: "合点 MenuCrew",
  },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="zh-CN"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col">
        <script data-design-contract="b013bc00" type="application/json">
          {JSON.stringify({
            thesis:
              "Menu Crew turns a shared meal into one continuous dining route, from taking a seat to placing one final bilingual order.",
            ownWorld:
              "Warm map paper, food-terrain contours, coral route ink, green field marks, ochre annotations, numbered controls, and receipt-like records.",
            story:
              "The stable table map stays beneath every screen. Completed legs remain visible, the current control becomes the focal point, and future legs recede without disappearing.",
            firstViewport:
              "Multilingual phrases form the terrain while one dining route crosses the page toward the create-table control; pointer movement shifts nearby language and route depth without delaying the action.",
            form: "Impeccable direction seed b013bc00, chosen world notation-diagram-systems-orienteering-map, code-led.",
            finish:
              "unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance",
          })}
        </script>
        {children}
        <DiningRouteTransition />
      </body>
    </html>
  );
}
