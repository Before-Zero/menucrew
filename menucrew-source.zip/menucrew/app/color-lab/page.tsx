import { ColorDirectionLab } from "@/components/color-direction-lab";

export default function ColorLabPage() {
  return <ColorDirectionLab />;
}
