"use client";

import { useEffect } from "react";

export default function GlobalError({
  error,
  retry,
}: {
  error: Error & { digest?: string };
  retry: () => void;
}) {
  useEffect(() => {
    console.error("应用渲染失败", error.digest ?? "no-digest");
  }, [error.digest]);

  return (
    <html lang="zh-CN">
      <body
        style={{
          background: "#f3efe8",
          color: "#211f1d",
          display: "grid",
          fontFamily: "Arial, sans-serif",
          margin: 0,
          minHeight: "100vh",
          padding: "24px",
          placeItems: "center",
        }}
      >
        <main
          style={{
            background: "#fffefb",
            border: "1px solid #d8d7d2",
            borderRadius: "20px",
            boxShadow: "0 24px 70px rgb(33 31 29 / 0.1)",
            boxSizing: "border-box",
            maxWidth: "560px",
            overflow: "hidden",
            width: "100%",
          }}
        >
          <section style={{ padding: "40px" }}>
            <p style={{ color: "#d95d45", fontSize: "13px", fontWeight: 700 }}>
              合点 MenuCrew
            </p>
            <h1
              style={{
                fontSize: "36px",
                letterSpacing: "-1.5px",
                margin: "28px 0 12px",
              }}
            >
              应用暂时没有响应。
            </h1>
            <p style={{ color: "#6e6e73", lineHeight: 1.75, margin: 0 }}>
              可能是网络或云端服务短暂不可用。你的数据不会因此被清空，请重新加载。
            </p>
            <button
              onClick={() => retry()}
              style={{
                background: "#d95d45",
                border: 0,
                borderRadius: "10px",
                color: "#ffffff",
                cursor: "pointer",
                fontSize: "14px",
                fontWeight: 700,
                marginTop: "28px",
                padding: "12px 18px",
              }}
              type="button"
            >
              重新加载
            </button>
          </section>
        </main>
      </body>
    </html>
  );
}
