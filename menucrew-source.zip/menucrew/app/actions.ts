"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { after } from "next/server";
import { isAppLocale, LOCALE_COOKIE } from "@/lib/i18n";
import {
  createInviteToken,
  digestInviteToken,
  inviteCookieName,
} from "@/lib/invitations";
import { recordProductEvent } from "@/lib/product-events";
import type { RoomActionState } from "@/lib/room-action-state";
import { getRoomJourneySnapshot } from "@/lib/room-progress";
import { createClient } from "@/lib/supabase/server";
import {
  isValidInviteToken,
  validateCreateRoomInput,
  validateJoinCodeInput,
  validateJoinRoomInput,
} from "@/lib/validation";

async function ensureAnonymousSession() {
  const supabase = await createClient();
  // Browser-first anonymous sign-in writes the session cookie immediately
  // before this Server Action runs. Reuse that cookie-backed session so the
  // server does not create a second anonymous user. The RPC still validates
  // the JWT and auth.uid() at Supabase, so this is not an authorization check.
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (session) {
    return supabase;
  }

  const { data: claimsData } = await supabase.auth.getClaims();

  if (typeof claimsData?.claims?.sub === "string") {
    return supabase;
  }

  const { error } = await supabase.auth.signInAnonymously();

  if (error) {
    throw new Error("anonymous_sign_in_failed", { cause: error });
  }

  return supabase;
}

function serviceError(): RoomActionState {
  return {
    message: "暂时无法完成操作，请稍后重试。",
    status: "error",
  };
}

export async function createRoomAction(
  _previousState: RoomActionState,
  formData: FormData,
): Promise<RoomActionState> {
  const input = validateCreateRoomInput(formData);

  if (!input.valid) {
    return {
      fields: input.fields,
      message: "请检查标出的内容。",
      status: "error",
    };
  }

  const inviteToken = createInviteToken();
  const inviteDigest = digestInviteToken(inviteToken);
  let roomId: string;

  try {
    const supabase = await ensureAnonymousSession();
    const { data, error } = await supabase.rpc("create_room", {
      display_name: input.data.displayName,
      invite_digest: inviteDigest,
      room_name: input.data.roomName,
    });

    if (error || !data) {
      console.error(
        `create_room failed ${JSON.stringify(
          error
            ? {
                code: error.code,
                details: error.details,
                hint: error.hint,
                message: error.message,
              }
            : { message: "RPC returned no room id" },
        )}`,
      );
      return serviceError();
    }

    roomId = data;
    after(() => recordProductEvent("room_created", roomId));

    const cookieStore = await cookies();
    cookieStore.set(inviteCookieName(roomId), inviteToken, {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 365,
      path: `/rooms/${roomId}`,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    });
  } catch (error) {
    console.error("createRoomAction failed", error);
    return serviceError();
  }

  redirect(`/rooms/${roomId}`);
}

export async function setLocaleAction(returnTo: string, formData: FormData) {
  const locale = formData.get("locale");
  if (!isAppLocale(locale)) return;
  (await cookies()).set(LOCALE_COOKIE, locale, {
    maxAge: 60 * 60 * 24 * 365,
    path: "/",
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
  });
  redirect(returnTo.startsWith("/") ? returnTo : "/");
}

export async function joinRoomAction(
  token: string,
  _previousState: RoomActionState,
  formData: FormData,
): Promise<RoomActionState> {
  if (!isValidInviteToken(token)) {
    return {
      message: "邀请无效或已不可用，请联系组织者获取新链接。",
      status: "error",
    };
  }

  const input = validateJoinRoomInput(formData);

  if (!input.valid) {
    return {
      fields: input.fields,
      message: "请检查标出的内容。",
      status: "error",
    };
  }

  let roomId: string;
  let destination: string;

  try {
    const supabase = await ensureAnonymousSession();
    const { data, error } = await supabase.rpc("join_room", {
      display_name: input.data.displayName,
      invite_digest: digestInviteToken(token),
    });

    if (error || !data) {
      if (error?.message.includes("invite_unavailable")) {
        return {
          message: "邀请无效或已不可用，请联系组织者获取新链接。",
          status: "error",
        };
      }

      console.error("join_room failed", error);
      return serviceError();
    }

    roomId = data;
    after(() => recordProductEvent("room_joined", roomId));
    const journey = await getRoomJourneySnapshot(roomId);
    if (!journey) return serviceError();
    destination =
      journey.journey.stage === "completed"
        ? `/rooms/${roomId}/order`
        : journey.journey.stage === "collecting"
          ? `/rooms/${roomId}/selection`
          : `/rooms/${roomId}`;
  } catch (error) {
    console.error("joinRoomAction failed", error);
    return serviceError();
  }

  redirect(destination);
}

export async function joinRoomByCodeAction(
  _previousState: RoomActionState,
  formData: FormData,
): Promise<RoomActionState> {
  const input = validateJoinCodeInput(formData);
  if (!input.valid) {
    return {
      fields: input.fields,
      message: "请检查标出的内容。",
      status: "error",
    };
  }

  let roomId: string;
  let destination: string;
  try {
    const supabase = await ensureAnonymousSession();
    const { data, error } = await supabase.rpc("join_room_by_code", {
      display_name: input.data.displayName,
      room_code: input.data.roomCode,
    });
    if (error || !data) {
      if (error?.message.includes("room_code_unavailable")) {
        return {
          message: "没有找到可加入的餐桌，请核对 6 位入席码。",
          status: "error",
        };
      }
      console.error("join_room_by_code failed", error);
      return serviceError();
    }

    roomId = data;
    after(() => recordProductEvent("room_joined", roomId));
    const journey = await getRoomJourneySnapshot(roomId);
    if (!journey) return serviceError();
    destination =
      journey.journey.stage === "completed"
        ? `/rooms/${roomId}/order`
        : journey.journey.stage === "collecting"
          ? `/rooms/${roomId}/selection`
          : `/rooms/${roomId}`;
  } catch (error) {
    console.error("joinRoomByCodeAction failed", error);
    return serviceError();
  }

  redirect(destination);
}
