"use client";

import Link from "next/link";
import { useState } from "react";
import { MenuCrewMark } from "@/components/menu-crew-mark";
import styles from "./flat-lab.module.css";

const scenes = [
  {
    id: "start",
    short: "开一桌",
    title: "坐下 & 开吃",
    english: "TAKE A SEAT",
    copy: "不用注册。开一张共享餐桌，把私密邀请发给这顿饭的每个人。",
    action: "发起一桌",
  },
  {
    id: "menu",
    short: "读菜单",
    title: "看不懂 & 看得懂",
    english: "OPEN THE MENU",
    copy: "原菜单从一边展开，中英文在同一页上对齐。AI 只是帮忙，发布前仍由你确认。",
    action: "放入菜单",
  },
  {
    id: "choose",
    short: "各自选",
    title: "你选 & 我选",
    english: "PASS THE PLATES",
    copy: "每个人只操作自己的小碟子。数量、备注和忌口都留在本人选择里。",
    action: "选我想吃的",
  },
  {
    id: "order",
    short: "合一单",
    title: "散开 & 合点",
    english: "ONE TABLE. ONE ORDER.",
    copy: "分散的选择汇成一张可核对的双语订单。确认后，整桌人看到同一份结果。",
    action: "交给餐厅",
  },
] as const;

type SceneId = (typeof scenes)[number]["id"];

const sceneClass: Record<SceneId, string> = {
  start: styles.sceneStart,
  menu: styles.sceneMenu,
  choose: styles.sceneChoose,
  order: styles.sceneOrder,
};

export function FlatLab() {
  const [active, setActive] = useState<SceneId>("start");
  const scene = scenes.find((item) => item.id === active) ?? scenes[0];
  const activeIndex = scenes.findIndex((item) => item.id === active);
  const nextScene = scenes[(activeIndex + 1) % scenes.length];

  return (
    <main className={`${styles.page} ${sceneClass[active]}`}>
      <header className={styles.header}>
        <Link className={styles.brand} href="/">
          <MenuCrewMark className={styles.mark} />
          <span>合点 Menu Crew</span>
        </Link>
        <span className={styles.labLabel}>FLAT LAB</span>
        <Link className={styles.back} href="/">
          返回正式版
        </Link>
      </header>

      <section className={styles.stage} aria-live="polite">
        <div className={styles.copyBlock} key={`${active}-copy`}>
          <p className={styles.english}>{scene.english}</p>
          <h1>{scene.title}</h1>
          <p className={styles.description}>{scene.copy}</p>
          <button
            className={styles.primaryAction}
            onClick={() => setActive(nextScene.id)}
            type="button"
          >
            {scene.action}
          </button>
        </div>

        <div className={styles.visual} aria-hidden="true">
          <div className={styles.sun} />
          <div className={styles.table}>
            <div className={styles.tableTop} />
            <div className={`${styles.chair} ${styles.chairOne}`} />
            <div className={`${styles.chair} ${styles.chairTwo}`} />
            <div className={`${styles.chair} ${styles.chairThree}`} />
            <div className={`${styles.chair} ${styles.chairFour}`} />

            <div className={`${styles.plate} ${styles.plateOne}`}>
              <i />
            </div>
            <div className={`${styles.plate} ${styles.plateTwo}`}>
              <i />
            </div>
            <div className={`${styles.plate} ${styles.plateThree}`}>
              <i />
            </div>
            <div className={`${styles.plate} ${styles.plateFour}`}>
              <i />
            </div>

            <div className={styles.menu}>
              <div className={styles.menuLeft}>
                <span>MENU</span>
                <b>GADO GADO</b>
                <b>SOTO AYAM</b>
              </div>
              <div className={styles.menuRight}>
                <span>菜单</span>
                <b>花生酱蔬菜</b>
                <b>黄姜鸡汤</b>
              </div>
            </div>

            <div className={styles.receipt}>
              <strong>ONE TABLE</strong>
              <span>02 × GADO GADO</span>
              <span>01 × SOTO AYAM</span>
              <i />
              <b>READY TO ORDER</b>
            </div>
          </div>
          <p className={styles.sceneWord}>{scene.short}</p>
        </div>
      </section>

      <nav className={styles.sceneNav} aria-label="视觉阶段预览">
        {scenes.map((item, index) => (
          <button
            aria-current={active === item.id ? "step" : undefined}
            className={active === item.id ? styles.activeTab : undefined}
            key={item.id}
            onClick={() => setActive(item.id)}
            type="button"
          >
            <span>{String(index + 1).padStart(2, "0")}</span>
            {item.short}
          </button>
        ))}
      </nav>
    </main>
  );
}
