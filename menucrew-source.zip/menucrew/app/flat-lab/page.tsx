import type { Metadata } from "next";
import { FlatLab } from "./flat-lab";

export const metadata: Metadata = {
  title: "Flat Lab",
  description: "Menu Crew 扁平化视觉方向实验。",
};

export default function FlatLabPage() {
  return <FlatLab />;
}
