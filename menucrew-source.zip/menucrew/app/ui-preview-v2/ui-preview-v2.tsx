"use client";

import {
  Check,
  ChevronLeft,
  ChevronRight,
  Clipboard,
  Minus,
  Pencil,
  Plus,
  QrCode,
  Sparkles,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { MenuCrewMark } from "@/components/menu-crew-mark";
import styles from "./ui-preview-v2.module.css";

const stages = [
  { id: "room", label: "邀请入座" },
  { id: "menu", label: "整理菜单" },
  { id: "selection", label: "挑选想吃的" },
] as const;

type Stage = (typeof stages)[number]["id"];
type RecognitionState = "ready" | "recognizing" | "done";
type PreviewTransition = "arriving" | "covering" | "idle";

const dishes = [
  {
    id: "soup",
    original: "Sopa de tomate",
    title: "番茄汤",
    note: "Roasted tomato · basil",
  },
  {
    id: "bruschetta",
    original: "Bruschetta classica",
    title: "经典番茄面包",
    note: "Tomato · garlic · olive oil",
  },
  {
    id: "ragu",
    original: "Tagliatelle al ragù",
    title: "肉酱宽面",
    note: "Slow-cooked beef ragù",
  },
  {
    id: "melanzane",
    original: "Melanzane alla parmigiana",
    title: "帕玛森焗茄子",
    note: "Aubergine · tomato · cheese",
  },
  {
    id: "pollo",
    original: "Pollo al limone",
    title: "柠檬鸡",
    note: "Lemon · rosemary",
  },
] as const;

const recognizedDishes = [
  ["Bruschetta al Pomodoro", "番茄烤面包"],
  ["Gnocchi al Pesto", "青酱马铃薯团子"],
  ["Tagliata di Manzo", "香煎切片牛排"],
  ["Tiramisù", "提拉米苏"],
] as const;

function AmbientWords({ quiet }: { quiet: boolean }) {
  return (
    <div aria-hidden="true" className={styles.ambient} data-quiet={quiet}>
      <span>Bon appétit</span>
      <span>好好吃饭</span>
      <span>いただきます</span>
      <span>À table</span>
      <span>一起开饭</span>
      <span>맛있게 드세요</span>
    </div>
  );
}

function Header({
  stage,
  setStage,
}: {
  stage: Stage;
  setStage: (stage: Stage) => void;
}) {
  return (
    <header className={styles.header}>
      <div className={styles.brand}>
        <MenuCrewMark className={styles.brandMark} />
        <span>合点 Menu Crew</span>
      </div>
      <nav aria-label="V3 预览场景" className={styles.stageNav}>
        {stages.map((item, index) => (
          <button
            aria-current={stage === item.id ? "page" : undefined}
            className={styles.stageButton}
            data-active={stage === item.id}
            key={item.id}
            onClick={() => setStage(item.id)}
            type="button"
          >
            <span>{String(index + 1).padStart(2, "0")}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className={styles.locale}>
        <strong>中</strong>
        <span>/</span>
        EN
      </div>
    </header>
  );
}

function RoomScene() {
  const [copied, setCopied] = useState(false);

  async function copyInvite() {
    try {
      await navigator.clipboard.writeText("https://menucrew.app/join/MC-7K9P");
    } catch {
      // The visual preview still shows the interaction in restricted browsers.
    }
    setCopied(true);
  }

  return (
    <section aria-labelledby="room-title" className={styles.roomScene}>
      <div className={styles.roomIntro}>
        <p className={styles.eyebrow}>PREPARING · 邀请入座</p>
        <h1 id="room-title">罗马第一顿</h1>
        <p className={styles.lede}>先邀请同桌入席，再一起看菜单。</p>
        <div className={styles.roomAction}>
          <p>下一步，让同桌加入</p>
          <button
            className={styles.primaryButton}
            onClick={copyInvite}
            type="button"
          >
            {copied ? (
              <Check aria-hidden="true" />
            ) : (
              <Clipboard aria-hidden="true" />
            )}
            {copied ? "邀请链接已复制" : "复制邀请链接"}
          </button>
          <span>分享私密链接，成员不会看到彼此的选择。</span>
        </div>
        <dl className={styles.metrics}>
          <div>
            <dt>已入席</dt>
            <dd>4</dd>
          </div>
          <div>
            <dt>已提交</dt>
            <dd>3</dd>
          </div>
          <div>
            <dt>等待中</dt>
            <dd>1</dd>
          </div>
        </dl>
      </div>
      <div className={styles.inviteObject} data-copied={copied}>
        <p>PRIVATE TABLE INVITE</p>
        <strong>请同桌扫码入座</strong>
        <div className={styles.qrSurface}>
          <QrCode aria-label="房间邀请二维码演示" />
        </div>
        <div className={styles.roomCode}>
          <span>MC-7K9P</span>
          {copied ? <Check aria-hidden="true" /> : null}
        </div>
        <small>{copied ? "邀请链接已复制" : "房间链接只对这一桌有效"}</small>
        <i aria-hidden="true" className={styles.feedbackThread} />
      </div>
    </section>
  );
}

function MenuScene() {
  const [recognition, setRecognition] = useState<RecognitionState>("ready");
  const timerRef = useRef<number | null>(null);

  useEffect(
    () => () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    },
    [],
  );

  function recognize() {
    if (recognition === "recognizing") return;
    setRecognition("recognizing");
    timerRef.current = window.setTimeout(() => setRecognition("done"), 2100);
  }

  return (
    <section aria-labelledby="menu-title" className={styles.menuScene}>
      <div className={styles.menuHeading}>
        <div>
          <p className={styles.eyebrow}>MENU WORKSPACE · 整理菜单</p>
          <h1 id="menu-title">建立双语菜单</h1>
        </div>
        <p>图片、识别、确认，像翻开一本菜单一样自然。</p>
      </div>
      <div className={styles.menuSpread} data-state={recognition}>
        <section aria-label="菜单图片" className={styles.uploadSide}>
          <p className={styles.sectionIndex}>01 · 菜单图片</p>
          <div className={styles.imageWell}>
            <div aria-hidden="true" className={styles.menuPhoto}>
              <div className={styles.sourceMenu}>
                <strong>TRATTORIA ROMA</strong>
                <span>ANTIPASTI</span>
                <i>Bruschetta al pomodoro</i>
                <i>Carciofi alla romana</i>
                <span>PRIMI</span>
                <i>Gnocchi al pesto</i>
                <i>Tagliata di manzo</i>
                <span>DOLCI</span>
                <i>Tiramisù della casa</i>
              </div>
              <i className={styles.photoScan} />
            </div>
            <strong>menu_roma.jpg</strong>
            <span>已上传 · 适合识别</span>
          </div>
          <div className={styles.imageActions}>
            <button type="button">
              <Plus aria-hidden="true" />
              增加
            </button>
            <button type="button">
              <Pencil aria-hidden="true" />
              调整
            </button>
          </div>
        </section>
        <div aria-hidden="true" className={styles.binding}>
          <i />
        </div>
        <section
          aria-live="polite"
          aria-label="AI 识别结果"
          className={styles.recognitionSide}
        >
          <div className={styles.resultHeader}>
            <div>
              <p className={styles.sectionIndex}>02 · 识别结果</p>
              <h2>
                {recognition === "ready"
                  ? "等待开始"
                  : recognition === "recognizing"
                    ? "正在读菜单"
                    : "整理后的双语菜单"}
              </h2>
            </div>
            <span>{recognition === "done" ? "4 道菜" : "AI 辅助"}</span>
          </div>
          {recognition === "ready" ? (
            <div className={styles.recognitionEmpty}>
              <Sparkles aria-hidden="true" />
              <p>开始后，识别结果会在这里成为一份可以编辑的菜单。</p>
            </div>
          ) : null}
          {recognition === "recognizing" ? (
            <output aria-label="正在识别菜单" className={styles.skeletonList}>
              {[0, 1, 2, 3].map((item) => (
                <i key={item} />
              ))}
            </output>
          ) : null}
          {recognition === "done" ? (
            <ol className={styles.resultList}>
              {recognizedDishes.map(([original, translated]) => (
                <li key={original}>
                  <span>
                    <strong>{original}</strong>
                    <small>{translated}</small>
                  </span>
                  <Pencil aria-hidden="true" />
                </li>
              ))}
            </ol>
          ) : null}
          <button
            className={styles.primaryButton}
            onClick={recognize}
            type="button"
          >
            {recognition === "ready"
              ? "开始 AI 识别"
              : recognition === "recognizing"
                ? "正在识别…"
                : "重新播放识别"}
            {recognition === "recognizing" ? (
              <Sparkles aria-hidden="true" />
            ) : (
              <ChevronRight aria-hidden="true" />
            )}
          </button>
        </section>
      </div>
    </section>
  );
}

function SelectionScene() {
  const [quantities, setQuantities] = useState<Record<string, number>>({
    bruschetta: 2,
    melanzane: 1,
    soup: 1,
  });
  const [saved, setSaved] = useState(false);
  const total = Object.values(quantities).reduce(
    (sum, quantity) => sum + quantity,
    0,
  );
  const picked = Object.values(quantities).filter(
    (quantity) => quantity > 0,
  ).length;

  function changeQuantity(id: string, delta: number) {
    setSaved(false);
    setQuantities((current) => ({
      ...current,
      [id]: Math.max(0, Math.min(9, (current[id] ?? 0) + delta)),
    }));
  }

  return (
    <section
      aria-labelledby="selection-title"
      className={styles.selectionScene}
    >
      <div className={styles.selectionMain}>
        <p className={styles.eyebrow}>MY SELECTION · 个人选择</p>
        <h1 id="selection-title">这次，我想吃这些。</h1>
        <p className={styles.lede}>选自己的，不需要猜别人点了什么。</p>
        <ol className={styles.dishList}>
          {dishes.map((dish) => {
            const quantity = quantities[dish.id] ?? 0;
            return (
              <li data-selected={quantity > 0} key={dish.id}>
                <span aria-hidden="true" className={styles.selectedMark} />
                <div className={styles.dishName}>
                  <small>{dish.original}</small>
                  <strong>{dish.title}</strong>
                  <span>{dish.note}</span>
                </div>
                <fieldset
                  aria-label={`${dish.title}数量`}
                  className={styles.stepper}
                >
                  <button
                    aria-label={`减少${dish.title}`}
                    disabled={quantity === 0}
                    onClick={() => changeQuantity(dish.id, -1)}
                    type="button"
                  >
                    <Minus aria-hidden="true" />
                  </button>
                  <output aria-live="polite">{quantity}</output>
                  <button
                    aria-label={`增加${dish.title}`}
                    onClick={() => changeQuantity(dish.id, 1)}
                    type="button"
                  >
                    <Plus aria-hidden="true" />
                  </button>
                </fieldset>
              </li>
            );
          })}
        </ol>
      </div>
      <aside className={styles.selectionSummary} data-saved={saved}>
        <p>我的选择</p>
        <div>
          <strong>{picked}</strong>
          <span>道菜</span>
        </div>
        <div>
          <strong>{total}</strong>
          <span>份</span>
        </div>
        <p className={styles.summaryNote}>
          保存后仍可回来修改，直到组织者开始核对。
        </p>
        <button
          className={styles.primaryButton}
          onClick={() => setSaved(true)}
          type="button"
        >
          {saved ? <Check aria-hidden="true" /> : null}
          {saved ? "已保存" : "保存我的选择"}
        </button>
        <i aria-hidden="true" className={styles.saveThread} />
      </aside>
    </section>
  );
}

export function UiPreviewV2() {
  const [stage, setStage] = useState<Stage>("room");
  const [transition, setTransition] = useState<PreviewTransition>("idle");
  const [destination, setDestination] = useState<Stage>("room");
  const transitionTimer = useRef<number | null>(null);
  const arrivalTimer = useRef<number | null>(null);
  const activeIndex = stages.findIndex((item) => item.id === stage);

  useEffect(
    () => () => {
      if (transitionTimer.current) window.clearTimeout(transitionTimer.current);
      if (arrivalTimer.current) window.clearTimeout(arrivalTimer.current);
    },
    [],
  );

  function changeStage(next: Stage) {
    if (next === stage || transition !== "idle") return;
    setDestination(next);
    setTransition("covering");
    transitionTimer.current = window.setTimeout(() => {
      setStage(next);
      setTransition("arriving");
      arrivalTimer.current = window.setTimeout(
        () => setTransition("idle"),
        740,
      );
    }, 420);
  }

  function moveStage(direction: -1 | 1) {
    const nextIndex = Math.min(
      stages.length - 1,
      Math.max(0, activeIndex + direction),
    );
    changeStage(stages[nextIndex].id);
  }

  return (
    <main className={styles.page}>
      <AmbientWords quiet={stage === "selection"} />
      <Header setStage={changeStage} stage={stage} />
      <div className={styles.scene} key={stage}>
        {stage === "room" ? <RoomScene /> : null}
        {stage === "menu" ? <MenuScene /> : null}
        {stage === "selection" ? <SelectionScene /> : null}
      </div>
      <footer className={styles.previewFooter}>
        <button
          aria-label="上一个预览场景"
          disabled={activeIndex === 0}
          onClick={() => moveStage(-1)}
          type="button"
        >
          <ChevronLeft aria-hidden="true" />
        </button>
        <p>
          <span>交互样片</span> {stages[activeIndex].label}
        </p>
        <button
          aria-label="下一个预览场景"
          disabled={activeIndex === stages.length - 1}
          onClick={() => moveStage(1)}
          type="button"
        >
          <ChevronRight aria-hidden="true" />
        </button>
      </footer>
      <div
        aria-hidden="true"
        className={styles.previewTransition}
        data-phase={transition}
      >
        <span>
          {String(
            stages.findIndex((item) => item.id === destination) + 1,
          ).padStart(2, "0")}
        </span>
        <strong>
          {destination === "room"
            ? "邀请入座"
            : destination === "menu"
              ? "识别菜单"
              : "挑选想吃的"}
        </strong>
        <small>
          {destination === "room"
            ? "Take a seat"
            : destination === "menu"
              ? "Recognize"
              : "Select"}
        </small>
      </div>
    </main>
  );
}
