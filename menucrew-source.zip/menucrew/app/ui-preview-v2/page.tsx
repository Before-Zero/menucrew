import type { Metadata } from "next";
import { UiPreviewV2 } from "./ui-preview-v2";

export const metadata: Metadata = {
  title: "V3 动效设计预览",
  description: "Menu Crew 餐桌路线、菜单显影与个人选菜的 V3 交互样片。",
};

export default function UiPreviewV2Page() {
  return <UiPreviewV2 />;
}
