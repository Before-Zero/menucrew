import { type NextRequest, NextResponse } from "next/server";
import { isAppLocale, LOCALE_COOKIE } from "@/lib/i18n";

export async function POST(request: NextRequest) {
  const body: unknown = await request.json().catch(() => null);
  const locale =
    typeof body === "object" && body !== null && "locale" in body
      ? body.locale
      : null;
  if (!isAppLocale(locale)) {
    return NextResponse.json({ error: "invalid_locale" }, { status: 400 });
  }

  const response = NextResponse.json({ locale });
  response.cookies.set(LOCALE_COOKIE, locale, {
    httpOnly: true,
    maxAge: 60 * 60 * 24 * 365,
    path: "/",
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
  });
  return response;
}
