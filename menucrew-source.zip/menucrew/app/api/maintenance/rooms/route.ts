import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: Request) {
  if (
    request.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`
  )
    return new NextResponse("Unauthorized", { status: 401 });
  const supabase = createAdminClient();
  const cutoff = new Date(Date.now() - 30 * 86400000).toISOString();
  const { data: rooms, error } = await supabase
    .from("rooms")
    .select("id")
    .lt("last_activity_at", cutoff)
    .order("last_activity_at")
    .limit(25);
  if (error)
    return NextResponse.json({ error: "list_failed" }, { status: 500 });
  let deleted = 0;
  for (const room of rooms ?? []) {
    const { data: images } = await supabase
      .from("menu_images")
      .select("storage_path")
      .eq(
        "menu_id",
        (
          await supabase
            .from("menus")
            .select("id")
            .eq("room_id", room.id)
            .maybeSingle()
        ).data?.id ?? "00000000-0000-0000-0000-000000000000",
      );
    const paths = (images ?? []).map((image) => image.storage_path);
    if (paths.length) {
      const { error: storageError } = await supabase.storage
        .from("menu-images")
        .remove(paths);
      if (storageError) continue;
    }
    const { error: deleteError } = await supabase
      .from("rooms")
      .delete()
      .eq("id", room.id);
    if (!deleteError) deleted += 1;
  }
  return NextResponse.json({ candidates: rooms?.length ?? 0, deleted });
}
