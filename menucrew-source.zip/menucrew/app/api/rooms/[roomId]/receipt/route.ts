import { getMemberReceipt } from "@/lib/member-receipt";
import { isValidRoomId } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ roomId: string }> },
) {
  const { roomId } = await params;
  if (!isValidRoomId(roomId)) {
    return Response.json({ message: "invalid_room" }, { status: 404 });
  }
  const receipt = await getMemberReceipt(roomId);
  if (!receipt) {
    return Response.json({ message: "receipt_unavailable" }, { status: 403 });
  }
  return Response.json(receipt, {
    headers: { "Cache-Control": "private, no-store, max-age=0" },
  });
}
