import { NextResponse } from "next/server";
import { MENU_IMAGES_BUCKET } from "@/lib/menus";
import { getRoomAccess } from "@/lib/rooms";
import { createClient } from "@/lib/supabase/server";
import { isValidMenuEntityId, isValidRoomId } from "@/lib/validation";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ imageId: string; roomId: string }> },
) {
  const { imageId, roomId } = await params;
  if (!isValidRoomId(roomId) || !isValidMenuEntityId(imageId))
    return NextResponse.json({ message: "图片不存在。" }, { status: 404 });

  const access = await getRoomAccess(roomId);
  if (!access || access.currentMember.role !== "organizer")
    return NextResponse.json(
      { message: "只有组织者能移除图片。" },
      { status: 403 },
    );

  const supabase = await createClient();
  const { data: menu } = await supabase
    .from("menus")
    .select("id,status")
    .eq("room_id", roomId)
    .maybeSingle();
  if (!menu || menu.status !== "draft")
    return NextResponse.json(
      { message: "菜单不在可编辑的草稿状态。" },
      { status: 409 },
    );

  const { data: image } = await supabase
    .from("menu_images")
    .select("id,storage_path")
    .eq("id", imageId)
    .eq("menu_id", menu.id)
    .maybeSingle();
  if (!image)
    return NextResponse.json({ message: "图片不存在。" }, { status: 404 });

  const { error: storageError } = await supabase.storage
    .from(MENU_IMAGES_BUCKET)
    .remove([image.storage_path]);
  if (storageError)
    return NextResponse.json(
      { message: "暂时无法移除图片，请稍后重试。" },
      { status: 503 },
    );

  const { error: rowError } = await supabase
    .from("menu_images")
    .delete()
    .eq("id", image.id)
    .eq("menu_id", menu.id);
  if (rowError)
    return NextResponse.json(
      { message: "图片已移除，但列表未能刷新，请重试。" },
      { status: 503 },
    );

  return NextResponse.json({ ok: true });
}
