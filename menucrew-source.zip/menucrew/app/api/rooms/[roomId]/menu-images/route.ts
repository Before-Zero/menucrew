import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { MENU_IMAGES_BUCKET } from "@/lib/menus";
import { getRoomAccess } from "@/lib/rooms";
import { createClient } from "@/lib/supabase/server";
import {
  isValidRoomId,
  MENU_IMAGE_MAX_BYTES,
  MENU_IMAGE_MAX_COUNT,
  MENU_IMAGE_MIME_TYPES,
} from "@/lib/validation";

type ImageRequest = {
  byteSize?: unknown;
  mimeType?: unknown;
  originalName?: unknown;
  storagePath?: unknown;
};

function fail(message: string, status = 400) {
  return NextResponse.json({ message }, { status });
}

function validImageMetadata(body: ImageRequest) {
  return (
    typeof body.originalName === "string" &&
    body.originalName.trim().length > 0 &&
    body.originalName.trim().length <= 255 &&
    typeof body.mimeType === "string" &&
    MENU_IMAGE_MIME_TYPES.includes(
      body.mimeType as (typeof MENU_IMAGE_MIME_TYPES)[number],
    ) &&
    typeof body.byteSize === "number" &&
    Number.isInteger(body.byteSize) &&
    body.byteSize > 0 &&
    body.byteSize <= MENU_IMAGE_MAX_BYTES
  );
}

async function draftContext(roomId: string) {
  if (!isValidRoomId(roomId)) return null;
  const access = await getRoomAccess(roomId);
  if (!access || access.currentMember.role !== "organizer") return null;
  const supabase = await createClient();
  const { data: menu } = await supabase
    .from("menus")
    .select("id,status")
    .eq("room_id", roomId)
    .maybeSingle();
  if (!menu || menu.status !== "draft") return null;
  return { menu, supabase };
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ roomId: string }> },
) {
  const { roomId } = await params;
  const context = await draftContext(roomId);
  if (!context) return fail("只有组织者能为草稿上传图片。", 403);

  let body: ImageRequest;
  try {
    body = (await request.json()) as ImageRequest;
  } catch {
    return fail("图片信息无效。");
  }
  if (!validImageMetadata(body))
    return fail("图片必须是 6 MB 内的 JPEG、PNG 或 WebP。");

  const { count, error: countError } = await context.supabase
    .from("menu_images")
    .select("id", { count: "exact", head: true })
    .eq("menu_id", context.menu.id);
  if (countError) return fail("暂时无法检查图片数量。", 503);
  if ((count ?? 0) >= MENU_IMAGE_MAX_COUNT)
    return fail("每份菜单最多上传 4 张图片。", 409);

  const extension =
    body.mimeType === "image/png"
      ? "png"
      : body.mimeType === "image/webp"
        ? "webp"
        : "jpg";
  const storagePath = `${roomId}/${context.menu.id}/${randomUUID()}.${extension}`;
  const { data, error } = await context.supabase.storage
    .from(MENU_IMAGES_BUCKET)
    .createSignedUploadUrl(storagePath);

  if (error || !data) {
    console.error("createSignedUploadUrl failed", error);
    return fail("暂时无法开始上传，请稍后重试。", 503);
  }

  return NextResponse.json({ path: data.path, token: data.token });
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ roomId: string }> },
) {
  const { roomId } = await params;
  const context = await draftContext(roomId);
  if (!context) return fail("只有组织者能登记草稿图片。", 403);

  let body: ImageRequest;
  try {
    body = (await request.json()) as ImageRequest;
  } catch {
    return fail("图片信息无效。");
  }
  if (!validImageMetadata(body) || typeof body.storagePath !== "string")
    return fail("图片信息无效。");

  const expectedPrefix = `${roomId}/${context.menu.id}/`;
  if (!body.storagePath.startsWith(expectedPrefix))
    return fail("图片路径无效。", 403);
  const filename = body.storagePath.slice(expectedPrefix.length);
  if (!filename || filename.includes("/")) return fail("图片路径无效。");

  const { data: objects, error: listError } = await context.supabase.storage
    .from(MENU_IMAGES_BUCKET)
    .list(`${roomId}/${context.menu.id}`, { limit: 2, search: filename });
  if (listError || !objects?.some((object) => object.name === filename))
    return fail("上传没有完成，请重新选择图片。", 409);

  const { data: last } = await context.supabase
    .from("menu_images")
    .select("position")
    .eq("menu_id", context.menu.id)
    .order("position", { ascending: false })
    .limit(1)
    .maybeSingle();
  const { data: image, error } = await context.supabase
    .from("menu_images")
    .insert({
      byte_size: body.byteSize as number,
      menu_id: context.menu.id,
      mime_type: body.mimeType as string,
      original_name: (body.originalName as string).trim(),
      position: (last?.position ?? -100) + 100,
      storage_path: body.storagePath,
    })
    .select("id")
    .single();

  if (error || !image) {
    await context.supabase.storage
      .from(MENU_IMAGES_BUCKET)
      .remove([body.storagePath]);
    const message = error?.message.includes("menu_image_limit_reached")
      ? "每份菜单最多上传 4 张图片。"
      : "图片上传后未能保存，请重新尝试。";
    return fail(message, 409);
  }

  return NextResponse.json({ id: image.id });
}
