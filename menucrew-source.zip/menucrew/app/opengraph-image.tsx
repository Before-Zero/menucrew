import { ImageResponse } from "next/og";

export const alt = "合点 MenuCrew — 语言虽异，心意同桌";
export const size = { height: 630, width: 1200 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    <div
      style={{
        alignItems: "center",
        background: "#f4f1e8",
        color: "#24322d",
        display: "flex",
        height: "100%",
        justifyContent: "center",
        overflow: "hidden",
        position: "relative",
        width: "100%",
      }}
    >
      <div
        style={{
          border: "2px solid #b9433c",
          borderRadius: 999,
          height: 440,
          left: -170,
          opacity: 0.2,
          position: "absolute",
          top: 80,
          width: 440,
        }}
      />
      <div
        style={{
          border: "1px solid #4f7c70",
          borderRadius: 999,
          height: 560,
          opacity: 0.18,
          position: "absolute",
          right: -220,
          top: -120,
          width: 560,
        }}
      />
      <div style={{ display: "flex", flexDirection: "column", width: 980 }}>
        <div
          style={{
            alignItems: "center",
            display: "flex",
            fontSize: 27,
            fontWeight: 700,
            gap: 16,
          }}
        >
          <span
            style={{
              alignItems: "center",
              border: "2px solid #b9433c",
              borderRadius: 999,
              color: "#b9433c",
              display: "flex",
              height: 54,
              justifyContent: "center",
              width: 54,
            }}
          >
            合
          </span>
          合点 MenuCrew
        </div>
        <div
          style={{
            color: "#b9433c",
            display: "flex",
            fontSize: 20,
            fontWeight: 700,
            letterSpacing: 2,
            marginTop: 76,
          }}
        >
          DIFFERENT MENUS · ONE TABLE
        </div>
        <div
          style={{
            display: "flex",
            fontSize: 76,
            fontWeight: 800,
            letterSpacing: -4,
            lineHeight: 1.08,
            marginTop: 18,
          }}
        >
          语言虽异，心意同桌。
        </div>
        <div
          style={{
            color: "#5b6863",
            display: "flex",
            fontSize: 28,
            marginTop: 28,
          }}
        >
          多人各自选菜，实时汇成一份双语订单。
        </div>
        <div
          style={{
            alignItems: "center",
            display: "flex",
            gap: 18,
            marginTop: 60,
          }}
        >
          {["上传菜单", "邀请同桌", "合成订单"].map((label, index) => (
            <div
              key={label}
              style={{ alignItems: "center", display: "flex", gap: 10 }}
            >
              <span
                style={{
                  alignItems: "center",
                  border: "1px solid #b9433c",
                  borderRadius: 999,
                  color: "#b9433c",
                  display: "flex",
                  height: 38,
                  justifyContent: "center",
                  width: 38,
                }}
              >
                0{index + 1}
              </span>
              <span style={{ display: "flex", fontSize: 20, fontWeight: 650 }}>
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>,
    size,
  );
}
