"use client";

import { useEffect } from "react";
import { PageStatus } from "@/components/page-status";
import { Button } from "@/components/ui/button";

export default function ErrorPage({
  error,
  retry,
}: {
  error: Error & { digest?: string };
  retry: () => void;
}) {
  useEffect(() => {
    console.error("页面渲染失败", error.digest ?? "no-digest");
  }, [error.digest]);

  return (
    <PageStatus
      action={
        <Button onClick={() => retry()} type="button">
          重新读取
        </Button>
      }
      description="可能是网络或云端服务短暂不可用。你的房间数据不会因此被清空，可以直接重试。"
      title="这一页暂时没有打开。"
    />
  );
}
