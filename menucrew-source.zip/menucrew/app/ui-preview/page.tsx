import { FileCheck, Upload, Users } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import styles from "./ui-preview.module.css";

export const metadata: Metadata = {
  title: "首页设计预览",
  description: "合点 Menu Crew 首页视觉与动效预览。",
};

const desktopWords = [
  ["好好吃饭", "far"],
  ["Taste something new", "far"],
  ["ごちそうさま", "far"],
  ["Disfruta la comida", "far"],
  ["今天吃什么", "far"],
  ["Selamat makan", "far"],
  ["Eet smakelijk", "far"],
  ["맛있게 드세요", "far"],
  ["Poftă bună", "far"],
  ["Καλή όρεξη", "far"],
  ["Bom apetite", "far"],
  ["一起开饭", "mid"],
  ["Enjoy every bite", "mid"],
  ["いただきます", "mid"],
  ["Buen provecho", "mid"],
  ["Buon appetito", "mid"],
  ["잘 먹겠습니다", "mid"],
  ["Smacznego", "mid"],
  ["Afiyet olsun", "mid"],
  ["慢慢品尝", "mid"],
  ["Bon appétit", "near"],
  ["一起开饭", "near"],
  ["Enjoy your meal", "near"],
  ["Приятного аппетита", "near"],
  ["享受这一餐", "near"],
  ["いただきます", "near"],
  ["好好吃饭", "near"],
  ["请享用", "mid"],
  ["À table", "mid"],
  ["Share the table", "far"],
  ["慢慢品尝", "far"],
  ["Buon appetito", "far"],
] as const;

const mobileWords = [
  "Bon appétit",
  "一起开饭",
  "好好吃饭",
  "いただきます",
  "Enjoy your meal",
  "Buen provecho",
  "慢慢品尝",
  "맛있게 드세요",
  "Selamat makan",
  "Smacznego",
  "Afiyet olsun",
  "Bom apetite",
  "Καλή όρεξη",
  "Eet smakelijk",
  "Poftă bună",
  "今天吃什么",
] as const;

const steps = [
  {
    description: "上传餐厅菜单，AI辅助整理双语菜品。",
    icon: Upload,
    title: "上传菜单",
  },
  {
    description: "分享私密链接，大家在手机上独立选菜。",
    icon: Users,
    title: "邀请同桌",
  },
  {
    description: "自动汇总数量，生成全桌双语订单。",
    icon: FileCheck,
    title: "合成订单",
  },
] as const;

function AmbientWords() {
  return (
    <div aria-hidden="true" className={styles.ambient}>
      <div className={styles.desktopWords}>
        {desktopWords.map(([word, depth]) => (
          <span
            className={`${styles.word} ${styles[depth]}`}
            key={`${depth}-${word}`}
          >
            <span>{word}</span>
          </span>
        ))}
      </div>
      <div className={styles.mobileWords}>
        {mobileWords.map((word) => (
          <span className={styles.word} key={word}>
            <span>{word}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function BrandMark() {
  return (
    <span aria-hidden="true" className={styles.brandMark}>
      <svg
        className={styles.logoOuter}
        preserveAspectRatio="none"
        viewBox="0.000004 -0.000007 81.130596 85.031135"
      >
        <title>Menu Crew logo outer ring</title>
        <path d="M80.49825 62.38204c0.28742-0.51736 1.09222-2.75928-0.80478-4.25389-1.20719-0.97724-3.33414-0.68982-3.73653 0.80479l-0.28743 0.51737c-4.71377 9.08263-15.69341 20.06227-32.88143 20.06226-19.77485 0-36.96288-15.46347-36.96288-36.90538 0-17.70539 15.34851-36.90539 36.15809-36.90539 6.26587 0 13.22156 1.03473 23.3964 7.70299 0.86227 0.68982 1.83952 0.80479 2.81677 0.51736 1.95449-0.63233 2.64432-3.39162 0.86227-5.05868-5.34611-4.08144-12.53173-8.56527-24.02874-8.85269-3.0467-0.05749-6.03593 0.11497-8.68024 0.51736-17.07305 2.7018-33.8012 16.84311-36.1006 36.73294-1.95449 18.22275 7.64551 38.34251 26.84551 45.06826 4.36886 1.55209 9.37006 2.64432 15.80839 2.7018 12.53174 0 29.66228-5.86347 38.22754-22.99401" />
      </svg>
      <svg
        className={styles.logoDot}
        preserveAspectRatio="none"
        viewBox="0 0 7.81796 7.18563"
      >
        <title>Menu Crew logo dot</title>
        <path d="M3.67905 0c-2.01198 0-3.67905 1.60958-3.67905 3.62156 0 2.01198 1.37965 3.56407 3.90898 3.56407 1.9545 0 3.90898-1.49461 3.90898-3.56407 0-2.06946-1.72455-3.62156-4.13891-3.62156" />
      </svg>
      <svg
        className={styles.logoMenu}
        preserveAspectRatio="none"
        viewBox="-0.000005 -0.000001 41.524816 32.705053"
      >
        <title>Menu Crew logo menu mark</title>
        <path d="M38.69772 29.31343l-8.0479 0-0.28742-4.08144 2.75928-2.35688c0.68982-0.51737 0.80479-1.66707 0.28743-2.29941-0.57485-0.68982-1.66707-0.97725-2.52934-0.17245l-10.17485 8.50779-5.92096-5.34612 20.80958-18.28023 2.2994 24.02874 0.80478 0z m-32.594-23.97126l12.01437 10.7497-14.42875 12.35928 2.41438-23.10898z m32.65149-4.77126c-0.68982-0.68982-1.78204-0.80479-2.81676 0.05749l-15.29102 13.22155-14.42874-13.27904c-1.1497-1.1497-3.10419-0.45988-3.27665 1.1497l-2.93174 28.91497c-0.11497 1.03473 0.7473 2.06946 1.83952 2.06947l10.40479 0c1.60958 0 1.89701-3.04671 0.45988-3.39162-0.17245-0.05748-0.28742-0.05748-0.51736-0.05749l-4.31138 0 4.36886-3.56407 7.30061 6.55329c0.57485 0.51736 1.66706 0.63234 2.35688 0.11498l5.23114-4.48384 0.34491 3.16168c0.11498 0.86227 0.80479 1.60958 1.78203 1.60958l10.46228 0c1.03473 0.05749 1.897-1.09221 1.78204-2.01198l-2.47187-28.57006c0.05749-0.80479-0.11497-1.20719-0.28742-1.49461" />
      </svg>
    </span>
  );
}

function BrandHeader() {
  return (
    <header className={styles.header}>
      <div className={styles.brand}>
        <BrandMark />
        <span className={styles.brandName}>合点 Menu Crew</span>
      </div>
      <nav aria-label="当前界面语言" className={styles.language}>
        <span aria-current="true">简中</span>
        <span aria-hidden="true" className={styles.languageDivider}>
          /
        </span>
        <span className={styles.languageMuted}>EN</span>
      </nav>
    </header>
  );
}

function Hero() {
  return (
    <section aria-labelledby="preview-title" className={styles.hero}>
      <div aria-hidden="true" className={styles.heroOrbit}>
        <svg preserveAspectRatio="none" viewBox="0 0 720 320">
          <title>Decorative dining table orbit</title>
          <ellipse cx="360" cy="160" rx="338" ry="116" />
        </svg>
        <i className={styles.orbitDotOne} />
        <i className={styles.orbitDotTwo} />
        <i className={styles.orbitDotThree} />
      </div>
      <p className={styles.tagline}>Different menus. One table.</p>
      <h1 className={styles.title} id="preview-title">
        <span>
          <span>语言虽异，</span>
        </span>
        <span>
          <span>心意同桌。</span>
        </span>
      </h1>
      <p className={styles.description}>
        上传菜单，邀请同桌，各自选菜，
        <br className={styles.desktopBreak} />
        最后生成一份全桌都看得懂的双语订单。
      </p>
      <div className={styles.actionArea}>
        <Link className={styles.primaryAction} href="/">
          发起一桌
        </Link>
        <p className={styles.actionHint}>无需注册 · 创建后即可分享私密邀请</p>
      </div>
    </section>
  );
}

function StepGuide() {
  return (
    <section aria-labelledby="guide-title" className={styles.guide}>
      <h2 id="guide-title">一起开饭，只需三步</h2>
      <ol className={styles.stepList}>
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <li className={styles.step} key={step.title}>
              <span className={styles.stepNumber}>
                {String(index + 1).padStart(2, "0")}
              </span>
              <span className={styles.stepIcon}>
                <Icon aria-hidden="true" />
              </span>
              <span className={styles.stepCopy}>
                <strong>{step.title}</strong>
                <span>{step.description}</span>
              </span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

export default function UiPreviewPage() {
  return (
    <main className={styles.page}>
      <AmbientWords />
      <BrandHeader />
      <Hero />
      <StepGuide />
    </main>
  );
}
