import Link from "next/link";
import { AccountPanel } from "@/components/account-panel";
import { DiningRouteMap } from "@/components/dining-route-map";
import { LanguageSwitcher } from "@/components/language-switcher";
import { MenuCrewMark } from "@/components/menu-crew-mark";
import { RoomAmbientWords } from "@/components/room-ambient-words";
import { getAppLocale } from "@/lib/i18n-server";
import { createClient } from "@/lib/supabase/server";

type SavedTable = {
  id: string;
  joinedAt: string;
  name: string;
  role: "member" | "organizer";
};

export default async function AccountPage() {
  const [locale, supabase] = await Promise.all([
    getAppLocale(),
    createClient(),
  ]);
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const permanent = Boolean(user && !user.is_anonymous);
  let tables: SavedTable[] = [];

  if (user) {
    const { data: memberships } = await supabase
      .from("room_members")
      .select("room_id,role,joined_at")
      .eq("user_id", user.id)
      .order("joined_at", { ascending: false });
    const roomIds = memberships?.map((membership) => membership.room_id) ?? [];

    if (roomIds.length > 0) {
      const { data: rooms } = await supabase
        .from("rooms")
        .select("id,name")
        .in("id", roomIds);
      const roomNames = new Map(
        rooms?.map((room) => [room.id, room.name] as const) ?? [],
      );
      tables =
        memberships?.flatMap((membership) => {
          const name = roomNames.get(membership.room_id);
          return name &&
            (membership.role === "member" || membership.role === "organizer")
            ? [
                {
                  id: membership.room_id,
                  joinedAt: membership.joined_at,
                  name,
                  role: membership.role,
                },
              ]
            : [];
        }) ?? [];
    }
  }

  return (
    <main className="mc-room-page relative min-h-screen overflow-hidden bg-[#f4f1e8] px-5 py-8 text-[#24322d] sm:px-8">
      <DiningRouteMap activeControl={1} layout="spine" quiet />
      <RoomAmbientWords />
      <div className="relative z-10 mx-auto max-w-5xl">
        <header className="flex items-center justify-between gap-3 border-b border-[#24322d]/15 pb-5">
          <Link className="flex items-center gap-3 font-semibold" href="/">
            <MenuCrewMark className="size-9 text-[#b9433c]" />
            <span className="hidden sm:inline">合点 Menu Crew</span>
          </Link>
          <div className="flex items-center gap-3">
            <LanguageSwitcher locale={locale} />
            <Link
              className="whitespace-nowrap text-sm text-[#52615b] hover:text-[#b9433c]"
              href="/"
            >
              {locale === "en" ? "Back home" : "返回首页"}
            </Link>
          </div>
        </header>

        <section className="grid gap-10 py-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="space-y-5">
            <h1 className="max-w-xl text-4xl font-semibold leading-tight sm:text-6xl">
              {locale === "en"
                ? "Sign in once. Find every table again."
                : "登录一次，随时找回你的餐桌。"}
            </h1>
            <p className="max-w-lg text-base leading-8 text-[#52615b]">
              {locale === "en"
                ? "Use your email to sign in or register without a password. Guest ordering remains available when you want to start immediately."
                : "使用邮箱即可无密码登录或注册，之后可以跨设备找回餐桌；想马上开始时，仍然可以直接以游客身份点餐。"}
            </p>
          </div>

          <AccountPanel
            email={user?.email ?? ""}
            locale={locale}
            mode={permanent ? "account" : user ? "anonymous" : "signed-out"}
          />
        </section>

        <section className="border-t border-[#24322d]/15 py-10">
          <div className="mb-6 flex items-end justify-between gap-4">
            <div>
              <h2 className="mt-2 text-2xl font-semibold">
                {locale === "en" ? "My tables" : "我的餐桌"}
              </h2>
            </div>
            {!permanent && tables.length > 0 ? (
              <span className="text-sm text-[#8a6330]">
                {locale === "en"
                  ? "Save your account to keep these"
                  : "保存账户后可跨设备找回"}
              </span>
            ) : null}
          </div>

          {tables.length > 0 ? (
            <div className="divide-y divide-[#24322d]/12 border-y border-[#24322d]/15">
              {tables.map((table, index) => (
                <Link
                  className="group grid grid-cols-[3rem_1fr_auto] items-center gap-4 py-5"
                  href={`/rooms/${table.id}`}
                  key={table.id}
                >
                  <span className="font-mono text-sm text-[#b9433c]">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span>
                    <strong className="block text-lg group-hover:text-[#b9433c]">
                      {table.name}
                    </strong>
                    <small className="text-[#6d7873]">
                      {table.role === "organizer"
                        ? locale === "en"
                          ? "Organizer"
                          : "我发起的"
                        : locale === "en"
                          ? "Joined"
                          : "我参与的"}
                    </small>
                  </span>
                  <span className="text-sm text-[#52615b]">→</span>
                </Link>
              ))}
            </div>
          ) : (
            <p className="border-y border-[#24322d]/15 py-8 text-[#6d7873]">
              {locale === "en"
                ? "Your next shared meal will appear here."
                : "下一次一起吃饭，会从这里开始沉淀。"}
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
