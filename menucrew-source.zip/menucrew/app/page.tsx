import { createRoomAction } from "@/app/actions";
import { HomeCover } from "@/components/home-cover";
import { getAppLocale } from "@/lib/i18n-server";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const [locale, supabase] = await Promise.all([
    getAppLocale(),
    createClient(),
  ]);
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <HomeCover
      accountMode={user && !user.is_anonymous ? "account" : "guest"}
      action={createRoomAction}
      locale={locale}
    />
  );
}
