import { MenuCrewMark } from "@/components/menu-crew-mark";

export default function Loading() {
  return (
    <main
      aria-busy="true"
      aria-label="正在连接餐桌"
      className="relative grid min-h-svh place-items-center overflow-hidden bg-[#f4f1e8] px-6 text-[#24322d]"
    >
      <div
        aria-hidden="true"
        className="absolute size-[34rem] rounded-full border border-[#b9433c]/10"
      />
      <div className="relative z-10 max-w-lg text-center">
        <MenuCrewMark className="mx-auto size-12 text-[#b9433c]" />
        <div aria-hidden="true" className="mx-auto mt-8 flex w-44 items-center">
          <span className="size-3 rounded-full bg-[#b9433c] shadow-[0_0_0_8px_rgb(185_67_60_/_0.10)]" />
          <span className="h-px flex-1 bg-gradient-to-r from-[#b9433c] to-[#4f7c70]" />
          <span className="size-3 rounded-full border-2 border-[#4f7c70] bg-[#f4f1e8]" />
        </div>
        <p className="mt-8 font-mono text-[10px] font-bold tracking-[0.18em] text-[#b9433c] uppercase">
          Preparing your table
        </p>
        <h1 className="mt-3 text-3xl font-black tracking-[-0.04em] sm:text-4xl">
          正在连接这张餐桌
        </h1>
        <p className="mt-4 text-sm leading-7 text-[#5b6863] sm:text-base">
          页面需要读取菜单和同桌的最新选择。海外网络偶尔需要多等几秒，准备好后会自动进入，无需刷新。
        </p>
        <p className="mt-5 text-xs text-[#7a837f]">
          请稍候 · Please wait a moment
        </p>
      </div>
    </main>
  );
}
