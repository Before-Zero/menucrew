"use client";

import {
  AlertTriangle,
  LoaderCircle,
  RotateCcw,
  Save,
  Sparkles,
} from "lucide-react";
import Link from "next/link";
import { useActionState, useEffect, useMemo, useState } from "react";
import { MenuAssistantSheet } from "@/components/menu-assistant-sheet";
import { SelectionItemCard } from "@/components/selection-item-card";
import { SelectionStatus } from "@/components/selection-status";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { MenuAssistantActionState } from "@/lib/menu-assistant-action-state";
import type { MenuItem } from "@/lib/menus";
import {
  initialSelectionActionState,
  type SelectionActionState,
} from "@/lib/selection-action-state";
import { DIETARY_INFO_MAX_LENGTH } from "@/lib/validation";

type Action = (
  state: SelectionActionState,
  payload: FormData,
) => Promise<SelectionActionState>;

export function MemberSelectionForm({
  action,
  assistantAction,
  initialAllergyInfo,
  initialDietaryRestrictions,
  initialSavedAt,
  initialSelections,
  items,
  locale,
  readOnly = false,
  roomId,
}: {
  action: Action;
  assistantAction: (
    state: MenuAssistantActionState,
    payload: FormData,
  ) => Promise<MenuAssistantActionState>;
  initialAllergyInfo: string;
  initialDietaryRestrictions: string;
  initialSavedAt: string | null;
  initialSelections: Record<string, { note: string; quantity: number }>;
  items: MenuItem[];
  locale: AppLocale;
  readOnly?: boolean;
  roomId: string;
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialSelectionActionState,
  );
  const [dirty, setDirty] = useState(false);
  const [quantities, setQuantities] = useState<Record<string, number>>(() =>
    Object.fromEntries(
      items.map((item) => [item.id, initialSelections[item.id]?.quantity ?? 0]),
    ),
  );
  const [notes, setNotes] = useState<Record<string, string>>(() =>
    Object.fromEntries(
      items.map((item) => [item.id, initialSelections[item.id]?.note ?? ""]),
    ),
  );
  const [dietaryRestrictions, setDietaryRestrictions] = useState(
    initialDietaryRestrictions,
  );
  const [allergyInfo, setAllergyInfo] = useState(initialAllergyInfo);
  const [assistantItemId, setAssistantItemId] = useState<
    string | null | undefined
  >(undefined);
  const [recommendationUndo, setRecommendationUndo] = useState<Record<
    string,
    number
  > | null>(null);
  const [recommendationApplied, setRecommendationApplied] = useState(false);

  useEffect(() => {
    if (state.status === "success" && state.savedAt) setDirty(false);
  }, [state.status, state.savedAt]);

  const summary = useMemo(() => {
    const values = Object.values(quantities);
    return {
      dishCount: values.filter((quantity) => quantity > 0).length,
      totalQuantity: values.reduce((sum, quantity) => sum + quantity, 0),
    };
  }, [quantities]);

  const savedAt = state.savedAt ?? initialSavedAt;

  return (
    <>
      <form action={formAction} className="space-y-8">
        <Button
          className="mc-waiter-call w-full border-[#efb78f] text-[#9a461e]"
          onClick={() => setAssistantItemId(null)}
          type="button"
          variant="outline"
        >
          <Sparkles />{" "}
          {locale === "en"
            ? "Build an order with AI"
            : "让 AI 搭一份可以直接用的点餐"}
        </Button>
        {recommendationApplied ? (
          <div className="flex items-center justify-between gap-3 border-block border-[#4f7c70]/25 bg-[#eef9f2] px-4 py-3 text-sm text-[#146b45]">
            <span className="font-semibold">
              {locale === "en"
                ? "AI recommendations are filled in. Review and save them."
                : "AI 搭配已填入，检查后请保存。"}
            </span>
            <Button
              onClick={() => {
                if (recommendationUndo) setQuantities(recommendationUndo);
                setRecommendationApplied(false);
                setRecommendationUndo(null);
                setDirty(true);
              }}
              size="sm"
              type="button"
              variant="ghost"
            >
              <RotateCcw /> {locale === "en" ? "Undo" : "撤销"}
            </Button>
          </div>
        ) : null}
        <section className="border-y border-[#24322d]/20 bg-[#fbf9f2]/60 p-4 sm:p-5">
          <SelectionStatus
            dirty={dirty}
            dishCount={summary.dishCount}
            locale={locale}
            savedAt={savedAt}
            totalQuantity={summary.totalQuantity}
          />
          <p className="mt-3 border-t pt-3 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Quantities are the servings you personally want—not votes or table totals. Dishes left at 0 are not submitted."
              : "数量代表你本人实际想点的份数，不是投票，也不是整桌总量。保持 0 的菜不会进入你的提交。"}
          </p>
        </section>

        <ol className="mc-selection-route">
          {items.map((item, index) => (
            <SelectionItemCard
              index={index}
              item={item}
              key={item.id}
              locale={locale}
              note={notes[item.id] ?? ""}
              noteError={state.fieldErrors[`note:${item.id}`]}
              onNoteChange={(value) => {
                setNotes((current) => ({ ...current, [item.id]: value }));
                setDirty(true);
              }}
              onAskAi={() => setAssistantItemId(item.id)}
              onQuantityChange={(value) => {
                setQuantities((current) => ({ ...current, [item.id]: value }));
                if (value === 0) {
                  setNotes((current) => ({ ...current, [item.id]: "" }));
                }
                setDirty(true);
              }}
              quantity={quantities[item.id] ?? 0}
              quantityError={state.fieldErrors[`quantity:${item.id}`]}
              readOnly={readOnly}
            />
          ))}
        </ol>

        <section className="grid gap-5 border-y border-[#c28a42]/45 bg-[#efe3ce]/42 p-5 sm:p-6">
          <div>
            <p className="font-mono text-xs font-semibold tracking-[0.12em] text-[#9a5e0b] uppercase">
              Dietary notes
            </p>
            <h2 className="mt-2 text-lg font-bold">
              {locale === "en" ? "Your dietary information" : "整体验食信息"}
            </h2>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              {locale === "en"
                ? "You can save this even without choosing a dish. Menu Crew does not make medical judgments."
                : "即使一份菜也不选，也可以只保存下面的信息。系统不会替你作医学判断。"}
            </p>
          </div>

          <div>
            <label
              className="text-sm font-semibold"
              htmlFor="dietaryRestrictions"
            >
              {locale === "en" ? "Dietary restrictions" : "整体忌口"}{" "}
              <span className="font-normal text-muted-foreground">
                {locale === "en" ? "(optional)" : "（可选）"}
              </span>
            </label>
            <textarea
              aria-invalid={Boolean(state.fieldErrors.dietaryRestrictions)}
              className="mt-2 min-h-24 w-full resize-y rounded-xl border bg-[#fffefb] px-3 py-2 text-sm leading-6 outline-none transition focus:border-primary focus:ring-3 focus:ring-primary/15 aria-invalid:border-destructive"
              id="dietaryRestrictions"
              maxLength={DIETARY_INFO_MAX_LENGTH}
              name="dietaryRestrictions"
              disabled={readOnly}
              onChange={(event) => {
                setDietaryRestrictions(event.target.value);
                setDirty(true);
              }}
              placeholder={
                locale === "en"
                  ? "e.g. no cilantro, vegetarian"
                  : "例如：不吃香菜、素食"
              }
              value={dietaryRestrictions}
            />
            <div className="mt-1 flex justify-between gap-3 text-xs">
              <p className="text-destructive">
                {state.fieldErrors.dietaryRestrictions}
              </p>
              <span className="ml-auto text-muted-foreground">
                {dietaryRestrictions.length}/{DIETARY_INFO_MAX_LENGTH}
              </span>
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold" htmlFor="allergyInfo">
              {locale === "en" ? "Allergy information" : "过敏信息"}{" "}
              <span className="font-normal text-muted-foreground">
                {locale === "en" ? "(optional)" : "（可选）"}
              </span>
            </label>
            <textarea
              aria-invalid={Boolean(state.fieldErrors.allergyInfo)}
              className="mt-2 min-h-24 w-full resize-y rounded-xl border bg-[#fffefb] px-3 py-2 text-sm leading-6 outline-none transition focus:border-primary focus:ring-3 focus:ring-primary/15 aria-invalid:border-destructive"
              id="allergyInfo"
              maxLength={DIETARY_INFO_MAX_LENGTH}
              name="allergyInfo"
              disabled={readOnly}
              onChange={(event) => {
                setAllergyInfo(event.target.value);
                setDirty(true);
              }}
              placeholder={
                locale === "en"
                  ? "e.g. severe peanut allergy"
                  : "例如：花生严重过敏"
              }
              value={allergyInfo}
            />
            <div className="mt-1 flex justify-between gap-3 text-xs">
              <p className="text-destructive">
                {state.fieldErrors.allergyInfo}
              </p>
              <span className="ml-auto text-muted-foreground">
                {allergyInfo.length}/{DIETARY_INFO_MAX_LENGTH}
              </span>
            </div>
          </div>
        </section>

        <section className="sticky bottom-0 z-10 border-y-2 border-[#24322d] bg-[#f4f1e8]/95 p-4 shadow-[0_-14px_36px_rgb(36_50_45_/_0.12)] backdrop-blur sm:p-5">
          <SelectionStatus
            dirty={dirty}
            dishCount={summary.dishCount}
            locale={locale}
            savedAt={savedAt}
            totalQuantity={summary.totalQuantity}
          />
          {state.message ? (
            <p
              aria-live="polite"
              className={`mt-3 flex items-start gap-2 rounded-xl px-3 py-2 text-sm ${state.status === "error" ? "bg-destructive/8 text-destructive" : "bg-[#eef9f2] text-[#146b45]"}`}
            >
              {state.status === "error" ? (
                <AlertTriangle
                  aria-hidden="true"
                  className="mt-0.5 size-4 shrink-0"
                />
              ) : null}
              {state.message}
            </p>
          ) : null}
          {state.status === "success" ? (
            <div className="mt-4 rounded-xl border border-[#bde0ca] bg-[#f1fbf5] p-4">
              <p className="font-bold text-[#146b45]">
                {locale === "en"
                  ? "Your choices were submitted"
                  : "你的选择已成功提交"}
              </p>
              <p className="mt-1 text-sm leading-6 text-[#416454]">
                {locale === "en"
                  ? `${summary.dishCount} dishes and ${summary.totalQuantity} servings. You can edit them until the organizer begins review.`
                  : `已选择 ${summary.dishCount} 道菜，共 ${summary.totalQuantity} 份。发起人结束收集前仍可修改。`}
              </p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                <Button asChild type="button" variant="outline">
                  <Link href={`/rooms/${roomId}/selection`}>
                    {locale === "en" ? "Keep editing" : "继续修改"}
                  </Link>
                </Button>
                <Button asChild type="button">
                  <Link href={`/rooms/${roomId}`}>
                    {locale === "en" ? "View table progress" : "查看聚餐进度"}
                  </Link>
                </Button>
              </div>
            </div>
          ) : null}
          {readOnly ? (
            <p className="mt-4 flex items-start gap-2 rounded-xl bg-[#fff5e5] px-3 py-3 text-sm font-semibold leading-6 text-[#7a4b0b]">
              <AlertTriangle className="mt-1 size-4 shrink-0" />
              {locale === "en"
                ? "The organizer is reviewing the order, so this page is read-only."
                : "组织者正在核对，当前内容只读。重新开放后刷新即可继续修改。"}
            </p>
          ) : (
            <Button
              className="mt-4 h-12 w-full rounded-xl text-base font-bold"
              disabled={pending}
              type="submit"
            >
              {pending ? (
                <LoaderCircle aria-hidden="true" className="animate-spin" />
              ) : (
                <Save aria-hidden="true" />
              )}
              {pending
                ? locale === "en"
                  ? "Saving everything…"
                  : "正在完整保存…"
                : locale === "en"
                  ? "Save my choices"
                  : "保存我的选择"}
            </Button>
          )}
        </section>
      </form>
      <MenuAssistantSheet
        action={assistantAction}
        allergyInfo={allergyInfo}
        currentSelections={JSON.stringify(
          items.map((item) => ({
            menuItemId: item.id,
            quantity: quantities[item.id] ?? 0,
          })),
        )}
        dietaryRestrictions={dietaryRestrictions}
        locale={locale}
        menuItemId={assistantItemId || undefined}
        menuItemName={
          assistantItemId
            ? items.find((item) => item.id === assistantItemId)?.original_name
            : undefined
        }
        onClose={() => setAssistantItemId(undefined)}
        onApplyRecommendation={(recommendedItems) => {
          setRecommendationUndo({ ...quantities });
          setQuantities((current) => {
            const next = { ...current };
            for (const item of recommendedItems)
              next[item.menuItemId] = item.quantity;
            return next;
          });
          setRecommendationApplied(true);
          setDirty(true);
        }}
        open={assistantItemId !== undefined}
      />
    </>
  );
}
