"use client";

import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  Info,
  LoaderCircle,
  ShieldAlert,
  Sparkles,
  TriangleAlert,
} from "lucide-react";
import type { AppLocale } from "@/lib/i18n";
import type {
  TableAdviceRecord,
  TableAdviceRisk,
  TableAdviceType,
} from "@/lib/table-advice";

const typeLabels: Record<TableAdviceType, string> = {
  allergy: "过敏 / 忌口",
  balance: "菜单结构",
  duplicate: "相似 / 重复",
  quantity: "份数复核",
};

const riskStyles: Record<TableAdviceRisk, string> = {
  critical: "border-[#e8a894] bg-[#fff4ef] text-[#9a3412]",
  info: "border-[#bcd4ef] bg-[#f3f8ff] text-[#285b8f]",
  warning: "border-[#efd197] bg-[#fffaf0] text-[#8a590e]",
};

function RecordStatus({
  current,
  locale,
}: {
  current: boolean;
  locale: AppLocale;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold ${current ? "bg-[#e2f5e9] text-[#176b48]" : "bg-[#fff0df] text-[#995816]"}`}
    >
      {current ? (
        <CheckCircle2 className="size-3" />
      ) : (
        <Clock3 className="size-3" />
      )}
      {current
        ? locale === "en"
          ? "Current summary"
          : "基于当前汇总"
        : locale === "en"
          ? "Outdated"
          : "已过期"}
    </span>
  );
}

export function TableAdvicePanel({
  confirmed,
  currentRevision,
  locale = "zh-CN",
  records,
}: {
  confirmed: boolean;
  currentRevision: number;
  locale?: AppLocale;
  records: TableAdviceRecord[];
}) {
  const visibleRecords = records.filter((record) => record.status !== "failed");
  const orderedRecords = [...visibleRecords].sort((left, right) => {
    const leftCurrent = left.source_revision === currentRevision ? 1 : 0;
    const rightCurrent = right.source_revision === currentRevision ? 1 : 0;
    return rightCurrent - leftCurrent;
  });
  return (
    <section className="overflow-hidden border-y border-[#4f7c70]/35 bg-[#4f7c70]/8">
      <div className="border-b border-[#dfe2fa] bg-[#eef0ff] px-5 py-4 sm:px-6">
        <div className="flex items-start gap-3">
          <span className="grid size-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
            <Sparkles className="size-5" />
          </span>
          <div>
            <h2 className="text-lg font-black">
              {locale === "en" ? "AI table review" : "整桌点餐建议"}
            </h2>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              {locale === "en"
                ? "AI only reads the calculated summary. It cannot change choices, quantities, or orders."
                : "AI 只阅读普通程序算好的汇总，不会修改选择、数量或订单。"}
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-5 p-5 sm:p-6">
        {confirmed ? (
          <p className="border-block bg-[#fffefb] px-4 py-3 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "The final order is confirmed. Previous advice remains visible, but no new advice is generated."
              : "最终订单已经确认，下面仍可查看历史建议，但不再生成新建议。"}
          </p>
        ) : null}

        {orderedRecords.length ? (
          <div className="space-y-5">
            {orderedRecords.map((record) => {
              const current = record.source_revision === currentRevision;
              return (
                <article
                  className="mc-advice-record border-y bg-[#fffefb] p-4"
                  key={record.id}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <RecordStatus current={current} locale={locale} />
                    </div>
                    <time className="text-xs text-muted-foreground">
                      {new Intl.DateTimeFormat(
                        locale === "en" ? "en" : "zh-CN",
                        {
                          dateStyle: "short",
                          timeStyle: "short",
                          timeZone: "UTC",
                        },
                      ).format(new Date(record.created_at))}
                      {" UTC"}
                    </time>
                  </div>

                  {record.status === "processing" ? (
                    <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                      <LoaderCircle className="size-4 animate-spin" />
                      {locale === "en"
                        ? "Advice is being generated. You can refresh later."
                        : "建议正在生成，可稍后刷新页面。"}
                    </p>
                  ) : null}
                  {record.status === "succeeded" && record.result ? (
                    <div className="mt-4 grid gap-3">
                      {record.result.items.map((item, index) => (
                        <section
                          className={`mc-advice-line border-y p-4 ${riskStyles[item.risk]}`}
                          key={`${item.type}-${item.title}-${index}`}
                        >
                          <div className="flex items-start gap-3">
                            {item.risk === "critical" ? (
                              <ShieldAlert className="mt-0.5 size-5 shrink-0" />
                            ) : item.risk === "warning" ? (
                              <TriangleAlert className="mt-0.5 size-5 shrink-0" />
                            ) : (
                              <Info className="mt-0.5 size-5 shrink-0" />
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold tracking-[0.12em] uppercase opacity-75">
                                {typeLabels[item.type]} · {item.risk}
                              </p>
                              <h3 className="mt-1 break-words font-black">
                                {item.title}
                              </h3>
                              <p className="mt-2 break-words text-sm leading-6">
                                {item.detail}
                              </p>
                              <p className="mt-2 break-words border-t border-current/15 pt-2 text-xs leading-5 opacity-80">
                                {locale === "en" ? "Evidence" : "依据"}：
                                {item.evidence}
                              </p>
                            </div>
                          </div>
                        </section>
                      ))}
                    </div>
                  ) : null}
                </article>
              );
            })}
          </div>
        ) : (
          <p className="border-y border-dashed bg-[#fffefb] px-4 py-6 text-center text-sm text-muted-foreground">
            {confirmed
              ? locale === "en"
                ? "This order has no previous AI review."
                : "这份订单没有历史建议。"
              : locale === "en"
                ? "No table advice is available right now. Continue reviewing and confirming the order normally."
                : "暂未生成整桌建议，你可以照常继续核对和确认订单。"}
          </p>
        )}

        <p className="flex items-start gap-2 border-block border-[#c28a42]/25 bg-[#fff8e8] px-4 py-3 text-xs leading-5 text-[#835515]">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          {locale === "en"
            ? "AI may be wrong. Confirm ingredients and allergens with restaurant staff; this is not a medical guarantee."
            : "AI 可能出错，食材与过敏原须向餐厅确认；这些提示不构成医疗保证。"}
        </p>
      </div>
    </section>
  );
}
