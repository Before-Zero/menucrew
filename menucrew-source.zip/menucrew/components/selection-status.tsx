import { CheckCircle2, CircleDashed } from "lucide-react";
import type { AppLocale } from "@/lib/i18n";

export function SelectionStatus({
  dirty,
  dishCount,
  locale = "zh-CN",
  savedAt,
  totalQuantity,
}: {
  dirty: boolean;
  dishCount: number;
  locale?: AppLocale;
  savedAt: string | null;
  totalQuantity: number;
}) {
  const savedTime = savedAt
    ? new Intl.DateTimeFormat(locale === "en" ? "en" : "zh-CN", {
        hour: "2-digit",
        minute: "2-digit",
        month: "short",
        day: "numeric",
        timeZone: "UTC",
      }).format(new Date(savedAt))
    : null;

  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-2 text-sm">
        {savedTime && !dirty ? (
          <CheckCircle2 aria-hidden="true" className="size-4 text-[#168252]" />
        ) : (
          <CircleDashed aria-hidden="true" className="size-4 text-[#b16a0d]" />
        )}
        <span className="font-semibold">
          {dirty
            ? locale === "en"
              ? "Unsaved changes"
              : "有尚未保存的修改"
            : savedTime
              ? `${locale === "en" ? "Saved" : "已保存"} · ${savedTime} UTC`
              : locale === "en"
                ? "Not saved yet"
                : "尚未保存"}
        </span>
      </div>
      <p className="font-mono text-xs text-muted-foreground">
        {locale === "en"
          ? `${dishCount} dishes · ${totalQuantity} servings`
          : `${dishCount} 道 · ${totalQuantity} 份`}
      </p>
    </div>
  );
}
