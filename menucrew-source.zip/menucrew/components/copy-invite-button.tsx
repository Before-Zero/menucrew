"use client";

import { Check, Copy, TriangleAlert } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";

export function CopyInviteButton({
  inviteToken,
  locale = "zh-CN",
}: {
  inviteToken: string;
  locale?: AppLocale;
}) {
  const [status, setStatus] = useState<"idle" | "copied" | "failed">("idle");
  const invitePath = `/join/${inviteToken}`;
  const [shareUrl, setShareUrl] = useState(invitePath);

  useEffect(() => {
    setShareUrl(`${window.location.origin}${invitePath}`);
  }, [invitePath]);

  async function copyInvite() {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setStatus("copied");
    } catch {
      setStatus("failed");
    }
  }

  return (
    <div className="space-y-2">
      <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">
        {locale === "en" ? "Invite link" : "邀请链接"}
        <input
          className="h-11 w-full rounded-xl border bg-[#fffefb] px-3 font-mono text-xs text-foreground"
          onFocus={(event) => event.currentTarget.select()}
          readOnly
          value={shareUrl}
        />
      </label>
      <Button
        className="h-11 w-full rounded-xl"
        onClick={copyInvite}
        type="button"
      >
        {status === "copied" ? (
          <Check aria-hidden="true" />
        ) : (
          <Copy aria-hidden="true" />
        )}
        {status === "copied"
          ? locale === "en"
            ? "Link copied"
            : "链接已复制"
          : locale === "en"
            ? "Copy invite link"
            : "复制邀请链接"}
      </Button>
      {status === "failed" ? (
        <p className="flex items-center gap-1.5 text-xs text-destructive">
          <TriangleAlert aria-hidden="true" className="size-3.5" />
          {locale === "en"
            ? "Could not copy automatically. Check clipboard permission and try again."
            : "无法自动复制，请检查浏览器剪贴板权限后重试。"}
        </p>
      ) : null}
    </div>
  );
}
