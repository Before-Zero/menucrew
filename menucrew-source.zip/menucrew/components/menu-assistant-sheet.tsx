"use client";

import {
  AlertTriangle,
  Check,
  LoaderCircle,
  Mic,
  MicOff,
  Sparkles,
  X,
} from "lucide-react";
import { useActionState, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import {
  initialMenuAssistantActionState,
  type MenuAssistantActionState,
} from "@/lib/menu-assistant-action-state";

type Action = (
  state: MenuAssistantActionState,
  formData: FormData,
) => Promise<MenuAssistantActionState>;

type SpeechRecognitionResultLike = {
  0: { transcript: string };
  isFinal: boolean;
};

type SpeechRecognitionLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  onend: (() => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onresult:
    | ((event: {
        resultIndex: number;
        results: ArrayLike<SpeechRecognitionResultLike>;
      }) => void)
    | null;
  start: () => void;
  stop: () => void;
};

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;

export function MenuAssistantSheet({
  action,
  allergyInfo,
  currentSelections,
  dietaryRestrictions,
  locale,
  menuItemId,
  menuItemName,
  onClose,
  onApplyRecommendation,
  open,
}: {
  action: Action;
  allergyInfo: string;
  currentSelections: string;
  dietaryRestrictions: string;
  locale: AppLocale;
  menuItemId?: string;
  menuItemName?: string;
  onClose: () => void;
  onApplyRecommendation: (
    items: Array<{ menuItemId: string; quantity: number }>,
  ) => void;
  open: boolean;
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialMenuAssistantActionState,
  );
  const [question, setQuestion] = useState("");
  const [mounted, setMounted] = useState(false);
  const [listening, setListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [speechMessage, setSpeechMessage] = useState("");
  const dialogRef = useRef<HTMLElement>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  useEffect(() => {
    setMounted(true);
    const speechWindow = window as typeof window & {
      SpeechRecognition?: SpeechRecognitionConstructor;
      webkitSpeechRecognition?: SpeechRecognitionConstructor;
    };
    setSpeechSupported(
      Boolean(
        speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition,
      ),
    );
  }, []);
  useEffect(() => {
    if (open)
      setQuestion(
        menuItemId
          ? locale === "en"
            ? "Explain this dish"
            : "介绍一下这道菜"
          : locale === "en"
            ? "Build a practical personal order for me"
            : "根据我的情况搭配一份可以直接点的菜单",
      );
  }, [open, menuItemId, locale]);
  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusFrame = window.requestAnimationFrame(() =>
      dialogRef.current?.focus(),
    );
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key !== "Tab" || !dialogRef.current) return;
      const focusable = Array.from(
        dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), textarea:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      );
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
      previousFocus?.focus();
    };
  }, [onClose, open]);
  useEffect(
    () => () => {
      recognitionRef.current?.stop();
    },
    [],
  );
  useEffect(() => {
    if (open) return;
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setListening(false);
  }, [open]);
  if (!open || !mounted) return null;

  function toggleSpeechInput() {
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    const speechWindow = window as typeof window & {
      SpeechRecognition?: SpeechRecognitionConstructor;
      webkitSpeechRecognition?: SpeechRecognitionConstructor;
    };
    const Recognition =
      speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
    if (!Recognition) return;
    const recognition = new Recognition();
    const startingQuestion = question.trim();
    recognition.lang = locale === "en" ? "en-US" : "zh-CN";
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      let transcript = "";
      for (
        let index = event.resultIndex;
        index < event.results.length;
        index += 1
      )
        transcript += event.results[index]?.[0]?.transcript ?? "";
      if (transcript.trim())
        setQuestion(
          [startingQuestion, transcript.trim()].filter(Boolean).join(" "),
        );
    };
    recognition.onerror = (event) => {
      setSpeechMessage(
        event.error === "not-allowed"
          ? locale === "en"
            ? "Microphone access was blocked. You can keep typing instead."
            : "麦克风权限被拒绝了，你仍可以继续打字。"
          : locale === "en"
            ? "I couldn't hear that clearly. Please try again."
            : "刚才没有听清，请再试一次。",
      );
      setListening(false);
    };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    setSpeechMessage("");
    setListening(true);
    recognition.start();
  }

  const quickQuestions = menuItemId
    ? locale === "en"
      ? ["What does this dish taste like?", "How is this dish usually cooked?"]
      : ["这道菜大概什么口味？", "这道菜通常怎么做？"]
    : locale === "en"
      ? [
          "Recommend dishes for my dietary needs",
          "Build a balanced, non-repetitive order",
        ]
      : ["根据我的忌口推荐几道菜", "帮我搭配一份不重复的菜单"];

  return createPortal(
    <div
      className="mc-assistant-backdrop fixed inset-0 z-[100] flex items-end bg-[#211f1d]/42 p-0 backdrop-blur-[2px] sm:items-stretch sm:justify-end sm:p-5"
      role="presentation"
    >
      <button
        aria-label={locale === "en" ? "Close menu assistant" : "关闭菜单助手"}
        className="absolute inset-0 cursor-default"
        onClick={onClose}
        type="button"
      />
      <section
        aria-label={locale === "en" ? "Menu assistant" : "菜单助手"}
        aria-modal="true"
        className="mc-assistant-dialog relative z-10 max-h-[90dvh] w-full overflow-y-auto bg-[#fffaf4] p-5 outline-none sm:max-h-none sm:max-w-[40rem] sm:p-8"
        ref={dialogRef}
        role="dialog"
        tabIndex={-1}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="mc-waiter-caption flex items-center gap-2 text-xs font-semibold text-[#c85d22]">
              <Sparkles className="size-4" />{" "}
              {locale === "en"
                ? menuItemId
                  ? "Dish guide"
                  : "AI order builder"
                : menuItemId
                  ? "单菜说明"
                  : "AI 点餐搭配"}
            </p>
            <h2 className="mt-2 text-2xl font-black">
              {locale === "en"
                ? menuItemId
                  ? "About this dish"
                  : "A personal order you can use"
                : menuItemId
                  ? "了解这道菜"
                  : "生成一套可以直接用的搭配"}
            </h2>
            {menuItemName ? (
              <p className="mt-1 text-sm text-muted-foreground">
                {menuItemName}
              </p>
            ) : null}
          </div>
          <Button
            aria-label={
              locale === "en" ? "Close menu assistant" : "关闭菜单助手"
            }
            onClick={onClose}
            size="icon"
            type="button"
            variant="ghost"
          >
            <X />
          </Button>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {quickQuestions.map((quick) => (
            <button
              className="mc-question-slip px-3 py-2 text-left text-sm"
              key={quick}
              onClick={() => setQuestion(quick)}
              type="button"
            >
              {quick}
            </button>
          ))}
        </div>

        <form action={formAction} className="mt-5">
          <input name="allergyInfo" type="hidden" value={allergyInfo} />
          <input
            name="currentSelections"
            type="hidden"
            value={currentSelections}
          />
          <input
            name="dietaryRestrictions"
            type="hidden"
            value={dietaryRestrictions}
          />
          <input name="locale" type="hidden" value={locale} />
          <input name="menuItemId" type="hidden" value={menuItemId ?? ""} />
          <input
            name="intent"
            type="hidden"
            value={menuItemId ? "explanation" : "recommendation"}
          />
          <div className="relative">
            <textarea
              className="mc-note-input min-h-32 w-full border bg-[#fffefb] px-4 py-3 pr-14 text-sm leading-6 outline-none focus:border-primary focus:ring-3 focus:ring-primary/15"
              maxLength={240}
              name="question"
              onChange={(event) => setQuestion(event.target.value)}
              placeholder={
                locale === "en"
                  ? "Tell AI what you feel like eating, or tap the microphone…"
                  : "说说或输入你想吃什么、口味和人数…"
              }
              required
              value={question}
            />
            {speechSupported ? (
              <button
                aria-label={
                  listening
                    ? locale === "en"
                      ? "Stop voice input"
                      : "停止语音输入"
                    : locale === "en"
                      ? "Start voice input"
                      : "开始语音输入"
                }
                aria-pressed={listening}
                className={`absolute right-3 bottom-3 grid size-10 place-items-center rounded-full border transition ${listening ? "border-[#b9433c] bg-[#b9433c] text-white shadow-[0_0_0_6px_rgb(185_67_60_/_0.12)]" : "border-[#24322d]/20 bg-[#f4f1e8] text-[#24322d] hover:border-[#b9433c] hover:text-[#b9433c]"}`}
                onClick={toggleSpeechInput}
                type="button"
              >
                {listening ? <MicOff /> : <Mic />}
              </button>
            ) : null}
          </div>
          <div className="mt-2 flex min-h-5 items-center justify-between gap-3 text-xs">
            <p aria-live="polite" className="text-muted-foreground">
              {listening
                ? locale === "en"
                  ? "Listening… tell me what you feel like eating."
                  : "正在听…说说你想吃什么。"
                : speechMessage ||
                  (speechSupported
                    ? locale === "en"
                      ? "Voice is converted to text before AI recommends dishes."
                      : "语音会先转成文字，再由 AI 推荐菜品。"
                    : locale === "en"
                      ? "Voice input is unavailable here; typing still works."
                      : "当前浏览器不支持语音输入，仍可正常打字。")}
            </p>
            <span className="shrink-0 font-mono text-muted-foreground">
              {question.length}/240
            </span>
          </div>
          <Button
            className="mt-3 w-full"
            disabled={pending || !question.trim()}
            type="submit"
          >
            {pending ? <LoaderCircle className="animate-spin" /> : <Sparkles />}
            {pending
              ? locale === "en"
                ? "Building your order…"
                : "正在搭配…"
              : locale === "en"
                ? state.status === "error"
                  ? "Try again"
                  : menuItemId
                    ? "Ask AI"
                    : "Build my order"
                : state.status === "error"
                  ? "重新生成"
                  : menuItemId
                    ? "查看说明"
                    : "生成我的点餐搭配"}
          </Button>
          {pending ? (
            <div className="mc-waiter-thinking mt-3" aria-live="polite">
              <span aria-hidden="true">
                <i />
                <i />
                <i />
              </span>
              <p className="text-xs leading-5 text-muted-foreground">
                {locale === "en"
                  ? "AI is checking the menu and your needs. This can take up to about 35 seconds; you may close this note and keep ordering."
                  : "AI 正在结合菜单和你的需求进行搭配，最长可能需要约 35 秒；你也可以先收起批注继续点餐。"}
              </p>
            </div>
          ) : null}
        </form>

        {state.result?.kind === "recommendation" ? (
          <article className="mc-assistant-answer mt-6 border bg-[#fffefb] p-5">
            <p className="font-bold leading-6">{state.result.summary}</p>
            <ol className="mt-4 divide-y">
              {state.result.items.map((item) => (
                <li className="py-3" key={item.menuItemId}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">{item.originalName}</p>
                      <p className="mt-1 text-sm leading-5 text-muted-foreground">
                        {item.reason}
                      </p>
                    </div>
                    <strong className="shrink-0 font-mono">
                      ×{item.quantity}
                    </strong>
                  </div>
                  {item.risk !== "none" ? (
                    <p className="mt-2 text-xs font-semibold text-[#9a461e]">
                      {item.riskNote ||
                        (locale === "en"
                          ? "Confirm ingredients and allergens with the restaurant"
                          : "食材与过敏原请向餐厅确认")}
                    </p>
                  ) : null}
                </li>
              ))}
            </ol>
            <Button
              className="mt-4 w-full"
              disabled={state.result.items.every(
                (item) => item.risk === "conflict",
              )}
              onClick={() => {
                onApplyRecommendation(
                  state.result?.kind === "recommendation"
                    ? state.result.items
                        .filter((item) => item.risk !== "conflict")
                        .map(({ menuItemId: id, quantity }) => ({
                          menuItemId: id,
                          quantity,
                        }))
                    : [],
                );
                onClose();
              }}
              type="button"
            >
              <Check />{" "}
              {locale === "en" ? "Use this order" : "应用这套搭配（仍需保存）"}
            </Button>
          </article>
        ) : state.result?.kind === "explanation" ? (
          <article className="mc-assistant-answer mt-6 border bg-[#fffefb] p-5">
            <p className="whitespace-pre-wrap text-sm leading-7">
              {state.result.answer}
            </p>
            {state.result.referencedItems.length ? (
              <p className="mt-3 text-xs font-semibold text-primary">
                {state.result.referencedItems
                  .map((item) => item.originalName)
                  .join(" · ")}
              </p>
            ) : null}
            {state.result.caution ? (
              <p className="mt-4 flex items-start gap-2 border-block border-[#c28a42]/25 bg-[#fff2e8] px-3 py-2 text-xs leading-5 text-[#8a461d]">
                <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                {state.result.caution}
              </p>
            ) : null}
          </article>
        ) : state.message ? (
          <p className="mt-4 border-block border-[#c28a42]/25 bg-[#fff2e8] px-3 py-2 text-sm text-[#8a461d]">
            {state.message}
          </p>
        ) : null}
        <p className="mt-4 text-xs leading-5 text-muted-foreground">
          {locale === "en"
            ? "AI may be wrong. Confirm ingredients and allergens with restaurant staff. Suggestions never change your order."
            : "AI 可能出错，食材和过敏原请向餐厅确认。应用只会填入当前页面，仍需你自己保存。"}
        </p>
      </section>
    </div>,
    document.body,
  );
}
