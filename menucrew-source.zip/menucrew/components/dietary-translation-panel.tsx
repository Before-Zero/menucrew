"use client";

import {
  AlertTriangle,
  Languages,
  LoaderCircle,
  ShieldAlert,
} from "lucide-react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import {
  type DiningNoteTranslationActionState,
  initialDiningNoteTranslationState,
} from "@/lib/dining-note-translation-action-state";
import type { AppLocale } from "@/lib/i18n";

type Action = (
  state: DiningNoteTranslationActionState,
  formData: FormData,
) => Promise<DiningNoteTranslationActionState>;

type DietaryMember = {
  allergyInfo: string;
  dietaryRestrictions: string;
  displayName: string;
  userId: string;
};

export function DietaryTranslationPanel({
  action,
  locale,
  members,
}: {
  action: Action;
  locale: AppLocale;
  members: DietaryMember[];
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialDiningNoteTranslationState,
  );
  const translations = new Map(
    state.translations.map((translation) => [translation.userId, translation]),
  );

  return (
    <section className="border-y border-[#c28a42]/45 bg-[#efe3ce]/42 p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <ShieldAlert className="mt-0.5 size-5 text-[#b56700]" />
          <div>
            <p className="font-mono text-[10px] font-semibold tracking-[0.14em] text-[#9a5e0b] uppercase">
              Dietary translation
            </p>
            <h2 className="mt-2 text-lg font-black">
              {locale === "en" ? "Dietary needs & allergies" : "忌口与过敏"}
            </h2>
          </div>
        </div>
        {members.length ? (
          <form action={formAction}>
            <input name="locale" type="hidden" value={locale} />
            <Button
              disabled={pending}
              size="sm"
              type="submit"
              variant="outline"
            >
              {pending ? (
                <LoaderCircle className="animate-spin" />
              ) : (
                <Languages />
              )}
              {pending
                ? locale === "en"
                  ? "Translating…"
                  : "正在翻译…"
                : locale === "en"
                  ? "Translate all"
                  : "翻译全部备注"}
            </Button>
          </form>
        ) : null}
      </div>

      {members.length ? (
        <ul className="mt-4 divide-y divide-[#d8c39f]">
          {members.map((member) => {
            const translated = translations.get(member.userId);
            return (
              <li className="py-4 first:pt-0 last:pb-0" key={member.userId}>
                <p className="break-words text-sm font-bold">
                  {member.displayName}
                </p>
                {member.allergyInfo ? (
                  <div className="mt-2 rounded-lg bg-[#fff0eb] px-3 py-2 text-sm leading-5 text-[#9a3412]">
                    <p className="flex items-start gap-2 font-semibold">
                      <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                      {locale === "en" ? "Original allergy" : "过敏原文"}：
                      {member.allergyInfo}
                    </p>
                    {translated?.allergyEn ? (
                      <p className="mt-2 border-t border-[#9a3412]/15 pt-2">
                        <strong>EN</strong> · {translated.allergyEn}
                      </p>
                    ) : null}
                    {translated?.allergyZh ? (
                      <p className="mt-1">
                        <strong>中文</strong> · {translated.allergyZh}
                      </p>
                    ) : null}
                  </div>
                ) : null}
                {member.dietaryRestrictions ? (
                  <div className="mt-2 break-words text-sm leading-5 text-muted-foreground">
                    <p>
                      {locale === "en" ? "Original dietary note" : "忌口原文"}：
                      {member.dietaryRestrictions}
                    </p>
                    {translated?.dietaryEn ? (
                      <p className="mt-2 border-t border-[#24322d]/10 pt-2 text-[#24322d]">
                        <strong>EN</strong> · {translated.dietaryEn}
                      </p>
                    ) : null}
                    {translated?.dietaryZh ? (
                      <p className="mt-1 text-[#24322d]">
                        <strong>中文</strong> · {translated.dietaryZh}
                      </p>
                    ) : null}
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="mt-4 text-sm leading-6 text-muted-foreground">
          {locale === "en"
            ? "No submitted diner added dietary information."
            : "已提交成员没有填写整体饮食信息。"}
        </p>
      )}
      {state.message ? (
        <p
          aria-live="polite"
          className={`mt-4 text-xs leading-5 ${state.status === "error" ? "text-[#9a3412]" : "text-[#317268]"}`}
        >
          {state.message}
        </p>
      ) : null}
      <p className="mt-4 text-xs leading-5 text-muted-foreground">
        {locale === "en"
          ? "AI translation may be wrong. Always confirm ingredients and allergens with restaurant staff. Original notes are never replaced."
          : "AI 翻译可能出错，食材与过敏原仍须向餐厅确认；系统不会覆盖任何人的原始备注。"}
      </p>
    </section>
  );
}
