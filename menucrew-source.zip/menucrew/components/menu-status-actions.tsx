"use client";

import { LoaderCircle, RotateCcw, Send } from "lucide-react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import {
  initialMenuActionState,
  type MenuActionState,
} from "@/lib/menu-action-state";

export function MenuStatusActions({
  action,
  canPublish = true,
  locale = "zh-CN",
  mode,
}: {
  action: (
    state: MenuActionState,
    payload: FormData,
  ) => Promise<MenuActionState>;
  canPublish?: boolean;
  locale?: AppLocale;
  mode: "create" | "publish" | "reopen";
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialMenuActionState,
  );
  const publish = mode === "publish";
  const create = mode === "create";
  return (
    <form
      action={formAction}
      className="space-y-3"
      onSubmit={(event) => {
        const prompt = publish
          ? locale === "en"
            ? "Publish this menu to everyone in the room?"
            : "确定发布当前菜单给所有房间成员吗？"
          : create
            ? null
            : locale === "en"
              ? "Return to draft? Diners will temporarily lose access to the menu."
              : "确定退回草稿吗？成员将暂时看不到菜单。";
        if (prompt && !window.confirm(prompt)) event.preventDefault();
      }}
    >
      <Button
        className="h-12 w-full rounded-xl"
        disabled={pending || (publish && !canPublish)}
        type="submit"
        variant={publish ? "default" : "outline"}
      >
        {pending ? (
          <LoaderCircle aria-hidden="true" className="animate-spin" />
        ) : publish ? (
          <Send aria-hidden="true" />
        ) : create ? null : (
          <RotateCcw aria-hidden="true" />
        )}
        {pending
          ? locale === "en"
            ? "Working…"
            : "正在处理"
          : publish
            ? locale === "en"
              ? "Publish menu"
              : "发布菜单并邀请成员"
            : create
              ? locale === "en"
                ? "Create menu draft"
                : "建立菜单草稿"
              : locale === "en"
                ? "Return to draft"
                : "退回草稿继续编辑"}
      </Button>
      {create ? null : (
        <p className="text-xs leading-5 text-muted-foreground">
          {publish
            ? locale === "en"
              ? "Diners will see every bilingual dish in this order. Return to draft before editing."
              : "发布后成员会按当前顺序看到全部双语菜品；要修改需先退回草稿。"
            : locale === "en"
              ? "Diners cannot see the menu until you publish it again."
              : "退回后成员会暂时看不到菜单，直到你再次发布。"}
        </p>
      )}
      {state.message ? (
        <p
          aria-live="polite"
          className={
            state.status === "error"
              ? "rounded-xl bg-destructive/5 px-4 py-3 text-sm text-destructive"
              : "rounded-xl bg-[#edf8f2] px-4 py-3 text-sm text-[#16724a]"
          }
        >
          {state.message}
        </p>
      ) : null}
    </form>
  );
}
