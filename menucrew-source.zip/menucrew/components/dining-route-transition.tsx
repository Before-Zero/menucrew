"use client";

import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

type TransitionPhase =
  | "idle"
  | "departing"
  | "covering"
  | "arriving"
  | "shifting";

const stageForPath = (pathname: string) => {
  if (/\/order(?:\/|$)/.test(pathname))
    return {
      key: "order",
      number: "03",
      title: "汇总落单",
      english: "Order together",
    };
  if (/\/summary(?:\/|$)/.test(pathname))
    return {
      key: "order",
      number: "03",
      title: "汇总落单",
      english: "Review together",
    };
  if (/\/receipt(?:\/|$)/.test(pathname))
    return {
      key: "order",
      number: "03",
      title: "汇总落单",
      english: "Order together",
    };
  if (/\/selection(?:\/|$)/.test(pathname))
    return {
      key: "selection",
      number: "02",
      title: "各自选菜",
      english: "Choose your dishes",
    };
  if (/\/menu(?:\/|$)/.test(pathname))
    return {
      key: "menu",
      number: "01",
      title: "准备菜单",
      english: "Prepare the menu",
    };
  return {
    key: "menu",
    number: "01",
    title: "准备开饭",
    english: "Gather at the table",
  };
};

export function DiningRouteTransition() {
  const pathname = usePathname();
  const router = useRouter();
  const [phase, setPhase] = useState<TransitionPhase>("idle");
  const [stage, setStage] = useState(() => stageForPath(pathname));
  const phaseRef = useRef<TransitionPhase>("idle");
  const previousPath = useRef(pathname);
  const navigationTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const finishTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fallbackTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const departureTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updatePhase = useCallback((next: TransitionPhase) => {
    phaseRef.current = next;
    setPhase(next);
  }, []);

  useEffect(() => {
    function onClick(event: MouseEvent) {
      if (
        event.defaultPrevented ||
        event.button !== 0 ||
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey ||
        phaseRef.current !== "idle"
      )
        return;

      const anchor = (event.target as Element | null)?.closest("a");
      if (
        !(anchor instanceof HTMLAnchorElement) ||
        anchor.target ||
        anchor.hasAttribute("download")
      )
        return;

      const url = new URL(anchor.href, window.location.href);
      if (
        url.origin !== window.location.origin ||
        !url.pathname.startsWith("/rooms/") ||
        url.pathname === window.location.pathname
      )
        return;

      const reducedMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)",
      ).matches;
      if (reducedMotion) return;

      const currentStage = stageForPath(window.location.pathname);
      const targetStage = stageForPath(url.pathname);
      if (currentStage.key === targetStage.key) {
        document.documentElement.style.setProperty(
          "--mc-shift-y",
          `${event.clientY}px`,
        );
        setStage(targetStage);
        updatePhase("shifting");
        finishTimer.current = setTimeout(() => updatePhase("idle"), 540);
        return;
      }

      event.preventDefault();
      const control = document.querySelector<HTMLElement>(
        "[data-mc-active-control]",
      );
      const rect = control?.getBoundingClientRect();
      const x = rect ? rect.left + rect.width / 2 : event.clientX;
      const y = rect ? rect.top + rect.height / 2 : event.clientY;
      document.documentElement.style.setProperty("--mc-transition-x", `${x}px`);
      document.documentElement.style.setProperty("--mc-transition-y", `${y}px`);
      setStage(stageForPath(url.pathname));
      updatePhase("covering");

      navigationTimer.current = setTimeout(() => {
        router.push(`${url.pathname}${url.search}${url.hash}`);
        fallbackTimer.current = setTimeout(() => updatePhase("idle"), 4000);
      }, 540);
    }

    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, [router, updatePhase]);

  useEffect(() => {
    function beginDeparture(event: Event) {
      if (phaseRef.current !== "idle") return;
      const detail = (event as CustomEvent<{ x?: number; y?: number }>).detail;
      document.documentElement.style.setProperty(
        "--mc-transition-x",
        `${detail?.x ?? window.innerWidth / 2}px`,
      );
      document.documentElement.style.setProperty(
        "--mc-transition-y",
        `${detail?.y ?? window.innerHeight / 2}px`,
      );
      setStage(stageForPath("/rooms/pending"));
      updatePhase("departing");
      departureTimer.current = setTimeout(() => updatePhase("covering"), 1160);
    }

    function cancelDeparture() {
      if (departureTimer.current) clearTimeout(departureTimer.current);
      if (phaseRef.current === "departing" || phaseRef.current === "covering")
        updatePhase("idle");
    }

    window.addEventListener("menucrew:home-departure", beginDeparture);
    window.addEventListener("menucrew:home-departure-cancel", cancelDeparture);
    return () => {
      window.removeEventListener("menucrew:home-departure", beginDeparture);
      window.removeEventListener(
        "menucrew:home-departure-cancel",
        cancelDeparture,
      );
    };
  }, [updatePhase]);

  useEffect(() => {
    if (previousPath.current === pathname) return;
    const previousPathname = previousPath.current;
    const previousStage = stageForPath(previousPathname);
    const enteredFirstRoom =
      previousPathname === "/" && pathname.startsWith("/rooms/");
    previousPath.current = pathname;
    const nextStage = stageForPath(pathname);

    if (previousStage.key === nextStage.key && !enteredFirstRoom) {
      setStage(nextStage);
      if (phaseRef.current !== "shifting") {
        updatePhase("shifting");
        finishTimer.current = setTimeout(() => updatePhase("idle"), 540);
      }
      return;
    }

    if (phaseRef.current === "covering" && fallbackTimer.current)
      clearTimeout(fallbackTimer.current);
    if (departureTimer.current) clearTimeout(departureTimer.current);

    let attempts = 0;
    const locateTarget = () => {
      requestAnimationFrame(() => {
        const target = document.querySelector<HTMLElement>(
          "[data-mc-transition-target]",
        );
        const rect = target?.getBoundingClientRect();
        const targetIsReady =
          rect &&
          rect.width > 0 &&
          rect.height > 0 &&
          rect.top >= 0 &&
          rect.top < window.innerHeight;
        if (!targetIsReady && attempts < 12) {
          attempts += 1;
          locateTarget();
          return;
        }
        const fallbackX = Math.max(
          45,
          (window.innerWidth - Math.min(window.innerWidth, 1248)) / 2 +
            (window.innerWidth >= 640 ? 45 : 37),
        );
        const x = rect ? rect.left + rect.width / 2 : fallbackX;
        const y = rect
          ? rect.top + rect.height / 2
          : window.innerWidth >= 640
            ? 141
            : 117;
        document.documentElement.style.setProperty(
          "--mc-transition-target-x",
          `${x}px`,
        );
        document.documentElement.style.setProperty(
          "--mc-transition-target-y",
          `${y}px`,
        );
        setStage(nextStage);
        updatePhase("arriving");
        finishTimer.current = setTimeout(() => updatePhase("idle"), 920);
      });
    };
    locateTarget();
  }, [pathname, updatePhase]);

  useEffect(
    () => () => {
      if (navigationTimer.current) clearTimeout(navigationTimer.current);
      if (finishTimer.current) clearTimeout(finishTimer.current);
      if (fallbackTimer.current) clearTimeout(fallbackTimer.current);
      if (departureTimer.current) clearTimeout(departureTimer.current);
    },
    [],
  );

  return (
    <div
      aria-hidden="true"
      className={`mc-route-transition is-${phase}`}
      data-phase={phase}
    >
      <div className="mc-route-transition-label">
        <span>{stage.number}</span>
        <strong>{stage.title}</strong>
        <small>{stage.english}</small>
      </div>
      <span className="mc-route-transition-ink" />
      <span className="mc-home-departure-route">
        <i />
      </span>
    </div>
  );
}
