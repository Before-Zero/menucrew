import { AlertTriangle, RotateCcw } from "lucide-react";
import type { ReactNode } from "react";
import { MenuCrewMark } from "@/components/menu-crew-mark";

export function PageStatus({
  action,
  description,
  title,
}: {
  action: ReactNode;
  description: string;
  title: string;
}) {
  return (
    <main className="grid min-h-svh place-items-center bg-background px-5 py-12 text-foreground">
      <section className="w-full max-w-xl overflow-hidden rounded-[1.25rem] border bg-[#fffefb] shadow-[0_24px_70px_rgb(33_31_29_/_0.1)]">
        <div className="p-6 sm:p-10">
          <div className="flex items-center gap-3">
            <MenuCrewMark className="size-10 text-[#d95d45]" />
            <div>
              <p className="font-bold leading-none">合点</p>
              <p className="mt-1 font-mono text-[10px] tracking-[0.18em] text-muted-foreground uppercase">
                MenuCrew
              </p>
            </div>
          </div>
          <span className="mt-10 grid size-12 place-items-center rounded-xl bg-[#fff0eb] text-[#a63d1c]">
            <AlertTriangle className="size-5" />
          </span>
          <h1 className="mt-5 text-3xl font-black tracking-[-0.04em] sm:text-4xl">
            {title}
          </h1>
          <p className="mt-3 max-w-md text-sm leading-7 text-muted-foreground sm:text-base">
            {description}
          </p>
          <div className="mt-7 flex items-center gap-2">
            <RotateCcw className="size-4 text-primary" />
            {action}
          </div>
        </div>
      </section>
    </main>
  );
}
