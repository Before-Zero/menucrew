"use client";

import { LoaderCircle, Plus, Save } from "lucide-react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import {
  initialMenuActionState,
  type MenuActionState,
} from "@/lib/menu-action-state";
import type { MenuItem } from "@/lib/menus";

const inputClass =
  "w-full rounded-xl border border-[#d8d7d2] bg-[#fffefb] px-4 py-3 text-sm outline-none transition placeholder:text-[#9a958f] focus:border-primary focus:ring-3 focus:ring-primary/15 aria-invalid:border-destructive";

type Props = {
  action: (
    state: MenuActionState,
    payload: FormData,
  ) => Promise<MenuActionState>;
  item?: MenuItem;
  locale?: AppLocale;
};

export function MenuItemForm({ action, item, locale = "zh-CN" }: Props) {
  const [state, formAction, pending] = useActionState(
    action,
    initialMenuActionState,
  );
  const prefix = item?.id ?? "new";

  return (
    <form action={formAction} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label
          className="space-y-2 text-sm font-semibold"
          htmlFor={`${prefix}-originalName`}
        >
          {locale === "en" ? "Original menu name" : "菜单原文"}
          <input
            aria-invalid={Boolean(state.fields?.originalName)}
            className={inputClass}
            defaultValue={item?.original_name}
            id={`${prefix}-originalName`}
            maxLength={120}
            name="originalName"
            placeholder="Spaghetti alle vongole"
            required
          />
          {state.fields?.originalName ? (
            <span className="block font-normal text-destructive">
              {state.fields.originalName}
            </span>
          ) : null}
        </label>
        <label
          className="space-y-2 text-sm font-semibold"
          htmlFor={`${prefix}-zhName`}
        >
          {locale === "en" ? "Simplified Chinese name" : "简体中文名"}
          <input
            aria-invalid={Boolean(state.fields?.zhName)}
            className={inputClass}
            defaultValue={item?.zh_name}
            id={`${prefix}-zhName`}
            maxLength={120}
            name="zhName"
            placeholder="蛤蜊意面"
            required
          />
          {state.fields?.zhName ? (
            <span className="block font-normal text-destructive">
              {state.fields.zhName}
            </span>
          ) : null}
        </label>
      </div>
      <label
        className="space-y-2 text-sm font-semibold"
        htmlFor={`${prefix}-description`}
      >
        {locale === "en" ? "Short description" : "简短解释"}
        <textarea
          aria-invalid={Boolean(state.fields?.description)}
          className={`${inputClass} min-h-24 resize-y`}
          defaultValue={item?.description}
          id={`${prefix}-description`}
          maxLength={240}
          name="description"
          placeholder="蛤蜊、蒜、白葡萄酒与欧芹"
          required
        />
        {state.fields?.description ? (
          <span className="block font-normal text-destructive">
            {state.fields.description}
          </span>
        ) : null}
      </label>
      <div className="flex flex-col-reverse items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
        <span
          aria-live="polite"
          className={
            state.status === "error"
              ? "text-sm text-destructive"
              : "text-sm text-[#16724a]"
          }
        >
          {state.message}
        </span>
        <Button
          className="h-10 rounded-xl px-4"
          disabled={pending}
          type="submit"
        >
          {pending ? (
            <LoaderCircle aria-hidden="true" className="animate-spin" />
          ) : item ? (
            <Save aria-hidden="true" />
          ) : (
            <Plus aria-hidden="true" />
          )}
          {pending
            ? locale === "en"
              ? "Saving…"
              : "正在保存"
            : item
              ? locale === "en"
                ? "Save changes"
                : "保存修改"
              : locale === "en"
                ? "Add to menu"
                : "加入菜单"}
        </Button>
      </div>
    </form>
  );
}
