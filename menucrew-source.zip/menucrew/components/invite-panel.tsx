import { Hash, Link2, QrCode } from "lucide-react";
import Image from "next/image";
import { CopyInviteButton } from "@/components/copy-invite-button";
import type { AppLocale } from "@/lib/i18n";

export function InvitePanel({
  defaultOpen = false,
  inviteToken,
  joinCode,
  locale = "zh-CN",
  qrDataUrl,
}: {
  defaultOpen?: boolean;
  inviteToken?: string;
  joinCode: string;
  locale?: AppLocale;
  qrDataUrl?: string;
}) {
  return (
    <details className="group mc-map-window bg-[#fbf9f2]/75" open={defaultOpen}>
      <summary className="flex cursor-pointer list-none items-center gap-3 p-5 font-bold">
        <span className="grid size-10 place-items-center rounded-full bg-[#fff0eb] text-primary">
          <Link2 className="size-5" />
        </span>
        <span className="flex-1">
          {locale === "en" ? "Invite diners" : "邀请成员"}
        </span>
        <span className="text-sm font-normal text-muted-foreground group-open:hidden">
          {locale === "en" ? "Show QR code" : "展开二维码"}
        </span>
      </summary>
      <div className="grid gap-5 border-t p-5 sm:grid-cols-[180px_1fr] sm:items-center">
        {qrDataUrl ? (
          <div className="mx-auto rounded-2xl border bg-[#fffefb] p-2 shadow-sm">
            <Image
              alt={
                locale === "en" ? "Room invitation QR code" : "房间邀请二维码"
              }
              className="size-40"
              height={160}
              src={qrDataUrl}
              unoptimized
              width={160}
            />
          </div>
        ) : (
          <span className="mx-auto grid size-40 place-items-center rounded-2xl bg-muted text-muted-foreground">
            <QrCode className="size-10" />
          </span>
        )}
        <div>
          <div className="mb-5 border-y border-[#24322d]/12 py-4">
            <p className="mb-2 flex items-center gap-2 text-xs font-semibold text-[#6d7873]">
              <Hash aria-hidden="true" className="size-4 text-[#b9433c]" />
              {locale === "en" ? "Six-digit table code" : "六位餐桌入席码"}
            </p>
            <p className="font-mono text-3xl font-semibold tracking-[0.24em] text-[#24322d] tabular-nums">
              {joinCode}
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              {locale === "en"
                ? "Open menucrew-demo.vercel.app/join and type these digits."
                : "打开 menucrew-demo.vercel.app/join，输入这段数字。"}
            </p>
          </div>
          <p className="mb-3 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Diners can scan to join now. If the menu is not ready, they'll see a waiting message."
              : "大家可以先扫码入席。菜单还没准备好时，他们会看到等待提示。"}
          </p>
          {inviteToken ? (
            <CopyInviteButton inviteToken={inviteToken} locale={locale} />
          ) : (
            <p className="text-xs text-muted-foreground">
              {locale === "en"
                ? "The original link is unavailable in this browser, but the table code still works."
                : "原邀请链接已不在当前浏览器中，但数字入席码仍可使用。"}
            </p>
          )}
        </div>
      </div>
    </details>
  );
}
