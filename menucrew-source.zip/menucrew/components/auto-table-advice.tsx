"use client";

import { LoaderCircle, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import type { TableAdviceActionState } from "@/lib/table-advice-action-state";
import { initialTableAdviceActionState } from "@/lib/table-advice-action-state";

type Action = (
  state: TableAdviceActionState,
  formData: FormData,
) => Promise<TableAdviceActionState>;

export function AutoTableAdvice({ action }: { action: Action }) {
  const started = useRef(false);
  const router = useRouter();
  const [message, setMessage] = useState("正在整理点餐建议…");

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const formData = new FormData();
    formData.set("confirmation", "generate");
    const slowNotice = window.setTimeout(
      () =>
        setMessage("AI 仍在处理，你可以先继续核对或生成最终订单，不必等待。"),
      10_000,
    );
    action(initialTableAdviceActionState, formData)
      .then((result) => {
        window.clearTimeout(slowNotice);
        setMessage(result.message);
        router.refresh();
      })
      .catch(() => {
        window.clearTimeout(slowNotice);
        setMessage("建议暂时没有生成，不影响继续确认订单。");
      });
    return () => window.clearTimeout(slowNotice);
  }, [action, router]);

  return (
    <div className="flex items-center gap-3 rounded-xl border bg-[#fffefb] px-4 py-3 text-sm text-muted-foreground">
      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-[#eef0ff] text-primary">
        {message.startsWith("正在") ? (
          <LoaderCircle className="size-4 animate-spin" />
        ) : (
          <Sparkles className="size-4" />
        )}
      </span>
      <span>{message}</span>
    </div>
  );
}
