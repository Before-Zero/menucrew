import { ShieldAlert } from "lucide-react";
import type { AppLocale } from "@/lib/i18n";
import type { FinalOrderDietaryNote } from "@/lib/orders";

export function FinalOrderDietaryNotes({
  compact = false,
  locale = "zh-CN",
  notes,
  restaurantMode = false,
  translating = false,
}: {
  compact?: boolean;
  locale?: AppLocale;
  notes: FinalOrderDietaryNote[];
  restaurantMode?: boolean;
  translating?: boolean;
}) {
  if (!notes.length) return null;
  const englishLabels = restaurantMode || locale === "en";

  return (
    <section
      className={`mc-order-dietary-notes border-y border-[#9a5e0b]/35 bg-[#fff5e5]/72 ${compact ? "p-4" : "p-5 sm:p-6"}`}
    >
      <div className="flex items-start gap-3">
        <ShieldAlert
          aria-hidden="true"
          className="mt-0.5 size-5 shrink-0 text-[#9a5e0b]"
        />
        <div className="min-w-0 flex-1">
          <h2 className="font-black text-[#5f410e]">
            {englishLabels ? "Dietary & allergy notes" : "本桌忌口与过敏信息"}
          </h2>
          <p className="mt-1 text-xs leading-5 text-[#715d38]">
            {englishLabels
              ? "Read these notes to the restaurant and confirm ingredients directly."
              : "请将以下内容一并告知餐厅，并当面确认食材和过敏原。"}
          </p>
          {translating ? (
            <p
              aria-live="polite"
              className="mt-2 text-xs font-semibold text-[#9a5e0b]"
            >
              {locale === "en"
                ? "Preparing the bilingual restaurant wording…"
                : "正在补齐餐厅英文与中文核对译文…"}
            </p>
          ) : null}
          <ul className="mt-4 grid gap-3">
            {notes.map((note, index) => (
              <li
                className="grid gap-2 border-t border-dashed border-[#9a5e0b]/25 pt-3 sm:grid-cols-[8rem_minmax(0,1fr)]"
                key={`${note.displayName}-${index}`}
              >
                <strong className="break-words text-sm">
                  {note.displayName}
                </strong>
                <div className="grid gap-1 text-sm leading-6 text-[#493e2b]">
                  {note.allergyInfo ? (
                    <p>
                      <span className="font-bold text-[#9a3e22]">
                        {englishLabels ? "Allergy" : "过敏"}：
                      </span>
                      {restaurantMode
                        ? note.allergyEn || note.allergyInfo
                        : note.allergyZh || note.allergyInfo}
                    </p>
                  ) : null}
                  {note.dietaryRestrictions ? (
                    <p>
                      <span className="font-bold">
                        {englishLabels ? "Dietary note" : "忌口"}：
                      </span>
                      {restaurantMode
                        ? note.dietaryEn || note.dietaryRestrictions
                        : note.dietaryZh || note.dietaryRestrictions}
                    </p>
                  ) : null}
                  {(restaurantMode &&
                    ((note.allergyEn && note.allergyEn !== note.allergyInfo) ||
                      (note.dietaryEn &&
                        note.dietaryEn !== note.dietaryRestrictions))) ||
                  (!restaurantMode &&
                    ((note.allergyZh && note.allergyZh !== note.allergyInfo) ||
                      (note.dietaryZh &&
                        note.dietaryZh !== note.dietaryRestrictions))) ? (
                    <p className="mt-1 break-words text-xs text-[#715d38]">
                      {restaurantMode ? "Original" : "原文"}：
                      {[note.allergyInfo, note.dietaryRestrictions]
                        .filter(Boolean)
                        .join("；")}
                    </p>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
