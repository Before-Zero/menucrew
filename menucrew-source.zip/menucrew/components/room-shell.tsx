import { UserRound } from "lucide-react";
import Link from "next/link";
import type { ReactNode } from "react";
import { DiningRouteMap } from "@/components/dining-route-map";
import { LanguageSwitcher } from "@/components/language-switcher";
import { MenuCrewMark } from "@/components/menu-crew-mark";
import { RoomAmbientWords } from "@/components/room-ambient-words";
import { RoomJourneyNav } from "@/components/room-journey-nav";
import { RoomRealtimeRefresh } from "@/components/room-realtime-refresh";
import type { AppLocale } from "@/lib/i18n";
import type { RoomJourney } from "@/lib/room-journey";

type RoomShellProps = {
  activeControl?: number;
  aside?: ReactNode;
  children: ReactNode;
  description: string;
  eyebrow: string;
  journey?: RoomJourney;
  locale?: AppLocale;
  roomId?: string;
  title: string;
  wide?: boolean;
};

function shellTone() {
  return {
    background: "bg-[#f4f1e8]",
    foreground: "text-[#24322d]",
  };
}

function routeControlFor(
  eyebrow: string,
  title: string,
  journey?: RoomJourney,
) {
  const surface = `${eyebrow} ${title}`;
  if (/订单|落单|完成/.test(surface) || journey?.stage === "completed")
    return 7;
  if (/汇总|本桌点单|核对/.test(surface)) return 6;
  if (/选择|想吃/.test(surface)) return 5;
  if (/菜单/.test(surface)) return journey?.stage === "collecting" ? 4 : 2;
  if (journey?.stage === "collecting") return 5;
  return 1;
}

function roleFromEyebrow(eyebrow: string) {
  if (/组织者|发起人/.test(eyebrow)) return "发起人";
  if (/成员|参与者|我的/.test(eyebrow)) return "参与者";
  return "房间成员";
}

function localizedRole(eyebrow: string, locale: AppLocale) {
  const role = roleFromEyebrow(eyebrow);
  if (locale !== "en") return role;
  if (role === "发起人") return "Organizer";
  if (role === "参与者") return "Diner";
  return "Table member";
}

function localizedStage(stage: string, locale: AppLocale) {
  if (locale !== "en") return stage;
  if (stage === "准备中") return "Preparing";
  if (stage === "点餐中") return "Ordering";
  if (stage === "已完成") return "Complete";
  return stage;
}

function primaryStepFor(control: number) {
  if (control >= 6) return 3;
  if (control === 5) return 2;
  return 1;
}

export function RoomShell({
  activeControl: activeControlOverride,
  aside,
  children,
  description,
  eyebrow,
  journey,
  locale = "zh-CN",
  roomId,
  title,
  wide = false,
}: RoomShellProps) {
  const tone = shellTone();
  const activeControl =
    activeControlOverride ?? routeControlFor(eyebrow, title, journey);

  return (
    <main
      className={`mc-room-page relative min-h-svh overflow-hidden ${tone.background} ${tone.foreground}`}
      data-journey-step={primaryStepFor(activeControl)}
    >
      {roomId ? <RoomRealtimeRefresh roomId={roomId} /> : null}
      <DiningRouteMap activeControl={activeControl} layout="spine" />
      <RoomAmbientWords />

      <header className="relative z-20 border-b border-[#24322d]/12 bg-[#f4f1e8]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-16 w-full max-w-[1248px] items-center justify-between gap-4 px-4 sm:h-[72px] sm:px-6">
          <Link
            className="group flex min-w-0 items-center gap-2.5 rounded-xl outline-none focus-visible:ring-3 focus-visible:ring-primary/25 sm:gap-3"
            href={roomId ? `/rooms/${roomId}` : "/"}
          >
            <MenuCrewMark className="size-8 text-[#b9433c] sm:size-[34px]" />
            <span className="hidden text-sm font-semibold tracking-[-0.02em] sm:block">
              合点 Menu Crew
            </span>
            {roomId ? (
              <>
                <span className="hidden h-5 w-px bg-[#24322d]/20 sm:block" />
                <span className="max-w-32 truncate text-xs text-muted-foreground sm:max-w-44 sm:text-sm">
                  {title}
                </span>
              </>
            ) : null}
          </Link>

          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              aria-label={locale === "en" ? "My tables" : "我的餐桌"}
              className="grid size-9 place-items-center rounded-full text-[#52615b] transition hover:bg-[#24322d]/6 hover:text-[#b9433c] focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[#b9433c]/20"
              href="/account"
            >
              <UserRound aria-hidden="true" className="size-[18px]" />
            </Link>
            {roomId ? (
              <span className="hidden border border-[#24322d]/15 px-2.5 py-1.5 text-xs font-semibold text-[#24322d] md:inline-flex">
                {localizedRole(eyebrow, locale)}
              </span>
            ) : null}
            {journey ? (
              <span className="hidden bg-[#b9433c] px-2.5 py-1.5 text-xs font-semibold text-white sm:inline-flex">
                {localizedStage(journey.stageLabel, locale)}
              </span>
            ) : null}
            <LanguageSwitcher locale={locale} />
          </div>
        </div>
        {journey ? <RoomJourneyNav journey={journey} locale={locale} /> : null}
      </header>

      <div
        className={`mc-page-enter relative z-10 mx-auto grid w-full max-w-[1248px] gap-7 px-4 pb-24 pt-8 sm:px-6 sm:pt-10 ${wide ? "" : "lg:grid-cols-[minmax(0,0.72fr)_minmax(560px,1.28fr)] lg:items-start lg:gap-14 lg:pt-12"}`}
      >
        <section className="min-w-0">
          <div className="mc-control-heading">
            <span
              aria-hidden="true"
              data-mc-active-control
              data-mc-transition-target
            >
              {primaryStepFor(activeControl)}
            </span>
            <div>
              <p>{eyebrow}</p>
              <h1>{title}</h1>
            </div>
          </div>
          <p className="mt-4 max-w-2xl text-pretty text-sm leading-6 text-muted-foreground sm:ml-[4.65rem] sm:text-base sm:leading-7">
            {description}
          </p>
          {aside ? (
            <div className="mt-6 sm:ml-[4.65rem] sm:mt-8">{aside}</div>
          ) : null}
        </section>

        <section className="min-w-0">
          <div
            className={`mc-paper-enter mc-work-surface ${wide ? "" : "mc-work-surface-contained"}`}
          >
            {children}
          </div>
        </section>
      </div>
    </main>
  );
}
