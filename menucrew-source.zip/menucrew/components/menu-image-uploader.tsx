"use client";

import {
  AlertTriangle,
  CheckCircle2,
  ImagePlus,
  LoaderCircle,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { MenuAiActionState } from "@/lib/menu-ai-action-state";
import { initialMenuAiActionState } from "@/lib/menu-ai-action-state";
import type { MenuImage } from "@/lib/menus";
import { createClient } from "@/lib/supabase/client";
import {
  MENU_IMAGE_MAX_BYTES,
  MENU_IMAGE_MAX_COUNT,
  MENU_IMAGE_MIME_TYPES,
  validateMenuImage,
} from "@/lib/validation";

type Props = {
  images: MenuImage[];
  locale?: AppLocale;
  recognitionStatus?: "failed" | "idle" | "processing" | "succeeded";
  recognizeAction: (
    state: MenuAiActionState,
    formData: FormData,
  ) => Promise<MenuAiActionState>;
  roomId: string;
};
type SelectedImage = { file: File; previewUrl: string };

export function MenuImageUploader({
  images,
  locale = "zh-CN",
  recognitionStatus = "idle",
  recognizeAction,
  roomId,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [selected, setSelected] = useState<SelectedImage[]>([]);
  const developing = busy || recognitionStatus === "processing";
  const activeImage = selected[0]?.previewUrl ?? images[0]?.previewUrl;
  const activeName = selected[0]?.file.name ?? images[0]?.original_name;

  useEffect(
    () => () => {
      for (const image of selected) URL.revokeObjectURL(image.previewUrl);
    },
    [selected],
  );

  function selectFiles(files: FileList | null) {
    if (!files?.length) return;
    const chosen = Array.from(files);
    if (images.length + chosen.length > MENU_IMAGE_MAX_COUNT) {
      setMessage(
        locale === "en"
          ? `You can upload ${MENU_IMAGE_MAX_COUNT - images.length} more images.`
          : `还可以上传 ${MENU_IMAGE_MAX_COUNT - images.length} 张图片。`,
      );
      return;
    }
    const invalid = chosen.map(validateMenuImage).find(Boolean);
    if (invalid) {
      setMessage(invalid);
      return;
    }
    setSelected(
      chosen.map((file) => ({ file, previewUrl: URL.createObjectURL(file) })),
    );
    setMessage(
      locale === "en"
        ? `${chosen.length} images selected. Review the preview before uploading.`
        : `已选择 ${chosen.length} 张，确认预览后再上传。`,
    );
  }

  async function upload() {
    if (!selected.length) return;

    setBusy(true);
    setMessage("");
    const supabase = createClient();
    let completed = 0;

    for (const { file } of selected) {
      try {
        const reservation = await fetch(`/api/rooms/${roomId}/menu-images`, {
          body: JSON.stringify({
            byteSize: file.size,
            mimeType: file.type,
            originalName: file.name,
          }),
          headers: { "content-type": "application/json" },
          method: "POST",
        });
        const reserved = (await reservation.json()) as {
          message?: string;
          path?: string;
          token?: string;
        };
        if (!reservation.ok || !reserved.path || !reserved.token)
          throw new Error(
            reserved.message ??
              (locale === "en" ? "Could not start upload." : "无法开始上传。"),
          );

        const { error: uploadError } = await supabase.storage
          .from("menu-images")
          .uploadToSignedUrl(reserved.path, reserved.token, file, {
            contentType: file.type,
          });
        if (uploadError) throw uploadError;

        const finalize = await fetch(`/api/rooms/${roomId}/menu-images`, {
          body: JSON.stringify({
            byteSize: file.size,
            mimeType: file.type,
            originalName: file.name,
            storagePath: reserved.path,
          }),
          headers: { "content-type": "application/json" },
          method: "PUT",
        });
        const finalized = (await finalize.json()) as { message?: string };
        if (!finalize.ok)
          throw new Error(
            finalized.message ??
              (locale === "en" ? "Could not save image." : "无法保存图片。"),
          );
        completed += 1;
      } catch (error) {
        setMessage(
          `${completed ? (locale === "en" ? `${completed} uploaded; ` : `已上传 ${completed} 张；`) : ""}${error instanceof Error ? error.message : locale === "en" ? "Upload failed. Try again." : "上传失败，请重试。"}`,
        );
        break;
      }
    }

    if (completed === selected.length) {
      setMessage(
        locale === "en"
          ? `${completed} images uploaded. Recognizing the menu…`
          : `已上传 ${completed} 张图片，正在自动识别菜单…`,
      );
      const formData = new FormData();
      formData.set("confirmation", "recognize");
      try {
        const recognition = await recognizeAction(
          initialMenuAiActionState,
          formData,
        );
        setMessage(recognition.message);
      } catch {
        setMessage(
          locale === "en"
            ? "Images are saved, but recognition did not finish. Try again later or edit manually."
            : "图片已保存，自动识别暂时未完成。你可以稍后重试或手动修改。",
        );
      }
    }
    setSelected([]);
    if (inputRef.current) inputRef.current.value = "";
    setBusy(false);
    router.refresh();
  }

  async function remove(imageId: string) {
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(
        `/api/rooms/${roomId}/menu-images/${imageId}`,
        { method: "DELETE" },
      );
      const body = (await response.json()) as { message?: string };
      setMessage(
        response.ok
          ? locale === "en"
            ? "Image removed."
            : "图片已移除。"
          : (body.message ??
              (locale === "en"
                ? "Could not remove image."
                : "暂时无法移除图片。")),
      );
      if (response.ok) router.refresh();
    } catch {
      setMessage(
        locale === "en"
          ? "The connection was interrupted. The image is still safe; try again later."
          : "网络连接中断了，图片仍然保留，可以稍后重试。",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section
      aria-labelledby="menu-images-heading"
      aria-busy={developing}
      className={`mc-developing-desk ${developing ? "is-developing" : ""} ${recognitionStatus === "succeeded" ? "is-complete" : ""} ${recognitionStatus === "failed" ? "is-failed" : ""}`}
    >
      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="mc-desk-caption">
            {locale === "en"
              ? "Menu source · Recognition desk"
              : "菜单显影台 · Menu source"}
          </p>
          <h2 className="mt-2 text-lg font-bold" id="menu-images-heading">
            {developing
              ? locale === "en"
                ? "Developing the menu"
                : "正在显影菜单"
              : recognitionStatus === "succeeded"
                ? locale === "en"
                  ? "Menu photos are ready"
                  : "菜单照片已就位"
                : recognitionStatus === "failed"
                  ? locale === "en"
                    ? "Photos preserved for retry"
                    : "照片保留，等待重试"
                  : activeImage
                    ? locale === "en"
                      ? "Review this menu photo"
                      : "核对这张菜单照片"
                    : locale === "en"
                      ? "Add a menu photo"
                      : "放入一张菜单照片"}
          </h2>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Organizer only. Recognition starts automatically after upload."
              : "仅组织者可见；上传完成后会自动识别菜单。"}
          </p>
        </div>
        <span className="font-mono text-xs text-muted-foreground">
          {images.length} / {MENU_IMAGE_MAX_COUNT}
        </span>
      </div>

      <div
        className="mc-developing-stage"
        data-state={developing ? "processing" : recognitionStatus}
      >
        {activeImage ? (
          <figure className="mc-developing-photo">
            {selected[0] ? (
              <>
                {/* Blob previews only exist in this browser before upload. */}
                {/* biome-ignore lint/performance/noImgElement: Next Image cannot optimize ephemeral blob URLs. */}
                <img
                  alt={`${locale === "en" ? "Pending upload" : "待上传"}：${activeName}`}
                  src={activeImage}
                />
              </>
            ) : (
              <Image
                alt={`${locale === "en" ? "Original menu image" : "菜单原图"}：${activeName}`}
                fill
                sizes="(max-width: 1024px) 100vw, 480px"
                src={activeImage}
                unoptimized
              />
            )}
            <span className="mc-developing-scan" />
            {developing ? (
              <span aria-hidden="true" className="mc-ink-route-loader">
                <i />
                <i />
                <i />
              </span>
            ) : null}
            <span className="mc-viewfinder is-top-left" />
            <span className="mc-viewfinder is-bottom-right" />
            {recognitionStatus === "succeeded" ? (
              <span className="mc-photo-state">
                <CheckCircle2 aria-hidden="true" />{" "}
                {locale === "en" ? "Recognized" : "已识别"}
              </span>
            ) : null}
          </figure>
        ) : (
          <button
            className="mc-upload-zone"
            disabled={busy || images.length >= MENU_IMAGE_MAX_COUNT}
            onClick={() => inputRef.current?.click()}
            type="button"
          >
            <span className="mc-menu-paper" aria-hidden="true">
              <i />
              <i />
              <i />
            </span>
            <span className="grid size-11 place-items-center rounded-full bg-[#b9433c] text-white">
              <ImagePlus aria-hidden="true" />
            </span>
            <strong>
              {locale === "en" ? "Choose menu photos" : "选择菜单照片"}
            </strong>
            <small>
              {locale === "en"
                ? "Take photos or choose from your library. Diners never see the originals."
                : "支持拍照或从相册选择，原图不会展示给成员"}
            </small>
          </button>
        )}
      </div>

      {activeImage ? (
        <div className="mc-photo-meta">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{activeName}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {selected.length
                ? locale === "en"
                  ? "Preview before upload"
                  : "上传前预览"
                : locale === "en"
                  ? "Original menu image saved privately"
                  : "已安全保存的菜单原图"}
            </p>
          </div>
          {selected.length ? (
            <Button
              aria-label={
                locale === "en" ? "Clear selected images" : "清除已选择图片"
              }
              disabled={busy}
              onClick={() => setSelected([])}
              size="icon-sm"
              type="button"
              variant="ghost"
            >
              <X aria-hidden="true" />
            </Button>
          ) : null}
        </div>
      ) : null}

      {images.length > 1 ? (
        <fieldset className="mc-photo-strip">
          <legend className="sr-only">
            {locale === "en" ? "Other original menu images" : "其余菜单原图"}
          </legend>
          {images.map((image, index) => (
            <figure key={image.id}>
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  alt={`${locale === "en" ? "Original menu image" : "菜单原图"} ${index + 1}：${image.original_name}`}
                  className="object-cover"
                  fill
                  sizes="112px"
                  src={image.previewUrl}
                  unoptimized
                />
              </div>
              <Button
                aria-label={`${locale === "en" ? "Remove" : "移除"} ${image.original_name}`}
                disabled={busy}
                onClick={() => remove(image.id)}
                size="icon-sm"
                type="button"
                variant="ghost"
              >
                <Trash2 aria-hidden="true" />
              </Button>
            </figure>
          ))}
        </fieldset>
      ) : images.length === 1 && !selected.length ? (
        <Button
          className="mc-remove-photo"
          disabled={busy}
          onClick={() => remove(images[0].id)}
          size="sm"
          type="button"
          variant="ghost"
        >
          <Trash2 aria-hidden="true" />
          {locale === "en" ? "Remove this photo" : "移除这张照片"}
        </Button>
      ) : null}

      {developing ? (
        <div className="mc-recognition-steps" aria-live="polite">
          <p className="is-current">
            <span />
            {locale === "en" ? "Reading menu text" : "读取菜单文字"}
          </p>
          <p>
            <span />
            {locale === "en" ? "Organizing bilingual dishes" : "整理双语菜名"}
          </p>
          <p>
            <span />
            {locale === "en" ? "Waiting for your review" : "等待人工核对"}
          </p>
        </div>
      ) : null}

      {recognitionStatus === "failed" && !developing ? (
        <p className="mc-desk-note is-error">
          <AlertTriangle aria-hidden="true" />
          {locale === "en"
            ? "Original images are safe. Retry on the right or open manual editing."
            : "原图没有丢失。请在右侧重试，或展开人工修改入口。"}
        </p>
      ) : null}

      <input
        accept={MENU_IMAGE_MIME_TYPES.join(",")}
        className="sr-only"
        disabled={busy || images.length >= MENU_IMAGE_MAX_COUNT}
        id="menu-images-input"
        multiple
        onChange={(event) => selectFiles(event.currentTarget.files)}
        ref={inputRef}
        type="file"
      />
      <div className="mt-5 grid gap-2 sm:grid-cols-2">
        <Button
          className="h-11 rounded-xl"
          disabled={busy || images.length >= MENU_IMAGE_MAX_COUNT}
          onClick={() => inputRef.current?.click()}
          type="button"
          variant="outline"
        >
          <ImagePlus aria-hidden="true" />
          {selected.length
            ? locale === "en"
              ? "Choose again"
              : "重新选择"
            : images.length >= MENU_IMAGE_MAX_COUNT
              ? locale === "en"
                ? "4-image limit reached"
                : "已达到 4 张上限"
              : locale === "en"
                ? "Choose menu images"
                : "选择菜单图片"}
        </Button>
        <Button
          className="h-11 rounded-xl"
          disabled={busy || !selected.length}
          onClick={upload}
          type="button"
        >
          {busy ? (
            <LoaderCircle aria-hidden="true" className="animate-spin" />
          ) : (
            <UploadCloud aria-hidden="true" />
          )}
          {busy
            ? locale === "en"
              ? "Processing images"
              : "正在处理图片"
            : selected.length
              ? locale === "en"
                ? `Upload ${selected.length}`
                : `上传 ${selected.length} 张`
              : locale === "en"
                ? "Waiting for selection"
                : "等待选择"}
        </Button>
      </div>
      <p className="mt-3 text-xs leading-5 text-muted-foreground">
        {locale === "en"
          ? "JPEG, PNG or WebP; up to"
          : "JPEG、PNG 或 WebP；单张不超过"}{" "}
        {MENU_IMAGE_MAX_BYTES / 1024 / 1024} MB
        {locale === "en" ? " each." : "。"}
      </p>
      {message ? (
        <p aria-live="polite" className="mc-desk-note mt-4">
          {message}
        </p>
      ) : null}
    </section>
  );
}
