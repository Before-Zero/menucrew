"use client";

import {
  CheckCircle2,
  Languages,
  MessageSquareText,
  Store,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import type { FinalDietaryTranslationResult } from "@/app/rooms/[roomId]/summary/final-translation-actions";
import { CopyOrderText } from "@/components/copy-order-text";
import { FinalOrderDietaryNotes } from "@/components/final-order-dietary-notes";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { FinalOrder } from "@/lib/orders";

type ViewMode = "restaurant" | "chinese";

function formatConfirmedAt(value: string) {
  return `${new Date(value).toLocaleString("zh-CN", { timeZone: "UTC" })} UTC`;
}

function orderText(data: FinalOrder, mode: ViewMode) {
  const lines = [
    mode === "restaurant"
      ? `${data.access.room.name} · FINAL ORDER`
      : `${data.access.room.name} · 中文核对清单`,
    mode === "restaurant"
      ? `Confirmed: ${formatConfirmedAt(data.order.confirmed_at)}`
      : `确认时间：${formatConfirmedAt(data.order.confirmed_at)}`,
    "",
  ];
  if (data.order.dietary_notes.length) {
    lines.push(
      mode === "restaurant" ? "DIETARY & ALLERGY NOTES" : "忌口与过敏信息",
    );
    data.order.dietary_notes.forEach((note) => {
      lines.push(`- ${note.displayName}`);
      if (note.allergyInfo)
        lines.push(
          mode === "restaurant"
            ? `  Allergy: ${note.allergyEn || note.allergyInfo}`
            : `  过敏：${note.allergyZh || note.allergyInfo}`,
        );
      if (note.dietaryRestrictions)
        lines.push(
          mode === "restaurant"
            ? `  Dietary note: ${note.dietaryEn || note.dietaryRestrictions}`
            : `  忌口：${note.dietaryZh || note.dietaryRestrictions}`,
        );
      const translated =
        mode === "restaurant"
          ? note.allergyEn || note.dietaryEn
          : note.allergyZh || note.dietaryZh;
      if (translated)
        lines.push(
          mode === "restaurant"
            ? `  Original: ${[note.allergyInfo, note.dietaryRestrictions].filter(Boolean).join("; ")}`
            : `  原文：${[note.allergyInfo, note.dietaryRestrictions].filter(Boolean).join("；")}`,
        );
    });
    lines.push("");
  }
  data.items.forEach((item, index) => {
    const restaurantName = item.original_name || item.en_name || item.zh_name;
    const chineseName = item.zh_name || item.original_name || item.en_name;
    lines.push(
      mode === "restaurant"
        ? `${index + 1}. ${restaurantName} × ${item.final_quantity}`
        : `${index + 1}. ${chineseName} × ${item.final_quantity}`,
    );
    if (
      mode === "restaurant" &&
      item.en_name &&
      item.en_name !== restaurantName
    )
      lines.push(`   ${item.en_name}`);
    if (
      mode === "chinese" &&
      item.original_name &&
      item.original_name !== chineseName
    )
      lines.push(`   菜单原文：${item.original_name}`);
    if (item.note)
      lines.push(
        mode === "restaurant"
          ? `   Note: ${item.note}`
          : `   餐厅备注：${item.note}`,
      );
  });
  return lines.join("\n");
}

export function FinalOrderView({
  data,
  locale = "zh-CN",
  translationAction,
}: {
  data: FinalOrder;
  locale?: AppLocale;
  translationAction?: () => Promise<FinalDietaryTranslationResult>;
}) {
  const [mode, setMode] = useState<ViewMode>("restaurant");
  const [translating, setTranslating] = useState(false);
  const translationStarted = useRef(false);
  const router = useRouter();
  const total = data.items.reduce((sum, item) => sum + item.final_quantity, 0);
  const restaurantMode = mode === "restaurant";
  const needsTranslation = data.order.dietary_notes.some(
    (note) =>
      (note.allergyInfo && !(note.allergyEn && note.allergyZh)) ||
      (note.dietaryRestrictions && !(note.dietaryEn && note.dietaryZh)),
  );

  useEffect(() => {
    if (!translationAction || !needsTranslation || translationStarted.current)
      return;
    translationStarted.current = true;
    setTranslating(true);
    translationAction()
      .then((result) => {
        if (result.status === "updated") router.refresh();
        else setTranslating(false);
      })
      .catch(() => setTranslating(false));
  }, [needsTranslation, router, translationAction]);

  return (
    <div className="mx-auto max-w-3xl">
      <div aria-hidden="true" className="mc-receipt-convergence">
        <span />
        <span />
        <span />
        <strong>
          {locale === "en" ? "Table choices combined" : "同桌选择已汇合"}
        </strong>
      </div>
      <div className="mc-receipt-view-switch mb-5 grid grid-cols-2 border-b border-[#24322d]/20 p-1">
        <Button
          aria-pressed={restaurantMode}
          className="rounded-none"
          onClick={() => setMode("restaurant")}
          type="button"
          variant={restaurantMode ? "default" : "ghost"}
        >
          <Store /> {locale === "en" ? "Show restaurant" : "给餐厅看"}
        </Button>
        <Button
          aria-pressed={!restaurantMode}
          className="rounded-none"
          onClick={() => setMode("chinese")}
          type="button"
          variant={!restaurantMode ? "default" : "ghost"}
        >
          <Languages /> {locale === "en" ? "Chinese check" : "中文核对"}
        </Button>
      </div>

      <article className="mc-final-receipt relative overflow-hidden border border-[#24322d]/25 bg-[#fffdf9] shadow-[0_24px_60px_rgb(36_50_45_/_0.13)]">
        <span aria-hidden="true" className="mc-receipt-stamp">
          TABLE COMPLETE
        </span>
        <div className="border-b border-dashed border-[#d8d7d2] p-6 text-center sm:p-8">
          <span className="inline-flex items-center gap-2 rounded-full bg-[#dff5e8] px-3 py-1.5 text-xs font-bold text-[#146b45]">
            <CheckCircle2 className="size-4" />
            {locale === "en" ? "Confirmed · Read only" : "已确认 · 不可修改"}
          </span>
          <p className="mt-5 font-mono text-xs tracking-[0.16em] text-muted-foreground uppercase">
            {restaurantMode ? "Restaurant order" : "Chinese checklist"}
          </p>
          <h2 className="mt-2 text-3xl font-black">
            {restaurantMode
              ? locale === "en"
                ? "Final order"
                : "请向餐厅点这些"
              : "中文核对清单"}
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {restaurantMode
              ? locale === "en"
                ? "Only dish names, quantities and restaurant notes are shown."
                : "只保留菜名、数量和需要告诉餐厅的备注。"
              : "中文为主，菜单原文用于和餐厅菜单对应。"}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            {formatConfirmedAt(data.order.confirmed_at)}
          </p>
        </div>

        <FinalOrderDietaryNotes
          compact
          locale={locale}
          notes={data.order.dietary_notes}
          restaurantMode={restaurantMode}
          translating={translating}
        />

        <ol className="divide-y divide-dashed divide-[#d8d7d2] px-5 sm:px-8">
          {data.items.map((item, index) => {
            const primaryName = restaurantMode
              ? item.original_name || item.en_name || item.zh_name
              : item.zh_name || item.original_name || item.en_name;
            const secondaryName = restaurantMode
              ? item.en_name && item.en_name !== primaryName
                ? item.en_name
                : ""
              : item.original_name && item.original_name !== primaryName
                ? item.original_name
                : "";
            return (
              <li
                className="grid gap-4 py-6 sm:grid-cols-[minmax(0,1fr)_6rem] sm:items-start"
                key={item.id}
              >
                <div className="min-w-0">
                  <p className="font-mono text-xs tracking-[0.12em] text-primary uppercase">
                    Item {String(index + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 break-words text-xl font-black">
                    {primaryName}
                  </h3>
                  {secondaryName ? (
                    <p className="mt-1 break-words text-sm font-semibold text-primary">
                      {restaurantMode
                        ? secondaryName
                        : `菜单原文：${secondaryName}`}
                    </p>
                  ) : null}
                  {item.note ? (
                    <p className="mt-3 flex items-start gap-2 break-words rounded-lg bg-[#fff5e5] px-3 py-2 text-sm leading-6 text-[#7a4b0b]">
                      <MessageSquareText className="mt-1 size-4 shrink-0" />
                      {restaurantMode ? "Note" : "餐厅备注"}：{item.note}
                    </p>
                  ) : null}
                </div>
                <div className="mc-order-ticket border border-[#b9433c]/35 bg-[#b9433c] p-4 text-white sm:text-center">
                  <p className="font-mono text-xs tracking-[0.12em] text-white/75 uppercase">
                    {restaurantMode ? "Order qty" : "数量"}
                  </p>
                  <p className="mt-1 font-mono text-4xl font-black tabular-nums">
                    {item.final_quantity}
                  </p>
                  <p className="mt-1 text-xs text-white/70">
                    {restaurantMode ? "servings" : "份"}
                  </p>
                </div>
              </li>
            );
          })}
        </ol>

        <footer className="border-t border-dashed border-[#d8d7d2] p-6 sm:p-8">
          <div className="mb-5 flex items-end justify-between gap-4">
            <p className="font-bold">
              {restaurantMode
                ? `${data.items.length} dishes`
                : `共 ${data.items.length} 道菜`}
            </p>
            <p className="font-mono text-3xl font-black tabular-nums">
              {total} {restaurantMode ? "servings" : "份"}
            </p>
          </div>
          <CopyOrderText locale={locale} text={orderText(data, mode)} />
        </footer>
      </article>
    </div>
  );
}
