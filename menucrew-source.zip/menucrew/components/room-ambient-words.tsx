"use client";

import { usePathname } from "next/navigation";
import type { CSSProperties } from "react";

type Phrase = readonly [string, string, string, string, string, string];

const phraseLayouts = [
  ["3%", "17%", "2.8rem", "34s", "-8s"],
  ["77%", "12%", "2.3rem", "39s", "-19s"],
  ["-2%", "43%", "2.55rem", "43s", "-13s"],
  ["80%", "47%", "2.2rem", "37s", "-4s"],
  ["5%", "72%", "1.2rem", "41s", "-23s"],
  ["71%", "77%", "2.35rem", "45s", "-16s"],
  ["25%", "91%", "1.45rem", "40s", "-11s"],
  ["84%", "91%", "1.05rem", "36s", "-25s"],
] as const;

const stagePhrases = {
  menu: [
    "看懂这张菜单",
    "Lire le menu",
    "メニューを読む",
    "Leer el menú",
    "What shall we share?",
    "메뉴를 읽어요",
    "慢慢显影",
    "Leggere il menu",
  ],
  order: [
    "一起确认这桌",
    "À table",
    "注文を確認",
    "Compartir la mesa",
    "One table, one order",
    "함께 주문해요",
    "准备开饭",
    "Il conto è pronto",
  ],
  room: [
    "好好吃饭",
    "Bon appétit",
    "いただきます",
    "Buen provecho",
    "Share the table",
    "맛있게 드세요",
    "慢慢品尝",
    "Buon appetito",
  ],
  selection: [
    "这次，我想吃这些",
    "Je prends celui-ci",
    "これをください",
    "Quiero probarlo",
    "Save me a bite",
    "이걸 먹고 싶어요",
    "来一份",
    "Lo vorrei",
  ],
} as const;

function stageForPath(pathname: string) {
  if (/\/(?:summary|order|receipt)(?:\/|$)/.test(pathname)) return "order";
  if (/\/selection(?:\/|$)/.test(pathname)) return "selection";
  if (/\/menu(?:\/|$)/.test(pathname)) return "menu";
  return "room";
}

export function RoomAmbientWords() {
  const stage = stageForPath(usePathname());
  const phrases: Phrase[] = stagePhrases[stage].map((phrase, index) => [
    phrase,
    ...phraseLayouts[index],
  ]);

  return (
    <div aria-hidden="true" className="mc-room-ambient" data-stage={stage}>
      {phrases.map(([phrase, left, top, size, duration, delay]) => (
        <span
          key={`${stage}-${phrase}`}
          style={
            {
              "--mc-word-delay": delay,
              "--mc-word-duration": duration,
              "--mc-word-left": left,
              "--mc-word-size": size,
              "--mc-word-top": top,
            } as CSSProperties
          }
        >
          {phrase}
        </span>
      ))}
    </div>
  );
}
