"use client";

import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  RefreshCw,
  Sparkles,
  WandSparkles,
} from "lucide-react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { MenuAiRun } from "@/lib/menu-ai";
import type { MenuAiActionState } from "@/lib/menu-ai-action-state";
import { initialMenuAiActionState } from "@/lib/menu-ai-action-state";

type Action = (
  state: MenuAiActionState,
  formData: FormData,
) => Promise<MenuAiActionState>;

function SubmitButton({
  children,
  pendingLabel,
  prominent = false,
  variant = "default",
}: {
  children: React.ReactNode;
  pendingLabel: string;
  prominent?: boolean;
  variant?: "default" | "outline";
}) {
  const { pending } = useFormStatus();
  return (
    <Button
      className={
        prominent ? "h-14 w-full rounded-xl text-base" : "w-full sm:w-auto"
      }
      disabled={pending}
      type="submit"
      variant={variant}
    >
      {pending ? <RefreshCw className="animate-spin" /> : null}
      {pending ? pendingLabel : children}
    </Button>
  );
}

function ActionFeedback({ state }: { state: MenuAiActionState }) {
  if (state.status === "idle" || !state.message) return null;
  return (
    <output
      className={`mt-3 rounded-xl px-4 py-3 text-sm leading-6 ${
        state.status === "success"
          ? "bg-[#e7f7ee] text-[#176b48]"
          : "bg-[#fff1eb] text-[#9a3e22]"
      }`}
    >
      {state.message}
    </output>
  );
}

export function MenuAiPanel({
  applyAction,
  imageCount,
  itemCount,
  locale = "zh-CN",
  recognizeAction,
  run,
}: {
  applyAction: Action | null;
  imageCount: number;
  itemCount: number;
  locale?: AppLocale;
  recognizeAction: Action;
  run: MenuAiRun | null;
}) {
  const [recognizeState, recognizeFormAction] = useActionState(
    recognizeAction,
    initialMenuAiActionState,
  );
  const [applyState, applyFormAction] = useActionState(
    applyAction ?? recognizeAction,
    initialMenuAiActionState,
  );
  const succeeded = run?.status === "succeeded" && run.result;
  const processing = run?.status === "processing";

  return (
    <section
      className={`mc-ai-field mc-ai-console ${processing ? "is-processing" : ""}`}
    >
      <div className="mc-ai-console-head">
        <div className="mc-ai-stage-mark" aria-hidden="true">
          <span>03</span>
          <WandSparkles className="size-4" />
        </div>
        <div className="min-w-0">
          <p className="text-[11px] font-bold tracking-[0.14em] text-primary uppercase">
            AI transcription
          </p>
          <h2 className="mt-2 text-balance text-xl font-black tracking-[-0.03em] sm:text-2xl">
            {locale === "en"
              ? "Turn photos into a bilingual menu you can review"
              : "把照片整理成可核对的双语菜单"}
          </h2>
          <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">
            {locale === "en"
              ? "Recognition creates a private draft. Diners see it only after you confirm."
              : "识别只生成私有候选；你确认无误后，成员才会看到菜单。"}
          </p>
        </div>
      </div>

      <div className="mc-ai-console-body space-y-5">
        {!run ? (
          <div className="mc-ai-status" data-state="waiting">
            <span className="mc-ai-status-dot" />
            <div>
              <p className="font-semibold">
                {locale === "en" ? "Waiting for menu photos" : "等待菜单照片"}
              </p>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">
                {locale === "en"
                  ? "Choose and upload photos on the left to start recognition automatically."
                  : "从左侧选择并上传图片后，这里会自动进入识别状态。"}
              </p>
            </div>
          </div>
        ) : null}

        {run?.status === "failed" ? (
          <div className="mc-ai-status" data-state="error">
            <p className="flex items-center gap-2 font-semibold text-[#9a3e22]">
              <AlertTriangle className="size-4" />
              {locale === "en"
                ? "Recognition did not finish"
                : "上次识别未完成"}
            </p>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              {run.error_message ??
                (locale === "en"
                  ? "Images and manual drafts are preserved. Continue manually or try again later."
                  : "图片和人工草稿均已保留，可继续手工录入或稍后重试。")}
            </p>
          </div>
        ) : null}

        {processing ? (
          <div className="mc-ai-status" data-state="processing">
            <p className="flex items-center gap-2 font-semibold">
              <Clock3 className="size-4 animate-pulse text-primary" />
              {locale === "en"
                ? "Recognizing current images"
                : "正在识别当前图片"}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              {locale === "en"
                ? "Please wait. Refreshing will not lose this recognition run."
                : "请稍候。刷新页面也不会丢失这次记录。"}
            </p>
          </div>
        ) : null}

        {succeeded ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="flex items-center gap-2 font-semibold text-[#176b48]">
                <CheckCircle2 className="size-4" />
                {locale === "en" ? "Recognition draft" : "识别候选"} ·{" "}
                {run.result?.items.length} {locale === "en" ? "dishes" : "道"}
              </p>
            </div>
            <div className="max-h-[34rem] space-y-3 overflow-y-auto pr-1">
              {run.result?.items.map((item, index) => (
                <article
                  className="mc-ai-result p-4"
                  key={`${item.originalName}-${index}`}
                >
                  <div className="flex gap-3">
                    <span className="font-mono text-xs text-primary">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0">
                      <p className="break-words font-bold">
                        {item.originalName}
                      </p>
                      <p className="mt-1 break-words text-sm font-semibold text-primary">
                        {item.zhName}
                      </p>
                      <p className="mt-2 break-words text-sm leading-6 text-muted-foreground">
                        <span className="font-semibold text-foreground">
                          {item.category}
                        </span>
                        {" · "}
                        {item.description}
                      </p>
                      {item.uncertainty ? (
                        <p className="mt-2 break-words text-xs leading-5 text-[#9a5c18]">
                          {locale === "en" ? "Check" : "待确认"}：
                          {item.uncertainty}
                        </p>
                      ) : null}
                    </div>
                  </div>
                </article>
              ))}
            </div>
            {applyAction ? (
              <form action={applyFormAction} className="pt-2">
                <input name="confirmation" type="hidden" value="publish" />
                <SubmitButton
                  pendingLabel={
                    locale === "en" ? "Publishing menu…" : "正在发布菜单…"
                  }
                  prominent
                >
                  {locale === "en" ? "Publish menu" : "发布菜单"}
                </SubmitButton>
                <ActionFeedback state={applyState} />
              </form>
            ) : null}
          </div>
        ) : null}

        {run?.status === "failed" ? (
          <form
            action={recognizeFormAction}
            className="border-t border-[#d8d7d2] pt-5"
          >
            <input name="confirmation" type="hidden" value="recognize" />
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-sm font-semibold">
                  {locale === "en"
                    ? `${imageCount} images · ${itemCount} manual draft dishes`
                    : `当前 ${imageCount} 张图片 · ${itemCount} 道人工草稿`}
                </p>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">
                  {locale === "en"
                    ? "Images are safely preserved. Retry now or edit manually below."
                    : "图片已经安全保留，可以直接重试，也可以展开下方入口手动修改。"}
                </p>
              </div>
              <SubmitButton
                pendingLabel={
                  locale === "en" ? "Recognizing again…" : "正在重新识别…"
                }
              >
                <Sparkles />
                {locale === "en" ? "Recognize again" : "重新识别"}
              </SubmitButton>
            </div>
            <ActionFeedback state={recognizeState} />
          </form>
        ) : null}
      </div>
    </section>
  );
}
