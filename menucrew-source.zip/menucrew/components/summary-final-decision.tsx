"use client";

import { ArrowLeft, CheckCircle2, LoaderCircle } from "lucide-react";
import Link from "next/link";
import { useActionState, useMemo, useRef, useState } from "react";
import { FinalOrderConfirmation } from "@/components/final-order-confirmation";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { OrderActionState } from "@/lib/order-action-state";
import type { OrderCandidate } from "@/lib/orders";

type Action = (
  state: OrderActionState,
  formData: FormData,
) => Promise<OrderActionState>;

const initialState: OrderActionState = {
  message: "",
  orderId: null,
  status: "idle",
};

export function SummaryFinalDecision({
  action,
  adjustHref,
  candidates,
  locale = "zh-CN",
}: {
  action: Action;
  adjustHref: string;
  candidates: OrderCandidate[];
  locale?: AppLocale;
}) {
  const [state, formAction, pending] = useActionState(action, initialState);
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const allowSubmit = useRef(false);
  const formRef = useRef<HTMLFormElement>(null);
  const total = useMemo(
    () => candidates.reduce((sum, item) => sum + item.requestedQuantity, 0),
    [candidates],
  );
  return (
    <>
      <section className="mc-decision-field border-y-2 border-[#b9433c] bg-[#efe3ce]/45 p-5 sm:p-6">
        <h2 className="text-xl font-black">
          {locale === "en" ? "Is everyone ready to order?" : "大家都点好了吗？"}
        </h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          {locale === "en"
            ? "Confirmation creates the restaurant order from this summary and stops further edits."
            : "确认后会按当前汇总生成餐厅订单，并停止继续修改。"}
        </p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <form
            action={formAction}
            ref={formRef}
            onSubmit={(event) => {
              if (allowSubmit.current) {
                allowSubmit.current = false;
                return;
              }
              event.preventDefault();
              setConfirmationOpen(true);
            }}
          >
            {candidates.map((item) => (
              <input
                key={item.id}
                name={`quantity:${item.id}`}
                type="hidden"
                value={item.requestedQuantity}
              />
            ))}
            <Button
              className="h-12 w-full rounded-xl font-bold"
              disabled={pending}
              type="submit"
            >
              {pending ? (
                <LoaderCircle className="animate-spin" />
              ) : (
                <CheckCircle2 />
              )}
              {pending
                ? locale === "en"
                  ? "Creating final order…"
                  : "正在生成订单…"
                : locale === "en"
                  ? "Confirm final order"
                  : "确认并生成最终订单"}
            </Button>
          </form>
          <Button
            asChild
            className="h-12 rounded-xl font-bold"
            variant="outline"
          >
            <Link href={adjustHref}>
              <ArrowLeft />
              {locale === "en" ? "Adjust choices" : "还要调整，返回菜单"}
            </Link>
          </Button>
        </div>
        {state.message ? (
          <p className="mt-4 rounded-xl bg-[#fff1eb] px-4 py-3 text-sm text-[#9a3e22]">
            {state.message}
          </p>
        ) : null}
      </section>
      <FinalOrderConfirmation
        dishCount={
          candidates.filter((item) => item.requestedQuantity > 0).length
        }
        locale={locale}
        onCancel={() => setConfirmationOpen(false)}
        onConfirm={() => {
          setConfirmationOpen(false);
          allowSubmit.current = true;
          formRef.current?.requestSubmit();
        }}
        open={confirmationOpen}
        total={total}
      />
    </>
  );
}
