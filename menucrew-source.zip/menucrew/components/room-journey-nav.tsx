"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { AppLocale } from "@/lib/i18n";
import type { RoomJourney } from "@/lib/room-journey";

const EN_LABELS: Record<string, string> = {
  菜单: "Menu",
  我的选择: "My choices",
  本桌点单: "Table order",
};

export function RoomJourneyNav({
  journey,
  locale = "zh-CN",
}: {
  journey: RoomJourney;
  locale?: AppLocale;
}) {
  const pathname = usePathname();

  function isCurrent(href?: string) {
    if (!href) return false;
    if (pathname === href) return true;
    return (
      href.endsWith("/summary") &&
      /\/(?:summary|order|receipt)(?:\/|$)/.test(pathname)
    );
  }

  return (
    <nav
      aria-label={locale === "en" ? "Room navigation" : "房间导航"}
      className="mx-auto w-full max-w-[1248px] px-4 sm:px-6"
    >
      <ul className="mc-journey-controls flex gap-0 overflow-x-auto pb-2 sm:absolute sm:top-[1.05rem] sm:left-1/2 sm:-translate-x-1/2 sm:pb-0">
        {journey.navigationItems.map((item, index) => {
          const current = isCurrent(item.href);
          return (
            <li key={item.label}>
              {item.status === "available" && item.href ? (
                <Link
                  aria-current={current ? "step" : undefined}
                  className={`mc-journey-control is-available inline-flex h-10 items-center gap-2 whitespace-nowrap px-3 text-xs font-semibold transition duration-200 hover:text-[#b9433c] focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-primary/20 ${current ? "is-current text-[#b9433c]" : "text-muted-foreground"}`}
                  href={item.href}
                >
                  <span aria-hidden="true">{index + 1}</span>
                  {locale === "en"
                    ? EN_LABELS[item.label] || item.label
                    : item.label}
                </Link>
              ) : (
                <span
                  className="mc-journey-control inline-flex h-10 cursor-not-allowed items-center gap-2 whitespace-nowrap px-3 text-xs text-muted-foreground/50"
                  title={item.description}
                >
                  <span aria-hidden="true">{index + 1}</span>
                  {locale === "en"
                    ? EN_LABELS[item.label] || item.label
                    : item.label}
                </span>
              )}
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
