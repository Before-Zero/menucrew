"use client";

import { ClipboardList, Eye, ImageUp, UsersRound, X } from "lucide-react";
import Link from "next/link";
import { type CSSProperties, useEffect, useRef, useState } from "react";
import { DiningRouteMap } from "@/components/dining-route-map";
import { LanguageSwitcher } from "@/components/language-switcher";
import { MenuCrewMark } from "@/components/menu-crew-mark";
import { RoomForm } from "@/components/room-form";
import type { AppLocale } from "@/lib/i18n";
import type { RoomActionState } from "@/lib/room-action-state";
import styles from "./home-cover.module.css";

type CreateAction = (
  state: RoomActionState,
  payload: FormData,
) => Promise<RoomActionState>;

const words = [
  ["好好吃饭", "far", 6, 13],
  ["Taste something new", "far", 28, 9],
  ["ごちそうさま", "far", 49, 15],
  ["Disfruta la comida", "far", 76, 10],
  ["今天吃什么", "far", 14, 36],
  ["Selamat makan", "far", 82, 37],
  ["Eet smakelijk", "far", 3, 62],
  ["맛있게 드세요", "far", 88, 63],
  ["Poftă bună", "far", 20, 83],
  ["Καλή όρεξη", "far", 65, 85],
  ["Bom apetite", "far", 83, 90],
  ["Share the table", "far", 49, 94],
  ["一起开饭", "mid", 2, 24],
  ["Enjoy every bite", "mid", 72, 24],
  ["いただきます", "mid", 6, 74],
  ["Buen provecho", "mid", 79, 76],
  ["Buon appetito", "mid", 54, 8],
  ["잘 먹겠습니다", "mid", 83, 50],
  ["Smacznego", "mid", 22, 68],
  ["Afiyet olsun", "mid", 58, 72],
  ["慢慢品尝", "mid", 40, 90],
  ["Bon appétit", "near", -3, 3],
  ["一起开饭", "near", 86, -2],
  ["Enjoy your meal", "near", 79, 28],
  ["Приятного аппетита", "near", 65, 92],
  ["享受这一餐", "near", -4, 90],
  ["慢慢品尝", "near", -4, 58],
] as const;

const stepsZh = [
  {
    description: "上传餐厅菜单，AI 辅助整理双语菜品。",
    icon: ImageUp,
    label: "上传菜单",
  },
  {
    description: "分享私密邀请，大家在手机上独立选菜。",
    icon: UsersRound,
    label: "邀请同桌",
  },
  {
    description: "合并全桌菜品和数量，生成双语订单。",
    icon: ClipboardList,
    label: "合成订单",
  },
] as const;

const stepsEn = [
  {
    description:
      "Upload a restaurant menu and let AI organize bilingual dishes.",
    icon: ImageUp,
    label: "Upload menu",
  },
  {
    description: "Share a private invite so everyone chooses on their phone.",
    icon: UsersRound,
    label: "Invite diners",
  },
  {
    description: "Combine dishes and quantities into one bilingual order.",
    icon: ClipboardList,
    label: "Create order",
  },
] as const;

export function HomeCover({
  action,
  accountMode,
  locale,
}: {
  accountMode: "account" | "guest";
  action: CreateAction;
  locale: AppLocale;
}) {
  const [open, setOpen] = useState(false);
  const [departing, setDeparting] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);
  const modalRef = useRef<HTMLElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const ambientRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLElement>(null);
  const steps = locale === "en" ? stepsEn : stepsZh;

  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        return;
      }
      if (event.key !== "Tab") return;
      const focusable = Array.from(
        modalRef.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])',
        ) ?? [],
      );
      const first = focusable.at(0);
      const last = focusable.at(-1);
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      (previousFocus ?? triggerRef.current)?.focus();
    };
  }, [open]);

  useEffect(() => {
    const ambient = ambientRef.current;
    const finePointer = window.matchMedia("(pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!(ambient && finePointer.matches) || reducedMotion.matches) return;

    let frame = 0;
    const update = (event: PointerEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const x = event.clientX / window.innerWidth - 0.5;
        const y = event.clientY / window.innerHeight - 0.5;
        ambient.style.setProperty("--mouse-far-x", `${x * -3}px`);
        ambient.style.setProperty("--mouse-far-y", `${y * -2}px`);
        ambient.style.setProperty("--mouse-mid-x", `${x * -8}px`);
        ambient.style.setProperty("--mouse-mid-y", `${y * -6}px`);
        ambient.style.setProperty("--mouse-near-x", `${x * -30}px`);
        ambient.style.setProperty("--mouse-near-y", `${y * -22}px`);
        ambient.style.setProperty("--cursor-x", `${event.clientX}px`);
        ambient.style.setProperty("--cursor-y", `${event.clientY}px`);
        heroRef.current?.style.setProperty("--hero-x", `${x * 8}px`);
        heroRef.current?.style.setProperty("--hero-y", `${y * 6}px`);

        const radius = 210;
        for (const word of ambient.querySelectorAll<HTMLElement>(
          "[data-ambient-word]",
        )) {
          const dx = word.offsetLeft + word.offsetWidth / 2 - event.clientX;
          const dy = word.offsetTop + word.offsetHeight / 2 - event.clientY;
          const distance = Math.hypot(dx, dy);
          const force = Math.max(0, 1 - distance / radius);
          const safeDistance = Math.max(distance, 1);
          word.style.setProperty(
            "--repel-x",
            `${(dx / safeDistance) * force * 34}px`,
          );
          word.style.setProperty(
            "--repel-y",
            `${(dy / safeDistance) * force * 26}px`,
          );
        }
      });
    };
    const reset = () => {
      ambient.style.removeProperty("--mouse-far-x");
      ambient.style.removeProperty("--mouse-far-y");
      ambient.style.removeProperty("--mouse-mid-x");
      ambient.style.removeProperty("--mouse-mid-y");
      ambient.style.removeProperty("--mouse-near-x");
      ambient.style.removeProperty("--mouse-near-y");
      ambient.style.removeProperty("--cursor-x");
      ambient.style.removeProperty("--cursor-y");
      heroRef.current?.style.removeProperty("--hero-x");
      heroRef.current?.style.removeProperty("--hero-y");
      for (const word of ambient.querySelectorAll<HTMLElement>(
        "[data-ambient-word]",
      )) {
        word.style.removeProperty("--repel-x");
        word.style.removeProperty("--repel-y");
      }
    };

    window.addEventListener("pointermove", update, { passive: true });
    document.documentElement.addEventListener("mouseleave", reset);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", update);
      document.documentElement.removeEventListener("mouseleave", reset);
    };
  }, []);

  useEffect(() => {
    const begin = () => setDeparting(true);
    const cancel = () => setDeparting(false);
    window.addEventListener("menucrew:home-departure", begin);
    window.addEventListener("menucrew:home-departure-cancel", cancel);
    return () => {
      window.removeEventListener("menucrew:home-departure", begin);
      window.removeEventListener("menucrew:home-departure-cancel", cancel);
    };
  }, []);

  return (
    <main className={`${styles.page} ${departing ? styles.departing : ""}`}>
      <DiningRouteMap
        activeControl={1}
        className={`${styles.routeMap} mc-home-overview`}
        layout="overview"
        quiet
      />
      <div aria-hidden="true" className={styles.ambient} ref={ambientRef}>
        <span className={styles.cursorHalo} />
        {words.map(([word, depth, left, top], index) => (
          <span
            className={`${styles.word} ${styles[depth]}`}
            data-ambient-word
            key={`${word}-${left}-${top}`}
            style={
              {
                "--delay": `${index * 45}ms`,
                "--duration": `${18 + (index % 7) * 2}s`,
                "--left": `${left}%`,
                "--top": `${top}%`,
              } as CSSProperties
            }
          >
            {word}
          </span>
        ))}
      </div>

      <header className={styles.header}>
        <div className={styles.brand}>
          <MenuCrewMark className="size-[30px] sm:size-[34px]" />
          <span>合点 Menu Crew</span>
        </div>
        <div className="flex items-center gap-3">
          <Link className={styles.accountLink} href="/account">
            {locale === "en"
              ? accountMode === "account"
                ? "My tables"
                : "Sign in / Register"
              : accountMode === "account"
                ? "我的餐桌"
                : "登录 / 注册"}
          </Link>
          <LanguageSwitcher locale={locale} variant="home" />
        </div>
      </header>

      <section className={styles.hero} ref={heroRef}>
        <div aria-hidden="true" className={styles.tableSignal}>
          <span>01</span>
          <i>TAKE A SEAT</i>
        </div>
        <p className={styles.tagline}>Different menus. One table.</p>
        <h1>
          <span>{locale === "en" ? "Different languages," : "语言虽异，"}</span>
          <span>{locale === "en" ? "one table." : "心意同桌。"}</span>
        </h1>
        <p className={styles.description}>
          {locale === "en"
            ? "Upload the menu, invite your table, choose separately, and finish with one bilingual order everyone understands."
            : "上传菜单，邀请同桌，各自选菜，最后生成一份全桌都看得懂的双语订单。"}
        </p>
        <button
          className={styles.cta}
          onClick={() => setOpen(true)}
          ref={triggerRef}
          type="button"
        >
          {locale === "en" ? "Start a table" : "发起一桌"}
        </button>
        <Link className={styles.demoLink} href="/demo">
          <Eye aria-hidden="true" />
          {locale === "en" ? "View the complete demo" : "直接查看完整示例"}
        </Link>
        <Link className={styles.joinCodeLink} href="/join">
          {locale === "en" ? "Have a table code?" : "已有入席码？输入数字加入"}
        </Link>
        <p className={styles.helper}>
          {locale === "en"
            ? "No registration · Share a private invite after creating"
            : "无需注册 · 创建后即可分享私密邀请"}
        </p>
      </section>

      <section className={styles.guide}>
        <h2>
          {locale === "en" ? "One table, in three steps" : "一起开饭，只需三步"}
        </h2>
        <ol>
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <li key={step.label} style={{ "--step": index } as CSSProperties}>
                <span className={styles.number}>0{index + 1}</span>
                <span className={styles.icon}>
                  <Icon aria-hidden="true" />
                </span>
                <span className={styles.stepCopy}>
                  <strong>{step.label}</strong>
                  <small>{step.description}</small>
                </span>
              </li>
            );
          })}
        </ol>
      </section>

      {open ? (
        <div className={styles.modalLayer}>
          <section
            aria-labelledby="create-dinner-title"
            aria-modal="true"
            className={styles.modal}
            ref={modalRef}
            role="dialog"
          >
            <button
              aria-label={locale === "en" ? "Close" : "关闭"}
              className={styles.close}
              onClick={() => setOpen(false)}
              ref={closeRef}
              type="button"
            >
              <X aria-hidden="true" />
            </button>
            <h2 id="create-dinner-title">
              {locale === "en" ? "Create this table" : "创建这次聚餐"}
            </h2>
            <p className={styles.modalDescription}>
              {locale === "en"
                ? "You'll become the organizer and receive a private invite link to share."
                : "你会成为组织者，并得到一条可分享的私密邀请链接。"}
            </p>
            <RoomForm action={action} locale={locale} mode="create" />
          </section>
        </div>
      ) : null}
    </main>
  );
}
