"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef } from "react";
import { createClient } from "@/lib/supabase/client";

export function RoomRealtimeRefresh({ roomId }: { roomId: string }) {
  const router = useRouter();
  const refreshTimer = useRef<number | null>(null);

  useEffect(() => {
    const supabase = createClient();
    const requestRefresh = () => {
      if (document.visibilityState !== "visible") return;
      if (refreshTimer.current) window.clearTimeout(refreshTimer.current);
      refreshTimer.current = window.setTimeout(() => router.refresh(), 120);
    };
    const channel = supabase
      .channel(`room-page:${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `id=eq.${roomId}`,
          schema: "public",
          table: "rooms",
        },
        requestRefresh,
      )
      .subscribe();

    const onVisible = () => {
      if (document.visibilityState === "visible") requestRefresh();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      if (refreshTimer.current) window.clearTimeout(refreshTimer.current);
      document.removeEventListener("visibilitychange", onVisible);
      void supabase.removeChannel(channel);
    };
  }, [roomId, router]);

  return null;
}
