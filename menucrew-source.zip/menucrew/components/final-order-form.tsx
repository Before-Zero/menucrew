"use client";

import { CheckCircle2, LoaderCircle, Minus, Plus, Stamp } from "lucide-react";
import { useActionState, useMemo, useRef, useState } from "react";
import { FinalOrderConfirmation } from "@/components/final-order-confirmation";
import { FinalOrderDietaryNotes } from "@/components/final-order-dietary-notes";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import {
  initialOrderActionState,
  type OrderActionState,
} from "@/lib/order-action-state";
import type { FinalOrderDietaryNote, OrderCandidate } from "@/lib/orders";

type Action = (
  state: OrderActionState,
  formData: FormData,
) => Promise<OrderActionState>;

export function FinalOrderForm({
  action,
  candidates,
  dietaryNotes,
  locale = "zh-CN",
}: {
  action: Action;
  candidates: OrderCandidate[];
  dietaryNotes: FinalOrderDietaryNote[];
  locale?: AppLocale;
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialOrderActionState,
  );
  const [quantities, setQuantities] = useState(() =>
    Object.fromEntries(
      candidates.map((item) => [item.id, item.requestedQuantity]),
    ),
  );
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const allowSubmit = useRef(false);
  const formRef = useRef<HTMLFormElement>(null);
  const total = useMemo(
    () => Object.values(quantities).reduce((sum, value) => sum + value, 0),
    [quantities],
  );

  return (
    <>
      <form
        action={formAction}
        className="grid gap-6"
        onSubmit={(event) => {
          if (allowSubmit.current) {
            allowSubmit.current = false;
            return;
          }
          event.preventDefault();
          setConfirmationOpen(true);
        }}
        ref={formRef}
      >
        <section className="mc-final-notice border-y border-[#f0c88f] bg-[#fffaf1] p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <Stamp className="mt-0.5 size-5 text-[#a65f00]" />
            <div>
              <p className="font-mono text-xs font-semibold tracking-[0.12em] text-[#9a5e0b] uppercase">
                {locale === "en" ? "Final confirmation" : "最终确认"}
              </p>
              <h2 className="mt-2 text-xl font-black">
                {locale === "en"
                  ? "Cannot be changed after confirmation"
                  : "人工确认后不可修改"}
              </h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                {locale === "en"
                  ? "Requested quantities come from diners. Final quantities are what the restaurant receives. Confirmation saves an immutable snapshot."
                  : "左侧需求数来自成员提交，右侧才是最终向餐厅点的数量。确认会保存一份稳定快照。"}
              </p>
            </div>
          </div>
        </section>

        <FinalOrderDietaryNotes
          locale={locale}
          notes={dietaryNotes}
          restaurantMode={locale === "en"}
        />

        <ol className="mc-convergence-list">
          {candidates.map((item, index) => {
            const quantity = quantities[item.id] ?? 0;
            return (
              <li className="mc-convergence-item overflow-hidden" key={item.id}>
                <div className="grid gap-5 p-5 sm:p-6 lg:grid-cols-[minmax(0,1fr)_9rem_12rem] lg:items-start">
                  <div className="flex min-w-0 items-start gap-3">
                    <span className="mc-convergence-index grid size-8 shrink-0 place-items-center font-mono text-xs font-black text-primary">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0">
                      <h3 className="break-words text-lg font-black">
                        {locale === "en"
                          ? item.enName || item.originalName || item.zhName
                          : item.zhName}
                      </h3>
                      <p className="mt-1 break-words font-mono text-xs text-primary">
                        {item.originalName}
                      </p>
                      {item.description ? (
                        <p className="mt-2 break-words text-sm leading-6 text-muted-foreground">
                          {locale === "en"
                            ? item.descriptionEn || item.description
                            : item.description}
                        </p>
                      ) : null}
                      <p className="mt-3 break-words text-xs text-muted-foreground">
                        {item.contributors.length
                          ? locale === "en"
                            ? `Requested by: ${item.contributors.join(", ")}`
                            : `需求成员：${item.contributors.join("、")}`
                          : locale === "en"
                            ? "No diner selected this; the organizer may add it"
                            : "成员未选择，可由组织者补充"}
                      </p>
                    </div>
                  </div>
                  <div className="mc-request-ticket border border-[#4f7c70]/25 bg-[#4f7c70]/10 p-4">
                    <p className="font-mono text-xs tracking-[0.12em] text-muted-foreground uppercase">
                      {locale === "en" ? "Requested" : "成员需求"}
                    </p>
                    <p className="mt-2 font-mono text-3xl font-black tabular-nums">
                      {item.requestedQuantity}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {locale === "en" ? "Read only" : "不可编辑"}
                    </p>
                  </div>
                  <div className="mc-final-stepper border-2 border-[#b9433c] p-3">
                    <p className="text-center font-mono text-xs font-bold tracking-[0.12em] uppercase">
                      {locale === "en" ? "Final order" : "最终点单"}
                    </p>
                    <input
                      name={`quantity:${item.id}`}
                      type="hidden"
                      value={quantity}
                    />
                    <div className="mt-2 flex items-center justify-center gap-2">
                      <Button
                        aria-label={
                          locale === "en"
                            ? `Decrease final quantity of ${item.enName || item.originalName}`
                            : `减少 ${item.zhName} 最终数量`
                        }
                        disabled={quantity === 0}
                        onClick={() =>
                          setQuantities((current) => ({
                            ...current,
                            [item.id]: Math.max(0, quantity - 1),
                          }))
                        }
                        size="icon"
                        type="button"
                        variant="outline"
                      >
                        <Minus />
                      </Button>
                      <output className="mc-quantity-output min-w-10 text-center font-mono text-2xl font-black tabular-nums">
                        <span key={quantity}>{quantity}</span>
                      </output>
                      <Button
                        aria-label={
                          locale === "en"
                            ? `Increase final quantity of ${item.enName || item.originalName}`
                            : `增加 ${item.zhName} 最终数量`
                        }
                        disabled={quantity === 99}
                        onClick={() =>
                          setQuantities((current) => ({
                            ...current,
                            [item.id]: Math.min(99, quantity + 1),
                          }))
                        }
                        size="icon"
                        type="button"
                      >
                        <Plus />
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="border-t bg-[#f8f5ef] px-5 py-4 sm:px-6">
                  <label
                    className="text-sm font-semibold"
                    htmlFor={`order-note-${item.id}`}
                  >
                    {locale === "en"
                      ? "Note for the restaurant"
                      : "给餐厅的备注"}{" "}
                    <span className="font-normal text-muted-foreground">
                      {locale === "en" ? "(optional)" : "（可选）"}
                    </span>
                  </label>
                  <textarea
                    className="mt-2 min-h-20 w-full resize-y rounded-xl border bg-[#fffefb] px-3 py-2 text-sm leading-6 outline-none focus:border-primary focus:ring-3 focus:ring-primary/15"
                    id={`order-note-${item.id}`}
                    maxLength={500}
                    name={`note:${item.id}`}
                    placeholder={
                      locale === "en"
                        ? "e.g. sauce on the side, mild spice"
                        : "例如：酱汁另放、少辣"
                    }
                  />
                </div>
              </li>
            );
          })}
        </ol>

        <section className="sticky bottom-0 z-10 border-y-2 border-[#24322d] bg-[#f4f1e8]/95 p-4 shadow-[0_-14px_36px_rgb(36_50_45_/_0.12)] backdrop-blur sm:p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs text-muted-foreground">
                {locale === "en" ? "Final total servings" : "最终总份数"}
              </p>
              <p className="font-mono text-3xl font-black tabular-nums">
                {total}
              </p>
            </div>
            <p className="max-w-xs text-right text-xs leading-5 text-muted-foreground">
              {locale === "en"
                ? "After confirmation, everyone sees the same result and choices cannot change."
                : "确认后所有成员看到同一结果，且不能再修改选择。"}
            </p>
          </div>
          {state.message ? (
            <p
              aria-live="polite"
              className={`mt-3 rounded-xl px-3 py-2 text-sm ${state.status === "error" ? "bg-destructive/8 text-destructive" : "bg-[#eef9f2] text-[#146b45]"}`}
            >
              {state.message}
            </p>
          ) : null}
          <Button
            className="mt-4 h-12 w-full bg-[#b9433c] text-base font-black text-white"
            disabled={pending || total === 0}
            type="submit"
          >
            {pending ? (
              <LoaderCircle className="animate-spin" />
            ) : (
              <CheckCircle2 />
            )}
            {pending
              ? locale === "en"
                ? "Creating stable snapshot…"
                : "正在生成稳定快照…"
              : locale === "en"
                ? "Confirm and create final order"
                : "确认并生成最终订单"}
          </Button>
        </section>
      </form>
      <FinalOrderConfirmation
        dishCount={
          Object.values(quantities).filter((value) => value > 0).length
        }
        locale={locale}
        onCancel={() => setConfirmationOpen(false)}
        onConfirm={() => {
          setConfirmationOpen(false);
          allowSubmit.current = true;
          formRef.current?.requestSubmit();
        }}
        open={confirmationOpen}
        total={total}
      />
    </>
  );
}
