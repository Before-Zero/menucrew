import { ArrowRight, Clock3 } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { WaitForMenuRefresh } from "@/components/wait-for-menu-refresh";
import type { AppLocale } from "@/lib/i18n";
import type { RoomJourney } from "@/lib/room-journey";

export function MemberRoomDashboard({
  journey,
  locale = "zh-CN",
  memberCount,
  roomId,
  submittedCount,
}: {
  journey: RoomJourney;
  locale?: AppLocale;
  memberCount: number;
  roomId: string;
  submittedCount: number;
}) {
  const action = journey.primaryAction;

  return (
    <div className="grid gap-6">
      {journey.stage === "preparing" ? (
        <WaitForMenuRefresh roomId={roomId} />
      ) : null}
      <section className="border-y border-[#d8d7d2] py-6">
        <p className="font-mono text-[10px] font-semibold tracking-[0.16em] text-primary uppercase">
          {locale === "en" ? "Current stage" : "当前阶段"}
        </p>
        <h2 className="mt-2 text-2xl font-black">{journey.stageLabel}</h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          {journey.stageDescription}
        </p>
      </section>

      <section className="grid grid-cols-2 border-b border-[#d8d7d2] pb-6">
        <article className="border-r border-[#d8d7d2] pr-5">
          <p className="text-3xl font-semibold tabular-nums">
            {memberCount} {locale === "en" ? "diners" : "人"}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            {locale === "en" ? "joined this table" : "已加入这次聚餐"}
          </p>
        </article>
        <article className="pl-5">
          <p className="text-3xl font-semibold tabular-nums">
            {submittedCount}/{memberCount}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            {locale === "en" ? "finished choosing" : "人已完成选择"}
          </p>
        </article>
      </section>

      <section className="mc-next-control py-2 pl-16">
        <p className="font-bold">
          {locale === "en" ? "Next" : "下一步"}：{action.label}
        </p>
        <p className="mt-1 text-sm leading-6 text-muted-foreground">
          {action.description}
        </p>
        {action.kind === "link" ? (
          <Button asChild className="mt-4 h-12 w-full text-base font-bold">
            <Link href={action.href}>
              {action.label}
              <ArrowRight data-icon="inline-end" />
            </Link>
          </Button>
        ) : (
          <p className="mt-4 flex items-start gap-2 rounded-xl bg-[#fff5e5] px-4 py-3 text-sm leading-6 text-[#7a4b0b]">
            <Clock3 className="mt-0.5 size-4 shrink-0" />
            {action.description}
          </p>
        )}
      </section>
    </div>
  );
}
