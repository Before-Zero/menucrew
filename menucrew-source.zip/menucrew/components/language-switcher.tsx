"use client";

import { Languages, LoaderCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import type { AppLocale } from "@/lib/i18n";

export function LanguageSwitcher({
  locale,
  variant = "default",
}: {
  locale: AppLocale;
  variant?: "default" | "home";
}) {
  const router = useRouter();
  const [pendingLocale, setPendingLocale] = useState<AppLocale | null>(null);
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  async function changeLocale(nextLocale: AppLocale) {
    if (nextLocale === locale || pendingLocale) return;
    setPendingLocale(nextLocale);
    try {
      const response = await fetch("/api/locale", {
        body: JSON.stringify({ locale: nextLocale }),
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      if (response.ok) router.refresh();
    } finally {
      setPendingLocale(null);
    }
  }

  const home = variant === "home";

  return (
    <fieldset
      className={
        home
          ? "mc-home-language-switch inline-grid grid-cols-2 items-center text-xs"
          : "inline-flex items-center gap-1 rounded-full border border-[#cbd4e5] bg-[#fffefb] p-1 text-xs"
      }
    >
      <legend className="sr-only">Language</legend>
      {home ? null : (
        <Languages aria-hidden="true" className="ml-1 size-4 text-primary" />
      )}
      {(["zh-CN", "en"] as const).map((value) => (
        <button
          aria-pressed={locale === value}
          className={
            home
              ? `mc-home-language-option ${locale === value ? "is-active" : ""}`
              : `rounded-full px-2.5 py-1.5 font-semibold transition ${locale === value ? "bg-[#211f1d] text-white" : "text-muted-foreground hover:text-foreground"}`
          }
          disabled={Boolean(pendingLocale)}
          key={value}
          onClick={() => changeLocale(value)}
          type="button"
        >
          {pendingLocale === value ? (
            <LoaderCircle
              aria-label={
                locale === "en" ? "Switching language" : "正在切换语言"
              }
              className="mx-auto size-3.5 animate-spin"
            />
          ) : value === "zh-CN" ? (
            "中文"
          ) : home ? (
            "English"
          ) : (
            "EN"
          )}
        </button>
      ))}
    </fieldset>
  );
}
