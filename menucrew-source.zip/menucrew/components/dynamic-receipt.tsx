"use client";

import { ReceiptText, RefreshCw } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { MemberReceipt } from "@/lib/member-receipt";
import { createClient } from "@/lib/supabase/client";

export function DynamicReceipt({
  initialReceipt,
  locale,
  memberCount,
  submittedCount,
}: {
  initialReceipt: MemberReceipt;
  locale: AppLocale;
  memberCount?: number;
  submittedCount?: number;
}) {
  const [receipt, setReceipt] = useState(initialReceipt);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (receipt.orderConfirmed) return;
    let active = true;
    async function refresh() {
      if (document.visibilityState !== "visible") return;
      setUpdating(true);
      try {
        const response = await fetch(
          `/api/rooms/${initialReceipt.roomId}/receipt`,
          { cache: "no-store" },
        );
        if (!response.ok) return;
        const next = (await response.json()) as MemberReceipt;
        if (active)
          setReceipt((current) =>
            next.revision !== current.revision ||
            next.orderConfirmed !== current.orderConfirmed
              ? next
              : current,
          );
      } finally {
        if (active) setUpdating(false);
      }
    }
    const supabase = createClient();
    const channel = supabase
      .channel(`live-ticket:${initialReceipt.roomId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `id=eq.${initialReceipt.roomId}`,
          schema: "public",
          table: "rooms",
        },
        () => void refresh(),
      )
      .subscribe();
    const timer = window.setInterval(refresh, 15000);
    const onVisible = () => void refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      active = false;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
      void supabase.removeChannel(channel);
    };
  }, [initialReceipt.roomId, receipt.orderConfirmed]);

  return (
    <div className="mc-live-ticket grid gap-5">
      <div className="mc-live-ticket-head flex items-center justify-between gap-3 px-4 py-3 text-sm">
        <span className="flex items-center gap-2 font-semibold">
          <ReceiptText className="size-4 text-primary" />
          {locale === "en" ? "Live table order" : "本桌实时点单"}
        </span>
        <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <RefreshCw className={`size-3.5 ${updating ? "animate-spin" : ""}`} />
          {locale === "en" ? "Updates automatically" : "自动更新"}
        </span>
      </div>

      {typeof memberCount === "number" && typeof submittedCount === "number" ? (
        <p className="rounded-xl bg-[#f8f5ef] px-4 py-3 text-sm font-semibold">
          {locale === "en"
            ? `${submittedCount} of ${memberCount} people have saved their choices`
            : `${submittedCount}/${memberCount} 人已提交，当前数量仍会变化`}
        </p>
      ) : null}

      {receipt.items.length ? (
        <ol className="mc-live-ticket-lines divide-y border-y border-dashed">
          {receipt.items.map((item) => (
            <li className="flex items-start gap-4 py-5" key={item.id}>
              <div className="min-w-0 flex-1">
                <p className="break-words text-lg font-black">
                  {locale === "en" ? item.enName || item.zhName : item.zhName}
                </p>
                <p className="mt-1 break-words font-mono text-xs text-primary">
                  {item.originalName}
                </p>
                {item.myQuantity > 0 ? (
                  <p className="mt-2 text-xs font-semibold text-[#146b45]">
                    {locale === "en"
                      ? `Mine: ${item.myQuantity}`
                      : `我的 ${item.myQuantity} 份`}
                  </p>
                ) : null}
              </div>
              <strong className="font-mono text-2xl tabular-nums">
                ×{item.totalQuantity}
              </strong>
            </li>
          ))}
        </ol>
      ) : (
        <p className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          {locale === "en" ? "No dishes yet." : "本桌还没有正数量菜品。"}
        </p>
      )}

      <Button asChild variant="outline">
        <Link href={`/rooms/${receipt.roomId}/selection`}>
          {locale === "en"
            ? "Add or edit my choices"
            : "如需添加或修改，返回我的选择"}
        </Link>
      </Button>
      {receipt.orderConfirmed ? (
        <Button asChild>
          <Link href={`/rooms/${receipt.roomId}/summary`}>
            {locale === "en" ? "View final order" : "查看最终订单"}
          </Link>
        </Button>
      ) : null}
    </div>
  );
}
