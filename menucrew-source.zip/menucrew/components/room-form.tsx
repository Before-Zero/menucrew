"use client";

import { ArrowRight, LoaderCircle } from "lucide-react";
import { useActionState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import {
  INITIAL_ROOM_ACTION_STATE,
  type RoomActionState,
} from "@/lib/room-action-state";
import { createClient } from "@/lib/supabase/client";

type RoomFormProps = {
  action: (
    state: RoomActionState,
    payload: FormData,
  ) => Promise<RoomActionState>;
  mode: "code" | "create" | "join";
  locale?: AppLocale;
};

const inputClassName =
  "h-12 w-full rounded-xl border border-[#d8d7d2] bg-[#fffefb] px-4 text-base text-foreground shadow-[0_1px_0_rgb(33_31_29_/_0.03)] outline-none transition placeholder:text-[#9a958f] focus:border-primary focus:ring-3 focus:ring-primary/15 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/10";

function anonymousSessionError(
  error: {
    code?: string;
    message?: string;
    status?: number;
  },
  locale: AppLocale,
): RoomActionState {
  const isRateLimited =
    error.status === 429 ||
    error.code === "over_request_rate_limit" ||
    error.message?.toLowerCase().includes("rate limit");

  return {
    status: "error",
    message:
      locale === "en"
        ? isRateLimited
          ? "There are many anonymous joins from this network. Try again shortly; your entries are still here."
          : "We couldn't create an anonymous identity. Check your connection and try again; your entries are still here."
        : isRateLimited
          ? "当前网络的匿名入席请求较多，请稍后再试；你填写的内容还在。"
          : "暂时没能建立匿名身份，请检查网络后重试；你填写的内容还在。",
  };
}

export function RoomForm({ action, locale = "zh-CN", mode }: RoomFormProps) {
  const departureStarted = useRef(false);

  async function submitWithAnonymousSession(
    state: RoomActionState,
    payload: FormData,
  ) {
    if (
      mode === "create" &&
      !window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      await new Promise((resolve) => window.setTimeout(resolve, 1400));
    }

    const supabase = createClient();
    const { data, error: sessionError } = await supabase.auth.getSession();

    if (sessionError) return anonymousSessionError(sessionError, locale);

    if (!data.session) {
      const { error } = await supabase.auth.signInAnonymously();
      if (error) return anonymousSessionError(error, locale);
    }

    return action(state, payload);
  }

  const [state, formAction, pending] = useActionState(
    submitWithAnonymousSession,
    INITIAL_ROOM_ACTION_STATE,
  );
  const isCreate = mode === "create";
  const isCode = mode === "code";

  useEffect(() => {
    if (state.status !== "error" || !departureStarted.current) return;
    departureStarted.current = false;
    window.dispatchEvent(new CustomEvent("menucrew:home-departure-cancel"));
  }, [state.status]);

  return (
    <form
      action={formAction}
      className="space-y-5"
      onSubmit={(event) => {
        if (
          !isCreate ||
          !event.currentTarget.checkValidity() ||
          window.matchMedia("(prefers-reduced-motion: reduce)").matches
        )
          return;
        const submitter = event.nativeEvent.submitter;
        const rect =
          submitter instanceof HTMLElement
            ? submitter.getBoundingClientRect()
            : event.currentTarget.getBoundingClientRect();
        departureStarted.current = true;
        window.dispatchEvent(
          new CustomEvent("menucrew:home-departure", {
            detail: {
              x: rect.left + rect.width / 2,
              y: rect.top + rect.height / 2,
            },
          }),
        );
      }}
    >
      {isCreate ? (
        <div className="space-y-2">
          <label className="text-sm font-semibold" htmlFor="roomName">
            {locale === "en" ? "Name this meal" : "给这次聚餐起个名字"}
          </label>
          <input
            aria-describedby={
              state.fields?.roomName ? "roomName-error" : undefined
            }
            aria-invalid={Boolean(state.fields?.roomName)}
            className={inputClassName}
            id="roomName"
            maxLength={60}
            name="roomName"
            placeholder={
              locale === "en" ? "e.g. Friday dinner" : "例如：周五晚餐"
            }
            required
          />
          {state.fields?.roomName ? (
            <p className="text-sm text-destructive" id="roomName-error">
              {state.fields.roomName}
            </p>
          ) : null}
        </div>
      ) : null}

      {isCode ? (
        <div className="space-y-2">
          <label className="text-sm font-semibold" htmlFor="roomCode">
            {locale === "en" ? "Six-digit table code" : "六位入席码"}
          </label>
          <input
            aria-describedby={
              state.fields?.roomCode ? "roomCode-error" : "roomCode-hint"
            }
            aria-invalid={Boolean(state.fields?.roomCode)}
            autoComplete="one-time-code"
            className={`${inputClassName} font-mono text-xl tracking-[0.32em] tabular-nums`}
            id="roomCode"
            inputMode="numeric"
            maxLength={6}
            name="roomCode"
            pattern="[0-9]{6}"
            placeholder="000000"
            required
          />
          {state.fields?.roomCode ? (
            <p className="text-sm text-destructive" id="roomCode-error">
              {state.fields.roomCode}
            </p>
          ) : (
            <p className="text-xs text-muted-foreground" id="roomCode-hint">
              {locale === "en"
                ? "Ask the organizer for the code shown beside the QR."
                : "向发起人询问二维码旁的数字。"}
            </p>
          )}
        </div>
      ) : null}

      <div className="space-y-2">
        <label className="text-sm font-semibold" htmlFor="displayName">
          {locale === "en"
            ? isCreate
              ? "What should everyone call you?"
              : "What should we call you at the table?"
            : isCreate
              ? "大家怎么称呼你"
              : "你想在房间里叫什么"}
        </label>
        <input
          aria-describedby={
            state.fields?.displayName ? "displayName-error" : undefined
          }
          aria-invalid={Boolean(state.fields?.displayName)}
          autoComplete="nickname"
          className={inputClassName}
          id="displayName"
          maxLength={60}
          name="displayName"
          placeholder={
            locale === "en"
              ? isCreate
                ? "e.g. Alex"
                : "Enter your name"
              : isCreate
                ? "例如：小林"
                : "输入你的称呼"
          }
          required
        />
        {state.fields?.displayName ? (
          <p className="text-sm text-destructive" id="displayName-error">
            {state.fields.displayName}
          </p>
        ) : null}
      </div>

      {state.status === "error" && state.message ? (
        <div
          className="rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-3 text-sm text-destructive"
          role="alert"
        >
          {state.message}
        </div>
      ) : null}

      <Button
        className="h-12 w-full rounded-xl px-5 text-base shadow-[0_10px_24px_rgb(217_93_69_/_0.18)]"
        disabled={pending}
        size="lg"
        type="submit"
      >
        {pending ? (
          <>
            <LoaderCircle aria-hidden="true" className="animate-spin" />
            {locale === "en"
              ? isCreate
                ? "Creating room"
                : "Joining"
              : isCreate
                ? "正在建房间"
                : "正在加入"}
          </>
        ) : (
          <>
            {locale === "en"
              ? isCreate
                ? "Create room"
                : isCode
                  ? "Join with code"
                  : "Join room"
              : isCreate
                ? "创建房间"
                : "加入房间"}
            <ArrowRight aria-hidden="true" data-icon="inline-end" />
          </>
        )}
      </Button>

      <p className="text-center text-xs leading-5 text-muted-foreground">
        {locale === "en"
          ? "No registration required. Save your identity later only if you want cross-device access."
          : "无需注册。身份保存在当前浏览器；清除浏览器数据后无法找回。"}
      </p>
    </form>
  );
}
