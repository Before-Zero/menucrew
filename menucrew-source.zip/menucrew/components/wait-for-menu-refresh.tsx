"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { createClient } from "@/lib/supabase/client";

export function WaitForMenuRefresh({ roomId }: { roomId: string }) {
  const router = useRouter();
  useEffect(() => {
    const refresh = () => {
      if (document.visibilityState === "visible") router.refresh();
    };
    const supabase = createClient();
    const channel = supabase
      .channel(`menu-ready:${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `room_id=eq.${roomId}`,
          schema: "public",
          table: "menus",
        },
        refresh,
      )
      .subscribe();
    const timer = window.setInterval(refresh, 15000);
    return () => {
      window.clearInterval(timer);
      void supabase.removeChannel(channel);
    };
  }, [roomId, router]);
  return null;
}
