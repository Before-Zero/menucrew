"use client";

import { Check, Copy, TriangleAlert } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";

export function CopyOrderText({
  locale = "zh-CN",
  text,
}: {
  locale?: AppLocale;
  text: string;
}) {
  const [status, setStatus] = useState<"idle" | "copied" | "failed">("idle");
  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setStatus("copied");
    } catch {
      setStatus("failed");
    }
  }
  return (
    <div>
      <Button
        className="h-12 w-full rounded-xl font-bold"
        onClick={copy}
        type="button"
      >
        {status === "copied" ? <Check /> : <Copy />}
        {status === "copied"
          ? locale === "en"
            ? "Order text copied"
            : "订单文本已复制"
          : locale === "en"
            ? "Copy bilingual order"
            : "复制双语订单文本"}
      </Button>
      {status === "failed" ? (
        <p className="mt-2 flex items-start gap-2 text-xs text-destructive">
          <TriangleAlert className="size-4 shrink-0" />
          {locale === "en"
            ? "Clipboard access was blocked. Try again or select the page text manually."
            : "浏览器没有允许复制，请重试或手动选择页面内容。"}
        </p>
      ) : null}
    </div>
  );
}
