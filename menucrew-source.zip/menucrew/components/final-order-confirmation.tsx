"use client";

import { CheckCircle2, Stamp, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";

export function FinalOrderConfirmation({
  dishCount,
  locale = "zh-CN",
  onCancel,
  onConfirm,
  open,
  total,
}: {
  dishCount: number;
  locale?: AppLocale;
  onCancel: () => void;
  onConfirm: () => void;
  open: boolean;
  total: number;
}) {
  const [mounted, setMounted] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusFrame = window.requestAnimationFrame(() =>
      cancelRef.current?.focus(),
    );

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") onCancel();
      if (event.key !== "Tab" || !dialogRef.current) return;
      const focusable = Array.from(
        dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      );
      const first = focusable[0];
      const last = focusable.at(-1);
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
      previousFocus?.focus();
    };
  }, [onCancel, open]);

  if (!mounted || !open) return null;

  return createPortal(
    <div className="mc-final-confirmation-backdrop fixed inset-0 z-[110] flex items-end justify-center bg-[#24322d]/48 p-0 backdrop-blur-[2px] sm:items-center sm:p-6">
      <button
        aria-label={locale === "en" ? "Keep reviewing" : "继续核对订单"}
        className="absolute inset-0 cursor-default"
        onClick={onCancel}
        type="button"
      />
      <section
        aria-describedby="final-order-confirmation-description"
        aria-labelledby="final-order-confirmation-title"
        aria-modal="true"
        className="mc-final-confirmation-paper relative z-10 w-full max-w-lg overflow-hidden border-y-2 border-[#24322d] bg-[#fffdf9] p-6 text-[#24322d] shadow-[0_30px_90px_rgb(33_31_29_/_0.22)] sm:border-2 sm:p-8"
        ref={dialogRef}
        role="dialog"
        tabIndex={-1}
      >
        <button
          aria-label={locale === "en" ? "Close confirmation" : "关闭确认窗口"}
          className="absolute top-4 right-4 grid size-11 place-items-center rounded-full text-[#5b6863] transition hover:bg-[#e9e6dc] hover:text-[#24322d] focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[#b9433c]/35"
          onClick={onCancel}
          type="button"
        >
          <X className="size-5" />
        </button>

        <div aria-hidden="true" className="mc-final-confirmation-route">
          <span />
          <span />
          <span />
          <Stamp className="size-6" />
        </div>
        <h2
          className="max-w-sm text-3xl font-black tracking-[-0.035em] sm:text-4xl"
          id="final-order-confirmation-title"
        >
          {locale === "en"
            ? "Place this table's final order?"
            : "把这一桌，正式落单？"}
        </h2>
        <p
          className="mt-3 max-w-md text-sm leading-7 text-[#5b6863] sm:text-base"
          id="final-order-confirmation-description"
        >
          {locale === "en"
            ? "This combines everyone's choices into one order. Once confirmed, everyone sees the same result and it cannot be edited or undone."
            : "这一刻会把大家的选择收束为同一份订单。确认后所有成员都将看到这份结果，不能再修改或撤销。"}
        </p>

        <dl className="mt-7 grid grid-cols-2 border-y border-dashed border-[#cfcabd] py-5">
          <div className="border-r border-[#cfcabd] pr-5">
            <dt className="text-xs text-[#5b6863]">
              {locale === "en" ? "Dish varieties" : "最终菜品种类"}
            </dt>
            <dd className="mt-1 font-mono text-3xl font-black tabular-nums">
              {dishCount}
              <span className="ml-1 text-sm font-medium">
                {locale === "en" ? "types" : "种"}
              </span>
            </dd>
          </div>
          <div className="pl-5">
            <dt className="text-xs text-[#5b6863]">
              {locale === "en" ? "Final quantity" : "最终数量"}
            </dt>
            <dd className="mt-1 font-mono text-3xl font-black tabular-nums">
              {total}
              <span className="ml-1 text-sm font-medium">
                {locale === "en" ? "servings" : "份"}
              </span>
            </dd>
          </div>
        </dl>

        <div className="mt-7 grid gap-3 sm:grid-cols-[0.8fr_1.2fr]">
          <Button
            className="h-12 rounded-xl font-bold"
            onClick={onCancel}
            ref={cancelRef}
            type="button"
            variant="outline"
          >
            {locale === "en" ? "Keep reviewing" : "继续核对"}
          </Button>
          <Button
            className="h-12 rounded-xl bg-[#b9433c] font-black text-white"
            onClick={onConfirm}
            type="button"
          >
            <CheckCircle2 />
            {locale === "en" ? "Place final order" : "确认落单"}
          </Button>
        </div>
      </section>
    </div>,
    document.body,
  );
}
