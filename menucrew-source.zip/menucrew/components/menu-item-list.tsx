"use client";

import { ArrowDown, ArrowUp, LoaderCircle, Pencil, Trash2 } from "lucide-react";
import { useActionState } from "react";
import {
  deleteMenuItemAction,
  moveMenuItemAction,
  saveMenuItemAction,
} from "@/app/rooms/[roomId]/menu/actions";
import { MenuItemForm } from "@/components/menu-item-form";
import { Button } from "@/components/ui/button";
import { type AppLocale, localizedMenuText } from "@/lib/i18n";
import {
  initialMenuActionState,
  type MenuActionState,
} from "@/lib/menu-action-state";
import type { MenuItem } from "@/lib/menus";

type Action = (
  state: MenuActionState,
  payload: FormData,
) => Promise<MenuActionState>;

function SmallAction({
  action,
  confirmMessage,
  disabled = false,
  icon,
  label,
  variant = "outline",
}: {
  action: Action;
  confirmMessage?: string;
  disabled?: boolean;
  icon: React.ReactNode;
  label: string;
  variant?: "destructive" | "outline";
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialMenuActionState,
  );
  return (
    <form
      action={formAction}
      onSubmit={(event) => {
        if (confirmMessage && !window.confirm(confirmMessage)) {
          event.preventDefault();
        }
      }}
    >
      <Button
        aria-label={label}
        disabled={pending || disabled}
        size="icon-sm"
        title={state.message || label}
        type="submit"
        variant={variant}
      >
        {pending ? (
          <LoaderCircle aria-hidden="true" className="animate-spin" />
        ) : (
          icon
        )}
      </Button>
    </form>
  );
}

type MenuItemListProps = {
  editable?: boolean;
  items: MenuItem[];
  locale?: AppLocale;
  roomId?: string;
};

export function MenuItemList(props: MenuItemListProps) {
  const { items, locale = "zh-CN" } = props;
  if (!items.length)
    return (
      <div className="rounded-2xl border border-dashed bg-[#f8f5ef] px-5 py-8 text-center">
        <p className="font-semibold">
          {locale === "en" ? "No dishes yet" : "还没有菜品"}
        </p>
        <p className="mt-1 text-sm leading-6 text-muted-foreground">
          {locale === "en"
            ? "Add dishes from the original image. Original names, Chinese names, and descriptions are all preserved."
            : "照着原图逐道录入，原文、中文名和解释都会保留。"}
        </p>
      </div>
    );

  return (
    <ol className="mc-menu-route">
      {items.map((item, index) => {
        const localized = localizedMenuText(item, locale);
        return (
          <li className="mc-menu-route-item py-5 sm:py-6" key={item.id}>
            <div className="flex items-start gap-4">
              <span className="mc-menu-route-number shrink-0 font-mono text-xs">
                {String(index + 1).padStart(2, "0")}
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="break-words text-lg font-bold leading-tight">
                  {localized.name}
                </h3>
                <p className="mt-1 break-words font-mono text-xs leading-5 text-primary">
                  {item.original_name}
                </p>
                <p className="mt-3 break-words text-sm leading-6 text-muted-foreground">
                  {localized.description}
                </p>
              </div>
            </div>
            {props.editable && props.roomId ? (
              <div className="mt-4 flex items-center justify-end gap-2 border-t pt-3">
                <SmallAction
                  action={moveMenuItemAction.bind(
                    null,
                    props.roomId,
                    item.id,
                    "up",
                  )}
                  disabled={index === 0}
                  icon={<ArrowUp aria-hidden="true" />}
                  label={
                    locale === "en"
                      ? `Move ${localized.name} up`
                      : `上移 ${item.zh_name}`
                  }
                />
                <SmallAction
                  action={moveMenuItemAction.bind(
                    null,
                    props.roomId,
                    item.id,
                    "down",
                  )}
                  disabled={index === items.length - 1}
                  icon={<ArrowDown aria-hidden="true" />}
                  label={
                    locale === "en"
                      ? `Move ${localized.name} down`
                      : `下移 ${item.zh_name}`
                  }
                />
                <SmallAction
                  action={deleteMenuItemAction.bind(
                    null,
                    props.roomId,
                    item.id,
                  )}
                  confirmMessage={
                    locale === "en"
                      ? `Delete “${localized.name}”?`
                      : `确定删除“${item.zh_name}”吗？`
                  }
                  icon={<Trash2 aria-hidden="true" />}
                  label={
                    locale === "en"
                      ? `Delete ${localized.name}`
                      : `删除 ${item.zh_name}`
                  }
                  variant="destructive"
                />
              </div>
            ) : null}
            {props.editable && props.roomId ? (
              <details className="group mt-3">
                <summary className="flex cursor-pointer list-none items-center gap-2 rounded-lg px-2 py-2 text-sm font-semibold text-primary outline-none focus-visible:ring-3 focus-visible:ring-primary/20">
                  <Pencil aria-hidden="true" className="size-4" />
                  {locale === "en" ? "Edit this dish" : "编辑这道菜"}
                </summary>
                <div className="mt-3 border-t pt-4">
                  <MenuItemForm
                    action={saveMenuItemAction.bind(
                      null,
                      props.roomId,
                      item.id,
                    )}
                    item={item}
                    locale={locale}
                  />
                </div>
              </details>
            ) : null}
          </li>
        );
      })}
    </ol>
  );
}
