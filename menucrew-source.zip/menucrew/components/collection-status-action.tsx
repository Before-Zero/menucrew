"use client";

import { LoaderCircle, LockKeyhole, RotateCcw, Unlock } from "lucide-react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import {
  type AggregationActionState,
  initialAggregationActionState,
} from "@/lib/aggregation-action-state";

type Action = (
  state: AggregationActionState,
) => Promise<AggregationActionState>;

export function CollectionStatusAction({
  action,
  currentStatus,
  pendingCount = 0,
}: {
  action: Action;
  currentStatus: string;
  pendingCount?: number;
}) {
  const [state, formAction, pending] = useActionState(
    action,
    initialAggregationActionState,
  );
  const reviewing = currentStatus === "reviewing";

  return (
    <form
      action={formAction}
      className="grid gap-3"
      onSubmit={(event) => {
        if (!reviewing && pendingCount > 0) {
          const confirmed = window.confirm(
            `还有 ${pendingCount} 人尚未提交。结束后成员将暂时不能修改，是否继续？`,
          );
          if (!confirmed) event.preventDefault();
        }
      }}
    >
      <Button
        className={`h-12 rounded-xl font-bold ${reviewing ? "border-[#2c7a55] text-[#146b45]" : "bg-[#211f1d] text-white hover:bg-[#34302d]"}`}
        disabled={pending}
        type="submit"
        variant={reviewing ? "outline" : "default"}
      >
        {pending ? (
          <LoaderCircle className="animate-spin" />
        ) : reviewing ? (
          <RotateCcw />
        ) : (
          <LockKeyhole />
        )}
        {pending
          ? "正在切换…"
          : reviewing
            ? "重新开放收集"
            : "结束收集并开始核对"}
      </Button>
      <p className="flex items-start gap-2 text-xs leading-5 text-muted-foreground">
        {reviewing ? <Unlock className="mt-0.5 size-3.5 shrink-0" /> : null}
        {reviewing
          ? "重新开放不会删除已有提交，成员刷新后可继续保存。"
          : pendingCount > 0
            ? `还有 ${pendingCount} 人未提交。锁定后，已经打开的成员页面也无法绕过数据层继续保存。`
            : "锁定后，已经打开的成员页面也无法绕过数据层继续保存。"}
      </p>
      {state.message ? (
        <p
          aria-live="polite"
          className={`rounded-lg px-3 py-2 text-sm ${state.status === "error" ? "bg-destructive/8 text-destructive" : "bg-[#eef9f2] text-[#146b45]"}`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  );
}
