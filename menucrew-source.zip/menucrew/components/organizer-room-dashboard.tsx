import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { InvitePanel } from "@/components/invite-panel";
import { Button } from "@/components/ui/button";
import type { AppLocale } from "@/lib/i18n";
import type { RoomJourney } from "@/lib/room-journey";

export function OrganizerRoomDashboard({
  inviteToken,
  joinCode,
  journey,
  locale = "zh-CN",
  memberCount,
  qrDataUrl,
  submittedCount,
}: {
  inviteToken?: string;
  joinCode: string;
  journey: RoomJourney;
  locale?: AppLocale;
  memberCount: number;
  qrDataUrl?: string;
  submittedCount: number;
}) {
  const pendingCount = Math.max(memberCount - submittedCount, 0);
  const action = journey.primaryAction;

  return (
    <div className="grid gap-5">
      <section className="border-y border-[#d8d7d2] py-6">
        <p className="font-mono text-[10px] font-semibold tracking-[0.16em] text-primary uppercase">
          {locale === "en" ? "Current stage" : "当前阶段"}
        </p>
        <h2 className="mt-2 text-2xl font-black">{journey.stageLabel}</h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          {journey.stageDescription}
        </p>
      </section>

      <section className="grid grid-cols-3 border-b border-[#d8d7d2] pb-6">
        <article className="border-r border-[#d8d7d2] pr-4">
          <p className="text-3xl font-semibold tabular-nums">{memberCount}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {locale === "en" ? "diners joined" : "人已加入"}
          </p>
        </article>
        <article className="border-r border-[#d8d7d2] px-4">
          <p className="text-3xl font-semibold tabular-nums">
            {submittedCount}/{memberCount}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            {locale === "en" ? "submitted" : "人已提交"}
          </p>
        </article>
        <article className="pl-4">
          <p className="text-3xl font-semibold tabular-nums">{pendingCount}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {locale === "en" ? "remaining" : "人待提交"}
          </p>
        </article>
      </section>

      <section className="grid gap-5 lg:grid-cols-[minmax(0,1.18fr)_minmax(280px,0.82fr)] lg:items-start">
        <div className="mc-next-control py-2 pl-16">
          <p className="font-mono text-[10px] font-bold tracking-[0.16em] text-[#d95d45] uppercase">
            {locale === "en" ? "Next step" : "下一步"}
          </p>
          <h3 className="mt-3 font-heading text-2xl font-bold">
            {action.label}
          </h3>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">
            {action.description}
          </p>
          {action.kind === "link" ? (
            <Button asChild className="mt-6 h-12 px-6 text-base font-bold">
              <Link href={action.href}>
                {action.label}
                <ArrowRight data-icon="inline-end" />
              </Link>
            </Button>
          ) : (
            <p className="mt-5 rounded-xl bg-[#f1f2f4] px-4 py-3 text-sm text-muted-foreground">
              {action.description}
            </p>
          )}
        </div>
        <InvitePanel
          defaultOpen={journey.stage === "preparing"}
          inviteToken={inviteToken}
          joinCode={joinCode}
          locale={locale}
          qrDataUrl={qrDataUrl}
        />
      </section>
    </div>
  );
}
