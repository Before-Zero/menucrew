"use client";

import { Check, LoaderCircle, LogOut, Mail } from "lucide-react";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";
import type { AppLocale } from "@/lib/i18n";
import { createClient } from "@/lib/supabase/client";

type AccountMode = "account" | "anonymous" | "signed-out";

export function AccountPanel({
  email,
  locale,
  mode,
}: {
  email: string;
  locale: AppLocale;
  mode: AccountMode;
}) {
  const router = useRouter();
  const [address, setAddress] = useState("");
  const [message, setMessage] = useState("");
  const [messageTone, setMessageTone] = useState<"error" | "success">(
    "success",
  );
  const [pending, setPending] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setMessage("");
    try {
      const supabase = createClient();
      const redirectTo = `${window.location.origin}/auth/callback?next=/account`;
      const result =
        mode === "anonymous"
          ? await supabase.auth.updateUser(
              { email: address },
              { emailRedirectTo: redirectTo },
            )
          : await supabase.auth.signInWithOtp({
              email: address,
              options: { emailRedirectTo: redirectTo },
            });
      setMessageTone(result.error ? "error" : "success");
      setMessage(
        result.error
          ? locale === "en"
            ? "We couldn't send the email. If this address already has an account, use sign in from a clean browser session."
            : "邮件暂时没有发出。如果这个邮箱已有账户，请在无游客会话的浏览器中直接登录。"
          : locale === "en"
            ? "Check your inbox. This table identity will be ready when you return."
            : "请查看邮箱。确认后，当前餐桌身份就会被保存。",
      );
    } catch {
      setMessageTone("error");
      setMessage(
        locale === "en"
          ? "The connection was interrupted. Your email is still here; try again when the network is ready."
          : "网络连接中断了。邮箱内容还在，网络恢复后可以直接重试。",
      );
    } finally {
      setPending(false);
    }
  }

  async function signOut() {
    setPending(true);
    try {
      const { error } = await createClient().auth.signOut();
      if (error) throw error;
      router.push("/");
      router.refresh();
    } catch {
      setPending(false);
      setMessageTone("error");
      setMessage(
        locale === "en"
          ? "We couldn't sign you out. Check your connection and try again."
          : "暂时无法退出，请检查网络后重试。",
      );
    }
  }

  if (mode === "account") {
    return (
      <section className="border-y border-[#4f7d71]/45 bg-[#fffdf7]/65 p-6 sm:p-8">
        <span className="flex size-11 items-center justify-center rounded-full bg-[#dcece4] text-[#257055]">
          <Check aria-hidden="true" />
        </span>
        <h2 className="mt-5 text-2xl font-semibold">
          {locale === "en" ? "Your identity is saved" : "你的餐桌身份已保存"}
        </h2>
        <p className="mt-3 break-all text-[#52615b]">{email}</p>
        <button
          className="mt-8 inline-flex items-center gap-2 border-b border-[#24322d] pb-1 text-sm font-semibold outline-none focus-visible:ring-3 focus-visible:ring-[#b9433c]/25"
          disabled={pending}
          onClick={signOut}
          type="button"
        >
          {pending ? (
            <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />
          ) : (
            <LogOut aria-hidden="true" className="size-4" />
          )}
          {pending
            ? locale === "en"
              ? "Signing out…"
              : "正在退出…"
            : locale === "en"
              ? "Sign out"
              : "退出登录"}
        </button>
        {message ? (
          <output
            aria-live="polite"
            className="mt-4 block text-sm text-[#9a3f38]"
          >
            {message}
          </output>
        ) : null}
      </section>
    );
  }

  return (
    <section className="border-y border-[#b9433c]/35 bg-[#fffdf7]/65 p-6 sm:p-8">
      <span className="flex size-11 items-center justify-center rounded-full bg-[#f4ded7] text-[#b9433c]">
        <Mail aria-hidden="true" />
      </span>
      <h2 className="mt-5 text-2xl font-semibold">
        {locale === "en"
          ? mode === "anonymous"
            ? "Sign in or register"
            : "Sign in to your tables"
          : mode === "anonymous"
            ? "登录或注册"
            : "登录并找回餐桌"}
      </h2>
      <p className="mt-3 text-sm leading-6 text-[#52615b]">
        {locale === "en"
          ? "No password. We'll send one secure email link. Guest ordering remains available without this step."
          : "输入邮箱即可登录；新邮箱会同时完成注册。无需设置密码，我们只发送一封安全登录邮件。游客点餐仍然可用。"}
      </p>
      <form className="mt-7 space-y-4" onSubmit={submit}>
        <label className="block text-sm font-semibold" htmlFor="accountEmail">
          {locale === "en" ? "Email address" : "邮箱地址"}
        </label>
        <input
          aria-describedby={message ? "account-message" : undefined}
          autoComplete="email"
          className="h-12 w-full border border-[#24322d]/20 bg-[#fffefb] px-4 outline-none focus:border-[#b9433c]"
          id="accountEmail"
          onChange={(event) => setAddress(event.target.value)}
          placeholder={locale === "en" ? "you@example.com" : "输入你的邮箱"}
          required
          type="email"
          value={address}
        />
        <button
          className="flex h-12 w-full items-center justify-center gap-2 bg-[#b9433c] px-5 font-semibold text-white disabled:opacity-60"
          disabled={pending}
          type="submit"
        >
          {pending ? (
            <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />
          ) : null}
          {locale === "en" ? "Continue with email" : "使用邮箱继续"}
        </button>
      </form>
      {message ? (
        <output
          aria-live="polite"
          className={`mt-4 block text-sm leading-6 ${messageTone === "error" ? "text-[#9a3f38]" : "text-[#146b45]"}`}
          id="account-message"
        >
          {message}
        </output>
      ) : null}
    </section>
  );
}
