import { MessageSquareText, Users } from "lucide-react";
import type { AggregatedDish } from "@/lib/aggregation";

export function AggregationDishList({ dishes }: { dishes: AggregatedDish[] }) {
  if (!dishes.length) {
    return (
      <div className="mc-paper-empty border border-dashed p-8 text-center">
        <p className="font-bold">还没有已选菜品</p>
        <p className="mt-2 text-sm text-muted-foreground">
          成员即使只提交饮食信息，也会计入提交进度。
        </p>
      </div>
    );
  }

  return (
    <ol className="mc-convergence-list">
      {dishes.map((dish, index) => (
        <li className="mc-convergence-item overflow-hidden" key={dish.id}>
          <div className="grid gap-4 p-5 sm:grid-cols-[minmax(0,1fr)_7.5rem] sm:items-start sm:p-6">
            <div className="min-w-0">
              <div className="flex items-start gap-3">
                <span className="mc-convergence-index grid size-8 shrink-0 place-items-center font-mono text-xs font-black text-primary">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="min-w-0">
                  <h3 className="break-words text-lg font-black">
                    {dish.zhName}
                  </h3>
                  <p className="mt-1 break-words font-mono text-xs text-primary">
                    {dish.originalName}
                  </p>
                  {dish.description ? (
                    <p className="mt-2 break-words text-sm leading-6 text-muted-foreground">
                      {dish.description}
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="mc-total-ticket p-4 text-white sm:text-center">
              <p className="font-mono text-xs tracking-[0.12em] text-white/75 uppercase">
                整桌总份数
              </p>
              <p className="mt-1 font-mono text-4xl font-black tabular-nums">
                {dish.totalQuantity}
              </p>
              <p className="mt-1 flex items-center gap-1 text-xs text-white/70 sm:justify-center">
                <Users className="size-3.5" />
                {dish.contributors.length} 人
              </p>
            </div>
          </div>
          <div className="border-t border-[#24322d]/15 bg-[#efe3ce]/35 px-5 py-3 sm:px-6">
            <p className="font-mono text-xs font-semibold tracking-[0.12em] text-muted-foreground uppercase">
              数量来源
            </p>
            <ul className="mt-2 divide-y">
              {dish.contributors.map((contributor) => (
                <li
                  className="grid gap-1 py-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start sm:gap-4"
                  key={contributor.userId}
                >
                  <div className="min-w-0">
                    <p className="break-words text-sm font-bold">
                      {contributor.displayName}
                    </p>
                    {contributor.note ? (
                      <p className="mt-1 flex items-start gap-1.5 break-words text-sm leading-5 text-muted-foreground">
                        <MessageSquareText className="mt-0.5 size-3.5 shrink-0" />
                        {contributor.note}
                      </p>
                    ) : null}
                  </div>
                  <p className="font-mono text-sm font-black tabular-nums text-primary">
                    本人 {contributor.quantity} 份
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </li>
      ))}
    </ol>
  );
}
