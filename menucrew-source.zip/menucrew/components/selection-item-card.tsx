"use client";

import { Minus, Plus, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { type AppLocale, localizedMenuText } from "@/lib/i18n";
import type { MenuItem } from "@/lib/menus";
import {
  SELECTION_NOTE_MAX_LENGTH,
  SELECTION_QUANTITY_MAX,
} from "@/lib/validation";

export function SelectionItemCard({
  index,
  item,
  locale = "zh-CN",
  note,
  noteError,
  onNoteChange,
  onAskAi,
  onQuantityChange,
  quantity,
  quantityError,
  readOnly = false,
}: {
  index: number;
  item: MenuItem;
  locale?: AppLocale;
  note: string;
  noteError?: string;
  onNoteChange: (value: string) => void;
  onAskAi?: () => void;
  onQuantityChange: (value: number) => void;
  quantity: number;
  quantityError?: string;
  readOnly?: boolean;
}) {
  const selected = quantity > 0;
  const localized = localizedMenuText(item, locale);

  return (
    <li
      className={`mc-selection-stop relative px-1 py-6 transition-colors sm:px-3 ${selected ? "is-selected" : ""}`}
    >
      {selected ? (
        <span
          aria-hidden="true"
          className="mc-selection-active-line absolute inset-y-6 left-0"
        />
      ) : null}
      {selected ? (
        <span aria-hidden="true" className="mc-selection-stamp">
          {locale === "en" ? "Selected" : "已选"}
        </span>
      ) : null}
      <input name={`quantity:${item.id}`} type="hidden" value={quantity} />
      <div className="grid gap-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start">
        <div className="flex min-w-0 items-start gap-3">
          <span
            className={`mc-selection-number shrink-0 font-mono text-xs ${selected ? "font-bold" : ""}`}
          >
            {String(index + 1).padStart(2, "0")}
          </span>
          <div className="min-w-0">
            <h2 className="break-words text-lg font-bold leading-tight">
              {localized.name}
            </h2>
            <p className="mt-1 break-words font-mono text-xs leading-5 text-primary">
              {item.original_name}
            </p>
            <p className="mt-2 break-words text-sm leading-6 text-muted-foreground">
              {localized.description}
            </p>
            {onAskAi ? (
              <button
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#c85d22] hover:underline"
                onClick={onAskAi}
                type="button"
              >
                <Sparkles className="size-3.5" />{" "}
                {locale === "en" ? "Ask about this dish" : "问问这道菜"}
              </button>
            ) : null}
          </div>
        </div>

        <div
          className={`mc-quantity-stepper justify-self-start ${selected ? "is-active" : ""} sm:justify-self-end`}
        >
          <div className="flex items-center gap-2">
            <Button
              aria-label={
                locale === "en"
                  ? `Decrease my servings of ${localized.name}`
                  : `减少 ${item.zh_name} 的本人份数`
              }
              disabled={readOnly || quantity === 0}
              onClick={() => onQuantityChange(Math.max(0, quantity - 1))}
              size="icon-lg"
              type="button"
              variant="outline"
            >
              <Minus aria-hidden="true" />
            </Button>
            <output
              aria-live="polite"
              className="mc-quantity-output min-w-10 text-center font-mono text-2xl font-black tabular-nums"
            >
              <span key={quantity}>{quantity}</span>
            </output>
            <Button
              aria-label={
                locale === "en"
                  ? `Increase my servings of ${localized.name}`
                  : `增加 ${item.zh_name} 的本人份数`
              }
              disabled={readOnly || quantity === SELECTION_QUANTITY_MAX}
              onClick={() =>
                onQuantityChange(Math.min(SELECTION_QUANTITY_MAX, quantity + 1))
              }
              size="icon-lg"
              type="button"
            >
              <Plus aria-hidden="true" />
            </Button>
          </div>
          {quantityError ? (
            <p className="mt-2 max-w-40 text-xs text-destructive">
              {quantityError}
            </p>
          ) : null}
        </div>
      </div>

      {selected ? (
        <div className="mt-5 border-t border-primary/15 pt-4">
          <label className="text-sm font-semibold" htmlFor={`note-${item.id}`}>
            {locale === "en" ? "Note for this dish" : "这道菜的口味备注"}{" "}
            <span className="font-normal text-muted-foreground">
              {locale === "en" ? "(optional)" : "（可选）"}
            </span>
          </label>
          <textarea
            aria-describedby={noteError ? `note-error-${item.id}` : undefined}
            aria-invalid={Boolean(noteError)}
            className="mt-2 min-h-20 w-full resize-y rounded-xl border bg-[#fffefb] px-3 py-2 text-sm leading-6 outline-none transition focus:border-primary focus:ring-3 focus:ring-primary/15 aria-invalid:border-destructive"
            id={`note-${item.id}`}
            maxLength={SELECTION_NOTE_MAX_LENGTH}
            name={`note:${item.id}`}
            disabled={readOnly}
            onChange={(event) => onNoteChange(event.target.value)}
            placeholder={
              locale === "en"
                ? "e.g. mild spice, sauce on the side"
                : "例如：少辣、酱汁另放"
            }
            value={note}
          />
          <div className="mt-1 flex justify-between gap-3 text-xs">
            <p className="text-destructive" id={`note-error-${item.id}`}>
              {noteError}
            </p>
            <span className="ml-auto text-muted-foreground">
              {note.length}/{SELECTION_NOTE_MAX_LENGTH}
            </span>
          </div>
        </div>
      ) : null}
    </li>
  );
}
