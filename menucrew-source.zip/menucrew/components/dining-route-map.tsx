import type { CSSProperties } from "react";

const routeControls = [
  { label: "入座", x: 92, y: 702 },
  { label: "菜单", x: 244, y: 552 },
  { label: "识别", x: 438, y: 618 },
  { label: "发布", x: 586, y: 430 },
  { label: "选菜", x: 780, y: 488 },
  { label: "汇总", x: 956, y: 286 },
  { label: "落单", x: 1132, y: 178 },
] as const;

const overviewControls = [
  { label: "入座", x: 620, y: 84 },
  { label: "菜单", x: 204, y: 576 },
  { label: "识别", x: 414, y: 646 },
  { label: "发布", x: 604, y: 540 },
  { label: "选菜", x: 790, y: 630 },
  { label: "汇总", x: 970, y: 410 },
  { label: "落单", x: 1140, y: 246 },
] as const;

const spineControls = [
  { label: "入座", x: 620, y: 730 },
  { label: "菜单", x: 606, y: 628 },
  { label: "识别", x: 628, y: 526 },
  { label: "发布", x: 612, y: 424 },
  { label: "选菜", x: 630, y: 322 },
  { label: "汇总", x: 610, y: 220 },
  { label: "落单", x: 622, y: 118 },
] as const;

const routePath =
  "M92 702C140 666 197 600 244 552S364 579 438 618 525 515 586 430 705 441 780 488 899 381 956 286 1076 231 1132 178";
const overviewPath =
  "M620 84C538 198 296 445 204 576S334 608 414 646 530 580 604 540 715 590 790 630 901 506 970 410 1081 317 1140 246";
const spinePath =
  "M620 730C600 694 600 662 606 628S636 560 628 526 602 458 612 424 638 356 630 322 600 254 610 220 630 152 622 118";

export function DiningRouteMap({
  activeControl = 1,
  className = "",
  layout = "route",
  quiet = false,
}: {
  activeControl?: number;
  className?: string;
  layout?: "overview" | "route" | "spine";
  quiet?: boolean;
}) {
  const controls =
    layout === "overview"
      ? overviewControls
      : layout === "spine"
        ? spineControls
        : routeControls;
  const path =
    layout === "overview"
      ? overviewPath
      : layout === "spine"
        ? spinePath
        : routePath;
  return (
    <div
      aria-hidden="true"
      className={`mc-route-map is-${layout} ${quiet ? "is-quiet" : ""} ${className}`}
      style={
        {
          "--route-progress": Math.max(0.02, activeControl - 1),
        } as CSSProperties
      }
    >
      <svg
        aria-hidden="true"
        preserveAspectRatio="xMidYMid slice"
        viewBox="0 0 1240 820"
      >
        <g className="mc-terrain-lines">
          <path d="M-80 126C96 44 171 178 322 112S532 20 690 106s229 85 342 8 238-40 310 15" />
          <path d="M-54 160C108 82 189 215 336 151s211-89 365-4 222 86 333 14 234-32 306 22" />
          <path d="M-22 201C122 131 218 249 358 192s204-75 346 4 211 88 321 22 224-25 297 29" />
          <path d="M-70 430C88 343 176 472 314 402s244-130 390-37 201 131 330 54 212-55 309-2" />
          <path d="M-42 470C102 392 192 507 329 444s235-118 374-31 197 122 322 53 208-45 299 7" />
          <path d="M-16 516C116 448 212 549 345 492s223-101 357-19 193 111 313 50 201-36 284 15" />
          <path d="M535 845c-56-137 58-183 8-310s-111-187-45-304 187-129 160-278" />
          <path d="M584 848c-48-131 67-178 19-299S500 369 570 258 752 135 730-42" />
          <path d="M635 850c-41-124 74-171 31-286s-93-171-20-276S822 170 805-35" />
        </g>

        <g className="mc-terrain-fields">
          <path d="M74 214c62-79 183-67 220 10s-25 161-120 165S15 292 74 214Z" />
          <path d="M828 576c77-78 206-44 218 53s-84 159-177 117-112-99-41-170Z" />
          <path d="M916 53c54-43 144-23 157 45s-52 117-119 92-92-92-38-137Z" />
        </g>

        <path className="mc-route-future" d={path} pathLength="6" />
        <path className="mc-route-shadow" d={path} />
        <path className="mc-route-line" d={path} pathLength="6" />

        <g className="mc-route-controls">
          {controls.map((control, index) => {
            const number = index + 1;
            const state =
              number < activeControl
                ? "is-complete"
                : number === activeControl
                  ? "is-active"
                  : "is-future";
            return (
              <g
                className={`mc-route-control ${state}`}
                key={control.label}
                transform={`translate(${control.x} ${control.y})`}
              >
                {state === "is-active" ? (
                  <circle className="mc-route-active-halo" r="72" />
                ) : null}
                <circle r="19" />
                <text className="mc-route-number" textAnchor="middle" y="5">
                  {number}
                </text>
                <text className="mc-route-label" textAnchor="middle" y="48">
                  {control.label}
                </text>
              </g>
            );
          })}
        </g>
      </svg>
    </div>
  );
}
