import { Check, Clock3 } from "lucide-react";
import type { AggregationMember } from "@/lib/aggregation";
import type { AppLocale } from "@/lib/i18n";

export function AggregationMemberStatus({
  locale = "zh-CN",
  members,
}: {
  locale?: AppLocale;
  members: AggregationMember[];
}) {
  return (
    <section className="border-y border-[#24322d]/20 bg-[#fbf9f2]/60 p-5 sm:p-6">
      <div className="flex items-end justify-between gap-4 border-b pb-4">
        <div>
          <p className="font-mono text-[10px] font-semibold tracking-[0.16em] text-primary uppercase">
            Submission rail
          </p>
          <h2 className="mt-2 text-xl font-black">
            {locale === "en" ? "Diner progress" : "成员进度"}
          </h2>
        </div>
        <span className="font-mono text-sm font-bold tabular-nums">
          {members.filter((member) => member.submittedAt).length}/
          {members.length}
        </span>
      </div>
      <ol className="mt-5 grid gap-1">
        {members.map((member, index) => {
          const submitted = Boolean(member.submittedAt);
          return (
            <li
              className="grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-3"
              key={member.userId}
            >
              <div className="relative grid place-items-center self-stretch">
                {index < members.length - 1 ? (
                  <span className="absolute top-1/2 bottom-[-50%] w-px bg-[#d7deeb]" />
                ) : null}
                <span
                  className={`relative z-10 grid size-7 place-items-center rounded-full ${submitted ? "bg-[#dff5e8] text-[#146b45]" : "bg-[#eef1f6] text-muted-foreground"}`}
                >
                  {submitted ? (
                    <Check className="size-4" />
                  ) : (
                    <Clock3 className="size-4" />
                  )}
                </span>
              </div>
              <div className="min-w-0 py-3">
                <p className="break-words text-sm font-bold">
                  {member.displayName}
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {member.role === "organizer"
                    ? locale === "en"
                      ? "Organizer"
                      : "组织者"
                    : locale === "en"
                      ? "Diner"
                      : "成员"}
                </p>
              </div>
              <span
                className={`rounded-full px-2.5 py-1 text-xs font-semibold ${submitted ? "bg-[#eef9f2] text-[#146b45]" : "bg-[#fff5e5] text-[#9a5e0b]"}`}
              >
                {submitted
                  ? locale === "en"
                    ? "Submitted"
                    : "已提交"
                  : locale === "en"
                    ? "Waiting"
                    : "未提交"}
              </span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
