"use client";

import {
  Check,
  ChevronRight,
  ImagePlus,
  Minus,
  Plus,
  ScanLine,
  Stamp,
  TriangleAlert,
  Utensils,
} from "lucide-react";
import { useEffect, useState } from "react";
import styles from "./color-direction-lab.module.css";

type Direction = "night-voyage" | "passport" | "midnight";
type Device = "desktop" | "mobile";
type Scene = "home" | "menu" | "selection" | "confirm";

const scenes: Array<{ id: Scene; label: string }> = [
  { id: "home", label: "首页" },
  { id: "menu", label: "菜单识别" },
  { id: "selection", label: "选菜" },
  { id: "confirm", label: "最终落单" },
];

const palettes = {
  "night-voyage": [
    "#F2F7F7",
    "#12343B",
    "#006B73",
    "#315EFB",
    "#D7E85B",
    "#237A57",
    "#B42318",
  ],
  passport: ["#F1EFE8", "#182532", "#2855A6", "#C9932E", "#C64832"],
  midnight: ["#211727", "#F4E8CF", "#6D3C78", "#D2A74A", "#D7623E"],
};

function RouteMark() {
  return (
    <svg aria-hidden="true" className={styles.routeMark} viewBox="0 0 360 100">
      <path d="M-12 86 C68 82 72 18 148 30 S245 108 374 18" />
      <circle cx="48" cy="73" r="7" />
      <circle cx="151" cy="31" r="7" />
      <circle cx="258" cy="66" r="7" />
    </svg>
  );
}

function Header() {
  return (
    <header className={styles.previewHeader}>
      <div className={styles.brand}>
        <span className={styles.logoMark}>M</span>
        <strong>合点 Menu Crew</strong>
      </div>
      <span>简中 / EN</span>
    </header>
  );
}

function HomeScene() {
  return (
    <div className={`${styles.scene} ${styles.homeScene}`}>
      <Header />
      <div aria-hidden="true" className={styles.words}>
        <span>好好吃饭</span>
        <span>Bon appétit</span>
        <span>いただきます</span>
        <span>Buen provecho</span>
        <span>맛있게 드세요</span>
      </div>
      <RouteMark />
      <main className={styles.hero}>
        <span className={styles.tableSignal}>
          <Utensils />
        </span>
        <h2>语言虽异，心意同桌。</h2>
        <p>
          上传菜单，邀请同桌，各自选择。最后生成一份全桌都看得懂的双语订单。
        </p>
        <button type="button">
          发起一桌
          <ChevronRight />
        </button>
      </main>
      <ol className={styles.steps}>
        <li>
          <span>01</span>
          <strong>准备菜单</strong>
        </li>
        <li>
          <span>02</span>
          <strong>各自选菜</strong>
        </li>
        <li>
          <span>03</span>
          <strong>汇总落单</strong>
        </li>
      </ol>
    </div>
  );
}

function MenuScene() {
  return (
    <div className={`${styles.scene} ${styles.workScene}`}>
      <Header />
      <RouteMark />
      <div className={styles.workHeading}>
        <span>01</span>
        <div>
          <h2>让菜单显影。</h2>
          <p>上传原图后识别双语菜品，再由你确认发布。</p>
        </div>
      </div>
      <div className={styles.menuWorkbench}>
        <section className={styles.uploadPaper}>
          <div className={styles.photoFrame}>
            <ImagePlus />
            <strong>菜单原图</strong>
            <small>JPG · PNG · WEBP</small>
            <i />
          </div>
          <button type="button">重新选择</button>
        </section>
        <section className={styles.recognitionPaper}>
          <div className={styles.scanStatus}>
            <ScanLine />
            <span>正在识别菜单</span>
          </div>
          <ol>
            <li>
              <span>01</span>
              <div>
                <strong>经典番茄面包</strong>
                <small>Bruschetta classica</small>
              </div>
              <Check />
            </li>
            <li>
              <span>02</span>
              <div>
                <strong>肉酱宽面</strong>
                <small>Tagliatelle al ragù</small>
              </div>
              <Check />
            </li>
            <li>
              <span>03</span>
              <div>
                <strong>柠檬鸡</strong>
                <small>Pollo al limone</small>
              </div>
              <i />
            </li>
          </ol>
        </section>
      </div>
    </div>
  );
}

function Dish({
  name,
  original,
  quantity,
}: {
  name: string;
  original: string;
  quantity: number;
}) {
  return (
    <li className={quantity ? styles.selectedDish : undefined}>
      <div>
        <strong>{name}</strong>
        <small>{original}</small>
      </div>
      <div className={styles.stepper}>
        <Minus />
        <span>{quantity}</span>
        <Plus />
      </div>
    </li>
  );
}

function SelectionScene({ confirmation = false }: { confirmation?: boolean }) {
  return (
    <div className={`${styles.scene} ${styles.workScene}`}>
      <Header />
      <RouteMark />
      <div className={styles.workHeading}>
        <span>02</span>
        <div>
          <h2>这次，我想吃这些。</h2>
          <p>选自己的，不需要猜别人点了什么。</p>
        </div>
      </div>
      <ol className={styles.dishList}>
        <Dish name="经典番茄面包" original="Bruschetta classica" quantity={2} />
        <Dish name="肉酱宽面" original="Tagliatelle al ragù" quantity={1} />
        <Dish name="柠檬鸡" original="Pollo al limone" quantity={0} />
      </ol>
      <div className={styles.saveRail}>
        <span>
          <strong>3</strong> 道菜 · <strong>4</strong> 份
        </span>
        <button type="button">保存我的选择</button>
      </div>
      {confirmation ? <ConfirmationPaper /> : null}
    </div>
  );
}

function ConfirmationPaper() {
  return (
    <div className={styles.confirmBackdrop}>
      <section className={styles.confirmPaper}>
        <div className={styles.confirmRoute}>
          <i />
          <i />
          <i />
          <Stamp />
        </div>
        <h2>把这一桌，正式落单？</h2>
        <p>确认后所有成员看到同一份结果，不能再修改或撤销。</p>
        <dl>
          <div>
            <dt>已选菜品</dt>
            <dd>3 道</dd>
          </div>
          <div>
            <dt>最终数量</dt>
            <dd>4 份</dd>
          </div>
        </dl>
        <div className={styles.allergyNote}>
          <TriangleAlert />
          <span>
            <strong>过敏提醒</strong>
            M2 对花生过敏，请向餐厅再次确认。
          </span>
        </div>
        <div className={styles.confirmActions}>
          <button type="button">继续核对</button>
          <button type="button">确认落单</button>
        </div>
      </section>
    </div>
  );
}

function ScenePreview({ scene }: { scene: Scene }) {
  if (scene === "home") return <HomeScene />;
  if (scene === "menu") return <MenuScene />;
  if (scene === "confirm") return <SelectionScene confirmation />;
  return <SelectionScene />;
}

export function ColorDirectionLab() {
  const [direction, setDirection] = useState<Direction>("night-voyage");
  const [device, setDevice] = useState<Device>("desktop");
  const [scene, setScene] = useState<Scene>("home");
  const directionName =
    direction === "night-voyage"
      ? "夜航青"
      : direction === "passport"
        ? "青花护照"
        : "午夜餐桌";

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requestedTheme = params.get("theme");
    const requestedDevice = params.get("device");
    const requestedScene = params.get("scene");

    if (
      requestedTheme === "night-voyage" ||
      requestedTheme === "passport" ||
      requestedTheme === "midnight"
    ) {
      setDirection(requestedTheme);
    }
    if (requestedDevice === "desktop" || requestedDevice === "mobile") {
      setDevice(requestedDevice);
    }
    if (scenes.some((item) => item.id === requestedScene)) {
      setScene(requestedScene as Scene);
    }
  }, []);

  return (
    <main className={styles.lab}>
      <header className={styles.labHeader}>
        <div>
          <p>Menu Crew · Color Study</p>
          <h1>
            同一张餐桌，
            <br />
            三种颜色世界。
          </h1>
          <span>结构、文案和交互保持一致，只比较色彩气质。</span>
        </div>
        <div className={styles.directionPicker}>
          <button
            aria-pressed={direction === "night-voyage"}
            onClick={() => setDirection("night-voyage")}
            type="button"
          >
            <span>N</span>
            夜航青
            <small>清醒 · 协作 · 跨语言</small>
          </button>
          <button
            aria-pressed={direction === "passport"}
            onClick={() => setDirection("passport")}
            type="button"
          >
            <span>A</span>
            青花护照
            <small>明亮 · 国际 · 克制</small>
          </button>
          <button
            aria-pressed={direction === "midnight"}
            onClick={() => setDirection("midnight")}
            type="button"
          >
            <span>B</span>
            午夜餐桌
            <small>浓郁 · 戏剧 · 夜宴</small>
          </button>
        </div>
      </header>

      <nav aria-label="预览场景" className={styles.scenePicker}>
        <div>
          {scenes.map((item) => (
            <button
              aria-pressed={scene === item.id}
              key={item.id}
              onClick={() => setScene(item.id)}
              type="button"
            >
              {item.label}
            </button>
          ))}
        </div>
        <div>
          <button
            aria-pressed={device === "desktop"}
            onClick={() => setDevice("desktop")}
            type="button"
          >
            桌面
          </button>
          <button
            aria-pressed={device === "mobile"}
            onClick={() => setDevice("mobile")}
            type="button"
          >
            手机
          </button>
        </div>
      </nav>

      <section className={styles.comparisonStage} data-theme={direction}>
        <div className={styles.stageMeta}>
          <div>
            <span>
              {direction === "night-voyage"
                ? "N"
                : direction === "passport"
                  ? "A"
                  : "B"}
            </span>
            <div>
              <strong>{directionName}</strong>
              <small>
                {direction === "night-voyage"
                  ? "Petrol · Signal Blue · Pomelo"
                  : direction === "passport"
                    ? "Porcelain · Cobalt · Cinnabar"
                    : "Aubergine · Brass · Persimmon"}
              </small>
            </div>
          </div>
          <ul aria-label={`${directionName} 色板`}>
            {palettes[direction].map((color) => (
              <li key={color} style={{ backgroundColor: color }}>
                <span>{color}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className={styles.deviceStage} data-device={device}>
          <div className={styles.browserChrome}>
            <i />
            <i />
            <i />
            <span>menucrew.app / {scene}</span>
          </div>
          <div className={styles.viewport}>
            <ScenePreview scene={scene} />
          </div>
        </div>
      </section>

      <footer className={styles.labFooter}>
        <p>
          当前查看：<strong>{directionName}</strong> ·{" "}
          {device === "desktop" ? "桌面端" : "手机端"} ·{" "}
          {scenes.find((item) => item.id === scene)?.label}
        </p>
        <span>N 是新的夜航青；A 和 B 保留为旧方向对照。</span>
      </footer>
    </main>
  );
}
