---
name: "合点 Menu Crew"
description: "一张持续展开的用餐路线图，让不同语言最终汇聚为同一桌双语订单。"
colors:
  map-paper: "#F4F1E8"
  paper-surface: "#FBF9F2"
  receipt-paper: "#FFFDF9"
  ink: "#24322D"
  action-coral: "#B9433C"
  action-on-coral: "#FFFFFF"
  terrain-green: "#4F7C70"
  contour-ochre: "#C28A42"
  annotation-wash: "#EFE3CE"
  muted-surface: "#E9E6DC"
  muted-ink: "#5B6863"
  rule: "#CFCABD"
  success-ink: "#146B45"
  warning-ink: "#9A5E0B"
typography:
  display:
    fontFamily: '"Noto Sans SC", "Microsoft YaHei", sans-serif'
    fontSize: "clamp(3.5rem, 4vw, 4.75rem)"
    fontWeight: 650
    lineHeight: 1
    letterSpacing: "-0.033em"
  headline:
    fontFamily: '"Geist", "Noto Sans SC", "Microsoft YaHei", ui-sans-serif, sans-serif'
    fontSize: "clamp(2rem, 5vw, 3.8rem)"
    fontWeight: 760
    lineHeight: 0.98
    letterSpacing: "-0.04em"
  title:
    fontFamily: '"Geist", "Noto Sans SC", "Microsoft YaHei", ui-sans-serif, sans-serif'
    fontSize: "1.25rem"
    fontWeight: 800
    lineHeight: 1.25
  body:
    fontFamily: '"Geist", "Geist Fallback", ui-sans-serif, system-ui, sans-serif'
    fontSize: "1rem"
    fontWeight: 400
    lineHeight: 1.75
  label:
    fontFamily: '"Geist Mono", "Geist Mono Fallback", ui-monospace, monospace'
    fontSize: "0.625rem"
    fontWeight: 700
    lineHeight: 1.4
    letterSpacing: "0.14em"
rounded:
  sm: "0.45rem"
  md: "0.6rem"
  lg: "0.75rem"
  xl: "1.05rem"
  2xl: "1.35rem"
  full: "999px"
spacing:
  xs: "0.25rem"
  sm: "0.5rem"
  md: "0.75rem"
  lg: "1rem"
  xl: "1.5rem"
  2xl: "2rem"
  section: "3rem"
components:
  button-primary:
    backgroundColor: "{colors.action-coral}"
    textColor: "{colors.action-on-coral}"
    rounded: "{rounded.lg}"
    padding: "0.75rem 1.25rem"
    height: "3rem"
  button-outline:
    backgroundColor: "{colors.map-paper}"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
    padding: "0.75rem 1.25rem"
    height: "3rem"
  input:
    backgroundColor: "{colors.receipt-paper}"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
    padding: "0.75rem 1rem"
    height: "3rem"
  control-marker-current:
    backgroundColor: "{colors.action-coral}"
    textColor: "{colors.action-on-coral}"
    rounded: "{rounded.full}"
    size: "2.375rem"
  control-marker-complete:
    backgroundColor: "{colors.terrain-green}"
    textColor: "{colors.action-on-coral}"
    rounded: "{rounded.full}"
    size: "2.375rem"
  map-window:
    backgroundColor: "{colors.paper-surface}"
    textColor: "{colors.ink}"
    rounded: "0"
    padding: "1.5rem"
  receipt:
    backgroundColor: "{colors.receipt-paper}"
    textColor: "{colors.ink}"
    rounded: "0"
    padding: "2rem"
---

# Design System: 合点 Menu Crew

## Overview

**Creative North Star: "同桌定向图 · The Shared-Table Orienteering Map"**

本规范固化代码主导的 Impeccable 方向种子 `b013bc00`，对应已选视觉世界 `notation-diagram-systems-orienteering-map`；最终成品审阅结论为 **SHIP**。

合点不是一组互相独立的 SaaS 页面，而是一张从“入座”延伸到“落单”的连续用餐地图。温暖的地图纸始终铺在界面底层，等高线、地形色块、珊瑚色路线、编号控制点和记录纸共同说明进度：地图稳定不动，人的选择沿路线向同一张桌子汇聚。

系统的表达来自标注、测绘与餐桌纸品，而非写实餐厅摄影。产品标志是路线的署名；中文、English 与多语言短句既是内容，也构成低对比度的语言地形。工作界面保持清晰、克制、可操作，关键动作始终先于氛围效果。

**Key Characteristics:**

- 暖地图纸上的深色油墨，少量高辨识度珊瑚色标记行动。
- 面向用户只呈现三步：准备菜单、各自选菜、汇总落单；入座、识别、发布等细分状态只用于系统内部定位，不与三步并列展示。
- 已完成、当前、未来三种路线状态持续可见，形成方向感而非向导式断页。
- 菜单记录、选择停靠点、汇聚轨道和最终小票随流程逐步改变材料形态。
- 首页与房间导航始终只讲“准备菜单、各自选菜、汇总落单”三步；进入房间后，路线收束为中央低对比“旅程脊柱”，只让当前任务拥有清晰视觉重量。
- 短促、可关闭的路线动效；`prefers-reduced-motion` 下完整保留信息与状态。
- 首页语言地形在精细指针设备上形成克制的“引力场”：近处短句避让指针、中心内容轻微产生景深；触屏与减少动态模式回退为稳定漂移和静态排版。
- 餐桌纸品不是装饰贴图，而是任务状态：菜单纸用于上传与识别、记录纸用于个人选择、收敛线用于整桌汇总，最终只在确认完成时形成有抬升感的订单小票。

## Colors

色彩像印在旧地图纸上的有限油墨：珊瑚负责行动与当前位置，绿色负责已完成与汇聚，赭色只描绘地形和提醒，深墨色承担全部正文。

### Primary

- **Action Coral:** 唯一主要行动色，用于主按钮、当前控制点、路线、焦点环与关键编号；它必须保持稀缺，不能变成大面积装饰。

### Secondary

- **Terrain Green:** 表示完成、稳定、整桌汇聚与成功数量；不与珊瑚争夺当前操作焦点。

### Tertiary

- **Contour Ochre:** 用于等高线、批注感底色、饮食提醒与地图细节；它提供食物与纸张的温度，不承担主操作。

### Neutral

- **Map Paper:** 全局稳定地形和页面底色。
- **Paper Surface:** 半透明工作纸、路线记录与常规容器。
- **Receipt Paper:** 仅用于需要更干净对比的表单、弹窗与最终小票。
- **Ink:** 标题、正文、边界和高对比度结构线。
- **Muted Ink:** 说明、辅助标签、未来状态与非主导信息。
- **Rule:** 输入边线、分隔线和地图纸上的细线。
- **Muted Surface:** 禁用、次要状态和轻量分区。

**The Route-Ink Rule.** 珊瑚表示“现在该做什么”，绿色表示“已经抵达什么”；不要交换两者的语义。

**The Paper-First Rule.** 大面积背景只使用地图纸及其近邻纸色，绝不以纯白卡片海洋取代地形。

**The One-Climax Rule.** 每个阶段只允许一个动效高潮：首页是语言引力场，菜单页是照片显影，选菜页是落笔盖章，最终页是三路汇合成小票；其他反馈必须让位于当前任务。

## Typography

**Display Font:** Noto Sans SC（回退到 Microsoft YaHei 与 sans-serif）  
**Body Font:** Geist（回退到系统无衬线字体）  
**Label/Mono Font:** Geist Mono（回退到系统等宽字体）

**Character:** 中文标题紧凑、直接，像地图上的主地名；Geist 让双语正文保持现代和高可读性；Geist Mono 把编号、数量、时间和菜单原文变成可核对的记录数据。

### Hierarchy

- **Display**（650，流体 56–76px，行高 1）：首页宣言，仅允许短行、强节奏的两行中文。
- **Headline**（760，流体 32–61px，行高 0.98）：每个控制点的任务标题，与大号圆形编号共同出现。
- **Title**（800，20px，行高 1.25）：工作段落、菜品、汇总与小票标题。
- **Body**（400，16px，行高 1.75）：解释与任务说明；手机可收至 14px，但保持 1.5 以上行高。
- **Label**（700，10px，字距 0.14em，通常大写）：控制标签、数量字段、记录编号和小票元数据。

**The Record-Type Rule.** 只有编号、数量、菜单原文、时间和短元数据使用等宽体；长说明和操作文案始终使用正文体。

## Layout

页面以 1248px 最大宽度为桌面地图边界，左右页边距为 24px；手机边距为 16px。房间页在大屏采用约 0.72/1.28 的双区布局：左侧负责控制点、标题、说明和角色上下文，右侧承载当前工作纸；宽内容页可合并为单列。垂直节奏以 8px 为基础，常用内部间距为 16px、24px，主要区段间距为 32–48px。

首页与房间导航都只用三步解释全程，禁止同时出现三步与七站两套编号。底图仍可保留七个内部控制点作为抽象路线，但编号与标签必须隐藏。进入房间后，桌面与手机只保留位于画面中央的低对比“旅程脊柱”：非当前节点显著降调，路线不穿过或竞争主要操作。标题编号缩至 42px，工作纸可贴近屏幕边缘。

路线记录遵循同一序列：菜单条目沿细轨排列，个人选择成为可点亮的停靠点，汇总与最终数量沿绿到珊瑚的收敛轨道排列，确认结果最终进入居中的小票。主要保存或确认区在长表单底部吸附，保持全宽、清晰且不被背景动画影响。

**The Stable-Terrain Rule.** 页面切换改变路线进度和当前工作纸，不重新发明背景构图；用户必须感觉自己仍在同一张地图上。

**The Overview-to-Leg Rule.** 首页的前景总览负责讲清全程；进入工作页后，背景只提示“正在一条连续路线中”，不再重复展示七组数字和文字。

## Elevation & Depth

系统默认是扁平的纸上分层。深度主要由纸色差、透明叠层、边线、虚线、角标和路线覆盖关系产生，而不是普遍的悬浮阴影。阴影只出现在真正脱离桌面的对象：创建聚餐弹窗、最终小票和长表单的底部吸附操作栏。

### Shadow Vocabulary

- **Action Lift** (`0 12px 28px rgb(228 95 75 / 0.17)`): 仅首页主行动按钮；悬停时轻微增强。
- **Sticky Rail** (`0 -14px 36px rgb(36 50 45 / 0.12)`): 长表单底部的保存与确认轨道，强调它悬在滚动内容上方。
- **Receipt Lift** (`0 24px 60px rgb(36 50 45 / 0.13)`): 最终订单小票，表示已经从路线记录收束为可递交的成品。
- **Modal Lift** (`0 30px 90px rgb(33 31 29 / 0.22)`): 模态表单的最高层级；背景同时使用克制模糊。

**The Flat-Until-Final Rule.** 普通工作容器不投影；只有模态、吸附操作和最终产物可以离开纸面。

## Shapes

路线与状态标记使用完整圆形，表达控制点、抵达和数量。常规交互控件采用 12px 左右的柔和圆角；弹窗可扩大到 24px。地图窗口、汇总记录、数量面板与最终小票则保留直角或近直角，依靠细边线、角部珊瑚取景框、虚线与冲孔缺口形成测绘和纸品感。

边框通常为 1px 深墨低透明度；决定性区域可使用 2px 珊瑚或深墨边线。不要把所有内容都装进同一种圆角卡片：圆角是交互舒适度，直角与纸边才是世界观。

**The Marker-vs-Paper Rule.** 圆形属于控制点与状态，直线和纸边属于记录与结果；两种几何必须共同存在。

## Components

### Buttons

- **Shape:** 常规按钮为柔和圆角（约 12px）；首页“发起一桌”是唯一的大胶囊主按钮。
- **Primary:** 珊瑚底、白字，高风险最终动作仍使用同一行动语义，并以周围 2px 决策边界加强。
- **Hover / Focus:** 悬停只做轻微色深或上移；键盘焦点使用可见的 3px 珊瑚色半透明环，外移焦点不可被裁切。
- **Secondary / Ghost:** 描边按钮落在地图纸上；幽灵按钮只用于视图切换和次要导航。禁用状态降低透明度但保留标签可读性。

### Chips

- **Style:** 胶囊只用于阶段、角色、确认/只读和风险等短状态，不承载长文案。
- **State:** 当前阶段使用珊瑚实底，已完成或成功使用浅绿底与深绿字，提醒使用浅赭底与棕色字。

### Cards / Containers

- **Corner Style:** 通用库卡片可用 12px 圆角，但核心旅程优先使用地图窗口、上下纸边或路线记录。
- **Background:** 纸面白与半透明纸色，允许绿色地形洗色或赭色批注洗色作为局部语义层。
- **Shadow Strategy:** 默认无阴影，遵循 Flat-Until-Final Rule。
- **Border:** 1px 低对比深墨线；地图窗口在左上和右下加珊瑚取景角。
- **Internal Padding:** 手机通常 16–20px，桌面通常 24px。

### Inputs / Fields

- **Style:** 干净的收据纸底、1px 规则线、12px 圆角，最小高度 48px；标签始终位于字段外部。
- **Focus:** 边线切换为珊瑚，并出现 3px 低透明度焦点环；文本光标同为珊瑚。
- **Error / Disabled:** 错误使用明确文字、图标和暖红洗色，不能只依赖颜色；只读状态保留原内容并给出原因。

### Navigation

品牌标志与“合点 Menu Crew”固定在页头左侧，语言切换固定在右侧。房间旅程导航以小号编号控制点和连接线横向排列：可用项有完整对比和悬停反馈，未来项降至约半透明并不可点击。窄屏允许水平滚动，不缩小到无法触达。

### Dining Route Map

底图内部控制点顺序仍为“入座 / 菜单 / 识别 / 发布 / 选菜 / 汇总 / 落单”，但对用户的文字与编号统一折叠为“1 准备菜单 / 2 各自选菜 / 3 汇总落单”。已完成点为绿色实心，当前点为珊瑚实心并获得一次抵达动效，未来点为空心且整体降调；已走路线为珊瑚实线，未来路线为珊瑚虚线。赭色等高线、绿色地形块与内页多语言短句永远低对比、不可交互、对辅助技术隐藏。

房间工作页采用中央旅程脊柱变体：路径集中在画面中央窄带，隐藏节点数字和文字，整体透明度低于前景纸张；首页底图同样隐藏编号与标签，完整信息只在前景总览出现。菜单上传与识别并排时不得使用独立吸顶，以确保两块工作区顶部基线一致。

### Route Records and Convergence Rails

菜单和选择记录使用编号圆点加细竖轨；选中菜品增加珊瑚左边线和淡色水平洗色。汇总与最终核对使用由绿色渐变到珊瑚的收敛轨道，数量块以大号等宽数字突出，来源与备注保留在同一记录下方。

### Final Receipt

最终订单是少数允许显著投影的容器。它使用干净收据纸、虚线分隔、顶部冲孔缺口和只读确认章；“给餐厅看 / 中文核对”只切换同一快照的呈现，不能制造第二张订单或不同的视觉真相。

### Motion

三大章节之间使用同一个圆形控制点完成共享元素转场：只有“准备菜单 / 各自选菜 / 汇总落单”跨阶段导航播放约 1.3–1.5 秒的完整覆盖与抵达；同一阶段内的查看、修改、AI 批注和返回使用约 540ms 的细墨线过渡，不重复打断操作。首页创建房间先用约 1.4 秒让语言地形退场并从主按钮绘出餐桌路线，再提交创建。接口较慢时全屏圆内显示“正在抵达下一站”，最多等待 4 秒便解除遮罩，绝不永久阻塞页面。

菜单显影台把抽象菜单纸、用户选择的真实照片、扫描线和识别结果视为同一个对象的连续状态。扫描线只在真实处理中以约 3 秒一轮自上而下运行；成功后取景框转绿并停止循环，失败时保留原图并在操作附近给出恢复提示。页面工作纸、路线绘制与首页多语言地形采用更从容的 650–1550ms 叙事节奏，按钮按压、悬停和错误提示仍保持 100–300ms 的即时反馈；在 `prefers-reduced-motion: reduce` 下取消覆盖、路径绘制、扫描、缩放与位移，只保留 100–150ms 以内的透明度变化和完整静态状态。

内页多语言地形随阶段改变语义：菜单阶段围绕阅读与识别，选菜阶段围绕“我想吃 / 来一份”，汇总阶段围绕确认与分享。数量控件从 0 变为正数时将路线点填墨并盖出“已选”批注；汇总列表沿绿到珊瑚的轨道展开，最终收束成小票。AI 助手以餐桌边缘展开的侍者批注纸呈现，不再使用通用居中对话卡片。

## Do's and Don'ts

### Do:

- **Do** 让每个房间页面明确对应三大阶段之一，并延续同一张底图与同一状态语义；七个内部控制点只作为隐藏的路线几何。
- **Do** 用编号、轨道、虚线、取景角、批注洗色和小票边缘组织信息。
- **Do** 保持主要操作至少 48px 高，并提供可见键盘焦点、文字错误说明和不依赖颜色的状态标签。
- **Do** 让双语菜名、原文、数量和时间具有稳定层级；用等宽体帮助快速核对数字与记录。
- **Do** 在手机工作页聚焦当前路段，首页和内页都只展示三步信息架构。
- **Do** 保留 Menu Crew 标志与多语言地形；语言应像地图背景一样低对比且不抢占操作。
- **Do** 让跨三大阶段的路由变化播放完整抵达反馈，同阶段路由只使用轻量墨线反馈；服务器动作或浏览器历史跳转按阶段差异补播相应反馈。

### Don't:

- **Don't** 把界面退化为均匀圆角、统一投影的 SaaS 卡片网格。
- **Don't** 用大面积珊瑚装饰背景，或让未来状态与当前状态拥有相同视觉重量。
- **Don't** 用写实餐厅摄影替代菜单纸、油墨、路线、批注和小票的抽象材料语言。
- **Don't** 让地形、视差或路线动画接收点击、进入可访问性树，或拖慢主要任务反馈。
- **Don't** 只用颜色传递完成、当前、未来、错误或只读状态。
- **Don't** 在最终确认后引入可编辑外观，或把餐厅视图与中文核对视图表现成两份不同订单。
- **Don't** 在同一视口同时展示“三步”和“七站”两套流程编号。
