import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
if (!url || !key) throw new Error("请先配置公开 Supabase 变量。");

const client = () =>
  createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });

async function signIn(target, label) {
  const { data, error } = await target.auth.signInAnonymously();
  if (error || !data.user)
    throw new Error(`${label}匿名登录失败：${error?.message ?? "没有用户"}`);
}

async function save(target, roomId, selections, dietary = "", allergy = "") {
  const { error } = await target.rpc("save_my_selection", {
    candidate_allergy_info: allergy,
    candidate_dietary_restrictions: dietary,
    candidate_room_id: roomId,
    candidate_selections: selections,
  });
  if (error) throw error;
}

const dishes = [
  ["Paella de verduras", "蔬菜西班牙饭", "藏红花米饭与时令蔬菜"],
  ["Pollo al ajillo", "蒜香鸡", "蒜、橄榄油与香草烹制的鸡肉"],
  ["Ensalada de tomate", "番茄沙拉", "番茄、洋葱与橄榄油"],
  ["Patatas bravas", "辣味炸土豆", "炸土豆配烟熏红椒酱"],
  ["Tortilla española", "西班牙土豆蛋饼", "土豆、鸡蛋与洋葱"],
  ["Pan con tomate", "番茄面包", "烤面包配番茄与橄榄油"],
  ["Crema catalana", "加泰罗尼亚焦糖布丁", "柑橘香草蛋奶布丁"],
  ["Sorbete de limón", "柠檬雪葩", "清爽柠檬冰品"],
];

const organizer = client();
const memberA = client();
const memberB = client();
await Promise.all([
  signIn(organizer, "演示组织者"),
  signIn(memberA, "演示成员 A"),
  signIn(memberB, "演示成员 B"),
]);

const inviteToken = randomBytes(32).toString("base64url");
const inviteDigest = createHash("sha256").update(inviteToken).digest("hex");
const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "演示组织者",
  invite_digest: inviteDigest,
  room_name: `MenuCrew 完整演示 ${new Date().toISOString().slice(0, 10)}`,
});
if (roomError || !roomId) throw new Error("创建演示房间失败。");
for (const [target, name] of [
  [memberA, "演示成员 A"],
  [memberB, "演示成员 B"],
]) {
  const { error } = await target.rpc("join_room", {
    display_name: name,
    invite_digest: inviteDigest,
  });
  if (error) throw error;
}

const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError) throw menuInsertError;
const { data: menu, error: menuError } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
if (menuError || !menu) throw new Error("创建演示菜单失败。");

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const storagePath = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(storagePath, png, { contentType: "image/png" });
if (uploadError) throw uploadError;
const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.length,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "synthetic-spanish-menu.png",
  position: 0,
  storage_path: storagePath,
});
if (imageError) throw imageError;

const { data: items, error: itemsError } = await organizer
  .from("menu_items")
  .insert(
    dishes.map(([original_name, zh_name, description], index) => ({
      description,
      menu_id: menu.id,
      original_name,
      position: index * 100,
      zh_name,
    })),
  )
  .select("id,position")
  .order("position");
if (itemsError || items.length !== 8) throw new Error("写入演示菜品失败。");
const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw publishError;

await save(organizer, roomId, [
  { menuItemId: items[0].id, note: "少盐", quantity: 1 },
  { menuItemId: items[2].id, note: "酱汁另放", quantity: 1 },
]);
await save(memberA, roomId, [
  { menuItemId: items[0].id, note: "", quantity: 1 },
  { menuItemId: items[1].id, note: "", quantity: 1 },
  { menuItemId: items[6].id, note: "", quantity: 1 },
]);
await save(
  memberB,
  roomId,
  [
    { menuItemId: items[3].id, note: "少辣", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
  "不吃香菜",
);

const { data: closed, error: closeError } = await organizer.rpc(
  "set_selection_collection_status",
  { candidate_room_id: roomId, candidate_status: "reviewing" },
);
if (closeError || !closed?.[0]) throw new Error("关闭演示收集失败。");
const finalQuantities = [2, 1, 1, 1, 0, 0, 1, 1];
const { data: orderId, error: orderError } = await organizer.rpc(
  "confirm_final_order",
  {
    candidate_items: items.map((item, index) => ({
      finalQuantity: finalQuantities[index],
      menuItemId: item.id,
      note: index === 0 ? "三人分享，少盐" : "",
    })),
    candidate_room_id: roomId,
    candidate_source_revision: closed[0].new_revision,
  },
);
if (orderError || !orderId) throw new Error("确认演示订单失败。");
const { data: visibleItems, error: readError } = await memberA
  .from("order_items")
  .select("id,final_quantity")
  .eq("order_id", orderId);
if (
  readError ||
  visibleItems.length !== 6 ||
  visibleItems.reduce((sum, item) => sum + item.final_quantity, 0) !== 7
)
  throw new Error("演示成员读取最终订单失败。");

console.log(
  JSON.stringify(
    {
      finalDishes: visibleItems.length,
      finalQuantity: 7,
      orderId,
      roomId,
      shareUrl: `${siteUrl.replace(/\/$/, "")}/join/${inviteToken}`,
      verified: "三名隔离身份、8 道菜单、3 份提交、双语最终订单",
    },
    null,
    2,
  ),
);
