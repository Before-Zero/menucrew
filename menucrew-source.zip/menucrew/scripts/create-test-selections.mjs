import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

if (!supabaseUrl || !publishableKey) {
  throw new Error("请先在 .env.local 配置公开 Supabase 变量。");
}

function testClient() {
  return createClient(supabaseUrl, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
}

async function anonymous(client, label) {
  const { data, error } = await client.auth.signInAnonymously();
  if (error || !data.user) {
    throw new Error(
      `${label}匿名登录失败：${error?.message ?? "没有返回用户"}`,
    );
  }
  return data.user.id;
}

async function join(client, inviteDigest, displayName) {
  const { error } = await client.rpc("join_room", {
    display_name: displayName,
    invite_digest: inviteDigest,
  });
  if (error) throw new Error(`${displayName}加入失败：${error.message}`);
}

async function save(client, roomId, input) {
  const { data, error } = await client.rpc("save_my_selection", {
    candidate_allergy_info: input.allergyInfo,
    candidate_dietary_restrictions: input.dietaryRestrictions,
    candidate_room_id: roomId,
    candidate_selections: input.selections,
  });
  if (error || !data) {
    throw new Error(`保存选择失败：${error?.message ?? "没有返回提交"}`);
  }
  return data;
}

const dishes = [
  ["Margherita Pizza", "玛格丽特披萨", "番茄、马苏里拉与罗勒的经典披萨"],
  ["Spaghetti alle Vongole", "蛤蜊意面", "白葡萄酒风味的蛤蜊意面"],
  ["Vitello Tonnato", "金枪鱼酱小牛肉", "冷切小牛肉配顺滑金枪鱼酱"],
  ["Melanzane alla Parmigiana", "帕玛森焗茄子", "茄子、番茄与奶酪分层烘烤"],
  ["Fritto Misto", "意式混合炸海鲜", "轻炸鱿鱼、虾与时蔬"],
  ["Risotto ai Funghi", "蘑菇烩饭", "奶油口感的综合蘑菇烩饭"],
  ["Pollo alla Cacciatora", "猎人式炖鸡", "番茄、香草与橄榄炖鸡"],
  ["Tiramisu", "提拉米苏", "咖啡与马斯卡彭奶酪甜点"],
];

const organizer = testClient();
const memberA = testClient();
const memberB = testClient();
const memberC = testClient();
const organizerId = await anonymous(organizer, "组织者");
const memberAId = await anonymous(memberA, "成员 A");
const memberBId = await anonymous(memberB, "成员 B");
const memberCId = await anonymous(memberC, "成员 C");
const inviteToken = randomBytes(32).toString("base64url");
const inviteDigest = createHash("sha256").update(inviteToken).digest("hex");

const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "003 测试组织者",
  invite_digest: inviteDigest,
  room_name: `003 成员选择验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId) {
  throw new Error(`创建房间失败：${roomError?.message ?? "没有返回房间"}`);
}

await Promise.all([
  join(memberA, inviteDigest, "成员 A"),
  join(memberB, inviteDigest, "成员 B"),
  join(memberC, inviteDigest, "成员 C"),
]);

const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError)
  throw new Error(`建立菜单失败：${menuInsertError.message}`);
const { data: menu, error: menuReadError } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
if (menuReadError || !menu) {
  throw new Error(`读取菜单失败：${menuReadError?.message ?? "没有返回菜单"}`);
}

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const storagePath = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(storagePath, png, { contentType: "image/png" });
if (uploadError) throw new Error(`上传图片失败：${uploadError.message}`);

const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.byteLength,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "003-self-made-menu.png",
  position: 0,
  storage_path: storagePath,
});
if (imageError) throw new Error(`登记图片失败：${imageError.message}`);

const { data: items, error: itemsError } = await organizer
  .from("menu_items")
  .insert(
    dishes.map(([original_name, zh_name, description], index) => ({
      description,
      menu_id: menu.id,
      original_name,
      position: index * 100,
      zh_name,
    })),
  )
  .select("id,position")
  .order("position");
if (itemsError || items.length !== dishes.length) {
  throw new Error(`写入菜品失败：${itemsError?.message ?? "数量不符"}`);
}

const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw new Error(`发布菜单失败：${publishError.message}`);

const submissionA = await save(memberA, roomId, {
  allergyInfo: "花生过敏",
  dietaryRestrictions: "不吃香菜",
  selections: [
    { menuItemId: items[0].id, note: "少盐", quantity: 2 },
    { menuItemId: items[2].id, note: "", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
    { menuItemId: items[1].id, note: "不会落库", quantity: 0 },
  ],
});
const submissionB = await save(memberB, roomId, {
  allergyInfo: "",
  dietaryRestrictions: "素食之外可吃蛋奶",
  selections: [
    { menuItemId: items[1].id, note: "", quantity: 1 },
    { menuItemId: items[2].id, note: "不要辣", quantity: 2 },
  ],
});
const submissionC = await save(memberC, roomId, {
  allergyInfo: "贝类过敏",
  dietaryRestrictions: "",
  selections: items.map((item) => ({
    menuItemId: item.id,
    note: "",
    quantity: 0,
  })),
});

for (const [label, client, expectedId, expectedRows, expectedTotal] of [
  ["A", memberA, submissionA, 3, 4],
  ["B", memberB, submissionB, 2, 3],
  ["C", memberC, submissionC, 0, 0],
]) {
  const { data: submissions, error: submissionError } = await client
    .from("member_submissions")
    .select("id,dietary_restrictions,allergy_info")
    .eq("room_id", roomId);
  if (
    submissionError ||
    submissions.length !== 1 ||
    submissions[0].id !== expectedId
  ) {
    throw new Error(`成员 ${label} 本人提交隔离验证失败。`);
  }
  const { data: selections, error: selectionError } = await client
    .from("member_selections")
    .select("quantity,note")
    .eq("submission_id", expectedId);
  const total = selections?.reduce((sum, row) => sum + row.quantity, 0) ?? -1;
  if (
    selectionError ||
    selections.length !== expectedRows ||
    total !== expectedTotal
  ) {
    throw new Error(`成员 ${label} 数量恢复验证失败。`);
  }
}

const { data: leakedSubmission, error: leakError } = await memberA
  .from("member_submissions")
  .select("id")
  .eq("id", submissionB);
if (leakError || leakedSubmission.length !== 0) {
  throw new Error("隐私验证失败：成员 A 读到了成员 B 的提交。");
}

const { error: directWriteError } = await memberA
  .from("member_selections")
  .insert({
    menu_item_id: items[3].id,
    quantity: 1,
    submission_id: submissionA,
  });
if (!directWriteError)
  throw new Error("权限验证失败：客户端可以直接写选择表。");

const { error: duplicateError } = await memberA.rpc("save_my_selection", {
  candidate_allergy_info: "会回滚",
  candidate_dietary_restrictions: "会回滚",
  candidate_room_id: roomId,
  candidate_selections: [
    { menuItemId: items[0].id, note: "", quantity: 1 },
    { menuItemId: items[0].id, note: "", quantity: 2 },
  ],
});
if (!duplicateError?.message.includes("duplicate_menu_item")) {
  throw new Error("原子验证失败：重复菜品请求没有被拒绝。");
}

const { data: unchanged, error: unchangedError } = await memberA
  .from("member_submissions")
  .select("dietary_restrictions,allergy_info")
  .eq("id", submissionA)
  .single();
if (
  unchangedError ||
  unchanged.dietary_restrictions !== "不吃香菜" ||
  unchanged.allergy_info !== "花生过敏"
) {
  throw new Error("原子验证失败：无效请求覆盖了原有提交。");
}

console.log(
  JSON.stringify(
    {
      itemCount: items.length,
      memberIds: { A: memberAId, B: memberBId, C: memberCId },
      menuId: menu.id,
      organizerId,
      roomId,
      shareUrl: `${siteUrl.replace(/\/$/, "")}/join/${inviteToken}`,
      submissions: { A: submissionA, B: submissionB, C: submissionC },
      verified: {
        A: "3 dishes / 4 portions",
        B: "2 dishes / 3 portions",
        C: "0 dishes / 0 portions",
        atomicRollback: true,
        directTableWriteDenied: true,
        ownerOnlyRead: true,
      },
    },
    null,
    2,
  ),
);
