import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
if (!url || !key) throw new Error("请先配置公开 Supabase 变量。");

const client = () =>
  createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });

async function signIn(target, label) {
  const { data, error } = await target.auth.signInAnonymously();
  if (error || !data.user) {
    throw new Error(
      `${label}匿名登录失败：${error?.message ?? "没有返回用户"}`,
    );
  }
  return data.user.id;
}

const organizer = client();
const member = client();
const outsider = client();
await signIn(organizer, "组织者");
await signIn(member, "成员");
await signIn(outsider, "非成员");

const token = randomBytes(32).toString("base64url");
const digest = createHash("sha256").update(token).digest("hex");
const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "006 测试组织者",
  invite_digest: digest,
  room_name: `006 AI 菜单验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId) throw new Error("创建测试房间失败");
const { error: joinError } = await member.rpc("join_room", {
  display_name: "006 测试成员",
  invite_digest: digest,
});
if (joinError) throw joinError;

const { error: menuError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuError) throw menuError;
const { data: menu } = await organizer
  .from("menus")
  .select("id,status")
  .eq("room_id", roomId)
  .single();

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const path = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(path, png, { contentType: "image/png" });
if (uploadError) throw uploadError;
const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.length,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "006-private-menu.png",
  position: 0,
  storage_path: path,
});
if (imageError) throw imageError;

const originalItems = [
  {
    description: "人工数据一",
    menu_id: menu.id,
    original_name: "Manual Dish One",
    position: 0,
    zh_name: "人工菜一",
  },
  {
    description: "人工数据二",
    menu_id: menu.id,
    original_name: "Manual Dish Two",
    position: 100,
    zh_name: "人工菜二",
  },
];
const { error: itemError } = await organizer
  .from("menu_items")
  .insert(originalItems);
if (itemError) throw itemError;

const candidate = {
  items: [
    {
      category: "Pasta",
      description: "蛤蜊、白葡萄酒与欧芹意面",
      originalName: "Spaghetti alle Vongole",
      uncertainty: "请向餐厅确认是否含黄油",
      zhName: "蛤蜊意面",
    },
    {
      category: "Dessert",
      description: "咖啡与马斯卡彭奶酪甜点",
      originalName: "Tiramisù",
      uncertainty: "",
      zhName: "提拉米苏",
    },
  ],
};

async function start(target, inputDigest) {
  return target
    .rpc("start_menu_ai_run", {
      candidate_input_digest: inputDigest,
      candidate_model: "gemini-3.6-flash",
      candidate_room_id: roomId,
    })
    .single();
}
async function finishSuccess(runId) {
  const { error } = await organizer.rpc("finish_menu_ai_run", {
    candidate_error_code: null,
    candidate_error_message: null,
    candidate_provider_response_id: "resp_006_test",
    candidate_result: candidate,
    candidate_run_id: runId,
    candidate_status: "succeeded",
  });
  if (error) throw error;
}
async function finishFailure(runId, number) {
  const { error } = await organizer.rpc("finish_menu_ai_run", {
    candidate_error_code: "simulated_failure",
    candidate_error_message: `模拟失败 ${number}`,
    candidate_provider_response_id: null,
    candidate_result: null,
    candidate_run_id: runId,
    candidate_status: "failed",
  });
  if (error) throw error;
}

const firstDigest = createHash("sha256").update("006-success").digest("hex");
const { data: first, error: firstError } = await start(organizer, firstDigest);
if (firstError || !first || first.reused) throw new Error("首次记录创建失败");
await finishSuccess(first.run_id);

const reusedIds = [];
for (let attempt = 0; attempt < 5; attempt += 1) {
  const { data, error } = await start(organizer, firstDigest);
  if (error || !data?.reused) throw new Error("成功记录未复用");
  reusedIds.push(data.run_id);
}
if (new Set(reusedIds).size !== 1 || reusedIds[0] !== first.run_id) {
  throw new Error("重复输入返回了不同记录");
}

const { data: memberRuns, error: memberReadError } = await member
  .from("menu_ai_runs")
  .select("id")
  .eq("room_id", roomId);
if (memberReadError || memberRuns.length !== 0) {
  throw new Error("成员读到了私有识别记录");
}
const { data: outsiderRuns, error: outsiderReadError } = await outsider
  .from("menu_ai_runs")
  .select("id")
  .eq("room_id", roomId);
if (outsiderReadError || outsiderRuns.length !== 0) {
  throw new Error("非成员读到了私有识别记录");
}
const memberStart = await start(member, firstDigest);
if (!memberStart.error) throw new Error("成员启动识别未被拒绝");
const memberApply = await member.rpc("apply_menu_ai_run", {
  candidate_run_id: first.run_id,
});
if (!memberApply.error) throw new Error("成员应用候选未被拒绝");
const directWrite = await organizer.from("menu_ai_runs").insert({
  input_digest: firstDigest,
  menu_id: menu.id,
  model: "forbidden",
  requested_by: (await organizer.auth.getUser()).data.user.id,
  room_id: roomId,
});
if (!directWrite.error) throw new Error("浏览器直接写识别记录未被拒绝");

const beforeFailure = await organizer
  .from("menu_items")
  .select("original_name,zh_name,description,position")
  .eq("menu_id", menu.id)
  .order("position");
for (let number = 1; number <= 4; number += 1) {
  const failedDigest = createHash("sha256")
    .update(`006-failure-${number}`)
    .digest("hex");
  const { data, error } = await start(organizer, failedDigest);
  if (error || !data) throw new Error(`失败记录 ${number} 创建失败`);
  await finishFailure(data.run_id, number);
}
const limitedDigest = createHash("sha256").update("006-limited").digest("hex");
const limited = await start(organizer, limitedDigest);
if (!limited.error?.message.includes("menu_ai_rate_limited")) {
  throw new Error("第 6 次不同输入未被限流");
}
const afterFailure = await organizer
  .from("menu_items")
  .select("original_name,zh_name,description,position")
  .eq("menu_id", menu.id)
  .order("position");
if (JSON.stringify(beforeFailure.data) !== JSON.stringify(afterFailure.data)) {
  throw new Error("识别失败改变了人工草稿");
}

const { data: appliedCount, error: applyError } = await organizer.rpc(
  "apply_menu_ai_run",
  { candidate_run_id: first.run_id },
);
if (applyError || appliedCount !== 2) throw new Error("应用候选失败");
const { data: afterApply } = await organizer
  .from("menus")
  .select("status")
  .eq("id", menu.id)
  .single();
if (afterApply.status !== "draft") throw new Error("AI 自动发布了菜单");
const { data: generated } = await organizer
  .from("menu_items")
  .select("id,original_name,zh_name,description,position")
  .eq("menu_id", menu.id)
  .order("position");
if (
  generated.length !== 2 ||
  generated[0].original_name !== "Spaghetti alle Vongole" ||
  !generated[0].description.includes("待确认")
) {
  throw new Error("候选结构应用不正确");
}
const { error: manualEditError } = await organizer
  .from("menu_items")
  .update({ zh_name: "人工修正的蛤蜊意面" })
  .eq("id", generated[0].id);
if (manualEditError) throw new Error("应用后无法人工修正");
await organizer.rpc("apply_menu_ai_run", { candidate_run_id: first.run_id });
const { data: corrected } = await organizer
  .from("menu_items")
  .select("zh_name")
  .eq("id", generated[0].id)
  .single();
if (corrected.zh_name !== "人工修正的蛤蜊意面") {
  throw new Error("重复应用覆盖了人工修正");
}

console.log(
  JSON.stringify(
    {
      appliedCount,
      directWriteDenied: Boolean(directWrite.error),
      failurePreservedDraft: true,
      memberApplyDenied: Boolean(memberApply.error),
      memberReadIsolated: memberRuns.length === 0,
      rateLimitVerified: true,
      reusedRunId: first.run_id,
      roomId,
      statusAfterApply: afterApply.status,
    },
    null,
    2,
  ),
);
