import { createHash, randomBytes } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

if (!supabaseUrl || !publishableKey) {
  throw new Error(
    "请先在 .env.local 配置 NEXT_PUBLIC_SUPABASE_URL 和 NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY。",
  );
}

function createTestClient() {
  return createClient(supabaseUrl, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
}

async function signInAnonymously(client, label) {
  const { data, error } = await client.auth.signInAnonymously();

  if (error || !data.user) {
    throw new Error(
      `${label}匿名登录失败：${error?.message ?? "没有返回用户"}`,
    );
  }

  return data.user.id;
}

const organizer = createTestClient();
const member = createTestClient();
const codeMember = createTestClient();
const organizerId = await signInAnonymously(organizer, "组织者");
const memberId = await signInAnonymously(member, "成员");
const codeMemberId = await signInAnonymously(codeMember, "数字码成员");
const inviteToken = randomBytes(32).toString("base64url");
const inviteDigest = createHash("sha256").update(inviteToken).digest("hex");

const { data: roomId, error: createError } = await organizer.rpc(
  "create_room",
  {
    display_name: "测试组织者",
    invite_digest: inviteDigest,
    room_name: `001 验收房间 ${new Date().toISOString()}`,
  },
);

if (createError || !roomId) {
  throw new Error(
    `创建测试房间失败：${createError?.message ?? "没有返回房间"}`,
  );
}

const { data: joinedRoomId, error: joinError } = await member.rpc("join_room", {
  display_name: "测试成员",
  invite_digest: inviteDigest,
});

if (joinError || joinedRoomId !== roomId) {
  throw new Error(`加入测试房间失败：${joinError?.message ?? "房间不一致"}`);
}

const { data: room, error: roomError } = await organizer
  .from("rooms")
  .select("join_code")
  .eq("id", roomId)
  .single();

if (roomError || !room?.join_code) {
  throw new Error(`读取入席码失败：${roomError?.message ?? "没有返回入席码"}`);
}

const { data: codeJoinedRoomId, error: codeJoinError } = await codeMember.rpc(
  "join_room_by_code",
  { display_name: "数字码成员", room_code: room.join_code },
);

if (codeJoinError || codeJoinedRoomId !== roomId) {
  throw new Error(`数字码加入失败：${codeJoinError?.message ?? "房间不一致"}`);
}

console.log(
  JSON.stringify(
    {
      memberId,
      codeMemberId,
      joinCode: room.join_code,
      organizerId,
      roomId,
      shareUrl: `${siteUrl.replace(/\/$/, "")}/join/${inviteToken}`,
    },
    null,
    2,
  ),
);
