import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
if (!url || !key) throw new Error("请先配置公开 Supabase 变量。");

const client = () =>
  createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });

async function signIn(target, label) {
  const { data, error } = await target.auth.signInAnonymously();
  if (error || !data.user)
    throw new Error(`${label}匿名登录失败：${error?.message ?? "没有用户"}`);
  return data.user.id;
}

async function save(target, roomId, itemId, quantity) {
  const { error } = await target.rpc("save_my_selection", {
    candidate_allergy_info: "贝类过敏",
    candidate_dietary_restrictions: "",
    candidate_room_id: roomId,
    candidate_selections: [
      { menuItemId: itemId, note: "请确认不含其他贝类", quantity },
    ],
  });
  if (error) throw error;
}

async function businessSnapshot(target, roomId, menuId) {
  const submissions = await target
    .from("member_submissions")
    .select("id,user_id,dietary_restrictions,allergy_info,submitted_at")
    .eq("room_id", roomId)
    .order("id");
  const ids = submissions.data?.map((row) => row.id) ?? [];
  const [room, menu, selections, orders] = await Promise.all([
    target
      .from("rooms")
      .select("id,selection_status,selection_revision")
      .eq("id", roomId)
      .single(),
    target
      .from("menu_items")
      .select("id,original_name,zh_name,description,position")
      .eq("menu_id", menuId)
      .order("position"),
    ids.length
      ? target
          .from("member_selections")
          .select("submission_id,menu_item_id,quantity,note")
          .in("submission_id", ids)
          .order("submission_id")
      : Promise.resolve({ data: [], error: null }),
    target.from("orders").select("id,source_revision").eq("room_id", roomId),
  ]);
  for (const result of [room, menu, submissions, selections, orders]) {
    if (result.error) throw result.error;
  }
  return JSON.stringify({
    menu: menu.data,
    orders: orders.data,
    room: room.data,
    selections: selections.data,
    submissions: submissions.data,
  });
}

const organizer = client();
const member = client();
const outsider = client();
const organizerId = await signIn(organizer, "组织者");
await signIn(member, "成员");
await signIn(outsider, "非成员");

const token = randomBytes(32).toString("base64url");
const digest = createHash("sha256").update(token).digest("hex");
const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "007 测试组织者",
  invite_digest: digest,
  room_name: `007 整桌建议验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId) throw new Error("创建 007 测试房间失败");
const { error: joinError } = await member.rpc("join_room", {
  display_name: "007 测试成员",
  invite_digest: digest,
});
if (joinError) throw joinError;

const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError) throw menuInsertError;
const { data: menu, error: menuError } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
if (menuError || !menu) throw new Error("建立菜单失败");
const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const storagePath = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(storagePath, png, { contentType: "image/png" });
if (uploadError) throw uploadError;
const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.length,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "007-fixed-menu.png",
  position: 0,
  storage_path: storagePath,
});
if (imageError) throw imageError;
const { data: items, error: itemsError } = await organizer
  .from("menu_items")
  .insert([
    {
      description: "蛤蜊、白葡萄酒与欧芹意面",
      menu_id: menu.id,
      original_name: "Spaghetti alle Vongole",
      position: 0,
      zh_name: "蛤蜊意面",
    },
    {
      description: "奶油蘑菇米饭",
      menu_id: menu.id,
      original_name: "Risotto ai Funghi",
      position: 100,
      zh_name: "蘑菇烩饭",
    },
    {
      description: "番茄与马苏里拉奶酪披萨",
      menu_id: menu.id,
      original_name: "Pizza Margherita",
      position: 200,
      zh_name: "玛格丽特披萨",
    },
    {
      description: "番茄罗勒汤",
      menu_id: menu.id,
      original_name: "Zuppa di Pomodoro",
      position: 300,
      zh_name: "番茄汤",
    },
    {
      description: "香草烤鸡",
      menu_id: menu.id,
      original_name: "Pollo Arrosto",
      position: 400,
      zh_name: "香草烤鸡",
    },
    {
      description: "时令蔬菜沙拉",
      menu_id: menu.id,
      original_name: "Insalata Mista",
      position: 500,
      zh_name: "混合沙拉",
    },
    {
      description: "咖啡奶酪甜点",
      menu_id: menu.id,
      original_name: "Tiramisu",
      position: 600,
      zh_name: "提拉米苏",
    },
    {
      description: "柠檬冰淇淋",
      menu_id: menu.id,
      original_name: "Gelato al Limone",
      position: 700,
      zh_name: "柠檬冰淇淋",
    },
  ])
  .select("id,position")
  .order("position");
if (itemsError || items.length !== 8) throw new Error("写入菜品失败");
const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw publishError;
await save(member, roomId, items[0].id, 1);

const { data: roomBefore } = await organizer
  .from("rooms")
  .select("selection_revision")
  .eq("id", roomId)
  .single();
const inputDigest = createHash("sha256")
  .update("007-fixed-conflict-snapshot")
  .digest("hex");
const adviceResult = {
  items: [
    {
      detail:
        "M2 填写了贝类过敏，同时选择了蛤蜊意面。不要据此判断安全，应先向餐厅确认原料和交叉接触风险。",
      evidence: "M2：贝类过敏；蛤蜊意面 × 1。",
      risk: "critical",
      title: "贝类过敏与蛤蜊意面存在明显冲突",
      type: "allergy",
    },
  ],
};

async function start(target, sourceRevision, candidateDigest) {
  return target
    .rpc("start_room_advice", {
      candidate_input_digest: candidateDigest,
      candidate_model: "gemini-3.6-flash",
      candidate_room_id: roomId,
      candidate_source_revision: sourceRevision,
    })
    .single();
}

const before = await businessSnapshot(organizer, roomId, menu.id);
const first = await start(
  organizer,
  roomBefore.selection_revision,
  inputDigest,
);
if (first.error || !first.data || first.data.disposition !== "created")
  throw new Error("首次建议记录创建失败");
const { error: finishError } = await organizer.rpc("finish_room_advice", {
  candidate_advice_id: first.data.advice_id,
  candidate_error_code: null,
  candidate_error_message: null,
  candidate_provider_response_id: "resp_007_test",
  candidate_result: adviceResult,
  candidate_status: "succeeded",
});
if (finishError) throw finishError;
const after = await businessSnapshot(organizer, roomId, menu.id);
if (before !== after) throw new Error("建议生成改变了业务数据");

for (let attempt = 0; attempt < 5; attempt += 1) {
  const repeated = await start(
    organizer,
    roomBefore.selection_revision,
    inputDigest,
  );
  if (
    repeated.error ||
    repeated.data?.disposition !== "reused" ||
    repeated.data.advice_id !== first.data.advice_id
  )
    throw new Error("相同输入没有复用成功建议");
}

const { data: memberRows, error: memberReadError } = await member
  .from("room_advice")
  .select("id")
  .eq("room_id", roomId);
if (memberReadError || memberRows.length !== 0)
  throw new Error("普通成员读到了组织者建议");
const memberStart = await start(
  member,
  roomBefore.selection_revision,
  inputDigest,
);
if (!memberStart.error?.message.includes("room_advice_access_denied"))
  throw new Error("普通成员启动建议未被拒绝");
const outsiderStart = await start(
  outsider,
  roomBefore.selection_revision,
  inputDigest,
);
if (!outsiderStart.error?.message.includes("room_advice_access_denied"))
  throw new Error("非成员启动建议未被拒绝");
const directWrite = await organizer.from("room_advice").insert({
  input_digest: inputDigest,
  model: "forbidden",
  requested_by: organizerId,
  room_id: roomId,
  source_revision: roomBefore.selection_revision,
});
if (!directWrite.error) throw new Error("浏览器直接写建议表未被拒绝");

for (let number = 1; number <= 4; number += 1) {
  const failureDigest = createHash("sha256")
    .update(`007-failure-${number}`)
    .digest("hex");
  const created = await start(
    organizer,
    roomBefore.selection_revision,
    failureDigest,
  );
  if (created.error || !created.data) throw new Error("创建失败记录失败");
  const { error } = await organizer.rpc("finish_room_advice", {
    candidate_advice_id: created.data.advice_id,
    candidate_error_code: "simulated_failure",
    candidate_error_message: `模拟失败 ${number}`,
    candidate_provider_response_id: null,
    candidate_result: null,
    candidate_status: "failed",
  });
  if (error) throw error;
}
const limitedDigest = createHash("sha256").update("007-limited").digest("hex");
const limited = await start(
  organizer,
  roomBefore.selection_revision,
  limitedDigest,
);
if (!limited.error?.message.includes("room_advice_rate_limited"))
  throw new Error("第 6 次不同输入未被限流");

await save(member, roomId, items[0].id, 2);
const { data: roomAfterChange } = await organizer
  .from("rooms")
  .select("selection_revision")
  .eq("id", roomId)
  .single();
const { data: savedAdvice } = await organizer
  .from("room_advice")
  .select("source_revision,result")
  .eq("id", first.data.advice_id)
  .single();
if (
  roomAfterChange.selection_revision === savedAdvice.source_revision ||
  savedAdvice.result?.items?.[0]?.type !== "allergy"
)
  throw new Error("成员修改后旧建议没有形成可判定的过期状态");

console.log(
  JSON.stringify(
    {
      adviceId: first.data.advice_id,
      businessDataUnchanged: true,
      conflict: adviceResult.items[0].title,
      directWriteDenied: true,
      memberReadIsolated: true,
      rateLimitVerified: true,
      reusedFiveTimes: true,
      roomId,
      staleAfterRevisionChange: true,
    },
    null,
    2,
  ),
);
