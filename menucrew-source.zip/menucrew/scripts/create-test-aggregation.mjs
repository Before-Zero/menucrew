import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

if (!supabaseUrl || !publishableKey) {
  throw new Error("请先在 .env.local 配置公开 Supabase 变量。");
}

function testClient() {
  return createClient(supabaseUrl, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
}

async function anonymous(client, label) {
  const { data, error } = await client.auth.signInAnonymously();
  if (error || !data.user) {
    throw new Error(
      `${label}匿名登录失败：${error?.message ?? "没有返回用户"}`,
    );
  }
  return data.user.id;
}

async function join(client, inviteDigest, displayName) {
  const { error } = await client.rpc("join_room", {
    display_name: displayName,
    invite_digest: inviteDigest,
  });
  if (error) throw new Error(`${displayName}加入失败：${error.message}`);
}

async function save(client, roomId, input) {
  const { data, error } = await client.rpc("save_my_selection", {
    candidate_allergy_info: input.allergyInfo,
    candidate_dietary_restrictions: input.dietaryRestrictions,
    candidate_room_id: roomId,
    candidate_selections: input.selections,
  });
  if (error || !data) {
    throw new Error(`保存选择失败：${error?.message ?? "没有返回提交"}`);
  }
  return data;
}

const dishData = [
  ["Margherita Pizza", "玛格丽特披萨", "番茄、马苏里拉与罗勒"],
  ["Spaghetti alle Vongole", "蛤蜊意面", "白葡萄酒风味蛤蜊意面"],
  ["Vitello Tonnato", "金枪鱼酱小牛肉", "冷切小牛肉配金枪鱼酱"],
  ["Melanzane alla Parmigiana", "帕玛森焗茄子", "茄子、番茄与奶酪"],
  ["Fritto Misto", "意式混合炸海鲜", "轻炸鱿鱼、虾与时蔬"],
  ["Risotto ai Funghi", "蘑菇烩饭", "奶油综合蘑菇烩饭"],
  ["Pollo alla Cacciatora", "猎人式炖鸡", "番茄、香草与橄榄炖鸡"],
  ["Tiramisu", "提拉米苏", "咖啡与马斯卡彭奶酪甜点"],
];

const organizer = testClient();
const memberA = testClient();
const memberB = testClient();
const memberC = testClient();
const memberD = testClient();
const outsider = testClient();
await Promise.all([
  anonymous(organizer, "组织者"),
  anonymous(memberA, "成员 A"),
  anonymous(memberB, "成员 B"),
  anonymous(memberC, "成员 C"),
  anonymous(memberD, "成员 D"),
  anonymous(outsider, "跨房间组织者"),
]);

const inviteToken = randomBytes(32).toString("base64url");
const inviteDigest = createHash("sha256").update(inviteToken).digest("hex");
const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "004 测试组织者",
  invite_digest: inviteDigest,
  room_name: `004 精确汇总验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId) {
  throw new Error(`创建房间失败：${roomError?.message ?? "没有返回房间"}`);
}

await Promise.all([
  join(memberA, inviteDigest, "成员 A"),
  join(memberB, inviteDigest, "成员 B"),
  join(memberC, inviteDigest, "成员 C"),
  join(memberD, inviteDigest, "成员 D"),
]);

const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError)
  throw new Error(`建立菜单失败：${menuInsertError.message}`);
const { data: menu, error: menuError } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
if (menuError || !menu) throw new Error("读取菜单失败。");

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const storagePath = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(storagePath, png, { contentType: "image/png" });
if (uploadError) throw new Error(`上传验收图片失败：${uploadError.message}`);
const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.byteLength,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "004-fixed-menu.png",
  position: 0,
  storage_path: storagePath,
});
if (imageError) throw new Error(`登记验收图片失败：${imageError.message}`);

const { data: items, error: itemsError } = await organizer
  .from("menu_items")
  .insert(
    dishData.map(([original_name, zh_name, description], position) => ({
      description,
      menu_id: menu.id,
      original_name,
      position: position * 100,
      zh_name,
    })),
  )
  .select("id,position")
  .order("position");
if (itemsError || items.length !== 8) throw new Error("写入 8 道菜失败。");
const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw new Error(`发布菜单失败：${publishError.message}`);

await save(organizer, roomId, {
  allergyInfo: "",
  dietaryRestrictions: "不吃香菜",
  selections: [
    { menuItemId: items[0].id, note: "少盐", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
});
const submissionA = await save(memberA, roomId, {
  allergyInfo: "花生过敏",
  dietaryRestrictions: "",
  selections: [
    { menuItemId: items[0].id, note: "少辣", quantity: 2 },
    { menuItemId: items[2].id, note: "", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
});
await save(memberB, roomId, {
  allergyInfo: "",
  dietaryRestrictions: "",
  selections: [
    { menuItemId: items[1].id, note: "", quantity: 1 },
    { menuItemId: items[2].id, note: "不要辣", quantity: 2 },
  ],
});
await save(memberC, roomId, {
  allergyInfo: "贝类过敏",
  dietaryRestrictions: "",
  selections: items.map((item) => ({
    menuItemId: item.id,
    note: "",
    quantity: 0,
  })),
});

const { data: submissions, error: submissionsError } = await organizer
  .from("member_submissions")
  .select("id,user_id")
  .eq("room_id", roomId);
if (submissionsError || submissions.length !== 4) {
  throw new Error("提交状态人工答案不符：应为 4/5。 ");
}
const { data: selections, error: selectionsError } = await organizer
  .from("member_selections")
  .select("submission_id,menu_item_id,quantity,note")
  .in(
    "submission_id",
    submissions.map((submission) => submission.id),
  );
if (selectionsError) throw new Error("组织者读取全员明细失败。");
const totals = new Map(items.map((item) => [item.id, 0]));
for (const selection of selections) {
  totals.set(
    selection.menu_item_id,
    (totals.get(selection.menu_item_id) ?? 0) + selection.quantity,
  );
}
const expected = [3, 1, 3, 0, 0, 0, 0, 2];
if (items.some((item, index) => totals.get(item.id) !== expected[index])) {
  throw new Error("逐菜人工答案不符。");
}
if ([...totals.values()].reduce((sum, value) => sum + value, 0) !== 9) {
  throw new Error("整桌人工答案不符：应为 9 份。");
}

const { data: memberAVisible } = await memberA
  .from("member_submissions")
  .select("id")
  .eq("room_id", roomId);
if (memberAVisible?.length !== 1 || memberAVisible[0].id !== submissionA) {
  throw new Error("成员读取隔离失败。");
}

const closeResult = await organizer.rpc("set_selection_collection_status", {
  candidate_room_id: roomId,
  candidate_status: "reviewing",
});
if (closeResult.error || closeResult.data?.[0]?.new_status !== "reviewing") {
  throw new Error(`关闭收集失败：${closeResult.error?.message ?? "状态不符"}`);
}
const closedRevision = closeResult.data[0].new_revision;
const repeatClose = await organizer.rpc("set_selection_collection_status", {
  candidate_room_id: roomId,
  candidate_status: "reviewing",
});
if (repeatClose.data?.[0]?.new_revision !== closedRevision) {
  throw new Error("重复关闭错误地递增了修订号。");
}

const blockedSave = await memberA.rpc("save_my_selection", {
  candidate_allergy_info: "会回滚",
  candidate_dietary_restrictions: "会回滚",
  candidate_room_id: roomId,
  candidate_selections: [
    { menuItemId: items[0].id, note: "错误覆盖", quantity: 3 },
  ],
});
if (!blockedSave.error?.message.includes("collection_closed")) {
  throw new Error("关闭后成员保存没有被数据层拒绝。");
}

const outsiderResult = await outsider.rpc("set_selection_collection_status", {
  candidate_room_id: roomId,
  candidate_status: "open",
});
if (!outsiderResult.error?.message.includes("room_access_denied")) {
  throw new Error("跨房间身份错误地取得了状态控制权。");
}

const reopenResult = await organizer.rpc("set_selection_collection_status", {
  candidate_room_id: roomId,
  candidate_status: "open",
});
if (reopenResult.error)
  throw new Error(`重新开放失败：${reopenResult.error.message}`);
await save(memberA, roomId, {
  allergyInfo: "花生过敏",
  dietaryRestrictions: "",
  selections: [
    { menuItemId: items[0].id, note: "少辣", quantity: 3 },
    { menuItemId: items[2].id, note: "", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
});

console.log(
  JSON.stringify(
    {
      expectedBeforeReopen: {
        dishTotals: [3, 1, 3, 2],
        selectedDishes: 4,
        submitted: "4/5",
        totalQuantity: 9,
      },
      finalTotalAfterMemberAUpdate: 10,
      roomId,
      shareUrl: `${siteUrl.replace(/\/$/, "")}/join/${inviteToken}`,
      summaryUrl: `${siteUrl.replace(/\/$/, "")}/rooms/${roomId}/summary`,
      verified: {
        closedSaveRejected: true,
        idempotentClose: true,
        memberIsolation: true,
        organizerFullRead: true,
        outsiderControlDenied: true,
        reopenedSaveSucceeded: true,
      },
    },
    null,
    2,
  ),
);
