import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

if (!supabaseUrl || !publishableKey) {
  throw new Error("请先在 .env.local 配置公开 Supabase 变量。");
}

function testClient() {
  return createClient(supabaseUrl, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
}

async function anonymous(client, label) {
  const { data, error } = await client.auth.signInAnonymously();
  if (error || !data.user)
    throw new Error(
      `${label}匿名登录失败：${error?.message ?? "没有返回用户"}`,
    );
  return data.user.id;
}

const dishes = [
  ["Margherita Pizza", "玛格丽特披萨", "番茄、马苏里拉与罗勒的经典披萨"],
  ["Spaghetti alle Vongole", "蛤蜊意面", "白葡萄酒风味的蛤蜊意面"],
  ["Vitello Tonnato", "金枪鱼酱小牛肉", "冷切小牛肉配顺滑金枪鱼酱"],
  ["Melanzane alla Parmigiana", "帕玛森焗茄子", "茄子、番茄与奶酪分层烘烤"],
  ["Fritto Misto", "意式混合炸海鲜", "轻炸鱿鱼、虾与时蔬"],
  ["Risotto ai Funghi", "蘑菇烩饭", "奶油口感的综合蘑菇烩饭"],
  ["Pollo alla Cacciatora", "猎人式炖鸡", "番茄、香草与橄榄炖鸡"],
  ["Tiramisu", "提拉米苏", "咖啡与马斯卡彭奶酪甜点"],
];

const organizer = testClient();
const member = testClient();
const organizerId = await anonymous(organizer, "组织者");
const memberId = await anonymous(member, "成员");
const inviteToken = randomBytes(32).toString("base64url");
const inviteDigest = createHash("sha256").update(inviteToken).digest("hex");

const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "002 测试组织者",
  invite_digest: inviteDigest,
  room_name: `002 菜单验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId)
  throw new Error(`创建房间失败：${roomError?.message ?? "没有返回房间"}`);

const { error: joinError } = await member.rpc("join_room", {
  display_name: "002 测试成员",
  invite_digest: inviteDigest,
});
if (joinError) throw new Error(`成员加入失败：${joinError.message}`);

const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError)
  throw new Error(`建立菜单失败：${menuInsertError.message}`);
const { data: menu, error: menuReadError } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
if (menuReadError || !menu)
  throw new Error(`读取菜单失败：${menuReadError?.message ?? "没有返回菜单"}`);

const { data: draftMemberMenu, error: draftReadError } = await member
  .from("menus")
  .select("id")
  .eq("room_id", roomId);
if (draftReadError || draftMemberMenu.length !== 0)
  throw new Error("草稿隔离验证失败：成员读到了草稿菜单。");

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const storagePath = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(storagePath, png, { contentType: "image/png" });
if (uploadError) throw new Error(`上传图片失败：${uploadError.message}`);

const { data: image, error: imageError } = await organizer
  .from("menu_images")
  .insert({
    byte_size: png.byteLength,
    menu_id: menu.id,
    mime_type: "image/png",
    original_name: "002-self-made-menu.png",
    position: 0,
    storage_path: storagePath,
  })
  .select("id")
  .single();
if (imageError || !image)
  throw new Error(`登记图片失败：${imageError?.message ?? "没有返回图片"}`);

const { error: itemsError } = await organizer.from("menu_items").insert(
  dishes.map(([original_name, zh_name, description], index) => ({
    description,
    menu_id: menu.id,
    original_name,
    position: index * 100,
    zh_name,
  })),
);
if (itemsError) throw new Error(`写入菜品失败：${itemsError.message}`);

const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw new Error(`发布菜单失败：${publishError.message}`);

const { data: memberItems, error: memberReadError } = await member
  .from("menu_items")
  .select("id,position")
  .eq("menu_id", menu.id)
  .order("position");
if (memberReadError || memberItems.length !== dishes.length)
  throw new Error("发布读取验证失败：成员没有读到完整菜单。");
const { data: memberImages, error: memberImageError } = await member
  .from("menu_images")
  .select("id")
  .eq("menu_id", menu.id);
if (memberImageError || memberImages.length !== 0)
  throw new Error("图片隐私验证失败：成员读到了图片元数据。");

console.log(
  JSON.stringify(
    {
      imageId: image.id,
      itemCount: memberItems.length,
      memberId,
      menuId: menu.id,
      organizerId,
      roomId,
      shareUrl: `${siteUrl.replace(/\/$/, "")}/join/${inviteToken}`,
      status: "published",
      storagePath,
    },
    null,
    2,
  ),
);
