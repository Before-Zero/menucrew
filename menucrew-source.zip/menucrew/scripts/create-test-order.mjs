import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
if (!url || !key) throw new Error("请先配置公开 Supabase 变量。");
const client = () =>
  createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
  });
async function anon(c, label) {
  const { data, error } = await c.auth.signInAnonymously();
  if (error || !data.user) throw new Error(`${label}登录失败`);
  return data.user.id;
}
async function join(c, digest, name) {
  const { error } = await c.rpc("join_room", {
    display_name: name,
    invite_digest: digest,
  });
  if (error) throw error;
}
async function save(c, roomId, selections, dietary = "", allergy = "") {
  const { error } = await c.rpc("save_my_selection", {
    candidate_allergy_info: allergy,
    candidate_dietary_restrictions: dietary,
    candidate_room_id: roomId,
    candidate_selections: selections,
  });
  if (error) throw error;
}

const organizer = client();
const memberA = client();
const memberB = client();
const memberC = client();
const memberD = client();
const outsider = client();
await Promise.all([
  anon(organizer, "组织者"),
  anon(memberA, "A"),
  anon(memberB, "B"),
  anon(memberC, "C"),
  anon(memberD, "D"),
  anon(outsider, "外部身份"),
]);
const token = randomBytes(32).toString("base64url");
const digest = createHash("sha256").update(token).digest("hex");
const { data: roomId, error: roomError } = await organizer.rpc("create_room", {
  display_name: "005 测试组织者",
  invite_digest: digest,
  room_name: `005 最终订单验收 ${new Date().toISOString()}`,
});
if (roomError || !roomId) throw new Error("创建房间失败");
await Promise.all([
  join(memberA, digest, "成员 A"),
  join(memberB, digest, "成员 B"),
  join(memberC, digest, "成员 C"),
  join(memberD, digest, "成员 D"),
]);
const { error: menuInsertError } = await organizer
  .from("menus")
  .insert({ room_id: roomId });
if (menuInsertError) throw menuInsertError;
const { data: menu } = await organizer
  .from("menus")
  .select("id")
  .eq("room_id", roomId)
  .single();
const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nS8AAAAASUVORK5CYII=",
  "base64",
);
const path = `${roomId}/${menu.id}/${randomUUID()}.png`;
const { error: uploadError } = await organizer.storage
  .from("menu-images")
  .upload(path, png, { contentType: "image/png" });
if (uploadError) throw uploadError;
const { error: imageError } = await organizer.from("menu_images").insert({
  byte_size: png.length,
  menu_id: menu.id,
  mime_type: "image/png",
  original_name: "005-menu.png",
  position: 0,
  storage_path: path,
});
if (imageError) throw imageError;
const dishes = [
  ["Margherita Pizza", "玛格丽特披萨"],
  ["Spaghetti alle Vongole", "蛤蜊意面"],
  ["Vitello Tonnato", "金枪鱼酱小牛肉"],
  ["Melanzane alla Parmigiana", "帕玛森焗茄子"],
  ["Fritto Misto", "意式混合炸海鲜"],
  ["Risotto ai Funghi", "蘑菇烩饭"],
  ["Pollo alla Cacciatora", "猎人式炖鸡"],
  ["Tiramisu", "提拉米苏"],
];
const { data: items, error: itemsError } = await organizer
  .from("menu_items")
  .insert(
    dishes.map(([original_name, zh_name], index) => ({
      description: `005 固定菜品 ${index + 1}`,
      menu_id: menu.id,
      original_name,
      position: index * 100,
      zh_name,
    })),
  )
  .select("id,position")
  .order("position");
if (itemsError || items.length !== 8) throw new Error("菜品写入失败");
const { error: publishError } = await organizer
  .from("menus")
  .update({ status: "published" })
  .eq("id", menu.id);
if (publishError) throw publishError;
await save(
  organizer,
  roomId,
  [
    { menuItemId: items[0].id, note: "少盐", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
  "不吃香菜",
);
await save(
  memberA,
  roomId,
  [
    { menuItemId: items[0].id, note: "少辣", quantity: 2 },
    { menuItemId: items[2].id, note: "", quantity: 1 },
    { menuItemId: items[7].id, note: "", quantity: 1 },
  ],
  "",
  "花生过敏",
);
await save(memberB, roomId, [
  { menuItemId: items[1].id, note: "", quantity: 1 },
  { menuItemId: items[2].id, note: "不要辣", quantity: 2 },
]);
await save(
  memberC,
  roomId,
  items.map((item) => ({ menuItemId: item.id, note: "", quantity: 0 })),
  "",
  "贝类过敏",
);
const { data: closed, error: closeError } = await organizer.rpc(
  "set_selection_collection_status",
  { candidate_room_id: roomId, candidate_status: "reviewing" },
);
if (closeError) throw closeError;
const payload = items.map((item, index) => ({
  finalQuantity:
    index === 0 ? 2 : index === 2 ? 3 : index === 3 ? 1 : index === 7 ? 2 : 0,
  menuItemId: item.id,
  note: index === 0 ? "少辣，酱汁另放" : index === 3 ? "加一份素食" : "",
}));
const args = {
  candidate_items: payload,
  candidate_room_id: roomId,
  candidate_source_revision: closed[0].new_revision,
};
const confirmations = [];
for (let attempt = 0; attempt < 5; attempt += 1) {
  const { data, error } = await organizer.rpc("confirm_final_order", args);
  if (error || !data) throw new Error(`确认失败 ${error?.message}`);
  confirmations.push(data);
}
if (new Set(confirmations).size !== 1)
  throw new Error("重复确认产生了多个订单");
const orderId = confirmations[0];
const { data: orderItems, error: orderItemsError } = await memberA
  .from("order_items")
  .select(
    "original_name,zh_name,requested_quantity,final_quantity,member_names,note,position",
  )
  .eq("order_id", orderId)
  .order("position");
if (
  orderItemsError ||
  orderItems.length !== 4 ||
  orderItems.reduce((sum, item) => sum + item.final_quantity, 0) !== 8
)
  throw new Error("成员读取固定订单失败");
if (orderItems.map((item) => item.requested_quantity).join(",") !== "3,3,0,2")
  throw new Error("需求快照不符");
const { error: reopenError } = await organizer.rpc(
  "set_selection_collection_status",
  { candidate_room_id: roomId, candidate_status: "open" },
);
if (!reopenError?.message.includes("order_already_confirmed"))
  throw new Error("确认后错误地重新开放");
const { error: saveError } = await memberA.rpc("save_my_selection", {
  candidate_allergy_info: "",
  candidate_dietary_restrictions: "",
  candidate_room_id: roomId,
  candidate_selections: [],
});
if (!saveError?.message.includes("collection_closed"))
  throw new Error("确认后成员仍可保存");
const { data: outsiderRead } = await outsider
  .from("orders")
  .select("id")
  .eq("id", orderId);
if (outsiderRead?.length) throw new Error("非成员读到了订单");
const { error: directWriteError } = await memberA.from("order_items").insert({
  final_quantity: 1,
  menu_item_id: items[0].id,
  order_id: orderId,
  original_name: "伪造",
  position: 0,
  requested_quantity: 0,
  zh_name: "伪造",
});
if (!directWriteError) throw new Error("成员可直接写订单");
const { error: outsiderConfirmError } = await outsider.rpc(
  "confirm_final_order",
  args,
);
if (!outsiderConfirmError?.message.includes("room_access_denied"))
  throw new Error("非成员可确认订单");
console.log(
  JSON.stringify(
    {
      expected: { finalDishes: 4, finalQuantity: 8, requested: [3, 3, 0, 2] },
      orderId,
      roomId,
      verified: {
        directWriteDenied: true,
        fiveConfirmationsIdempotent: true,
        memberRead: true,
        outsiderDenied: true,
        reopenDenied: true,
        saveDenied: true,
      },
    },
    null,
    2,
  ),
);
