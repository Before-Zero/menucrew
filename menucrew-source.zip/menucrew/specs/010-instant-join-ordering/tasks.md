# 任务：先入席、后点餐的极简链路

**输入**：`specs/010-instant-join-ordering/` 中的规格、计划、研究、数据模型与契约

## 阶段 1：共享准备

- [X] T001 固定安装二维码依赖并更新 package.json 与 package-lock.json
- [X] T002 [P] 在 lib/i18n.ts 建立简体中文与 English 偏好、字典和回退工具
- [X] T003 [P] 在 lib/invite-qr.ts 建立服务端二维码生成工具

## 阶段 2：阻塞性数据基础

- [X] T004 使用 Supabase CLI 创建 supabase/migrations/*_instant_join_ordering.sql
- [X] T005 在 010 迁移中增加菜品和订单 English 字段、动态小票 RPC、单步确认 RPC 与菜单助手运行边界
- [X] T006 更新 lib/supabase/database.types.ts 以覆盖 010 表、字段和 RPC
- [X] T007 更新 lib/menus.ts、lib/orders.ts 与 lib/room-journey.ts 的双语字段和三阶段派生

## 阶段 3：用户故事 1——建房后立即扫码入席（P1）

**目标**：发起人创建后同屏邀请和上传，成员可先加入并自动离开等待态。

**独立验收**：空房间创建后另一隔离浏览器扫码加入；发布前只等待，发布后不重新加入即可点餐。

- [X] T008 [US1] 在 components/invite-panel.tsx 实现稳定二维码、可复制链接和按需邀请面板
- [X] T009 [US1] 在 components/organizer-room-dashboard.tsx 与 app/rooms/[roomId]/page.tsx 合并创建后邀请和菜单上传入口
- [X] T010 [US1] 在 components/member-room-dashboard.tsx 实现可见时轻量刷新与等待后自动进入点餐

## 阶段 4：用户故事 2——AI 识别默认快速通道（P1）

**目标**：上传后自动识别，成功后只需一次人工确认即可应用并发布。

**独立验收**：正常识别不进入编辑页即可开放；失败和人工纠错不破坏草稿。

- [X] T011 [US2] 保留 lib/menu-ai.ts 的原文/中文结构化识别，由 010 字段填充边界为 English 名称与解释提供兼容回退
- [X] T012 [US2] 在 app/rooms/[roomId]/menu/ai-actions.ts 增加一次确认并发布 Action
- [X] T013 [US2] 重构 app/rooms/[roomId]/menu/page.tsx 与相关组件为识别状态、主确认和次要修改入口

## 阶段 5：用户故事 3——提交后动态小票（P1）

**目标**：首次提交后只看正数量整桌汇总，并在停留时及时更新。

**独立验收**：第二人新增菜时增加一行，同菜只更新 ×N，普通成员看不到任何他人信息。

- [X] T014 [US3] 在 lib/member-receipt.ts 封装成员安全的小票 RPC 数据
- [X] T015 [US3] 在 app/api/rooms/[roomId]/receipt/route.ts 提供鉴权 no-store 读取
- [X] T016 [US3] 在 components/dynamic-receipt.tsx 与 app/rooms/[roomId]/receipt/page.tsx 实现可见时轮询小票
- [X] T017 [US3] 修改 app/rooms/[roomId]/selection/actions.ts 与 components/member-selection-form.tsx，使保存成功进入动态小票且返回修改恢复原选择

## 阶段 6：用户故事 4——最终确认代替关闭点餐（P1）

**目标**：组织者在点餐中直接汇总、调整并以唯一确认动作锁定订单。

**独立验收**：确认前可改，确认后并发保存被拒绝，所有身份读取同一快照。

- [X] T018 [US4] 在 app/rooms/[roomId]/order/actions.ts 移除 collection_not_reviewing 前置并处理原子确认错误
- [X] T019 [US4] 在 components/organizer-room-dashboard.tsx 与 components/final-order-form.tsx 合并进度、汇总、调整和最终确认
- [X] T020 [US4] 删除常规 UI 中关闭收集与核对中阶段，保留旧 URL 作为恢复入口

## 阶段 7：用户故事 5——个人语言切换（P2）

**目标**：每个浏览器独立选择简体中文或 English，覆盖主流程且不清空输入。

**独立验收**：同房两端使用不同语言，一端切换不影响另一端或未保存表单。

- [X] T021 [US5] 在 app/actions.ts 与 components/language-switcher.tsx 实现个人 Cookie 语言选择
- [X] T022 [US5] 把语言入口接入 app/layout.tsx、首页、邀请页和 RoomShell
- [X] T023 [US5] 为菜单、动态小票、最终订单及关键房间工作台接入双语字典和安全回退

## 阶段 8：用户故事 6——轻量菜单助手（P2）

**目标**：点餐表单内提供不改数据、不保存历史的整份菜单/单菜单轮 AI 问答。

**独立验收**：助手按本人语言和饮食上下文回答，关闭后表单不丢，限额或失败不阻塞保存。

- [X] T024 [US6] 在 lib/menu-assistant.ts 实现输入摘要、最小提示、Gemini 结构化输出与严格校验
- [X] T025 [US6] 在 app/rooms/[roomId]/selection/assistant-actions.ts 实现鉴权、复用、限额和安全失败 Action
- [X] T026 [US6] 在 components/menu-assistant-sheet.tsx 实现单轮临时面板、快捷问题和自由问题
- [X] T027 [US6] 把整份菜单及单菜入口接入 components/member-selection-form.tsx 与 components/selection-item-card.tsx

## 阶段 9：收尾与验证

- [X] T028 更新 AGENTS.md 的 010 架构、迁移、命令和安全约定
- [X] T029 执行格式化、npm run verify 并修复所有静态问题
- [X] T030 按 specs/010-instant-join-ordering/quickstart.md 人工验收核心可运行链路并记录结果

## 依赖顺序

- 阶段 1 → 阶段 2 → 所有用户故事。
- US1 与 US2 共同完成“先加入再开放”；US3 依赖发布菜单和动态小票 RPC；US4 依赖新确认 RPC。
- US5 的数据字段在阶段 2 完成后可贯穿所有页面；US6 依赖已发布双语菜单和个人语言工具。
- 收尾阶段依赖全部目标故事完成。

## 实施策略

先完成数据迁移和 P1 主线，再实现语言与菜单助手。每一阶段结束即勾选任务；最终以静态检查和双隔离浏览器的核心链路为交付门槛。
