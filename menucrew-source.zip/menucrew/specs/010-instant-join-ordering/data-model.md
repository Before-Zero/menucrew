# 数据模型：先入席、后点餐的极简链路

## 1. 极简房间旅程（派生，不持久化）

### 输入事实

- `menu.status`：不存在、`draft` 或 `published`
- `orderConfirmed`：房间是否存在最终订单
- `mySubmitted`：当前身份是否已有提交
- `role`：`organizer` 或 `member`

### 派生阶段

| 优先级 | 条件 | 用户阶段 |
|---|---|---|
| 1 | 最终订单存在 | `completed` / 已完成 |
| 2 | 菜单已发布 | `ordering` / 点餐中 |
| 3 | 其他 | `preparing` / 菜单准备中 |

`rooms.selection_status='reviewing'` 不再显示为产品阶段，只作为最终确认事务写入的内部锁定值。

## 2. 个人语言偏好（Cookie）

- Cookie 名：`menucrew_locale`
- 合法值：`zh-CN`、`en`
- 默认：根据 `Accept-Language` 选择；无法匹配时为 `zh-CN`
- 作用域：`Path=/`、`SameSite=Lax`、一年有效期
- 不包含身份或敏感数据，不写入房间公共数据

## 3. 双语菜品

### `menu_items` 新字段

- `en_name text not null`：English 菜名；1–300 字符
- `description_en text not null default ''`：English 解释；最多 500 字符

既有字段语义保持：`original_name` 为餐厅菜单原文，`zh_name` 为简体中文名，`description` 为简体中文解释。

### 回退顺序

- 简体中文：`zh_name/description` → `original_name`
- English：`en_name/description_en` → `zh_name/description` → `original_name`

## 4. 最终订单条目

`order_items` 增加 `en_name text not null`，在确认瞬间复制 English 菜名。订单继续保存原文、中文名、需求数量、最终数量、成员来源和备注；确认后不可修改。

## 5. 成员动态小票（RPC 派生，不持久化）

返回头包含当前 `revision`、`order_confirmed` 和读取时间。每个正数量菜品行包含 `menu_item_id`、三种名称、`total_quantity`、`my_quantity` 与 `position`。

安全不变量：调用者必须是房间成员且已经完成首次提交；只返回当前已发布菜单的正数量菜；不返回其他用户 ID、姓名、备注、忌口、过敏信息、贡献列表或提交时间。

## 6. 菜单助手运行

### `menu_assistant_runs`

- `id uuid`：主键
- `room_id uuid`、`menu_id uuid`：当前房间与已发布菜单
- `requested_by uuid`：请求者，复合外键约束其为房间成员
- `input_digest text`：菜单内容、本人上下文、语言、入口与问题的 SHA-256；不保存明文私人输入
- `status text`：`processing`、`succeeded`、`failed`
- `model text`
- `result jsonb null`：成功时的严格结构化回答
- `error_code text null`、`error_message text null`
- `created_at`、`completed_at`

结果结构：`answer` 为 1–1200 字符；`referencedItems` 最多 8 个真实菜单引用；`caution` 最多 300 字符，涉及食材、忌口或过敏时必须非空。

同一房间滚动 24 小时最多 10 个 `processing` 或 `succeeded` 的新回答预留。同一请求者、同一菜单和输入摘要的成功结果可以复用。失败运行不作为成功回答长期占用额度。表不向客户端授予直接读写。

## 7. 状态转移

```text
draft + 图片 → AI processing → AI succeeded（仍是 draft）
→ 发起人一次确认 → 原子应用双语菜品 + published
```

失败保持原草稿与图片不变。

```text
open → 成员保存（revision + 1） → 发起人确认最终订单
→ 同一事务：校验 revision → reviewing 内部锁 → 创建订单快照
```

确认事务取得房间行锁。并发成员保存要么先完成并被新修订纳入，要么在锁定后因 `collection_closed` 被拒绝。
