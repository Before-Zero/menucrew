# 实施计划：先入席、后点餐的极简链路

**功能标识**：`010-instant-join-ordering` | **日期**：2026-08-22 | **规格**：[spec.md](spec.md)

## 摘要

把 009 的角色工作台进一步压缩为“菜单准备中、点餐中、已完成”三个用户阶段：建房成功即在同屏显示稳定二维码并允许成员提前加入；菜单图片上传后默认进入 AI 识别，发起人只需一次整体确认即可原子应用候选并发布；成员首次保存后直接进入只显示正数量菜品的动态小票；发起人在同一汇总任务中直接调整并确认最终订单，由数据库事务同时锁定选择和生成不可变快照。个人语言以浏览器 Cookie 保存，菜品增加 English 字段；点餐页增加受限的单轮菜单助手，但它只返回建议，不修改任何业务数据。

## 技术上下文

**语言/版本**：TypeScript 5、Node.js 24  
**主要依赖**：Next.js 16.3.1 App Router、React 19.2.8、Supabase JS 2.112.3、Tailwind CSS 4、现有 shadcn/ui、lucide-react、Gemini REST API；新增小型 `qrcode` 依赖用于本地生成二维码  
**存储**：Supabase Postgres；扩展双语菜品与订单快照字段，新增受限菜单助手运行记录和成员动态小票 RPC；语言偏好仅存个人 Cookie  
**测试**：遵循宪章，不新增自动化测试；执行 `npm run verify`，并用两个隔离浏览器人工验收完整双身份链路、并发锁定、双语和 AI 降级  
**目标平台**：Vercel 上的现代手机与桌面浏览器  
**项目类型**：单根目录 Next.js 全栈 Web 应用  
**性能目标**：动态小票可见时每 5 秒以内取得一次最新修订；只有修订变化时更新列表；AI 与二维码不得阻塞选择保存  
**约束**：不引入完整聊天、WebSocket 在线状态、相机扫码、短房间码或全局状态库；普通成员不得读取他人身份、备注或健康信息；最终确认必须保持原子和不可逆  
**规模/范围**：首页、加入页、房间根页、菜单准备、个人选择、动态小票、组织者汇总和最终订单八个现有页面组；两种界面语言；单房间菜单助手滚动 24 小时最多 10 次新回答

## 宪章检查

- **MVP 核心路径优先**：建房即邀请、AI 快速开放、提交后小票和单步最终确认都直接缩短核心演示链路；菜单助手限定为点餐内 P2 入口，不扩展成聊天产品，符合。
- **按需求直接实现**：复用现有路由、Gemini 调用、RLS 与订单快照；只新增二维码依赖、两个收窄 RPC、一个内部 AI 运行表和少量派生组件，不引入状态机、国际化框架或实时基础设施，符合。
- **最小可用数据闭环**：房间阶段继续从菜单和订单事实派生；动态小票来自真实提交即时聚合；最终确认在同一数据库事务生成快照，符合。
- **必要安全底线**：二维码仍使用已有随机邀请 token；成员小票 RPC 只返回菜品与本人/整桌数量；菜单助手只接收本人输入和已发布结构化菜单；AI 菜单仍需一次人工确认，符合。
- **静态检查即质量门槛**：交付要求 `npm run verify` 与双身份人工验收，不把新增自动化测试、无障碍或部署作为开发完成前置，符合。

研究与设计后复查：新增 `SECURITY DEFINER` 函数均固定空 `search_path`、显式校验 `auth.uid()` 与房间成员关系、撤销默认执行权后仅授权 `authenticated`；菜单助手表不向客户端开放直接表权限；新二维码依赖是满足离线稳定二维码的最小新增依赖。没有宪章冲突。

## 项目结构

### 本功能文档

```text
specs/010-instant-join-ordering/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   ├── database-rpc.md
│   ├── menu-assistant.md
│   └── room-flow-ui.md
└── checklists/
    └── requirements.md
```

### 源码变更范围

```text
app/
├── actions.ts
├── api/rooms/[roomId]/receipt/route.ts       # 新增：成员安全的小票读取
├── join/[token]/page.tsx
└── rooms/[roomId]/
    ├── page.tsx
    ├── menu/{page.tsx,actions.ts,ai-actions.ts}
    ├── selection/{page.tsx,actions.ts,assistant-actions.ts}
    ├── receipt/page.tsx                       # 新增：首次提交后的动态小票
    ├── summary/page.tsx
    └── order/{page.tsx,actions.ts}
components/
├── language-switcher.tsx                     # 新增
├── invite-panel.tsx                          # 新增/提取稳定二维码与链接
├── menu-assistant-sheet.tsx                  # 新增：单轮临时面板
├── member-selection-form.tsx
├── dynamic-receipt.tsx                       # 新增：仅可见时轻量更新
├── organizer-room-dashboard.tsx
├── member-room-dashboard.tsx
├── final-order-form.tsx
└── room-journey-nav.tsx
lib/
├── i18n.ts                                    # 新增：两种语言字典与回退
├── invite-qr.ts                               # 新增：服务端生成二维码
├── member-receipt.ts                          # 新增：小票 RPC 映射
├── menu-assistant.ts                          # 新增：受限 Gemini 输入/输出
├── menu-ai.ts
├── room-journey.ts
├── room-progress.ts
├── menus.ts
├── orders.ts
└── supabase/database.types.ts
supabase/migrations/
└── <timestamp>_instant_join_ordering.sql
AGENTS.md
package.json
package-lock.json
```

**结构决策**：保留现有菜单、汇总和订单 URL 作为纠错及恢复入口，常规主线由房间工作台和成功跳转串联。新增 `/receipt` 是成员提交后的专用阅读页，避免把完整菜单和整桌小票塞进同一长表单；组织者继续复用现有汇总与最终数量组件，但在房间主线中连续呈现。

## 复杂度跟踪

无宪章违规。新增 `qrcode` 依赖是为了在服务端稳定生成包含现有邀请链接的二维码，避免外部二维码服务泄露邀请 token，也避免自行实现二维码编码算法。
