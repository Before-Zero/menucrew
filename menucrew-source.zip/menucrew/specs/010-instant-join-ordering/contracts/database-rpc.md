# 契约：010 数据库 RPC

## `get_member_receipt(candidate_room_id uuid)`

**调用者**：`authenticated`，且必须是目标房间已完成首次提交的成员。  
**返回**：每个正数量菜品一行，包含 `revision`、`order_confirmed`、`menu_item_id`、`original_name`、`zh_name`、`en_name`、`total_quantity`、`my_quantity`、`position`。  
**拒绝**：未认证、非成员、尚未首次提交、菜单未发布或无权访问统一返回收窄错误，不泄露房间存在性。  
**禁止返回**：成员身份、显示名、任何单菜备注、忌口、过敏、提交时间、贡献者数组。

## `confirm_final_order(candidate_room_id, candidate_source_revision, candidate_items)`

**变化**：允许组织者从 `open` 直接确认，不再要求先调用关闭收集。  
**事务顺序**：锁房间 → 校验组织者 → 幂等检查订单 → 校验修订与输入 → 写内部锁定状态 → 创建订单及条目。  
**并发**：修订不一致返回 `stale_revision`；订单已存在返回既有订单 ID；写锁完成后所有选择保存必须返回 `collection_closed`。  
**快照**：条目同时保存 `original_name`、`zh_name`、`en_name`。

## `confirm_menu_ai_run_and_publish(candidate_run_id uuid)`

**调用者**：目标房间组织者。  
**前置**：运行成功、结果合法、菜单仍是草稿、至少一张图片、尚无最终订单。  
**效果**：在一个事务中用候选替换草稿菜品、写双语字段、标记运行已应用并把菜单设为 `published`。  
**幂等**：同一运行已确认且菜单已发布时返回现有菜品数量。  
**失败不变量**：不得留下部分菜品、已应用未发布或已发布空菜单。

## `start_menu_assistant_run(...)`

**输入**：房间 ID、输入 SHA-256、模型。明文问题与私人上下文不进入数据库参数。  
**调用者**：房间成员；菜单必须已发布且最终订单尚未确认。  
**返回**：`run_id`、`reused`、可选 `reused_result`。  
**限额**：锁目标房间后统计滚动 24 小时内处理中/成功的新回答；达到 10 次返回 `menu_assistant_rate_limited`。同一请求者相同摘要优先复用，不占新额度。

## `finish_menu_assistant_run(...)`

**调用者**：创建该运行的房间成员。  
**成功**：只接受通过数据库结构校验的结果并写完成时间。  
**失败**：只写收窄错误码和不含敏感输入的短消息。  
**业务不变量**：两个 RPC 都不得写菜单、选择、房间修订、汇总、收集状态或订单。

## 权限通则

- 所有 `SECURITY DEFINER` 函数使用 `set search_path = ''` 和全限定对象名。
- 创建后 `revoke all ... from public, anon`，仅把需要的 `execute` 授予 `authenticated`。
- `auth.uid()` 为空立即拒绝；所有房间访问在函数内部重新校验成员或组织者身份。
- 新表启用并强制 RLS，同时撤销 `anon`、`authenticated` 表权限；函数是唯一写入口。
