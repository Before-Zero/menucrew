# 接口契约：菜单 AI 识别

## 启动识别 Server Action

组织者在草稿期确认提交。成功返回识别记录 ID；相同输入复用成功记录。错误包括缺密钥、限流、非草稿、无图片、上游失败和输出无效。副作用仅限识别记录。

## Gemini 请求

- `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`
- 服务端 `x-goog-api-key` 密钥
- 默认 `gemini-3.6-flash`
- 说明文字及按稳定顺序排列的 `inlineData` 图片；图片由服务端通过短时签名链接读取
- `responseMimeType: application/json` 与 `responseSchema`，根对象只有 `items`
- 返回后继续执行本地字段、数量与长度二次校验

## 数据库 RPC

- `start_menu_ai_run(room_id, input_digest, model)`：鉴权、锁菜单、校验草稿与图片、复用成功结果、24 小时 5 次限流、创建 processing。
- `finish_menu_ai_run(run_id, ...)`：只有请求组织者可完成 processing 记录。
- `apply_menu_ai_run(run_id)`：锁菜单、校验成功结果，原子替换菜品，保持 draft。

## UI 状态

- 无记录：说明和开始按钮。
- 处理中：禁用重复提交。
- 成功：候选预览及二次确认应用。
- 失败：安全错误与重试入口，人工编辑继续可用。
