# 任务：AI 菜单理解

## 阶段 1：准备

- [x] T001 使用 Supabase CLI 创建 `supabase/migrations/*_ai_menu_understanding.sql`
- [x] T002 [P] 在 `.env.example` 增加仅服务端 Gemini 配置占位
- [x] T003 [P] 在 `package.json` 增加 `seed:menu-ai` 命令

## 阶段 2：基础能力

- [x] T004 在迁移中创建 `menu_ai_runs`、约束、索引、显式授权和组织者只读 RLS
- [x] T005 在迁移中实现开始、完成与应用候选的收窄原子 RPC
- [x] T006 将迁移应用到云项目并更新 `lib/supabase/database.types.ts`
- [x] T007 [P] 在 `lib/menu-ai-action-state.ts` 定义交互状态

## 阶段 3：用户故事 1——生成双语候选（P1）

- [x] T008 [US1] 在 `lib/menu-ai.ts` 实现图片摘要、短时签名 URL 和组织者记录读取
- [x] T009 [US1] 在 `lib/menu-ai.ts` 实现 Gemini 内联图片、结构化输出请求和严格结果二次校验
- [x] T010 [US1] 在 `app/rooms/[roomId]/menu/ai-actions.ts` 实现开始、去重、完成与安全错误映射
- [x] T011 [US1] 在 `components/menu-ai-panel.tsx` 实现开始确认、处理中、候选预览和重试
- [x] T012 [US1] 在 `app/rooms/[roomId]/menu/page.tsx` 接入仅组织者草稿期 AI 面板

## 阶段 4：用户故事 2——人工应用并发布（P1）

- [x] T013 [US2] 在 `app/rooms/[roomId]/menu/ai-actions.ts` 实现二次确认后的原子应用
- [x] T014 [US2] 在 `components/menu-ai-panel.tsx` 实现候选与现有菜品替换警告
- [x] T015 [US2] 在 `app/rooms/[roomId]/menu/page.tsx` 保持应用后人工编辑和主动发布链路
- [x] T016 [US2] 在 `scripts/create-test-menu-ai.mjs` 断言应用后仍为草稿、可编辑且不自动发布

## 阶段 5：用户故事 3——失败保护与限额（P2）

- [x] T017 [US3] 在 `lib/menu-ai.ts` 隔离缺密钥、超时、上游错误、拒绝和无效输出
- [x] T018 [US3] 在 `app/rooms/[roomId]/menu/ai-actions.ts` 保证失败只完成识别记录
- [x] T019 [US3] 在 `components/menu-ai-panel.tsx` 展示可恢复失败且不阻塞人工链路
- [x] T020 [US3] 在 `scripts/create-test-menu-ai.mjs` 断言失败保护、5 次去重、24 小时限额和越权拒绝

## 阶段 6：收口

- [x] T021 运行 `npm run seed:menu-ai` 并核对固定边界结果
- [x] T022 使用组织者、成员和非成员浏览器验收失败保护、候选隐私和响应式页面
- [x] T023 在配置真实密钥后验收外语图片识别、人工修正与主动发布
- [x] T024 运行 Supabase 安全与性能顾问并处理新增问题
- [x] T025 运行 `npm run verify` 与 `npm run build`
- [x] T026 [P] 同步 `AGENTS.md`、`progress.md` 和任务状态
- [x] T027 提交 006 功能与进度收口

## 依赖与策略

- 基础能力阻塞全部故事；US1 是最小识别候选，US2 保证人工确认，US3 保证失败不破坏原链路。
- 外部成功调用不可在无密钥环境伪造；数据库边界验收使用预置合法候选，真实成功验收必须使用实际 Gemini 密钥。
- AI 只写候选记录；应用 RPC 只改草稿菜品，永不发布。
