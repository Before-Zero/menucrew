# 研究：AI 菜单理解

## 决策 1：Gemini `generateContent` + 结构化输出

- **选择**：服务端调用 `models/{model}:generateContent`，输入说明文字与 1–4 个 `inlineData` 图片，使用 `responseMimeType: application/json` 和 `responseSchema`。
- **理由**：Google 官方文档确认 Gemini 可读取内联图片，并按 Schema 返回结构化 JSON；应用仍执行独立的数量、字段和长度二次校验。
- **替代方案**：自由 JSON 无法稳定约束字段；Files API 会增加上传生命周期与清理工作，本阶段图片规模无需引入。

## 决策 2：`gemini-3.6-flash`

- **选择**：默认模型固定为 `gemini-3.6-flash`，允许仅服务端通过 `GEMINI_MENU_MODEL` 覆盖。
- **理由**：该模型由当前 API 在旧稳定模型不可供新用户使用时明确推荐，并已用自制西班牙菜单图片实测图片输入与结构化输出成功；`gemini-3.7-flash` 在验收时持续因高负载返回 503，Demo 默认值优先采用可用模型。
- **限制**：免费层额度按项目计算且可能变化，实际 RPM、TPM、RPD 以 Google AI Studio 中显示的当前限额为准。

## 决策 3：原生 fetch 与服务端内联图片

- **选择**：使用 Node.js 原生 `fetch` 调用官方 HTTP API；先通过 Supabase 短时签名链接读取图片，再在单次请求内转换为 Base64 `inlineData`。
- **理由**：Gemini 不直接读取本项目的私有 Storage URL；单一端点符合直接实现原则并避免新增 SDK。
- **边界**：Google 对内联图片请求设定 20 MB 总请求上限；图片原始字节合计最多 12 MB，为 Base64 膨胀、说明文字和 JSON 预留空间。签名链接与 Base64 均不保存。

## 决策 4：明确免费层数据取舍

- **选择**：组织者操作区明确提示，免费层提交的内容可能用于改进 Google 产品，只上传适合演示的菜单图片。
- **理由**：Google 官方定价页明确区分免费层与付费层的数据使用方式；这属于用户上传私有图片前必须可见的事实。

## 决策 5：候选独立持久化

- **选择**：`menu_ai_runs.result` 保存候选；`apply_menu_ai_run` RPC 在草稿期原子替换菜品。
- **理由**：隔离非确定性输出与人工数据；失败和刷新不会损坏草稿；AI 不自动发布。

## 决策 6：摘要去重、数据库频控与错误最小化

- **选择**：稳定图片元数据生成 SHA-256；数据库锁菜单，复用成功记录，每房间滚动 24 小时最多 5 次新记录；只保存稳定错误码和安全摘要。
- **理由**：签名 URL 会变化，不能作为摘要；数据库边界避免多实例并发绕过；不保存密钥、签名 URL、完整响应或 Base64。

## 官方依据

- `https://ai.google.dev/gemini-api/docs/models`
- `https://ai.google.dev/gemini-api/docs/image-understanding`
- `https://ai.google.dev/gemini-api/docs/structured-output`
- `https://ai.google.dev/gemini-api/docs/pricing`
- `https://ai.google.dev/gemini-api/docs/rate-limits`
