# 数据模型：AI 菜单理解

## `menu_ai_runs`

| 字段 | 类型 | 规则 |
| --- | --- | --- |
| `id` | uuid | 主键 |
| `room_id` | uuid | 关联房间 |
| `menu_id` | uuid | 关联菜单 |
| `requested_by` | uuid | 房间组织者 |
| `input_digest` | text | 64 位 SHA-256 |
| `status` | text | `processing`、`succeeded`、`failed` |
| `model` | text | 实际模型 |
| `result` | jsonb/null | 严格候选对象 |
| `error_code` | text/null | 稳定错误码 |
| `error_message` | text/null | 安全摘要 |
| `provider_response_id` | text/null | 外部响应标识 |
| `created_at` | timestamptz | 创建时间 |
| `completed_at` | timestamptz/null | 完成时间 |
| `applied_at` | timestamptz/null | 应用时间 |

同一菜单与输入摘要最多一个成功结果；只有组织者可读，浏览器无直接写权限。

## 结构化候选

```text
result.items[1..80]
├── originalName: 1..120
├── zhName: 1..120
├── description: 1..240
├── category: 1..60
└── uncertainty: 0..240
```

应用到现有菜品时，分类与不确定提示合并进可编辑解释，避免扩大发布菜单模型。

## 状态转换

```text
processing -> succeeded -> applied_at
          \-> failed -> 新记录重试
```

应用必须锁菜单并重新验证组织者和草稿状态；失败不触碰任何业务数据。
