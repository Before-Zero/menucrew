# 实施计划：AI 菜单理解

**分支**：`codex/006-ai-menu-understanding` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

## 摘要

在现有私有菜单草稿工作区增加组织者专用的 AI 识别流程。服务端通过短时签名链接读取当前图片，再以内联图片调用 Google Gemini Developer API，并用结构化输出得到候选；候选独立持久化，经组织者明确应用后才原子替换草稿菜品，永不自动发布。数据库负责身份、草稿状态、去重、频率限制和原子应用。

## 技术上下文

**语言/版本**：TypeScript 5、SQL/PLpgSQL、Node.js 运行时  
**主要依赖**：Next.js 16.3.1、React 19.2.8、Supabase JS 2.112.3；Gemini Developer API 采用服务端原生 `fetch`，不新增 SDK
**存储**：Supabase Postgres `menu_ai_runs`；现有私有 Storage `menu-images`  
**测试**：可重复验收脚本、真实浏览器隔离会话、Biome、TypeScript、生产构建  
**目标平台**：Vercel Node.js Server Actions 与响应式浏览器  
**项目类型**：Next.js 全栈 Web 应用  
**性能目标**：相同图片立即复用；外部识别在单次请求期限内完成；不引入轮询或队列  
**约束**：1–4 张图、内联图片原始字节合计不超过 12 MB、1–80 道候选、24 小时 5 次新调用、只在草稿期、密钥仅服务端、不得自动发布
**规模/范围**：每房间一份菜单和少量识别记录；Demo 级并发

## 宪章检查

- **核心路径优先**：直接补齐图片到可审阅双语草稿，不扩展整桌建议或通用 AI 平台，符合。
- **直接实现**：使用原生 `fetch` 和既有 Server Action/RPC，不新增 SDK、队列或供应商抽象，符合。
- **真实数据闭环**：候选与应用结果写入真实云数据库，人工编辑和发布继续走现有链路，符合。
- **安全底线**：密钥、签名链接和图片 Base64 仅在单次服务端请求内存活；免费层数据使用提示对组织者可见；AI 不自动发布；数据库重新鉴权，符合。
- **质量门槛**：执行静态检查、构建和核心路径人工验收，符合。

研究与设计后复查：无宪章冲突，无需复杂度豁免。

## 项目结构

```text
app/rooms/[roomId]/menu/
├── actions.ts
├── ai-actions.ts
└── page.tsx
components/menu-ai-panel.tsx
lib/menu-ai.ts
lib/menu-ai-action-state.ts
scripts/create-test-menu-ai.mjs
supabase/migrations/*_ai_menu_understanding.sql
```

**结构决策**：保持单一 Next.js 应用；AI 编排位于可信服务端，可信业务边界由收窄数据库 RPC 承担，UI 只展示和触发。

## 复杂度跟踪

无宪章违规。
