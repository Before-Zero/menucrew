# 实现计划：人工确认与双语订单

**分支**：`codex/005-final-bilingual-order` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

## 摘要

在 004 的核对状态和确定性汇总上增加房间唯一、不可变的最终订单快照。确认页面列出当前菜单全部菜品，明确并列显示成员需求合计与最终点单数量；客户端只提交菜品 ID、最终数量和餐厅备注，数据库事务重新锁定房间、校验组织者、核对状态和来源修订，并从真实菜单、提交和成员关系生成双语名称、需求数量和姓名快照。确认后既有状态保持核对中，重开与成员保存均被拒绝。所有房间成员通过 RLS 只读同一订单，并可复制同序双语文本。

## 技术上下文

**语言/版本**：TypeScript 5；SQL（PostgreSQL 17）；Node.js 24

**主要依赖**：Next.js 16.3.1 App Router、React 19.2.8、Tailwind CSS 4、shadcn/ui、lucide-react、Supabase JS/SSR

**存储**：新增 `orders`、`order_items`；扩展现有状态 RPC 和保存 RPC

**测试**：`npm run verify`、`npm run build`、真实匿名身份固定数据脚本、隔离浏览器、360/1280 像素验收

**目标平台**：现代手机与桌面浏览器、Next.js 服务端、Supabase PostgreSQL

**性能目标**：2–8 名成员、8–50 道菜在单次事务内确认；成员订单页两次有界读取完成

**约束**：确认不可逆；唯一订单；客户端不能提供可信快照字段；无价格、金额、PDF、支付、AI 或实时推送

## 宪章检查

- **MVP 核心路径优先：通过。** 最终双语订单完成当前人工业务闭环。
- **按需求直接实现：通过。** 两张快照表与一个确认 RPC，不引入版本系统或订单工作流框架。
- **最小可用数据闭环：通过。** 从真实汇总确认并跨身份读取，不使用静态数据。
- **安全底线：通过。** 数据库从 `auth.uid()` 重验组织者；成员只读已确认快照。
- **静态检查：通过。** 保留项目质量门槛并增加固定数据和浏览器人工验收。

## 项目结构

```text
app/rooms/[roomId]/order/{actions.ts,page.tsx}
components/{final-order-form.tsx,final-order-view.tsx,copy-order-text.tsx}
lib/{orders.ts,order-action-state.ts}
scripts/create-test-order.mjs
supabase/migrations/*_final_bilingual_order.sql
```

**结构决策**：确认前不保存草稿；`lib/orders.ts` 分别提供组织者候选数据与全员已确认快照读取。数据库 RPC 是确认的唯一写入口，快照表对客户端只授予 SELECT。订单页面在未确认时为组织者展示确认表单、成员展示等待状态；确认后所有成员复用同一个只读组件。

## 复杂度跟踪

无宪章违规。
