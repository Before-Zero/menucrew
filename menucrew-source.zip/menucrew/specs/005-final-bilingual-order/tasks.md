# 任务：人工确认与双语订单

## 阶段 1：准备

- [x] T001 使用 Supabase CLI 创建 `supabase/migrations/*_final_bilingual_order.sql`
- [x] T002 [P] 在 `scripts/create-test-order.mjs` 准备固定订单验收数据
- [x] T003 [P] 在 `package.json` 增加 `seed:order` 命令

## 阶段 2：基础能力

- [x] T004 在迁移中创建 `orders` 与 `order_items`、约束、索引和显式授权
- [x] T005 在迁移中启用并强制 RLS，允许房间成员只读已确认订单
- [x] T006 在迁移中实现校验身份、状态、修订和 payload 的 `confirm_final_order` 原子 RPC
- [x] T007 在迁移中阻止已确认房间重新开放并保持成员保存锁定
- [x] T008 将迁移应用到云项目并更新 `lib/supabase/database.types.ts`

## 阶段 3：用户故事 1——调整并确认（P1）

- [x] T009 [US1] 在 `lib/orders.ts` 构建组织者候选菜品、需求数量和贡献姓名
- [x] T010 [P] [US1] 在 `lib/order-action-state.ts` 定义确认状态与错误映射
- [x] T011 [US1] 在 `app/rooms/[roomId]/order/actions.ts` 实现确认 Server Action
- [x] T012 [US1] 在 `components/final-order-form.tsx` 实现需求/最终数量分离、备注和确认表单
- [x] T013 [US1] 在 `app/rooms/[roomId]/order/page.tsx` 接入核对状态、陈旧修订和组织者确认入口

## 阶段 4：用户故事 2——唯一不可变与幂等（P1）

- [x] T014 [US2] 在 `lib/orders.ts` 实现已确认订单与稳定顺序菜品读取
- [x] T015 [US2] 在 `app/rooms/[roomId]/order/actions.ts` 处理重复确认返回既有订单
- [x] T016 [US2] 在 `app/rooms/[roomId]/summary/page.tsx` 和 `components/collection-status-action.tsx` 显示已确认并移除重开能力
- [x] T017 [US2] 在 `scripts/create-test-order.mjs` 断言 5 次确认、重开和成员保存不会改变快照

## 阶段 5：用户故事 3——全员查看与复制（P2）

- [x] T018 [P] [US3] 在 `components/final-order-view.tsx` 实现双语订单、需求姓名和备注只读视图
- [x] T019 [P] [US3] 在 `components/copy-order-text.tsx` 实现同序纯文本与复制反馈
- [x] T020 [US3] 在 `app/rooms/[roomId]/order/page.tsx` 接入成员等待、已确认和非成员拒绝状态
- [x] T021 [US3] 在 `app/rooms/[roomId]/page.tsx` 增加最终订单入口和确认状态
- [x] T022 [US3] 在 `scripts/create-test-order.mjs` 断言多成员一致读取、直接写拒绝和非成员隔离

## 阶段 6：用户故事 4——响应式现场订单（P3）

- [x] T023 [US4] 在 `components/final-order-form.tsx` 完成手机优先的“点菜单联”布局
- [x] T024 [P] [US4] 在 `components/final-order-view.tsx` 优化长双语名称、数量和备注换行
- [x] T025 [P] [US4] 在 `components/copy-order-text.tsx` 保证复制操作在窄屏可达
- [x] T026 [US4] 在 `app/rooms/[roomId]/order/page.tsx` 完成 360/1280 像素页面层级

## 阶段 7：收口

- [x] T027 运行 `npm run seed:order` 并核对 `quickstart.md` 固定快照
- [x] T028 使用组织者与两个隔离成员浏览器验收确认、共享、复制和权限
- [x] T029 在 360 与 1280 像素检查无横向滚动和浏览器错误
- [x] T030 运行 Supabase 安全与性能顾问并处理新增问题
- [x] T031 运行 `npm run verify` 与 `npm run build`
- [x] T032 [P] 同步 `AGENTS.md`、`progress.md` 和本任务状态
- [x] T033 提交 005 功能与进度收口

## 依赖与策略

- 阶段 2 阻塞所有故事；用户故事 1 是最小可用确认，故事 2 保证可信边界，故事 3/4 完成共享与现场体验。
- 快照字段只由数据库生成；客户端只提交最终数量和备注。
- 不实现共享草稿、确认后编辑、价格、金额、PDF、支付或 AI。
