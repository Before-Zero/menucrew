# 契约：最终订单确认与读取

## `confirm_final_order`

**调用者**：当前房间组织者。

**输入**：房间 ID、来源修订号、数组 `{menuItemId, finalQuantity, note}`。

**数据库重验**：身份、组织者角色、`reviewing`、修订号、当前菜单菜品、数量 0–99、备注长度、重复菜品、至少一项正数量。

**输出**：唯一订单 UUID。若已确认，直接返回既有 UUID 且不改变快照。

**错误**：`room_access_denied`、`collection_not_reviewing`、`stale_revision`、`invalid_items`、`invalid_menu_item`、`empty_order`。

## 读取契约

- 房间成员可读取本房间 `orders` 与 `order_items`。
- 非成员读取结果为空。
- 未确认时普通成员只能得到等待状态；不存在可读草稿。
- 客户端不能直接插入、更新或删除订单表。

## 文本契约

首行是房间名与确认时间；每道菜按 `position` 输出“最终数量 × 菜单原文 / 中文名”，随后按需输出“需求：N（姓名）”和“备注：…”。不输出价格、金额或空字段。
