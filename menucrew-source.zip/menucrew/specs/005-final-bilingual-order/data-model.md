# 数据模型：人工确认与双语订单

## 最终订单 `orders`

- `id`：UUID 主键。
- `room_id`：房间 UUID，唯一且级联删除。
- `source_revision`：确认时房间修订号，非负。
- `confirmed_by`：确认组织者身份。
- `confirmed_at`：确认时间。
- 约束：每房间仅一行；确认后无更新或删除权限。

## 最终订单菜品 `order_items`

- `id`、`order_id`：主键与订单外键。
- `menu_item_id`：确认时菜品标识，仅用于追踪，不依赖后续读取。
- `original_name`、`zh_name`：双语名称快照。
- `requested_quantity`：成员需求合计，可为 0。
- `final_quantity`：最终点单数量，1–99。
- `member_names`：贡献成员显示名有序快照，可为空数组。
- `note`：组织者餐厅沟通备注，最长 500 字。
- `position`：确认时稳定展示顺序。
- 约束：同一订单菜品唯一；名称去空白且非空；备注去空白；不保存最终数量 0。

## 状态与关系

```text
rooms(reviewing, revision R) 1 ── 0..1 orders(source_revision R)
orders 1 ── 1..N order_items
```

- 只有 `reviewing` 可确认。
- 确认后房间仍为 `reviewing`，订单存在会永久阻止重新开放。
- 重复确认返回既有订单，不发生状态转换。
