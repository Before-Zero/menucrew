# 数据模型：在线 Demo 发布

008 不新增持久化实体或数据库迁移。

## 复用数据

- 演示房间：现有 `rooms` 与 `room_members`。
- 演示菜单：现有 `menus`、`menu_images`、`menu_items`。
- 演示选择与汇总：现有 `member_submissions`、`member_selections` 与 `selection_revision`。
- 建议与订单：现有 `room_advice`、`orders`、`order_items`。

## 发布记录

部署 URL、目标、状态、代码提交、验收时间和回退地址属于发布操作记录，写入 `release-runbook.md`，不进入业务数据库。

## 演示数据约束

- 只使用“演示组织者”“成员 A”等合成显示名。
- 菜品、备注和饮食信息均为合成内容。
- 不保存真实个人、联系方式、地址或健康信息。
- 每次脚本创建独立房间，不覆盖现有房间。
