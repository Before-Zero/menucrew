# 契约：在线 Demo 发布

## 发布前门禁

- `npm run verify` 退出码为 0。
- `npm run build` 退出码为 0。
- 演示数据脚本成功创建完整房间。
- 390×844 与 1280×900 核心页面无横向溢出或关键操作遮挡。

## Vercel 环境契约

Preview 和 Production 必须存在以下名称，值不得记录在仓库：

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY`
- `GEMINI_API_KEY`
- `GEMINI_MENU_MODEL`
- `GEMINI_ADVICE_MODEL`

`SUPABASE_SECRET_KEY` 与 `GEMINI_API_KEY` 只能在服务端使用。

## Preview 契约

1. 部署达到 READY。
2. 使用 `vercel curl` 获取首页成功。
3. 受保护 Preview 使用 `vercel curl` 验证真实部署；完整隔离浏览器数据链路在同一构建提升后的 Production 验收。
4. 可恢复错误不显示内部密钥、响应或调用栈。

## Production 契约

1. 在 Preview 通过后发布。
2. 两个隔离会话完整走通房间、菜单、选择、汇总、建议和最终订单。
3. 两个会话看到同一最终订单；普通成员不能访问组织者能力。
4. 验收窗口通过 Vercel logs 扫描，无未处理 5xx。

## 回退契约

- 记录当前 Production URL 与最近一个已知可用部署。
- 代码回归使用 `vercel rollback` 或 `vercel promote` 回退部署别名。
- 已应用 Supabase 迁移只向前修复，不在发布回退中破坏性撤销。
