# MenuCrew Demo 发布手册

## 发布状态

- Vercel 项目：`david-ac9d/menucrew-demo`
- Preview：`https://menucrew-demo-1qg3jngsv-david-ac9d.vercel.app`（READY，受 Deployment Protection 保护）
- Production：`https://menucrew-demo.vercel.app`（READY）
- Production 部署：`dpl_ArWuUYEnuVKokeWpCfLLMANtiyEW`
- 009 功能提交：`41094e3`；双身份验收修复提交：`3913887`
- 最近验收：2026-08-23

## 必需环境变量

变量名称见 `contracts/release.md`。真实值只存在于 `.env.local` 与 Vercel 环境，不写入本文件。

Preview 与 Production 均已配置六项变量；`SUPABASE_SECRET_KEY` 与 `GEMINI_API_KEY` 使用 Vercel Sensitive 类型。`NEXT_PUBLIC_` 变量只包含可公开的 Supabase URL 与 publishable key。

## 发布命令

1. `npx vercel@59.3.0 link --yes --project menucrew-demo`
2. `npx vercel@59.3.0 deploy --yes`
3. `npx vercel@59.3.0 inspect <preview-url>`
4. `npx vercel@59.3.0 curl / --deployment <preview-url>`
5. `npx vercel@59.3.0 promote <preview-url> --yes`
6. `npx vercel@59.3.0 logs --environment production --level error --since 15m --limit 50`

当前仓库没有 Git 远端，本阶段按规格使用固定版本 CLI 直连发布；以后若接入 GitHub，再另行配置 Vercel Git Integration。

## 演示路径

1. 组织者创建房间并复制邀请。
2. 隔离成员加入。
3. 组织者上传合成菜单图，人工录入或 AI 识别后审阅并发布。
4. 成员提交实际数量和备注。
5. 组织者核对汇总，可选生成只读建议，关闭收集并确认双语订单。
6. 两个会话刷新并读取同一订单。

## 2026-08-22 验收记录

- 本地门禁：`npm run verify`、`npm run build` 和 `npm run seed:demo` 通过；最终演示脚本创建房间 `ddedcf51-96ab-4d43-ba55-319d15d635eb`、3 个匿名身份、8 道菜、3 份提交及订单 `3ae3b46c-d051-4e92-b001-43380ee1316f`（6 道、7 份）。
- Preview：修复版部署 `dpl_754Jb4uP576MQt1UHjuwAYFViTsU` 达到 READY；Deployment Protection 保持开启，`vercel curl` 返回 HTTP 200。
- Production 核心链路：房间 `91f788f5-2de0-4386-91f4-aefcea546abd` 使用组织者与隔离成员两个浏览器完成加入、8 道合成菜单、1/2/1 份选择、R1 精确汇总、R2 锁定、成员编辑禁用、组织者把海鲜饭从 1 调整为 2 并确认订单；双方刷新后均看到 3 道菜、5 份和相同双语备注。数据库确认只有 1 份订单、3 个条目、总量 5、来源修订 R2。
- Production AI：房间 `260f8c85-14fd-4b3d-9477-f1cee335a10c` 使用合成菜单截图真实调用 `gemini-3.6-flash`，得到 8 道合法候选；候选经组织者明确应用后仍保持草稿，随后主动发布。R1 汇总真实生成 2 条只读建议，其中一条指出“贝类过敏”与蛤蜊/混合海鲜冲突；生成后仍为 1 份提交、2 道、2 份、R1、0 订单。
- 故障降级：006/007 固定测试覆盖缺失密钥、失败记录、相同输入复用和 24 小时限额，失败前后图片、人工草稿、选择、汇总和订单不变；Production 核心链路同时在不调用 AI 的情况下走通到最终订单。
- 浏览器与运行日志：首次线上验收发现默认时区造成 React hydration 错误，提交 `533e678` 将客户端时间显式格式化为 UTC；重新部署后选择页、订单页和 AI 页面结构化错误数组均为空。Production 最近 15 分钟错误日志为空。
- 响应式：390×844 与 1280×900 已检查首页、房间、菜单、选择、汇总和订单；最终 Production 移动端订单截图保存在仓库外的验收目录。
- 009 角色链路：本地正式构建使用组织者与成员两个隔离浏览器完成创建、菜单发布、邀请加入、双方提交、2/2 进度、R3 汇总、核对锁定、最终 1 道 3 份不可变订单和成员汇总越权拒绝；另用隔离房间验证准备中加入只显示等待状态。验收中补充可见邀请地址，并修复组织者误把成员提交当作本人提交的问题。
- 009 发布：Preview `dpl_E2vrEvSy167xgGEWYb5ZucufgBXu` 构建和受保护首页检查通过，随后提升为 Production `dpl_89yEdvdzmyv68WJQ5nzvrN4Hr5xr`。正式域名浏览器创建房间成功并直接进入菜单准备页，控制台与页面错误为空；Production 最近 15 分钟错误日志为空。

## 2026-08-23 · 010 发布记录

- Preview `dpl_EaqKgi4C3wkmc7rYDcDseH4rum9p`（`menucrew-demo-hnj4cf0pq-david-ac9d.vercel.app`）达到 READY，远程构建完成且 errors-only 构建日志为空；受保护首页返回 HTTP 200。
- 同一 Preview 构建提升为 Production `dpl_ArWuUYEnuVKokeWpCfLLMANtiyEW`，正式域名 `https://menucrew-demo.vercel.app` 返回 HTTP 200，语言切换入口已出现在实际生产 HTML。
- 发布后 15 分钟运行错误聚类为空，该部署的 error/fatal 运行日志为空。本地双隔离浏览器验收详见 `specs/010-instant-join-ordering/quickstart.md`。

## 2026-08-23 · 011 发布记录

- 最终 Preview `dpl_2hGF9ku6ZvVz2xq8ae6biK51k7hL` 达到 READY，受保护首页由 `vercel curl` 返回 HTTP 200；同一构建提升为 Production `dpl_4aMdSvdSCHZLgUCLdmMZMeg7ZgPg`。
- 正式房间 `27e604e0-a8c8-4d21-893a-c6b7d54cea0e` 完成双身份、真实菜单识别、点餐助手、自动整桌建议、动态小票与唯一最终订单验收；最终 3 道、5 份，双方一致。
- 菜单助手正式验收发现 Gemini 内部推理耗尽 900 输出额度；提高至 4096 后真实结构化回答成功，仍保留严格结果校验与每房间限额。

## 2026-08-23 · 012 发布记录

- Preview `dpl_DvWWW8ShX3o1Mj71sWadZoJ4Rdp1`（`menucrew-demo-naslmf8k2-david-ac9d.vercel.app`）达到 READY，远程 Next.js 16.3.1 构建通过，受保护首页由 `vercel curl` 返回 HTTP 200。
- 同一构建提升为 Production `dpl_2Mkja68vwfBsmsTj3rpq9K14C1aG`，正式域名 `https://menucrew-demo.vercel.app` 返回 HTTP 200；发布后 15 分钟 errors-only 日志为空。
- 本地真实 Supabase 双身份房间 `5eb72581-a4a3-4973-ab86-4ee6b76bc082` 完成统一三入口、双方保存后直达同一 summary、2/2 提交、2 道 3 份安全实时汇总、普通成员页面/API 隐私、同入口最终确认和旧 receipt 跳转；两个浏览器无页面错误。
- Production 隔离房间 `b0773ce2-257e-4522-aded-011bcd62721b` 真实识别 5 道菜单并生成个人点餐搭配；应用后表单为 4 道 4 份，保留忌口、支持撤销且标记尚未保存，成员正式小票 API 仍返回 403，确认 AI 没有自动提交。
- 汇总页精简版 Preview `dpl_imD3QdVLF5QYbHCcKRGtkUVj2tYw` 达到 READY，随后提升为 Production `dpl_J9JyEU1jsb7qiry6rgCwhgSWb6Te`；删除与上方“本桌点单”重复的“逐道核对”菜品卡，保留成员进度、忌口/过敏、整桌建议与最终确认。发布后 errors-only 日志为空。

## 2026-08-23 · 013 发布记录

- 本地 `npm run check:fix`、`npm run verify` 和 `npm run build` 通过；首页本地响应为 HTTP 200 且无 Next.js 错误页。
- Preview `dpl_E9mLxJGk5NkmF4WM7NngvoxKRCzW`（`menucrew-demo-qf9vqovc3-david-ac9d.vercel.app`）达到 READY，远程 Next.js 构建和类型检查通过，受保护首页由 `vercel curl` 返回完整 HTTP 页面。
- 同一构建提升为 Production `dpl_CBfeEt5a93KsLXyrCXaCZCwDUYjk`（`menucrew-demo-79kenxqmz-david-ac9d.vercel.app`）；正式域名 `https://menucrew-demo.vercel.app` 已确认绑定该部署。
- 013 将个人与整桌 AI 建议的最长服务等待收紧为 15 秒，并强化复用、等待和失败反馈；最终订单仍使用唯一快照，默认餐厅视图隐藏成员内部信息，支持即时切换中文核对视图和分别复制。
- 当前环境未提供自动浏览器命令，因此没有把带房间身份的真实点击误记为自动验收；发布门禁由本地静态检查、生产构建、Preview READY、受保护首页和 Production 别名确认组成。
- 发布复核发现历史真实验收要求个人助手保留足够的内部推理输出余量，因此最终版恢复已验证的输出上限，只通过 15 秒超时、复用和非阻塞反馈控制等待，避免为追求速度引入截断失败。修正版 Preview `dpl_76XGzMLPfQCwAxtqmX121HJmNi4i` 返回 HTTP 200，最终 Production 为 `dpl_6ogALMXsWiPNmqho1myvY5cYG7J2`（`menucrew-demo-8x7bxctqd-david-ac9d.vercel.app`），正式域名已绑定且 errors-only 日志为空。

## AI 故障降级

- 菜单识别失败：保留图片和人工草稿，继续人工录入并发布。
- 整桌建议失败：保持汇总和订单不变，继续人工核对和确认。
- 每房间两类 AI 各最多 5 次新调用/24 小时；相同输入复用。

## 2026-08-23 · 015 发布记录

- 安装 `agent-browser` 0.34.0；独立 Chrome 下载受网络影响失败，但工具可调用电脑现有 Chrome，并已完成本地页面元素与表单交互检查。
- Supabase 已应用 `room_cleanup_analytics`、`index_product_events_room` 与 `touch_room_on_join` 三条迁移；30 天内菜单、成员、选择或订单活动都会刷新保护时间。当前到期候选为 0，没有删除现有房间。
- 每日 UTC 03:17 的受保护任务每次最多处理 25 间；先通过 Storage API 删除私有图片，失败则保留房间，成功后才级联删除数据库记录。
- 核心漏斗只记录固定事件名、房间关联和时间，客户端无读写权限；不记录姓名、菜品、备注、忌口、AI 问题或回答。
- AI 菜单输入将中英文描述各限制为 180 字，保留既有结果复用、可靠输出余量和 15 秒等待边界。
- Preview `dpl_2BjnjSztPk2yx3XfCwFhMvkvutrF` 达到 READY，首页 HTTP 200，未授权清理请求返回 401；Production `dpl_DvBBYBmQYiGzebYVh5JrD1m7Wa6V`（`menucrew-demo-n8dotyiol-david-ac9d.vercel.app`）达到 READY 并绑定正式域名，发布后 errors-only 日志为空。本机公网浏览器复查受 `ERR_CONNECTION_CLOSED`/TLS 网络波动影响，未将该项误记为通过。

## 回退

1. 当前 Production 010 为 `dpl_ArWuUYEnuVKokeWpCfLLMANtiyEW`，不可变地址为 `https://menucrew-demo-5xr0wxh91-david-ac9d.vercel.app`。
2. 若 010 出现回归，上一份已知可用 009 为 `dpl_89yEdvdzmyv68WJQ5nzvrN4Hr5xr`，不可变地址为 `https://menucrew-demo-37kqmwa0g-david-ac9d.vercel.app`；执行 `npx vercel@59.3.0 rollback dpl_89yEdvdzmyv68WJQ5nzvrN4Hr5xr --yes --scope david-ac9d`。
3. 用首页、创建房间和读取订单做快速检查。
4. 不破坏性回滚 Supabase 迁移；数据库问题使用新的向前迁移修复。
