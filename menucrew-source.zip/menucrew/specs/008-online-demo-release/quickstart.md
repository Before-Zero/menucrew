# 快速验收：在线 Demo 发布

1. 运行 `npm run verify`、`npm run build` 和 `npm run seed:demo`。
2. 本地以 390×844 与 1280×900 检查首页、房间、菜单、选择、汇总和订单。
3. 登录并显式绑定 Vercel 项目。
4. 从 `.env.local` 安全配置 Preview 与 Production 的全部变量名，不输出真实值。
5. 创建 Preview，等待 READY，并使用 `vercel curl` 检查首页。
6. 使用两个隔离会话在线走通完整核心链路；单独验证 AI 错误不阻断人工路径。
7. 创建 Production，重复双会话核心验收。
8. 扫描验收时间段运行日志，记录 URL、状态、提交和回退命令。
