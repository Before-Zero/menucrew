# 研究：在线 Demo 发布

## 决策 1：单项目显式绑定

- **选择**：使用固定版本 Vercel CLI，在仓库根目录执行 `vercel link` 建立 `.vercel/project.json`。
- **理由**：仓库只有一个根目录 Next.js 应用，不需要 monorepo 的 `--repo` 绑定；显式绑定可以避免部署命令隐式关联错误项目或团队。

## 决策 2：Preview 先验收，Production 后发布

- **选择**：先创建 Preview 并用 `vercel inspect` 等待 READY、用 `vercel curl` 检查受保护页面；验收通过后再创建 Production。
- **理由**：Preview 隔离风险；Vercel 官方建议受保护 Preview 使用 `vercel curl`，不关闭 Deployment Protection。
- **回退**：Production 出现回归时用 `vercel rollback <previous-url>` 或重新提升最近的已验收部署，不回滚数据库迁移。

## 决策 3：环境变量分环境设置

- **选择**：Preview 与 Production 均配置 `NEXT_PUBLIC_SUPABASE_URL`、`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`、`SUPABASE_SECRET_KEY`、`GEMINI_API_KEY`、`GEMINI_MENU_MODEL`、`GEMINI_ADVICE_MODEL`。
- **理由**：公开 Supabase 值用于浏览器和 SSR；secret key 只用于可信服务端签发上传；Gemini key 只用于服务端 AI。所有值来自本机忽略的 `.env.local`，不写入仓库或命令输出。

## 决策 4：不依赖 Git 集成完成当前发布

- **选择**：本次用 CLI 直接创建 Preview 与 Production；若以后接入 GitHub，可在 Vercel Dashboard 建立 Git 集成。
- **理由**：当前仓库没有 Git 远端，也没有 GitHub CLI；CLI 直连足以满足本阶段可重复发布与验收，不把新账号或仓库创建作为阻塞条件。

## 决策 5：App Router 约定错误与加载界面

- **选择**：根级 `loading.tsx` 提供路由切换反馈，`error.tsx` 提供可重试的局部错误，`global-error.tsx` 提供根布局故障兜底；均复用当前品牌语言。
- **理由**：不需要在每个页面复制状态代码；现有业务空状态已经针对角色和菜单阶段提供下一步。

## 决策 6：演示数据只走正式边界

- **选择**：新增脚本通过匿名认证、现有 RPC、RLS 和公开菜单操作创建合成房间、8 道双语菜与多成员提交，不使用 secret key 绕过业务权限。
- **理由**：脚本既能快速准备 Demo，也能证明线上配置和核心数据闭环真实可用。

## 官方依据

- `https://vercel.com/docs/cli`
- `https://vercel.com/docs/deployments`
- `https://vercel.com/docs/environment-variables`
- `https://vercel.com/docs/deployment-protection/methods-to-bypass-deployment-protection/vercel-automation-bypass-secret`
