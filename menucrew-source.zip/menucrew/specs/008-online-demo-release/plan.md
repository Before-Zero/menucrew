# 实施计划：在线 Demo 发布

**分支**：`codex/008-online-demo-release` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

## 摘要

对现有 Next.js 单体应用做最后的发布收口：补充统一加载与异常恢复页面、可重复合成演示房间和发布文档；在 390 与 1280 宽度完成视觉检查；通过 Vercel CLI 建立单项目绑定、分别配置 Preview/Production 变量，先验收 Preview，再发布同一代码到 Production，并用隔离会话走通完整线上业务和错误扫描。

## 技术上下文

**语言/版本**：TypeScript 5、Node.js 24、PowerShell 发布环境  
**主要依赖**：Next.js 16.3.1、React 19.2.8、Supabase JS 2.112.3、Vercel CLI 59.3.0  
**存储**：复用现有 Supabase Postgres 与私有 Storage；无新表  
**测试**：演示数据脚本、Biome、TypeScript、生产构建、隔离浏览器、Vercel inspect/logs  
**目标平台**：Vercel Preview 与 Production，现代手机和桌面浏览器  
**项目类型**：单根目录 Next.js 全栈 Web 应用  
**性能目标**：正常网络下动态页面持续给出反馈；Production 验收窗口无未处理 5xx  
**约束**：不公开推广、不新增付费资源、不提交密钥、AI 故障不阻断人工链路、先 Preview 后 Production  
**规模/范围**：小范围课程 Demo；双隔离会话验收

## 宪章检查

- **核心路径优先**：只处理完整演示所需状态、数据、部署和验证，不扩展公开产品能力，符合。
- **直接实现**：使用 Next.js 约定文件、现有组件和 Vercel CLI，不引入监控 SDK、CI 或新平台，符合。
- **真实数据闭环**：Preview/Production 继续连接真实 Supabase，线上从创建房间到最终订单完整验收，符合。
- **安全底线**：密钥仅配置在 Vercel 服务端环境；演示数据合成；Preview/Production 变量分环境管理，符合。
- **质量门槛**：规格明确要求 verify、build、移动端、线上双会话和运行错误扫描，符合。

研究与设计后复查：无宪章冲突；生产构建与部署属于 008 明确范围。

## 项目结构

```text
app/
├── loading.tsx
├── error.tsx
└── global-error.tsx
components/page-status.tsx
scripts/create-demo-room.mjs
specs/008-online-demo-release/
└── release-runbook.md
```

**结构决策**：不新增数据库或 API。全局状态使用 App Router 约定文件；演示数据脚本只调用现有公开认证、RLS 和 RPC；部署状态与回退步骤记录在发布手册。

## 复杂度跟踪

无宪章违规。
