# 任务：在线 Demo 发布

## 阶段 1：规格与发布准备

- [x] T001 确认 001–007 完成、创建 008 分支并更新 `.specify/feature.json`
- [x] T002 完成 `specs/008-online-demo-release/` 的规格、计划、研究、契约、手册和验收材料
- [x] T003 运行 Spec Kit 前置条件与规格检查清单

## 阶段 2：用户故事 1——线上核心链路（P1）

- [x] T004 [P] [US1] 在 `components/page-status.tsx` 建立品牌一致的加载与错误状态组件
- [x] T005 [US1] 在 `app/loading.tsx`、`app/error.tsx`、`app/global-error.tsx` 接入路由加载和可恢复异常反馈
- [x] T006 [US1] 审查核心空状态，确保首页、房间、菜单、选择、汇总和订单均提供下一步
- [x] T007 [US1] 在 `scripts/create-demo-room.mjs` 创建合成完整演示房间并在 `package.json` 暴露 `seed:demo`

## 阶段 3：用户故事 2——手机和桌面演示（P1）

- [x] T008 [US2] 在本地 390×844 检查六个核心页面并修复横向溢出或关键操作遮挡
- [x] T009 [US2] 在本地 1280×900 检查六个核心页面并修复布局回归
- [x] T010 [US2] 检查真实加载、空状态、长双语文本和建议卡片的可读性

## 阶段 4：用户故事 3——AI 故障降级（P1）

- [x] T011 [US3] 验证菜单识别缺失密钥、建议失败和次数限制均不改变业务数据
- [x] T012 [US3] 从 AI 错误状态继续走通人工菜单、汇总和最终订单

## 阶段 5：用户故事 4——可重复发布与回退（P2）

- [x] T013 [US4] 登录并显式绑定单根目录 Vercel 项目
- [x] T014 [US4] 从 `.env.local` 安全配置 Preview 与 Production 的全部变量
- [x] T015 [US4] 运行 `npm run verify`、`npm run build` 和 `npm run seed:demo`
- [x] T016 [US4] 创建 Preview、等待 READY、使用 `vercel curl` 和隔离浏览器验收
- [x] T017 [US4] 发布 Production 并用两个隔离会话完成核心链路
- [x] T018 [US4] 扫描 Production 运行错误，补全 `release-runbook.md` 的 URL、提交、验收和回退信息

## 阶段 6：收口

- [x] T019 更新 `AGENTS.md` 和 `progress.md`，记录发布命令、结果与已知边界
- [x] T020 提交 008 实现与发布文档，确认工作树干净
- [x] T021 执行全项目最终审计并将总进度更新为 8/8

## 依赖顺序

1. T001–T003 完成后进入体验与演示数据收口。
2. T004–T012 必须在任何外部发布前完成。
3. T013–T016 先建立并验收 Preview；T017 才允许 Production。
4. T018–T021 依赖 Production 验收完成。
