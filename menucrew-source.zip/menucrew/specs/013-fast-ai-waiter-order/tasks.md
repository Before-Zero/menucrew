# Tasks: 快速 AI 反馈与服务员订单

**Input**: `specs/013-fast-ai-waiter-order/` 下的规格与设计文档

## Phase 1: Setup

- [X] T001 核对 013 规格、体验契约与现有 AI/订单边界，确认不新增数据库迁移或依赖，记录于 `specs/013-fast-ai-waiter-order/plan.md`

## Phase 2: Foundational

- [X] T002 在 `lib/menu-assistant.ts` 与 `lib/table-advice.ts` 统一收窄 AI 输出预算和最大等待窗口，同时保留现有校验与错误边界
- [X] T003 [P] 在 `components/menu-assistant-sheet.tsx` 与 `components/auto-table-advice.tsx` 明确处理中、可继续操作和失败恢复文案

## Phase 3: User Story 1 - AI 等待不再阻塞点餐 (P1)

**Goal**: 缩短正常建议生成，并确保慢速或失败时用户有明确下一步且表单不丢失。

**Independent Test**: 请求个人建议和整桌建议，检查即时反馈、15 秒内结束等待或降级、相同输入复用和手动流程不受阻塞。

- [X] T004 [US1] 优化个人菜单助手的请求规模、超时错误映射和复用反馈，修改 `lib/menu-assistant.ts` 与 `app/rooms/[roomId]/selection/assistant-actions.ts`
- [X] T005 [US1] 优化整桌建议的请求规模与超时反馈，修改 `lib/table-advice.ts` 与 `components/auto-table-advice.tsx`
- [X] T006 [US1] 完善个人助手加载和失败状态，确保未保存表单不被修改，修改 `components/menu-assistant-sheet.tsx`

## Phase 4: User Story 2 - 给服务员看的独立订单视图 (P1)

**Goal**: 同一最终订单提供餐厅优先和中文核对两个展示/复制视图。

**Independent Test**: 用同一订单切换并复制两个视图，确认数量一致、语言重点不同，且餐厅视图没有成员内部信息。

- [X] T007 [US2] 在 `components/final-order-view.tsx` 增加默认餐厅视图与中文核对视图的即时切换状态
- [X] T008 [US2] 在 `components/final-order-view.tsx` 分离两个视图的菜名优先级、信息边界和复制文本
- [X] T009 [US2] 在 `app/rooms/[roomId]/order/page.tsx` 更新最终订单说明，使其匹配同一订单双视图行为

## Phase 5: User Story 3 - 慢速与失败状态保持可信 (P2)

**Goal**: 失败不伪装成结果，不取消风险提醒，也不阻塞确定性订单链路。

**Independent Test**: 模拟无效结果和超时，确认错误清楚、风险提醒保留、选择与最终订单不变化。

- [X] T010 [US3] 核对并收紧 AI 失败文案、风险提示和手动继续入口，修改 `components/menu-assistant-sheet.tsx`、`components/auto-table-advice.tsx` 与相关 Server Actions

## Phase 6: Polish & Verification

- [X] T011 [P] 更新 `AGENTS.md` 的 013 项目速览和 AI/最终订单约定
- [X] T012 执行 `npm run check:fix`、`npm run verify` 与 `npm run build`，修复本轮引入的问题
- [ ] T013 按 `specs/013-fast-ai-waiter-order/quickstart.md` 完成带真实房间身份的核心路径点击验收；当前已完成本地首页 200 响应与无错误页检查，自动浏览器工具在环境中不可用

## Dependencies & Execution Order

- T001 → T002/T003 → T004–T006。
- T007–T009 在 T001 后可与 AI 任务并行，但同一文件内顺序执行。
- T010 依赖 T004–T6；T011 可在功能稳定后执行；T012–T013 最后执行。

## Implementation Strategy

先完成 AI 时限与等待反馈，再完成最终订单的两个展示视图，最后统一验证。所有改动复用现有数据和页面，不增加迁移、依赖或新路由。
