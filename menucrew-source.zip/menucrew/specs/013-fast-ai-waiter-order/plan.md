# Implementation Plan: 快速 AI 反馈与服务员订单

**Branch**: `[013-fast-ai-waiter-order]` | **Date**: 2026-08-23 | **Spec**: [spec.md](spec.md)

**Input**: 来自 `specs/013-fast-ai-waiter-order/spec.md` 的功能规格。

## Summary

在不改变现有菜单、选择、汇总和最终订单数据边界的前提下，将 AI 等待限制在明确时长内，同时增强加载、复用与失败反馈；把现有最终双语订单改为同一快照上的“给餐厅看”和“中文核对”两个即时切换视图，并分别生成适合用途的复制文本。

## Technical Context

**Language/Version**: TypeScript 5、React 19.2.8、Next.js 16.3.1

**Primary Dependencies**: 现有 App Router、Server Actions、Supabase、Gemini Developer API、lucide-react、Tailwind CSS 4

**Storage**: 复用现有菜单助手运行记录、整桌建议记录和不可变最终订单快照；不新增表或迁移

**Testing**: `npm run verify`；按 quickstart 执行 AI 成功/复用/超时降级和双视图人工验收

**Target Platform**: Vercel 上的响应式 Web，优先移动端餐厅现场使用

**Project Type**: 单体全栈 Web 应用

**Performance Goals**: AI 1 秒内反馈；正常新请求 90% 在 10 秒内完成；15 秒后必须有可执行降级；订单视图即时切换

**Constraints**: 不取消 AI 结构校验、过敏提醒和人工确认；不拆分最终订单数据；不新增服务、依赖和持久状态

**Scale/Scope**: 现有个人菜单助手、整桌建议和最终订单展示三个边界内的增量修改

## Constitution Check

- **MVP 核心路径优先：通过。** 两项改动分别缩短点餐建议等待并改善最终递单，直接服务核心路径。
- **按需求直接实现：通过。** 复用现有 Server Actions、运行记录和最终订单快照，不引入新框架、依赖或页面。
- **最小可用数据闭环：通过。** 订单仍使用现有不可变快照，AI 仍不参与确定性数量计算。
- **必要安全底线：通过。** 保留服务端密钥、严格结果校验、过敏提示和最终人工确认。
- **静态检查质量门槛：通过。** 交付以 `npm run verify` 和核心路径人工验收为门槛。

设计完成后复核：所有门槛继续通过，无需复杂度例外。

## Project Structure

### Documentation (this feature)

```text
specs/013-fast-ai-waiter-order/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/experience-contracts.md
└── tasks.md
```

### Source Code (repository root)

```text
app/rooms/[roomId]/selection/assistant-actions.ts
app/rooms/[roomId]/summary/advice-actions.ts
components/menu-assistant-sheet.tsx
components/auto-table-advice.tsx
components/final-order-view.tsx
lib/menu-assistant.ts
lib/table-advice.ts
```

**Structure Decision**: 保持现有单体 Next.js 目录；AI 时限和输出约束留在服务端库，用户状态留在现有客户端组件，最终订单双视图集中在已有展示组件。

## Complexity Tracking

无宪章违规，不需要复杂度例外。
