# 任务：可选餐桌身份

- [x] T001 [US1] 在 `components/account-panel.tsx` 实现游客邮箱身份升级
- [x] T002 [US1] 在 `app/auth/callback/route.ts` 实现安全链接会话回调
- [x] T003 [US2] 在 `app/page.tsx` 与 `components/home-cover.tsx` 增加非阻塞账户入口
- [x] T004 [US3] 在 `app/account/page.tsx` 实现账户状态与餐桌历史
- [ ] T005 [US1] 在 Supabase 控制台确认邮箱认证、身份链接和正式回调地址
- [ ] T006 [US1] 人工验证游客升级前后用户 ID 与餐桌权限保持不变
- [ ] T007 [US3] 人工验证另一浏览器邮箱登录后恢复餐桌历史
- [ ] T008 [US4] 下一阶段设计常用同桌和待接受快捷邀请的数据模型
- [x] T009 [US5] 在 `supabase/migrations/20260829142504_add_numeric_room_code.sql` 增加唯一六位入席码与收窄加入函数
- [x] T010 [US5] 在 `app/join/page.tsx` 与 `components/room-form.tsx` 实现数字码入席页
- [x] T011 [US5] 在 `components/invite-panel.tsx` 展示与二维码并列的入席码
- [x] T012 [US5] 在 `scripts/create-test-room.mjs` 验证链接与数字码两种加入路径
