# 任务：成员个人选菜

**输入**：`specs/003-member-selection/` 下的规格与设计文档

**前置文档**：`plan.md`、`spec.md`、`research.md`、`data-model.md`、`contracts/member-selection.md`、`quickstart.md`

**测试口径**：项目宪章不要求新增自动化测试；本阶段使用 `npm run verify`、`npm run build`、真实匿名身份测试数据、数据库权限断言和 2–3 个隔离浏览器验收。

## 格式：`[ID] [P?] [Story] 描述`

- **[P]**：可与同阶段其他标记任务并行，文件不冲突且不依赖未完成任务
- **[Story]**：映射到 `spec.md` 的用户故事

## Phase 1：准备

**目标**：建立 003 迁移与测试脚本位置，确认不引入新依赖或外部服务。

- [x] T001 使用 Supabase CLI `migration new` 创建 `supabase/migrations/*_member_selection.sql`，不得手写迁移文件名
- [x] T002 [P] 审查 `.env.example`、`.gitignore` 与 `package.json`，确认 003 仅复用公开 Supabase 变量且不新增 AI、价格或 secret 依赖
- [x] T003 [P] 在 `package.json` 预留 `seed:selection` 命令并建立 `scripts/create-test-selections.mjs` 文件位置

---

## Phase 2：阻塞性基础

**目标**：完成所有故事共享的数据模型、事务保存入口、本人读取策略、显式授权和服务端读取基础。

**关键检查点**：本阶段完成前不得开放个人选择页面写入。

- [x] T004 在 `supabase/migrations/*_member_selection.sql` 创建 `member_submissions`、`member_selections`、字段约束、唯一约束和外键索引
- [x] T005 在 `supabase/migrations/*_member_selection.sql` 实现仅本人读取的 RLS 辅助函数与策略、撤销直接写权限并配置最小显式 GRANT
- [x] T006 在 `supabase/migrations/*_member_selection.sql` 实现固定空 `search_path` 的原子 `save_my_selection` RPC，校验当前成员、已发布菜单、菜品归属、数量、重复项和文字上限
- [x] T007 将 003 迁移应用到 Supabase 项目 `xxbuibqbcqfozifrwors`，运行 Security/Performance Advisors，并更新 `lib/supabase/database.types.ts`
- [x] T008 [P] 在 `lib/selection-action-state.ts` 与 `lib/validation.ts` 定义选择 action 状态、数量 0–20、单菜备注 240 字符和整体字段 500 字符校验
- [x] T009 在 `lib/selections.ts` 实现按当前身份读取本人提交、有效菜品选择、最近保存时间和本人摘要

---

## Phase 3：用户故事 1 — 提交本人实际想点的菜（P1）🎯 MVP

**目标**：房间成员从当前已发布菜单填写本人实际数量，并以一次完整操作保存正数量菜品。

**独立验收**：从至少 8 道菜中选择 3 道不同正数量，其他保持 0；保存刷新后只恢复 3 道，零菜品提交也成功。

- [x] T010 [US1] 在 `app/rooms/[roomId]/selection/actions.ts` 实现服务端解析、当前菜单复核、原子保存 RPC 调用与页面刷新
- [x] T011 [P] [US1] 在 `components/selection-item-card.tsx` 实现本人份数 0–20 步进器、双语菜品信息和清晰的非投票说明
- [x] T012 [US1] 在 `components/member-selection-form.tsx` 实现多菜数量状态、已选菜品种数、总份数、零菜提交与 pending/失败反馈
- [x] T013 [US1] 在 `app/rooms/[roomId]/selection/page.tsx` 实现房间访问校验、已发布菜单选择页和无菜单等待状态
- [x] T014 [US1] 扩展 `app/rooms/[roomId]/page.tsx`，显示本人选择入口、本人保存状态并保持组织者与成员相同的个人权限

**检查点**：任一房间成员可在不依赖 AI 的情况下保存本人正数量选择，数量 0 不落库。

---

## Phase 4：用户故事 2 — 补充口味、忌口与过敏信息（P1）

**目标**：正数量菜品可带单菜备注，并独立保存整体忌口和过敏信息。

**独立验收**：为一道菜填写“少辣”，填写整体忌口和过敏后保存；刷新准确恢复，把该菜改为 0 后菜品与备注同时移除。

- [x] T015 [US2] 扩展 `components/selection-item-card.tsx` 与 `components/member-selection-form.tsx`，为正数量菜品提供 240 字符口味备注并在数量归零时清除候选
- [x] T016 [US2] 在 `components/member-selection-form.tsx` 增加各 500 字符的整体忌口与过敏字段、字符提示和零菜保存说明
- [x] T017 [US2] 扩展 `app/rooms/[roomId]/selection/actions.ts`，对文字字段执行服务端校验并保证任一错误不部分覆盖旧提交

**检查点**：数量、单菜备注和整体限制在同一事务内完整保存或完整失败。

---

## Phase 5：用户故事 3 — 私密恢复并修改本人提交（P2）

**目标**：隔离身份刷新后只恢复自己的最新完整提交，任何身份都不能读取或修改他人数据。

**独立验收**：3 个隔离身份提交不同内容，多次刷新均只看到自己；直接读取他人结果为 0，直接写表或伪造他人标识被拒绝。

- [x] T018 [US3] 扩展 `app/rooms/[roomId]/selection/page.tsx` 与 `components/member-selection-form.tsx`，恢复本人最新数量、备注、限制和最近保存时间并支持整体替换修改
- [x] T019 [P] [US3] 在 `components/selection-status.tsx` 实现仅本人的未保存/已保存状态、菜品种数、总份数和最近保存时间展示
- [x] T020 [US3] 审查 `lib/selections.ts`、`app/rooms/[roomId]/selection/actions.ts` 与迁移，验证其他成员、组织者、跨房间身份和直接表写均不能越权
- [x] T021 [US3] 处理菜单退回草稿、删改菜品和重新发布后的恢复规则，只显示并允许保存当前已发布菜单中的有效选择

**检查点**：003 始终只有本人视角，不展示全员状态、姓名、数量、备注或任何汇总。

---

## Phase 6：用户故事 4 — 在手机上清楚完成个人选择（P3）

**目标**：长菜单在 360 与 1280 像素宽度均可快速调整数量、填写文字和保存，无横向滚动。

**独立验收**：两种宽度下完成 8 道菜浏览、3 道数量调整、备注、整体限制、保存和刷新，长双语文字与按钮不遮挡。

- [x] T022 [US4] 在 `app/globals.css`、`components/selection-item-card.tsx`、`components/member-selection-form.tsx`、`components/selection-status.tsx` 与 `app/rooms/[roomId]/selection/page.tsx` 完成 MenuCrew 响应式个人选择布局和移动端固定保存摘要

**检查点**：主要操作在目标宽度可见可用，页面明确显示个人份数而非投票或整桌数量。

---

## Phase 7：测试数据、验证与收尾

**目标**：生成真实可重复测试数据，执行权限、质量、浏览器和阶段台账门槛。

- [x] T023 在 `scripts/create-test-selections.mjs` 与 `package.json` 实现通过正式匿名身份、当前菜单和 `save_my_selection` RPC 创建 3 个隔离提交的 `npm run seed:selection`
- [x] T024 运行 `npm run seed:selection` 与只读 SQL，逐项验证正数量、零数量移除、备注、整体限制、唯一性、重复保存和本人 RLS，记录测试房间与提交 ID
- [x] T025 运行 `npm run verify` 与 `npm run build` 并修复所有 Biome、TypeScript 和生产构建问题
- [x] T026 按 `specs/003-member-selection/quickstart.md` 执行 3 个隔离浏览器、刷新恢复、修改、越权、草稿菜单、无 AI 和 360/1280 宽度验收
- [x] T027 运行 Supabase Security/Performance Advisors，处理本迁移新增告警并确认业务表无直接写权限、RPC 执行权和 RLS 生效
- [x] T028 更新 `AGENTS.md` 的页面、表、命令和个人数据隔离约定，并在 `progress.md` 勾选实际完成项、填写证据、日期和交付 commit

---

## 依赖与执行顺序

### Phase 依赖

- Phase 1 无依赖。
- Phase 2 依赖 Phase 1，并阻塞所有用户故事。
- US1 依赖 Phase 2；US2 扩展 US1 表单与同一事务；US3 依赖已保存数据；US4 在页面结构稳定后进行。
- 收尾依赖所有用户故事完成。

### 用户故事依赖图

```text
基础设施 → US1 本人数量 → US2 备注与整体限制 → US3 私密恢复与修改
全部页面状态 ───────────────────────────────→ US4 响应式
全部故事 → 测试数据与验收收尾
```

### 并行机会

- T002 与 T003 可并行；T008 可在迁移云端应用前完成。
- US1 中菜品卡片可与 Server Action 分文件推进。
- US3 的本人状态组件可与恢复读取分文件推进。

## 实现策略

1. 先完成两表模型、本人读取 RLS 和原子保存 RPC，再开放页面写入。
2. 先打通 US1 的正数量与零菜保存，确认 0 不形成选择行。
3. 在同一保存契约中加入 US2 文字字段，验证失败不部分覆盖。
4. 使用 3 个真实匿名身份验证 US3 刷新恢复与越权隔离。
5. 最后完成响应式、种子数据、完整构建、浏览器验收、Advisors 和阶段台账。

## 格式校验

- 共 28 个任务，编号 T001–T028 连续。
- 所有任务均包含 checkbox、任务 ID 和具体文件路径或明确验收文档。
- 用户故事阶段任务全部包含 `[US1]`–`[US4]` 标签；仅真正无文件冲突的任务标记 `[P]`。
