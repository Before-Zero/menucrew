# 实现计划：成员个人选菜

**分支**：`codex/003-member-selection` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

**输入**：`specs/003-member-selection/spec.md`

## 摘要

在 002 已发布双语菜单和房间匿名成员关系之上，增加一条完全个人化的选择链路：每个成员为菜品填写本人实际份数，对正数量菜品附口味备注，并保存整体忌口与过敏信息。每次保存由一个受控数据库入口在单一事务中校验当前已发布菜单并整体替换本人数据；业务表只向当前身份开放本人读取，不直接开放写权限，从而确保其他成员和组织者在 003 都不能读取或改动他人内容。页面复用现有 RoomShell 视觉体系，提供手机优先的数量步进器、本人摘要和保存反馈，不实现任何全员状态或汇总。

## 技术上下文

**语言/版本**：TypeScript 5；SQL（PostgreSQL 17）；Node.js 24 本地脚本

**主要依赖**：Next.js 16.3.1 App Router、React 19.2.8、Tailwind CSS 4、shadcn/ui、lucide-react、`@supabase/supabase-js` 2.112.3、`@supabase/ssr` 0.12.4

**存储**：现有 Supabase PostgreSQL；新增 `member_submissions` 与 `member_selections`，不新增 Storage 或外部服务

**测试**：`npm run verify`；`npm run build`；真实匿名身份种子脚本；数据库/RLS 只读与越权断言；2–3 个隔离浏览器和 360/1280 像素人工验收

**目标平台**：现代手机和桌面浏览器；Next.js Node.js 服务端；后续 Vercel 部署

**项目类型**：单体响应式 Web 应用

**性能目标**：几十道菜的小型房间中，保存一次完整个人选择后页面在一次反馈周期内恢复；读取使用成员与菜品索引，不产生逐成员查询

**约束**：每人每房间一份提交；每人每菜最多一条正数量；0–20 整数；单菜备注 240 字符；整体忌口/过敏各 500 字符；保存原子化；只读本人；仅已发布菜单可保存；不使用 AI、价格、汇总或关闭收集

**规模/范围**：2 张新表、1 个原子保存 RPC、1 个个人选择页面、1 个 Server Action、3 个 UI 组件、1 个可重复测试数据命令；Demo 房间通常 2–8 人、8–50 道菜

## 宪章检查

*门槛：Phase 0 前检查，Phase 1 设计后复核。*

- **MVP 核心路径优先：通过。** 个人数量与饮食限制是 004 精确汇总的直接输入；未加入他人查看、汇总或收集状态。
- **按需求直接实现：通过。** 复用现有身份、菜单、Server Action 和 Supabase client；只新增两张必要表、一个事务入口和一个页面，不新增依赖或通用表单框架。
- **最小可用数据闭环：通过。** 数据写入真实数据库并由隔离身份恢复，不以客户端假数据代替。
- **安全底线：通过。** RPC 从当前匿名身份推导所有权；业务表仅授权本人读取，函数固定空 `search_path` 并撤销默认执行权；不使用 secret key。
- **静态检查即质量门槛：通过。** 保留 `npm run verify` 和人工核心路径验收，不把新自动化测试设为前置条件；生产构建作为本阶段额外回归检查。
- **设计后复核：通过。** 研究、数据模型和契约没有引入未来汇总抽象、实时同步、AI 或新基础设施。

## 项目结构

### 本功能文档

```text
specs/003-member-selection/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── member-selection.md
├── checklists/
│   └── requirements.md
└── tasks.md
```

### 源码

```text
app/
└── rooms/[roomId]/
    ├── page.tsx
    └── selection/
        ├── actions.ts
        └── page.tsx

components/
├── member-selection-form.tsx
├── selection-item-card.tsx
└── selection-status.tsx

lib/
├── selection-action-state.ts
├── selections.ts
└── validation.ts

scripts/
└── create-test-selections.mjs

supabase/migrations/
└── *_member_selection.sql
```

**结构决策**：继续使用单体 App Router。房间页只显示本人选择入口与本人保存状态；个人选择统一位于 `/rooms/[roomId]/selection`。Server Component 读取本人数据，客户端表单负责即时数量摘要和 pending 状态，Server Action 解析输入后调用数据库事务 RPC。数据库函数负责最终菜单、成员、范围和重复项校验，并只用 `auth.uid()` 写本人记录。

## 复杂度跟踪

无宪章违规，无需复杂度豁免。
