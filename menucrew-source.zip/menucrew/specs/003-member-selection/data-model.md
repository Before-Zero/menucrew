# Phase 1 数据模型：成员个人选菜

## 关系概览

```text
rooms 1 ── 1 menus 1 ── N menu_items
  │
  └── N room_members 1 ── 1 member_submissions 1 ── N member_selections
                                                    N ── 1 menu_items
```

## `member_submissions`

代表某个房间成员在该房间的唯一个人提交，包括即使零菜品也需要保存的整体信息。

| 字段 | 类型 | 规则 |
| --- | --- | --- |
| `id` | UUID | 主键，默认随机生成 |
| `room_id` | UUID | 非空；与 `user_id` 组成外键指向 `room_members`；房间删除时级联 |
| `user_id` | UUID | 非空；始终由当前 `auth.uid()` 写入，不接受客户端指定 |
| `dietary_restrictions` | text | 非空默认空字符串；去首尾空白；最多 500 字符 |
| `allergy_info` | text | 非空默认空字符串；去首尾空白；最多 500 字符 |
| `submitted_at` | timestamptz | 最近一次完整保存时间，非空 |
| `created_at` | timestamptz | 首次提交时间，非空 |
| `updated_at` | timestamptz | 最近修改时间，非空 |

约束与索引：

- `unique (room_id, user_id)` 保证每房间每成员一份提交。
- 复合外键 `(room_id, user_id)` 指向 `room_members (room_id, user_id)`，防止非成员提交。
- `(user_id, room_id)` 复合索引支持本人读取与 RLS 所有权判断。

## `member_selections`

代表本人提交中一条正数量菜品需求；不存在即页面数量 0。

| 字段 | 类型 | 规则 |
| --- | --- | --- |
| `id` | UUID | 主键，默认随机生成 |
| `submission_id` | UUID | 非空外键指向 `member_submissions`，提交删除时级联 |
| `menu_item_id` | UUID | 非空外键指向 `menu_items`，菜品删除时级联 |
| `quantity` | smallint | 非空；1–20 整数 |
| `note` | text | 非空默认空字符串；去首尾空白；最多 240 字符 |
| `created_at` | timestamptz | 首次选择时间，非空 |
| `updated_at` | timestamptz | 最近修改时间，非空 |

约束与索引：

- `unique (submission_id, menu_item_id)` 保证每人每菜一条。
- `submission_id` 外键已由唯一索引左前缀覆盖；另建 `(menu_item_id, submission_id)` 支持 004 按菜汇总与级联。
- RPC 额外确认 `menu_item_id` 属于 `room_id` 当前唯一且已发布菜单。

## 状态与保存转换

```text
无提交
  └─ 保存任意合法表单（可全为 0） → 已提交

已提交
  ├─ 再次保存合法表单 → 原子替换为最新提交
  ├─ 某菜改为 0 → 删除该菜选择与备注
  └─ 菜单非 published / 任一字段非法 → 整次拒绝，保留旧提交
```

003 不设置“已锁定”或“关闭收集”状态；004 才会在房间级引入关闭与重新开放。

## RLS 与授权

### `member_submissions`

- `SELECT`：`user_id = (select auth.uid())`。
- 不向客户端角色授予直接 INSERT/UPDATE/DELETE。
- 原子保存 RPC 用当前身份写本人唯一记录。

### `member_selections`

- `SELECT`：私有辅助函数确认 `submission_id` 属于当前 `auth.uid()`。
- 不向客户端角色授予直接 INSERT/UPDATE/DELETE。
- 组织者没有额外策略；004 需要全员状态时通过后续迁移明确新增。

### `save_my_selection` RPC

- 仅 `authenticated` 可执行；`PUBLIC` 与 `anon` 无权执行。
- 必须有非空 `auth.uid()` 且是候选房间成员。
- 锁定当前房间菜单，要求 `published`。
- payload 必须为数组，菜品 ID 不重复，数量为 0–20 整数，备注不超过 240 字符，菜品均属于当前菜单。
- 在单一事务中 upsert 本人提交、删除旧明细、只插入正数量明细。
- 返回本人 submission UUID，不返回其他成员信息。
