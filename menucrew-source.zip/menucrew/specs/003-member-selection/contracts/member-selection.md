# Phase 1 接口契约：成员个人选菜

## 页面契约

### `GET /rooms/[roomId]`

- 已发布菜单存在时，所有房间成员看到“填写我的选择”入口。
- 入口显示本人“尚未保存”或“已保存 · N 道 / M 份”，只基于本人数据。
- 组织者原有菜单管理入口保持不变；页面不显示其他成员提交状态或汇总。

### `GET /rooms/[roomId]/selection`

- 必须有当前匿名身份与房间成员关系。
- 仅当前菜单为 `published` 时展示个人选择表单；无菜单或草稿时展示等待状态。
- 按发布菜单稳定顺序展示双语菜品、解释、0–20 数量控件和单菜备注。
- 读取并合并当前身份的提交；没有 `member_selections` 行的菜品显示 0。
- 顶部或保存区显示本人已选菜品种数、总份数和最近保存状态。
- 不生成或传输其他成员的选择、备注、忌口、过敏或提交状态。

## Server Action 契约

### `saveMySelectionAction(roomId, previousState, formData)`

**固定字段**：

- `dietaryRestrictions`：0–500 字符。
- `allergyInfo`：0–500 字符。

**每道菜字段**：

- `quantity:<menuItemId>`：0–20 整数。
- `note:<menuItemId>`：0–240 字符。

**行为**：

1. 验证房间 ID、字段名、菜单菜品 ID、数量与文字长度。
2. 只构造当前页面菜单中的菜品数组，不接受额外未知菜品。
3. 调用 `save_my_selection` RPC；数据库重新验证当前身份、成员关系和已发布菜单。
4. 成功返回 `{ status: "success", message, submittedAt }` 并刷新房间和个人选择页。
5. 失败返回可序列化错误状态，不清空浏览器尚未提交的表单，也不暴露数据库结构。

## 数据库 RPC 契约

### `save_my_selection(candidate_room_id uuid, dietary_restrictions text, allergy_info text, selections jsonb) returns uuid`

`selections` 中每项结构：

```json
{
  "menuItemId": "uuid",
  "quantity": 2,
  "note": "少辣"
}
```

**前置条件**：

- 当前 `auth.uid()` 非空且属于 `candidate_room_id`。
- 房间当前唯一菜单为 `published`。
- 数组没有重复 `menuItemId`；每项 ID、数量和备注合法；所有菜属于当前菜单。

**成功语义**：

- upsert 本人唯一 `member_submissions`，维护整体字段和提交时间。
- 删除本人此前所有 `member_selections`，再插入本次 `quantity > 0` 的项目。
- 整个调用是单一事务；返回本人 submission ID。

**失败语义**：

- 任一校验或写入失败，全部回滚；此前完整提交保持不变。
- 标准化错误类别：`not_room_member`、`menu_not_published`、`invalid_selection_payload`、`duplicate_menu_item`、`menu_item_not_available`。

## 数据读取契约

### `getMySelection(roomId)`

- 复用 `getRoomMenu(roomId)` 获取当前角色可见的已发布菜单。
- 查询当前身份唯一 `member_submissions`；RLS 保证只返回本人。
- 若有提交，读取其 `member_selections` 并按 `menu_item_id` 合并到菜单；RLS 保证只返回本人明细。
- 返回 `{ access, menu, items, submission, selectedCount, totalQuantity }`；不包含其他成员数据。

## 错误文案

| 类别 | 用户文案 | 后续动作 |
| --- | --- | --- |
| 数量非法 | 每道菜请输入 0–20 的整数 | 修正对应数量 |
| 备注过长 | 口味备注最多 240 个字符 | 缩短对应备注 |
| 整体信息过长 | 忌口和过敏信息各最多 500 个字符 | 缩短对应字段 |
| 菜单不可用 | 菜单正在更新，请刷新后重新选择 | 刷新页面 |
| 身份无权 | 无法访问或保存这份个人选择 | 使用正确房间身份 |
| 服务失败 | 暂时无法保存，你填写的内容仍在本页 | 稍后重试 |
