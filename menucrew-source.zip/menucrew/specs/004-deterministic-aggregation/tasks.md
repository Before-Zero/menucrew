# 任务：确定性汇总与收集控制

**输入**：`specs/004-deterministic-aggregation/` 下的设计文档

**前置资料**：`plan.md`、`spec.md`、`research.md`、`data-model.md`、`contracts/`、`quickstart.md`

## 格式：`[ID] [P?] [Story] 描述`

- **[P]**：可与同阶段其他任务并行，修改不同文件且不依赖未完成任务
- **[Story]**：映射到规格中的用户故事

## 阶段 1：准备

**目标**：建立 004 的数据库迁移与固定验收数据入口。

- [x] T001 使用 Supabase CLI 创建 `supabase/migrations/*_deterministic_aggregation.sql`
- [x] T002 [P] 在 `scripts/create-test-aggregation.mjs` 建立 5 名成员、8 道菜和固定人工答案的验收数据脚本
- [x] T003 [P] 在 `package.json` 增加 004 固定数据命令

---

## 阶段 2：基础能力（阻塞所有用户故事）

**目标**：完成收集状态、修订号、并发边界及组织者只读权限。

**关键检查点**：此阶段完成前不得实现汇总页面。

- [x] T004 在 `supabase/migrations/*_deterministic_aggregation.sql` 为 `rooms` 增加收集状态、切换时间和单调修订号及约束
- [x] T005 在 `supabase/migrations/*_deterministic_aggregation.sql` 增加组织者读取本房间全员提交与明细的 RLS 策略，并保持成员本人隔离
- [x] T006 在 `supabase/migrations/*_deterministic_aggregation.sql` 实现组织者关闭/重开收集的原子 RPC
- [x] T007 在 `supabase/migrations/*_deterministic_aggregation.sql` 改造 `save_my_selection`，统一先锁房间行、核对中整次拒绝并在成功保存后递增修订号
- [x] T008 将迁移应用到 Supabase 云项目并更新 `lib/supabase/database.types.ts`
- [x] T009 [P] 在 `lib/rooms.ts` 扩展房间收集状态与修订号读取类型

**检查点**：状态切换、保存边界、RLS 和类型均可供后续故事复用。

---

## 阶段 3：用户故事 1——提交状态与精确总数（优先级：P1）🎯 MVP

**目标**：组织者看到全部成员提交状态和按当前菜单确定性求和的菜品汇总。

**独立验收**：固定 5 人数据得到 4/5 已提交、4 道已选、9 份总量，逐菜总数为 3、1、3、2，数量 0 不出现。

- [x] T010 [US1] 在 `lib/aggregation.ts` 定义汇总结果类型并一次性读取成员、菜单、提交和选择
- [x] T011 [US1] 在 `lib/aggregation.ts` 使用 Map 与整数加法构建提交进度、菜品总数和整桌总份数
- [x] T012 [P] [US1] 在 `components/aggregation-member-status.tsx` 实现成员提交状态与未提交名单
- [x] T013 [P] [US1] 在 `components/aggregation-dish-list.tsx` 实现逐菜总份数与贡献人数核对卡片
- [x] T014 [US1] 在 `app/rooms/[roomId]/summary/page.tsx` 接入组织者汇总读取、关键指标和真实空状态

**检查点**：不依赖 AI，组织者可独立核对固定数据的提交人数和全部数量。

---

## 阶段 4：用户故事 2——关闭与重新开放收集（优先级：P1）

**目标**：组织者控制收集边界；核对中成员恢复本人数据但不可保存。

**独立验收**：关闭后已打开的成员表单保存失败且旧数据不变；重新开放后保存成功并准确更新汇总。

- [x] T015 [P] [US2] 在 `lib/aggregation-action-state.ts` 定义状态操作的 ActionState 与错误映射
- [x] T016 [US2] 在 `app/rooms/[roomId]/summary/actions.ts` 实现组织者关闭/重开 Server Action 与页面刷新
- [x] T017 [US2] 在 `components/collection-status-action.tsx` 实现开放/核对状态提示及确认操作
- [x] T018 [US2] 在 `lib/selections.ts` 和 `app/rooms/[roomId]/selection/page.tsx` 将核对中选择页切换为只读恢复
- [x] T019 [US2] 在 `components/member-selection-form.tsx` 禁用核对中的数量、备注、限制与保存操作
- [x] T020 [US2] 在 `app/rooms/[roomId]/selection/actions.ts` 将数据库关闭拒绝映射为明确提示
- [x] T021 [US2] 在 `app/rooms/[roomId]/summary/page.tsx` 接入收集控制、修订号和数字锁定提示

**检查点**：关闭、并发保存拒绝、刷新只读和重新开放链路可独立验收。

---

## 阶段 5：用户故事 3——成员归属、备注与饮食限制（优先级：P2）

**目标**：组织者能从每道菜总数追溯成员来源，并集中核对忌口和过敏。

**独立验收**：共同选择同一菜品的成员姓名、本人数量和备注逐项对应；零菜提交成员的过敏信息仍可见；普通成员无法读取。

- [x] T022 [US3] 在 `lib/aggregation.ts` 补充逐菜贡献成员、单菜备注和已提交成员饮食信息映射
- [x] T023 [US3] 在 `components/aggregation-dish-list.tsx` 展示逐成员数量、备注并校验明细和总数的视觉对应
- [x] T024 [US3] 在 `app/rooms/[roomId]/summary/page.tsx` 增加忌口与过敏核对区并处理空字段
- [x] T025 [US3] 在 `scripts/create-test-aggregation.mjs` 断言成员只能读取本人、跨房间组织者无权限且汇总明细无泄露

**检查点**：总数、来源、备注和饮食风险构成完整且权限收窄的核对信息。

---

## 阶段 6：用户故事 4——手机与桌面核对体验（优先级：P3）

**目标**：在 360 像素和 1280 像素下清楚查看和操作，无横向滚动。

**独立验收**：两种宽度下状态、关键总数、成员、长备注、饮食信息和关闭/重开按钮均完整可见。

- [x] T026 [US4] 在 `app/rooms/[roomId]/summary/page.tsx` 完成手机优先的核对夹板布局与桌面分栏层级
- [x] T027 [P] [US4] 在 `components/aggregation-member-status.tsx` 优化窄屏进度轨与长姓名换行
- [x] T028 [P] [US4] 在 `components/aggregation-dish-list.tsx` 优化大数字、贡献明细和长备注的响应式呈现
- [x] T029 [P] [US4] 在 `components/collection-status-action.tsx` 保证窄屏状态操作清楚可达

**检查点**：相同数据在手机与桌面保持一致、清楚且可操作。

---

## 阶段 7：收口与跨故事验证

**目标**：用真实云端数据、隔离身份、静态检查和生产构建完成 004 验收。

- [x] T030 运行 `scripts/create-test-aggregation.mjs` 并逐项核对 `specs/004-deterministic-aggregation/quickstart.md` 的固定人工答案
- [x] T031 使用 3 个隔离浏览器验收组织者、成员关闭/重开、刷新恢复和权限边界
- [x] T032 在 360 像素与 1280 像素完成汇总页面视觉和无横向滚动检查
- [x] T033 运行 Supabase 安全与性能顾问并处理本阶段引入的问题
- [x] T034 运行 `npm run verify` 与 `npm run build` 并修复全部错误
- [x] T035 [P] 同步 `AGENTS.md`、`progress.md` 与 `specs/004-deterministic-aggregation/tasks.md` 的最终状态和命令说明
- [x] T036 提交 004 的规格、迁移、实现与收口文档

---

## 依赖与执行顺序

- 阶段 1 无依赖，可立即开始。
- 阶段 2 依赖阶段 1，并阻塞所有用户故事。
- 用户故事 1 和 2 都是 004 的 P1 主路径；先完成精确读取，再接入状态操作。
- 用户故事 3 复用用户故事 1 的汇总结构；用户故事 4 复用前三个故事的组件。
- 收口阶段依赖全部目标故事完成。

### 可并行机会

- T002 与 T003 可并行准备；T009 可在数据库 SQL 完成时同步更新类型读取。
- 用户故事 1 的成员状态与菜品列表组件可并行实现。
- 用户故事 4 的三个组件响应式调整可并行进行。
- 文档状态可在验证命令运行期间整理，但最终勾选必须以真实结果为准。

## 实施策略

1. 先建立数据库状态、锁顺序、RLS 与修订号，确保边界由数据层保证。
2. 用固定人工答案交付用户故事 1 的最小可用精确汇总。
3. 接入关闭/重开，并验证已打开表单无法绕过。
4. 增加来源、备注和饮食核对，不改变求和来源。
5. 最后完成响应式与真实隔离浏览器验收，再统一提交。

## 说明

- 所有数量由服务端读取真实提交后用普通整数加法计算，不创建汇总副本。
- 任务不包含价格、最终订单快照、AI 建议、实时推送或成员修改他人提交。
- 每个勾选项都必须由实际实现或实际验收结果支持。
