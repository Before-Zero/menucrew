# 实现计划：确定性汇总与收集控制

**分支**：`codex/004-deterministic-aggregation` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

**输入**：`specs/004-deterministic-aggregation/spec.md`

## 摘要

在 003 的本人提交之上，为房间增加开放收集/核对中状态和单调修订号。成员保存与组织者状态切换统一先锁定同一房间行，从而明确并发先后：关闭先完成则后续保存整次失败，保存先完成则计入关闭后的稳定汇总。组织者获得本房间所有提交与明细的只读 RLS 权限，普通成员继续只读本人；服务端用菜单、成员、提交和正数量明细构建确定性汇总，不创建可编辑副本、不使用 AI。现有汇总骨架升级为手机优先的“核对夹板”，突出收集状态、提交进度、整桌总份数、逐菜来源和饮食信息。

## 技术上下文

**语言/版本**：TypeScript 5；SQL（PostgreSQL 17）；Node.js 24 本地脚本

**主要依赖**：Next.js 16.3.1 App Router、React 19.2.8、Tailwind CSS 4、shadcn/ui、lucide-react、`@supabase/supabase-js` 2.112.3、`@supabase/ssr` 0.12.4

**存储**：现有 Supabase PostgreSQL；只扩展 `rooms` 状态字段、现有选择 RLS 和 RPC，不新增业务表、Storage 或外部服务

**测试**：`npm run verify`、`npm run build`、真实匿名身份种子脚本、固定人工答案、数据库/RLS 断言、3 个隔离浏览器和 360/1280 像素人工验收

**目标平台**：现代手机和桌面浏览器；Next.js Node.js 服务端；后续 Vercel 部署

**项目类型**：单体响应式 Web 应用

**性能目标**：几十道菜和 2–8 名成员的演示房间在一次服务端读取中完成汇总；构建过程使用 Map 索引，避免按成员或菜品重复请求

**约束**：普通程序精确求和；关闭后数据层拒绝写入；状态切换只限组织者；成员仍只读本人；0 不统计；当前菜单菜品过滤；不使用 AI、价格、订单或实时推送

**规模/范围**：1 个增量迁移、2 个 RPC 变更、1 个汇总读取模块、1 个状态 Action、3 个汇总组件、1 个扩展测试数据命令；Demo 通常 2–8 人、8–50 道菜

## 宪章检查

- **MVP 核心路径优先：通过。** 精确汇总和关闭收集直接承接 003，并为 005 最终订单提供稳定输入；未加入 AI、价格、确认订单或实时同步。
- **按需求直接实现：通过。** 复用现有房间、菜单、提交和 RLS，只扩展房间状态及两条收窄 RPC；不创建汇总表、事件系统或通用工作流框架。
- **最小可用数据闭环：通过。** 汇总从真实云端提交计算，以固定数据和隔离浏览器核对，不使用客户端假数据。
- **安全底线：通过。** 组织者全员读取由房间角色 RLS 控制；成员保存和状态切换都从 `auth.uid()` 重新鉴权；无 secret client。
- **静态检查即质量门槛：通过。** 保留 `npm run verify` 和人工核心路径验收；生产构建作为本阶段额外回归检查。
- **设计后复核：通过。** 数据模型与契约没有引入可编辑汇总副本、最终订单快照、AI 或新基础设施。

## 项目结构

```text
app/rooms/[roomId]/summary/{actions.ts,page.tsx}
components/{collection-status-action.tsx,aggregation-dish-list.tsx,aggregation-member-status.tsx}
lib/{aggregation-action-state.ts,aggregation.ts,selections.ts}
scripts/create-test-aggregation.mjs
supabase/migrations/*_deterministic_aggregation.sql
```

**结构决策**：继续使用现有单体 App Router。`lib/aggregation.ts` 在服务端按当前组织者会话读取并构建只读结果；页面仅接收完成后的汇总结构。关闭/重开通过 Server Action 调用数据库事务 RPC。成员选择页面从 `rooms` 读取收集状态，核对中仍恢复本人提交但渲染只读状态。数据库不保存汇总副本，修订号只标识输入版本。

## 复杂度跟踪

无宪章违规，无需复杂度豁免。
