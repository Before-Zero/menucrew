# Tasks: 可执行 AI 推荐与共享点单链路

**Input**: `/specs/012-actionable-ai-handoff/` 中的 spec、plan、research、data-model、contracts 与 quickstart

## Phase 1: Setup

- [X] T001 核对现有 011/010 工作树、共享汇总与菜单助手实现边界，记录需保留的用户改动于 specs/012-actionable-ai-handoff/tasks.md
- [X] T002 验证 .gitignore 与 Next.js/TypeScript 项目忽略规则，不改动无关配置于 .gitignore

## Phase 2: Foundational

- [X] T003 定义个人推荐与单菜解释的判别式类型、摘要和严格验证规则于 lib/menu-assistant.ts
- [X] T004 [P] 梳理成员安全共享结果与组织者附加数据的服务端组合接口于 lib/member-receipt.ts、lib/room-progress.ts、lib/orders.ts

## Phase 3: User Story 1 - AI 推荐直接变成可编辑选择 (P1) 🎯 MVP

**Goal**: AI 返回真实菜单组合，一次应用到未保存表单，允许撤销和编辑，绝不自动提交。

**Independent Test**: 应用推荐后表单数量改变但数据库不变；主动保存后才持久化，备注和饮食字段始终保留。

- [X] T005 [US1] 扩展推荐提示词、最小输入、结构化解析、菜品/数量/风险白名单校验于 lib/menu-assistant.ts
- [X] T006 [US1] 扩展菜单助手 Server Action 支持推荐意图、现有限额复用及失败保护于 app/rooms/[roomId]/selection/assistant-actions.ts
- [X] T007 [US1] 将菜单助手界面重塑为个人组合主入口、单菜问答次入口并呈现过期/风险状态于 components/menu-assistant-sheet.tsx
- [X] T008 [US1] 在点餐表单接入应用、保留未涉及选择、dirty 标记与一次撤销于 components/member-selection-form.tsx
- [X] T009 [US1] 在个人选择页传递菜单/选择摘要及推荐回调所需数据于 app/rooms/[roomId]/selection/page.tsx

## Phase 4: User Story 2 - 全员同一个本桌点单页 (P1)

**Goal**: 保存后全员进入共享结果；确认前看安全实时汇总，确认后看最终订单。

**Independent Test**: 两身份保存后进入相同 URL 和总数；普通成员响应不含敏感数据；确认后同入口显示一致订单。

- [X] T010 [US2] 重构 summary 服务端加载为全员安全基础层和组织者私有附加层于 app/rooms/[roomId]/summary/page.tsx
- [X] T011 [US2] 将实时小票组件改造成共享实时汇总并保留 no-store 轮询、本人贡献和失败保留于 components/member-receipt-live.tsx
- [X] T012 [US2] 让选择保存成功后刷新并跳转共享 summary 于 app/rooms/[roomId]/selection/actions.ts
- [X] T013 [P] [US2] 将旧实时小票页面安全跳转至共享 summary 于 app/rooms/[roomId]/receipt/page.tsx
- [X] T014 [US2] 在最终确认后于同一 summary 复用稳定最终订单视图并停止实时状态于 app/rooms/[roomId]/summary/page.tsx、components/final-order-view.tsx

## Phase 5: User Story 3 - 菜单发布后共用一条旅程 (P1)

**Goal**: 所有人共用菜单、我的选择、本桌点单三个主入口，权限差异只在局部操作。

**Independent Test**: 两身份导航名称和顺序一致，普通成员无组织者专属能力。

- [X] T015 [US3] 统一发布后导航和主操作派生于 components/room-journey-nav.tsx、lib/room-journey.ts
- [X] T016 [US3] 调整组织者与成员房间工作台进入共享旅程的主操作于 components/organizer-room-dashboard.tsx、components/member-room-dashboard.tsx

## Phase 6: User Story 4 - 保留单菜解释 (P2)

- [X] T017 [US4] 验证单菜说明关闭后不重置未保存表单并补齐次要入口文案于 components/menu-assistant-sheet.tsx、components/member-selection-form.tsx

## Phase 7: Polish & Validation

- [X] T018 更新项目速览和 012 实现事实于 AGENTS.md、specs/012-actionable-ai-handoff/quickstart.md
- [X] T019 执行 npm run verify 与 npm run build 并修复本功能引入的问题于受影响源码
- [X] T020 按 quickstart 完成组织者/普通成员双身份、隐私、旧链接和 AI 未自动保存验收于 specs/012-actionable-ai-handoff/quickstart.md

## Dependencies

- T001–T004 阻塞所有用户故事。
- US1（T005–T009）可独立完成；T005 → T006 → T007/T008 → T009。
- US2（T010–T014）可与 US1 并行；T010/T011 → T012/T013 → T014。
- US3 依赖 US2 的规范入口；T015 → T016。
- US4 依赖 US1；T017 在 T007–T009 后执行。
- T018–T020 依赖全部故事完成。

## Parallel Opportunities

- T003 与 T004 可在不同服务文件并行分析。
- T007 与 T008 在接口确定后可分组件实施。
- T013 可与 T010–T012 并行。
- US1 与 US2 的核心服务实现可并行，但涉及页面集成时顺序合并。

## Implementation Strategy

先完成共享类型与安全数据边界；再分别交付可执行 AI 推荐和统一结果入口；随后统一导航、保留单菜解释，最后用静态构建与双身份链路验收整体闭环。
