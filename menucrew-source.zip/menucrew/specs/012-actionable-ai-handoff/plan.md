# Implementation Plan: 可执行 AI 推荐与共享点单链路

**Branch**: `012-actionable-ai-handoff` | **Date**: 2026-08-23 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/012-actionable-ai-handoff/spec.md`

## Summary

菜单发布后统一为“菜单 → 我的选择 → 本桌点单”。现有独立实时小票并入全员可访问的 `/rooms/[roomId]/summary`：确认前组合成员安全汇总、本人贡献和提交进度，确认后在同一入口展示最终订单；只有组织者额外获得成员明细、饮食风险、整桌建议和确认操作。

个人点餐页的主要 AI 能力升级为 2–4 道真实菜单菜组成的结构化推荐。推荐只写入浏览器内尚未保存的表单，允许撤销、修改后主动保存；单菜问答退居次要入口。复用现有 Gemini 调用、限额、安全 RPC、订单读取和轮询边界，不增加依赖、数据表或更宽权限。

## Technical Context

**Language/Version**: TypeScript 5；Next.js 16.3.1；React 19.2.8

**Primary Dependencies**: Next.js App Router、React、Tailwind CSS 4、shadcn/ui、Supabase SSR/JS、Google Gemini Developer API

**Storage**: Supabase Postgres；沿用现有菜单、提交、AI 运行记录和最终订单表

**Testing**: `npm run verify`、`npm run build`、现有 seed 脚本、双身份浏览器验收

**Target Platform**: Vercel 响应式 Web 应用，手机优先

**Project Type**: Next.js 全栈 Web 应用

**Performance Goals**: 保存后一次跳转进入共享结果；实时汇总复用轻量 no-store 读取；应用推荐即时完成且不等待保存

**Constraints**: 普通成员不得得到他人敏感信息；AI 只使用发布菜单和本人上下文；AI 不自动提交；旧链接安全兼容

**Scale/Scope**: 约 3 个主页面、4–6 个共享组件/服务及导航与验收文档；无新服务或数据库迁移

## Constitution Check

*GATE: Phase 0 前检查，并在 Phase 1 设计后复查。*

| 宪章原则 | 设计响应 | 结果 |
|---|---|---|
| MVP 优先 | 复用已有 RPC、AI 记录、订单和轮询 API，不新增表、服务或依赖 | PASS |
| 真实闭环 | AI 推荐进入真实表单；保存后进入真实汇总；确认仍生成正式快照 | PASS |
| 安全边界 | 共享层只读成员安全结果；敏感聚合只在组织者验证后加载 | PASS |
| 直接可维护 | 一个规范入口承载实时与最终状态；旧入口仅兼容跳转 | PASS |
| 可验证 | 静态检查、构建、AI 不自动保存与双身份隐私验收均已定义 | PASS |

**Phase 1 复查**: PASS。研究和数据设计未引入宪章例外。

## Project Structure

### Documentation (this feature)

```text
specs/012-actionable-ai-handoff/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/shared-journey-contracts.md
└── tasks.md                       # 后续由 $speckit-tasks 生成
```

### Source Code (repository root)

```text
app/rooms/[roomId]/
├── menu/
├── selection/
│   ├── actions.ts                 # 保存后跳转共享本桌点单
│   ├── assistant-actions.ts       # 个人推荐与单菜问答
│   └── page.tsx
├── summary/
│   ├── advice-actions.ts          # 组织者私有整桌建议
│   └── page.tsx                   # 全员规范入口
├── receipt/page.tsx               # 旧地址兼容跳转
└── order/                          # 保留订单能力与兼容访问

app/api/rooms/[roomId]/receipt/     # 复用成员安全 no-store 轮询

components/
├── member-selection-form.tsx
├── menu-assistant-sheet.tsx
├── member-receipt-live.tsx
├── room-journey-nav.tsx
└── final-order-view.tsx

lib/
├── menu-assistant.ts
├── member-receipt.ts
├── room-progress.ts
├── aggregation.ts
├── orders.ts
└── room-journey.ts
```

**Structure Decision**: 保持现有单体 Next.js App Router 结构。共享页在服务端按角色组合既有读取能力；普通成员请求不生成敏感数据，浏览器轮询只经过成员安全 API。

## Implementation Phases

### Phase A — 统一旅程和结果入口

1. 发布后导航统一为“菜单、我的选择、本桌点单”，组织者管理变为页面内专属操作。
2. `/summary` 对所有成员开放；先读成员安全汇总、进度和最终订单，仅为组织者追加敏感聚合和确认数据。
3. 把实时小票组件整合进共享页，保留轮询和本人贡献；确认后切换稳定订单视图。
4. 保存选择成功后 revalidate 并跳转 `/summary`。依 Next.js 16 文档，`redirect()` 位于错误捕获之外。
5. `/receipt` 页面安全转向 `/summary`，安全轮询 API 暂留作内部实现。

### Phase B — 可执行个人 AI 推荐

1. 菜单助手改为判别式结果：`recommendation` 返回摘要、风险和 2–4 个菜品 ID/份数/理由；`explanation` 沿用单菜回答。
2. 服务端严格验证菜品属于发布菜单、ID 唯一、数量 1–20、最多 4 项；无效或冲突项不可应用。
3. 推荐绑定菜单与本人表单摘要；来源变化后标记过期。
4. 合法推荐通过回调写入表单本地数量，保留未涉及选择和全部文字字段，并提供一次撤销。
5. AI 只改变未保存状态，唯一持久化入口仍是用户主动保存。

### Phase C — 组织者收尾与兼容整理

1. 同页追加组织者专属成员明细、饮食风险、自动整桌建议和最终确认。
2. 保持最终确认权限和原子快照不变；确认后全员从 `/summary` 读取同一订单。
3. 清理导航中的“实时小票”“组织者汇总”等重复概念，并明确旧 `/order`、`/receipt` 的兼容行为。

### Phase D — 验证

1. 静态检查和生产构建。
2. 验收 AI 格式、无效项、风险、失败保护、应用未保存、撤销和过期。
3. 双身份验收统一导航、保存跳转、实时更新、隐私隔离、确认及最终订单一致性。
4. 验收旧地址和越权访问。

## Complexity Tracking

无宪章违规，无需例外说明。
