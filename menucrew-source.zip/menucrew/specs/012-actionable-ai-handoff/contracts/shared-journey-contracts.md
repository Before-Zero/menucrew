# Contracts: 共享点单旅程与 AI 推荐

## 个人推荐 Action

输入包含 `roomId`、意图、当前菜品数量、本人忌口和过敏信息。服务端必须重新确认成员身份并自行读取发布菜单，不信任客户端菜名、角色或他人数据。

```ts
type RecommendationResult = {
  kind: "recommendation";
  summary: string;
  caution: string | null;
  menuDigest: string;
  selectionDigest: string;
  items: Array<{
    menuItemId: string;
    suggestedQuantity: number;
    reason: string;
    risk: "none" | "confirm" | "conflict";
    riskNote: string | null;
  }>;
};
```

允许副作用仅为现有 AI 运行记录、复用和限额；禁止写选择、菜单、汇总或订单。失败必须保留 SelectionDraft。

## 应用推荐

前置条件：菜单和选择摘要匹配、菜品仍存在、数量合法。应用后只改变本地表单并显示“尚未保存”；`conflict` 必须阻止，`confirm` 必须明确提示；支持一次撤销。

## 普通成员安全负载

包含状态、提交数、成员数、本人是否提交、修订、菜品总数、本人贡献和可选最终订单。禁止包含他人 ID/姓名/个人数量/备注/忌口/过敏/提交时间以及组织者建议。

组织者附加负载只有服务端确认 organizer 后才可生成，不属于共享 API。

## 导航与跳转

- 发布后全员主导航：`菜单`、`我的选择`、`本桌点单`。
- 保存成功：刷新相关数据后跳转 `/rooms/{roomId}/summary`。
- 旧 `/rooms/{roomId}/receipt`：校验访问后转向 `/summary`。
- `/summary` 对普通成员开放，不因非组织者身份转回首页。
- 确认后仍在 `/summary` 展示最终订单。

## 实时更新

- 仅在 `active-live` 轮询成员安全 API。
- 新修订替换旧汇总，不叠加。
- 检测到最终订单后停止轮询并切换稳定视图。
- 请求失败保留最后一次成功结果并显示重试状态。
