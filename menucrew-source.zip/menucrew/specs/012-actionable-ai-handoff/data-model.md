# Data Model: 可执行 AI 推荐与共享点单链路

本功能不新增数据库表。以下模型是现有持久化数据的结构化结果和派生视图。

## PersonalRecommendation

| 字段 | 类型 | 规则 |
|---|---|---|
| `kind` | `"recommendation"` | 与单菜解释形成判别式联合 |
| `summary` | string | 简短搭配思路 |
| `caution` | string / null | 风险提示 |
| `menuDigest` | string | 绑定发布菜单摘要 |
| `selectionDigest` | string | 绑定本人表单摘要，不保存明文上下文 |
| `items` | RecommendedDish[] | 1–4 项 |

状态：`idle → generating → ready → applied`；生成可进入 `failed`；来源变化进入 `stale`；应用后可 `reverted`。

验证：菜品必须在当前发布菜单、ID 唯一、数量是 1–20 整数、冲突不可静默应用、摘要不匹配不可应用。

## RecommendedDish

| 字段 | 类型 | 规则 |
|---|---|---|
| `menuItemId` | UUID | 真实发布菜品 |
| `suggestedQuantity` | integer | 1–20 |
| `reason` | string | 一句理由 |
| `risk` | `none \| confirm \| conflict` | conflict 阻止应用 |
| `riskNote` | string / null | 具体确认原因 |

## SelectionDraft

现有客户端表单状态。应用推荐只更新涉及菜品；未涉及正数量、单菜备注、忌口和过敏全部保留；表单变为 dirty，并保留一次 undo 快照。只有主动保存后才成为正式提交。

## SharedTableOrderView

由现有查询即时派生，不持久化。

| 字段 | 来源 | 普通成员可见 |
|---|---|---|
| 菜品合并总数、本人贡献、修订 | `get_member_receipt` | 是 |
| 提交数、成员数、本人状态 | `get_room_submission_progress` | 是 |
| 最终订单菜品快照 | final order RLS | 确认后是 |

状态：`empty-live`（尚无正数量）、`active-live`（仍会变化）、`confirmed`（稳定最终订单）。

## OrganizerReviewOverlay

仅在服务端确认 organizer 后加载：成员姓名和个人数量、备注/忌口/过敏风险、整桌建议、最终数量调整与确认。不得进入普通成员 props、轮询 API 或响应。

## 路由状态

| 条件 | `/summary` | 保存后 |
|---|---|---|
| 未确认 | 共享实时视图 | `/summary` |
| 组织者 | 共享视图 + 私有核对层 | `/summary` |
| 已确认 | 全员一致最终订单 | `/summary` |
| 旧 `/receipt` | 安全跳转 `/summary` | N/A |
