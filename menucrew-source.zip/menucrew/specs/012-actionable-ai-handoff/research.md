# Research: 可执行 AI 推荐与共享点单链路

## 1. `/summary` 是全员唯一“本桌点单”入口

**Decision**: 确认前显示成员安全实时汇总，确认后显示最终订单；`/receipt` 不再是主流程。

**Rationale**: 两者是同一结果的两个状态。一个入口消除重复页面和提交后无下一步的问题。

**Alternatives**: 给小票增加下一步仍保留重复概念；新建结果页扩大迁移；直接删除旧地址会破坏旧链接，因此采用跳转。

## 2. 服务端组合两层数据，不扩大权限

**Decision**: 所有人加载 `getMemberReceipt`、提交进度和成员可读最终订单；只有组织者才调用 `getRoomAggregation`、建议历史和确认候选。

**Rationale**: 现有收窄 RPC 已提供菜品总数、本人贡献和安全计数，无需新表或更宽 RLS。普通成员请求中不生成敏感数据，而非仅在界面隐藏。

**Alternatives**: 允许成员读全员提交会泄露隐私；共享汇总表会制造第二份事实；新增综合 RPC 在现有能力足够时没有必要。

Supabase 当前文档要求暴露表启用 RLS；security-definer 函数应使用安全 `search_path` 并限制执行角色。本功能继续沿用已验收边界。

## 3. 保留现有安全轮询 API

**Decision**: `/api/rooms/[roomId]/receipt` 暂作共享页内部 no-store 数据源，对用户隐藏“小票”概念。

**Rationale**: API 名称不影响用户理解，现有边界已验收。同步改名会无谓触碰路由、轮询与测试。

## 4. AI 使用结构化结果

**Decision**: `recommendation` 返回真实 `menuItemId`、1–20 份数、理由和风险；`explanation` 保留单菜回答。服务端白名单校验后才能交给表单。

**Rationale**: 自然语言难以可靠映射表单；ID 和严格结构可拒绝无效结果。客户端按菜名解析或 AI 直接保存都不安全。

## 5. 应用推荐是可撤销的本地操作

**Decision**: 只更新推荐涉及的数量，保留其他正数量和全部文字字段；保存应用前快照以支持一次撤销。数据库仅在主动保存时改变。

**Rationale**: AI 减少点击，但用户保有决定权，失败和撤销不会损坏输入。

## 6. Server Action 负责规范跳转

**Decision**: 保存后先失效相关缓存，再调用 `redirect('/rooms/[roomId]/summary')`，并把 redirect 放在错误捕获之外。

**Rationale**: Next.js 16 文档说明 Server Action 的 redirect 使用 303 且以抛出控制流实现。客户端再协调跳转没有必要。

## 7. 不增加迁移和依赖

**Decision**: 推荐结果继续使用现有菜单助手运行记录 JSON 和限额，共享页使用现有数据模型。

**Rationale**: 这是交互编排和结果结构升级，不是新的长期业务事实。
