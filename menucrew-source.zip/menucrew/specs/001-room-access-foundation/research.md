# Phase 0 研究：房间与访问骨架

## 决策 1：使用 Supabase Anonymous Auth 与 Cookie SSR 会话

- **决定**：创建或加入前，在 Server Action 中检查当前会话；没有会话时调用 `signInAnonymously()`。使用请求级 SSR client 读写 Cookie，并由根目录 `proxy.ts` 在请求到达页面前刷新会话。
- **理由**：匿名用户拥有稳定 `auth.uid()`，在 Data API 中使用 `authenticated` 数据库角色，可直接参与 RLS；Cookie 会话同时服务于 Server Components 和 Server Actions。当前 Supabase 文档明确匿名用户清除浏览器数据、退出或换设备后无法恢复，与 001 的 MVP 假设一致。
- **替代方案**：自建随机浏览器 ID 无法获得 Supabase Auth/RLS 的可信身份；邮箱登录超出范围；只使用浏览器 localStorage 会让服务端页面无法可靠鉴权。

## 决策 2：Proxy 只刷新会话，最终授权在数据库与数据读取层完成

- **决定**：Next.js 16 的 `proxy.ts` 调用 Supabase `getClaims()` 触发令牌刷新并同步请求/响应 Cookie；不在 Proxy 中访问业务数据库。每个页面和 Server Action仍重新取得身份，并由 RLS 或函数内检查决定权限。
- **理由**：Next.js 16 本地文档明确 Proxy 不适合慢速数据读取，也不能替代完整授权；Server Action 本身是可被直接调用的不可信入口。
- **替代方案**：仅靠页面是否渲染按钮做权限控制无法阻止构造请求；每次 Proxy 查询成员关系增加所有请求延迟且重复授权逻辑。

## 决策 3：创建和加入使用最小原子数据库函数

- **决定**：提供 `create_room` 与 `join_room` 两个数据库函数。二者运行在固定空 `search_path` 下，显式引用对象，验证 `auth.uid()`、匿名 claim、输入长度和邀请摘要；撤销 `PUBLIC`/`anon` 执行权限，仅授予 `authenticated`。函数只返回房间 UUID。
- **理由**：创建房间与组织者关系、验证邀请与成员关系都需要原子写入；仅用两次客户端写入会产生半完成状态。加入者在成为成员之前不应直接查询房间或摘要，因此需要一个收窄返回值的受控入口。
- **替代方案**：服务端 secret client 会绕过 RLS并要求额外高权限环境变量；公开房间摘要读取会泄露验证材料；多步普通写入不满足失败回滚。

## 决策 4：业务表显式 GRANT，并以成员关系实施 RLS

- **决定**：`rooms` 和 `room_members` 均启用并强制 RLS。只向 `authenticated` 显式授予需要的 `SELECT`，写入只经受控函数发生。房间可读条件是当前 `auth.uid()` 已有成员关系；成员列表同样只对该房间成员可见。角色保存在 `room_members.role`，不读取用户 metadata。
- **理由**：Supabase 2026 年变更使新表可能不再自动暴露给 Data API；GRANT 与 RLS 是两个独立门槛。成员关系是房间授权的唯一可信来源，且显示名可重复而不影响权限。
- **替代方案**：`TO authenticated` 而无行谓词会形成越权读取；使用 `user_metadata` 可被用户编辑；客户端直接写 role 会允许提权。

## 决策 5：邀请原值只在浏览器中保留，数据库只保存 SHA-256 摘要

- **决定**：Server Action 用加密安全随机源生成 32 字节 URL-safe token，写入数据库前计算 SHA-256 十六进制摘要。组织者原值存入按房间作用域命名的 HttpOnly、SameSite=Lax Cookie，以便同一浏览器刷新后重新复制；分享地址使用 `/join/<token>`。成员加入成功后跳转至 `/rooms/<roomId>`，地址中不再有 token。
- **理由**：32 字节随机值具备足够不可预测性；数据库泄露不能直接得到可用邀请；Cookie 与匿名身份一起构成同一浏览器的可恢复状态，丢失浏览器数据时二者同时不可恢复。
- **替代方案**：数据库存明文违反台账；单独引入服务端 HMAC secret 增加 001 配置；仅把 token 放 React 状态会在刷新后丢失复制能力。

## 决策 6：动态服务端页面与 Server Actions

- **决定**：首页、加入页、房间页和汇总骨架以 Server Components 为主；创建与加入由 Server Actions 处理；复制按钮和提交状态使用小型 Client Components。动态路由 `params` 按 Next.js 16 要求作为 Promise await。
- **理由**：Supabase 提醒匿名用户数据不应被 Next.js 静态页面跨用户缓存；服务端读取可避免客户端先渲染后鉴权闪烁。Server Actions 与表单、Cookie 写入和跳转天然集成。
- **替代方案**：为内部表单另建 REST API 增加不必要接口；全客户端读取会扩大数据与会话处理面。

## 文档与版本结论

- 本地 Next.js 版本为 16.3.1；根入口必须命名为 `proxy.ts`，导出 `proxy` 和 `config`。
- `cookies()`、动态路由 `params` 均为异步 API。
- Server Action 的 `redirect()` 必须放在 `try/catch` 之外。
- Supabase 项目当前为 PostgreSQL 17，`public` schema 尚无业务表和迁移。
- 当前相关 Supabase breaking changes 中，直接影响本阶段的是 Data API 不再默认暴露新表，因此迁移必须显式授权；自托管 Auth URL、Realtime schema 和 OpenAPI 读取变更与本阶段无关。
