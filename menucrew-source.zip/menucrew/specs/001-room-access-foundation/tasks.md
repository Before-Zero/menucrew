# 任务：房间与访问骨架

**输入**：`specs/001-room-access-foundation/` 下的规格与设计文档

**前置文档**：`plan.md`、`spec.md`、`research.md`、`data-model.md`、`contracts/room-access.md`、`quickstart.md`

**测试口径**：项目宪章不要求新增自动化测试；本阶段使用 `npm run verify`、数据库 Advisors、可重复测试脚本和隔离浏览器人工验收。

## 格式：`[ID] [P?] [Story] 描述`

- **[P]**：可与同阶段其他标记任务并行，文件不冲突且不依赖未完成任务
- **[Story]**：映射到 `spec.md` 的用户故事

## Phase 1：准备

**目标**：建立迁移与类型文件位置，确认目标云项目和本地环境可用。

- [x] T001 使用 Supabase CLI 创建 `supabase/migrations/*_room_access_foundation.sql`，不得手写迁移文件名
- [x] T002 [P] 确认 `.env.local` 的公开 Supabase 变量存在且 `.env.example`、`.gitignore` 不会提交真实值
- [x] T003 [P] 在 `package.json` 预留 `seed:room` 命令并建立 `scripts/create-test-room.mjs` 文件位置

---

## Phase 2：阻塞性基础

**目标**：完成所有用户故事共享的匿名会话、数据模型、RLS 和数据访问基础。

**关键检查点**：本阶段完成前不得实现用户故事页面。

- [x] T004 在 `supabase/migrations/*_room_access_foundation.sql` 定义 `rooms`、`room_members`、约束、索引、显式 GRANT、强制 RLS 与成员可读策略
- [x] T005 在同一迁移中定义收窄权限的 `create_room`、`join_room` 原子函数，撤销默认执行权限并只授权 `authenticated`
- [x] T006 将迁移应用到 Supabase 项目 `xxbuibqbcqfozifrwors`，运行安全/性能 Advisors，并在 `lib/supabase/database.types.ts` 保存生成类型
- [x] T007 [P] 在 `lib/supabase/proxy.ts` 与根 `proxy.ts` 实现请求级匿名会话刷新，不在 Proxy 查询业务数据
- [x] T008 [P] 在 `lib/validation.ts` 实现房间名、显示名、UUID 和邀请 token 的共享校验
- [x] T009 在 `lib/supabase/client.ts`、`lib/supabase/server.ts` 与 `lib/supabase/admin.ts` 接入 `Database` 类型且保持 secret client 仅服务端可引用
- [x] T010 在 `lib/rooms.ts` 实现按当前 `auth.uid()` 和 RLS 读取房间、本人关系及成员列表的数据访问函数

---

## Phase 3：用户故事 1 — 组织者创建并分享房间（P1）🎯 MVP

**目标**：匿名组织者从首页创建持久房间、进入工作区并复制邀请。

**独立验收**：全新浏览器从首页创建房间，进入工作区，复制分享链接并刷新后仍保持组织者身份。

- [x] T011 [P] [US1] 在 `components/room-form.tsx` 实现带 `useActionState`、字段错误和 pending 反馈的创建/加入复用表单
- [x] T012 [US1] 在 `app/actions.ts` 实现 `createRoomAction`：确保匿名身份、生成 32 字节 token、计算摘要、调用 `create_room`、写 HttpOnly Cookie并跳转
- [x] T013 [US1] 在 `app/page.tsx` 实现 MenuCrew 首页、产品说明、创建房间表单与 001 范围提示
- [x] T014 [P] [US1] 在 `components/copy-invite-button.tsx` 实现基于当前 origin 的分享链接复制与成功/失败反馈
- [x] T015 [US1] 在 `app/rooms/[roomId]/page.tsx` 实现组织者工作区、角色标识、邀请复制、成员列表和持久空状态

**检查点**：US1 可独立创建、分享和刷新恢复。

---

## Phase 4：用户故事 2 — 成员通过分享链接加入（P1）

**目标**：隔离浏览器使用邀请 token 加入同一房间，加入后地址移除 token 且角色保持为成员。

**独立验收**：无痕浏览器打开分享链接，提交显示名后进入稳定房间地址；重复加入不新增关系也不提升角色。

- [x] T016 [US2] 在 `app/actions.ts` 实现 `joinRoomAction`：校验 token、确保匿名身份、计算摘要、调用 `join_room`、统一无效邀请错误并跳转
- [x] T017 [US2] 在 `app/join/[token]/page.tsx` 实现不提前泄露房间信息的加入页、无效格式状态和成员显示名表单
- [x] T018 [US2] 扩展 `app/rooms/[roomId]/page.tsx`，为普通成员渲染成员房间页且隐藏邀请与组织者操作

**检查点**：US1 与 US2 可在两个隔离浏览器中形成同一真实房间。

---

## Phase 5：用户故事 3 — 刷新后恢复匿名访问（P2）

**目标**：Cookie 仍存在时恢复同一身份；身份丢失或非成员访问时使用不泄露数据的统一体验。

**独立验收**：组织者和成员各刷新三次均恢复；清除站点数据后直接访问稳定地址被拒绝。

- [x] T019 [US3] 在 `app/rooms/[roomId]/page.tsx` 与 `lib/rooms.ts` 完成未登录、非成员和不存在房间的统一无权访问分支
- [x] T020 [P] [US3] 在 `app/error.tsx` 建立可重试的页面级异常状态，避免向用户展示内部数据库或认证错误

**检查点**：身份恢复与身份丢失行为均符合规格。

---

## Phase 6：用户故事 4 — 角色权限始终隔离（P2）

**目标**：普通成员不能进入组织者汇总骨架或访问其他房间，角色只由成员关系决定。

**独立验收**：成员直接访问汇总地址和第二个房间均被拒绝；组织者可进入自己的汇总骨架。

- [x] T021 [US4] 在 `app/rooms/[roomId]/summary/page.tsx` 实现仅组织者可见的汇总空骨架和非组织者统一拒绝分支
- [x] T022 [US4] 审查 `app/actions.ts`、`lib/rooms.ts` 和迁移，确认所有写入口重新鉴权且不存在 metadata、显示名或仅 `authenticated` 的宽松授权

**检查点**：组织者/成员和跨房间边界均可人工验证。

---

## Phase 7：用户故事 5 — 常见屏幕上的清晰页面骨架（P3）

**目标**：所有 001 页面在手机与桌面清晰可用，未实现能力只显示真实空状态。

**独立验收**：360 和 1280 像素宽度走通创建、复制、加入和房间访问，无横向滚动或假业务数据。

- [x] T023 [P] [US5] 在 `components/room-shell.tsx` 建立首页、加入、组织者、成员和汇总页共用的响应式页面框架
- [x] T024 [US5] 在 `app/globals.css`、`app/layout.tsx` 和所有 001 页面完成 MenuCrew 视觉基线、中文 metadata、加载/空状态与移动端布局

**检查点**：全部用户故事在两种目标宽度下保持可用。

---

## Phase 8：测试数据、验证与收尾

**目标**：生成真实可重复测试数据，执行质量门槛并同步阶段台账。

- [x] T025 在 `scripts/create-test-room.mjs` 实现两个独立匿名 client 通过正式 RPC 创建组织者、房间和成员，并在 `package.json` 完成 `seed:room`
- [x] T026 运行 `npm run seed:room` 与只读 SQL 验证房间、唯一组织者、两名成员、邀请摘要和跨房间 RLS，记录测试房间 ID
- [x] T027 运行 `npm run verify` 并修复所有 Biome 与 TypeScript 问题
- [x] T028 按 `specs/001-room-access-foundation/quickstart.md` 执行普通/无痕浏览器、三次刷新、无效邀请、越权和 360/1280 宽度人工验收
- [x] T029 运行 Supabase Security/Performance Advisors，处理本迁移新增告警并确认 Anonymous Sign-Ins 已启用
- [x] T030 更新 `AGENTS.md` 的目录、命令、迁移与邀请安全约定，并在 `progress.md` 勾选实际完成项、填写证据、日期和交付 commit

---

## 依赖与执行顺序

### Phase 依赖

- Phase 1 无依赖。
- Phase 2 依赖 Phase 1，并阻塞所有用户故事。
- US1 依赖 Phase 2；US2 依赖 US1 提供的房间与页面；US3、US4 依赖 US1/US2 的访问链路。
- US5 可在 US1/US2 页面结构稳定后进行。
- 收尾依赖所有选定用户故事完成。

### 用户故事依赖图

```text
基础设施 → US1 创建分享 → US2 成员加入 → US3 会话恢复
                                ├──────→ US4 权限隔离
                                └──────→ US5 响应式骨架
全部故事 → 测试数据与验收收尾
```

### 并行机会

- T002 与 T003 可并行；T007 与 T008 可并行。
- US1 中 T011 与 T014 可并行，之后分别接入页面。
- US3 的异常页面可与 US4 的汇总骨架并行。
- US5 的共用框架可先于最终页面样式调整。

## 实现策略

1. 先完成真实数据和授权基础，立即用数据库只读查询验证。
2. 先使 US1 能独立创建和分享，再接入 US2 的第二浏览器加入。
3. 在真实双会话存在后验证恢复与越权，避免用静态假数据模拟。
4. 最后统一响应式表现、测试脚本、静态检查和阶段台账。

## 格式校验

- 共 30 个任务，编号 T001–T030 连续。
- 所有任务均包含 checkbox、任务 ID 和具体文件路径或明确的验收文档。
- 用户故事阶段任务全部包含 `[US1]`–`[US5]` 标签；仅真正无文件冲突的任务标记 `[P]`。
