# 实现计划：房间与访问骨架

**分支**：`codex/001-room-access-foundation` | **日期**：2026-08-20 | **规格**：[spec.md](spec.md)

**输入**：`specs/001-room-access-foundation/spec.md`

## 摘要

交付一个可跨浏览器使用的匿名房间访问闭环：组织者在首页创建房间并复制邀请链接，成员在隔离浏览器中通过链接加入，双方刷新后恢复同一身份和角色，普通成员无法执行组织者操作或读取其他房间。技术上使用请求级 Supabase SSR 会话、Next.js Proxy 刷新令牌、Server Actions 执行创建和加入、Server Components 按 RLS 读取房间，以及两个最小数据库函数原子建立房间成员关系。邀请原值只存在于分享地址和组织者的 HttpOnly Cookie，数据库只保存 SHA-256 摘要。

## 技术上下文

**语言/版本**：TypeScript 5、Next.js 16.3.1、React 19.2.8、Node.js 运行时

**主要依赖**：`@supabase/supabase-js` 2.112.3、`@supabase/ssr` 0.12.4、Tailwind CSS 4、shadcn/ui、lucide-react

**存储**：Supabase 托管 PostgreSQL 17；Supabase Auth Anonymous Sign-Ins；本阶段不使用 Storage

**测试**：`npm run verify`；两组隔离浏览器人工验收；数据库安全与性能 Advisors；可重复测试房间脚本

**目标平台**：现代手机和桌面浏览器中的响应式 Web 应用，服务端使用默认 Node.js runtime

**项目类型**：单体全栈 Web 应用（Next.js App Router）

**性能目标**：创建房间和成员加入各可在 60 秒内完成；普通网络下交互必须提供即时处理中反馈

**约束**：匿名身份丢失后不可恢复；菜单、选择、汇总计算和 AI 不得进入 001；不引入新运行时依赖；密钥不得进入浏览器或版本库

**规模/范围**：5 个用户可见页面状态、2 张业务表、2 个原子数据库函数、1 个首批迁移、1 个可重复测试数据脚本；面向小规模 Demo 房间

## 宪章检查

*门槛：Phase 0 研究前检查，并在 Phase 1 设计后复查。*

- **MVP 核心路径优先：通过。** 只建设后续所有阶段依赖的房间、匿名身份和角色边界，不实现菜单或视觉精修。
- **按需求直接实现：通过。** 复用现有 Next.js、Supabase 和 UI 依赖；不新增身份框架、ORM、仓储层或通用邀请系统。
- **最小可用的数据闭环：通过。** 房间和成员关系写入真实云数据库，并要求隔离浏览器验收，不使用组件静态假数据。
- **必要安全底线：通过。** 邀请只存摘要；所有表显式授权和 RLS；数据库函数自行验证 `auth.uid()`；客户端只使用 publishable key。
- **静态检查即质量门槛：通过。** 自动化测试不作为前置条件，执行 `npm run verify` 和核心路径人工验证。
- **中文文档：通过。** 规格、计划、设计和任务使用中文，代码标识符与 API 名保留英文。

Phase 1 复查结果：数据模型、接口契约和验收指南未引入宪章例外，全部门槛继续通过。

## 项目结构

### 本功能文档

```text
specs/001-room-access-foundation/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── room-access.md
├── checklists/
│   └── requirements.md
└── tasks.md
```

### 源码

```text
app/
├── actions.ts
├── page.tsx
├── error.tsx
├── join/[token]/page.tsx
└── rooms/[roomId]/
    ├── page.tsx
    └── summary/page.tsx
components/
├── copy-invite-button.tsx
├── room-form.tsx
└── room-shell.tsx
lib/
├── rooms.ts
├── validation.ts
└── supabase/
    ├── client.ts
    ├── server.ts
    ├── proxy.ts
    └── database.types.ts
scripts/
└── create-test-room.mjs
supabase/
└── migrations/
    └── <timestamp>_room_access_foundation.sql
proxy.ts
```

**结构决策**：保持现有单体 App Router 结构。读操作集中在服务端 `lib/rooms.ts`，写操作集中在 `app/actions.ts`，只有复制链接和表单待提交反馈需要 Client Component。数据库迁移保留在 `supabase/migrations/`，以便云端与仓库可追踪。

## 复杂度跟踪

无宪章例外，无需复杂度豁免。
