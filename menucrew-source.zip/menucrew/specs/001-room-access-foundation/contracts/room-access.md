# Phase 1 接口契约：房间与访问

## 页面契约

### `GET /`

- 显示产品说明、创建房间表单和 001 范围提示。
- 表单字段：`roomName`、`displayName`，均为 1–60 个去除首尾空白后的字符。
- 不读取或显示任何未授权房间数据。

### `GET /join/[token]`

- 在验证成功前仅显示邀请加入说明和显示名表单，不显示房间名称或成员。
- `token` 无法通过基本格式检查时显示统一“邀请不可用”状态。
- 提交成功后必须跳转，最终地址不得包含 token。

### `GET /rooms/[roomId]`

- 必须有有效匿名身份，且当前用户在 `room_members` 中属于该房间。
- 组织者看到组织者工作区、分享链接复制入口、成员列表和汇总骨架入口。
- 普通成员看到成员房间页、房间基本信息和真实空状态，不看到组织者操作。
- 不存在、未登录和不属于房间使用统一的无权访问体验，不泄露房间存在性。

### `GET /rooms/[roomId]/summary`

- 只有该房间 `organizer` 可访问。
- 001 只显示汇总尚未开放的骨架和返回房间入口，不计算或伪造数据。

## Server Action 契约

### `createRoomAction(previousState, formData)`

**输入**：`roomName`、`displayName`。

**成功**：确保匿名会话存在；原子创建房间与组织者关系；设置邀请 Cookie；跳转至 `/rooms/<roomId>`。

**失败**：返回可序列化状态 `{ status: "error", message, fields? }`；验证失败不写数据；基础设施失败不返回内部错误细节。

### `joinRoomAction(token, previousState, formData)`

**输入**：路由提供的 `token`、表单 `displayName`。

**成功**：确保匿名会话存在；验证摘要；原子复用或创建成员关系；跳转至 `/rooms/<roomId>`。

**失败**：无效 token 统一返回“邀请无效或已不可用”；不得返回 room ID、名称或成员；其他失败返回可重试提示。

## 数据库函数契约

### `public.create_room(room_name text, display_name text, invite_digest text) returns uuid`

- 只允许 `authenticated` 执行。
- 必须存在 `auth.uid()` 且 JWT 标记为匿名用户。
- 校验两个名称和 64 位摘要。
- 单事务插入房间与 `organizer` 关系。
- 只返回新房间 UUID。

### `public.join_room(display_name text, invite_digest text) returns uuid`

- 只允许 `authenticated` 执行。
- 必须存在 `auth.uid()` 且 JWT 标记为匿名用户。
- 只匹配有效摘要且 `invite_active = true` 的房间。
- 已存在关系时返回原房间且不更新 `role`；不存在时插入 `member`。
- 邀请不可用时抛出统一业务错误，不返回候选房间字段。

## 错误文案类别

| 类别 | 对用户展示 | 是否可重试 |
| --- | --- | --- |
| 字段验证 | 指明房间名称或显示名要求 | 修正后可重试 |
| 邀请不可用 | 邀请无效或已不可用，请联系组织者 | 需要新链接 |
| 无权访问 | 无法访问这个房间，请使用有效邀请 | 需要有效邀请 |
| 连接或服务失败 | 暂时无法完成，请稍后重试 | 是 |
