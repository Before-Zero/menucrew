# 实现计划：菜单草稿与发布

**分支**：`codex/002-menu-draft-publish` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

**输入**：`specs/002-menu-draft-publish/spec.md`

## 摘要

在 001 的真实房间与匿名角色基础上，交付一条不依赖 AI 的菜单准备闭环：组织者建立每房间唯一菜单，把 1–4 张菜单原图上传到私有文件桶并预览，人工维护可排序的菜单原文、简体中文名和解释，明确发布后由房间成员只读浏览。数据层新增菜单、原图元数据和菜品三类记录，对业务表与文件对象分别实施房间角色权限；二进制使用服务端签发 token 后的浏览器直传，普通字段和状态变化使用 Server Actions，所有入口均重新鉴权。

## 技术上下文

**语言/版本**：TypeScript 5、Next.js 16.3.1、React 19.2.8、Node.js 运行时

**主要依赖**：现有 `@supabase/supabase-js` 2.112.3、`@supabase/ssr` 0.12.4、Tailwind CSS 4、shadcn/ui、lucide-react；不新增运行时依赖

**存储**：Supabase 托管 PostgreSQL 17；一个私有 Supabase Storage 文件桶；本阶段不使用 AI、对象公开 URL 或高权限客户端

**测试**：`npm run verify`；数据库与 Storage RLS 只读/越权验证；Security/Performance Advisors；普通与隔离浏览器人工验收；自制菜单图片和至少 8 道固定菜品

**目标平台**：现代手机和桌面浏览器中的响应式 Web 应用，服务端使用默认 Node.js runtime

**项目类型**：单体全栈 Web 应用（Next.js App Router）

**性能目标**：6 MB 以内图片在普通网络下 60 秒内得到成功或失败反馈；保存菜品和发布均提供即时 pending 状态；小型 Demo 菜单一次读取完成

**约束**：1–4 张 JPEG/PNG/WebP、单张不超过 6 MB；原图仅组织者可见；菜单固定翻译为简体中文；发布必须人工触发；不新增 AI、价格、分类、版本历史或图片处理能力

**规模/范围**：1 个私有文件桶、3 张新业务表、1 个新页面、2 个上传 Route Handler、6 个菜单 Server Actions、最多 4 张图和几十道菜的小规模 Demo 房间

## 宪章检查

*门槛：Phase 0 研究前检查，并在 Phase 1 设计后复查。*

- **MVP 核心路径优先：通过。** 菜单原图、人工双语草稿和发布是 003 成员选择的直接前置条件，不增加 AI 或非核心管理能力。
- **按需求直接实现：通过。** 复用现有 App Router、Supabase client、房间角色和 UI 组件；不新增 ORM、上传库、菜单版本系统或后台任务。
- **最小可用的数据闭环：通过。** 图片、菜品和发布状态写入真实云服务，并由另一隔离浏览器读取，不使用组件静态假数据。
- **必要安全底线：通过。** 文件桶保持私有；业务表和文件对象均以房间组织者关系授权；浏览器与普通服务端请求只使用 publishable key。
- **静态检查即质量门槛：通过。** 不新增自动化测试前置条件，使用 `npm run verify`、数据库 Advisors 和核心路径人工验收。
- **中文文档：通过。** 规格、设计、任务和协作说明使用中文，代码标识符与 API 名保留英文。

Phase 1 复查结果：数据模型、接口契约和验收指南保持单体结构与直接数据流，未引入宪章例外，全部门槛继续通过。

## 项目结构

### 本功能文档

```text
specs/002-menu-draft-publish/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── menu-draft-publish.md
├── checklists/
│   └── requirements.md
└── tasks.md
```

### 源码

```text
app/
├── actions.ts
├── api/rooms/[roomId]/menu-images/
│   ├── route.ts
│   └── [imageId]/route.ts
└── rooms/[roomId]/
    ├── page.tsx
    └── menu/
        ├── actions.ts
        └── page.tsx
components/
├── menu-image-uploader.tsx
├── menu-item-form.tsx
├── menu-item-list.tsx
└── menu-status-actions.tsx
lib/
├── menus.ts
├── menu-action-state.ts
├── validation.ts
└── supabase/database.types.ts
scripts/
└── create-test-menu.mjs
supabase/migrations/
└── <timestamp>_menu_draft_publish.sql
```

**结构决策**：保持现有单体 App Router。房间页只展示菜单状态和入口，组织者管理与成员浏览统一位于 `/rooms/[roomId]/menu`，由服务端按当前角色渲染。文本和状态写入使用同目录 Server Actions；Route Handler 以当前会话签发随机私有路径的上传 token，浏览器直接上传，随后由 Handler 验证对象并登记元数据，全程不使用 secret key。菜单读取集中在 `lib/menus.ts`，数据库和文件桶权限由迁移追踪。

## 复杂度跟踪

无宪章例外，无需复杂度豁免。
