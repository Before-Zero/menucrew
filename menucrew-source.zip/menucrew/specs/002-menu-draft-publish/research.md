# Phase 0 研究：菜单草稿与发布

## 决策 1：使用私有文件桶与标准上传，单张限制为 6 MB

- **决定**：建立专用私有文件桶，只接受 JPEG、PNG 和 WebP，单张上限 6 MB。对象路径使用 `<roomId>/<menuId>/<randomId>.<ext>`，不覆盖旧路径。Route Handler 使用当前会话校验组织者与草稿后签发两小时上传 token，浏览器直接把二进制发送至私有 Storage，再由同一 Handler 验证对象并登记元数据。
- **理由**：Supabase 当前文档说明私有桶的下载也受 RLS 控制，标准上传最适合不超过 6 MB 的小文件；新路径可避免覆盖后的 CDN 陈旧内容。通过当前会话上传能继续依赖 Storage RLS，无需 service role 或额外上传库。
- **替代方案**：10 MB 以上图片更适合 TUS，会引入本阶段不需要的协议和依赖；公开桶会让任何持有 URL 的人绕过读取控制；把文件转交高权限 client 会扩大 secret 使用范围。

## 决策 2：图片上传使用 Route Handler，普通写入使用 Server Actions

- **决定**：图片签发、登记和删除使用 `/api/rooms/[roomId]/menu-images` 下的 Route Handler；菜品和菜单状态使用 Server Actions。上传完成后客户端调用 `router.refresh()`，服务端写入后使用 `revalidatePath()` 更新房间和菜单页。
- **理由**：Supabase 当前文档确认 `createSignedUploadUrl` 生成的 token 两小时有效，`uploadToSignedUrl` 无需再次认证；二进制不穿过 Next.js Function，因而 6 MB 产品上限不会受部署平台函数请求体限制。登记前服务端按精确路径确认对象存在，登记失败则尝试移除该对象。Server Actions 继续负责小型表单、pending 状态和服务端重鉴权。所有入口都视为可直接调用的不可信入口。
- **替代方案**：提高 Server Action body 限制会让所有 action 共享更大的请求上限；让 Route Handler 接收 multipart 会在后续 Vercel 部署受函数请求体限制；浏览器自行决定 Storage 路径会扩大可写范围；建立独立上传服务超出 MVP。

## 决策 3：每房间唯一菜单，菜品与图片元数据规范化存储

- **决定**：使用 `menus`、`menu_images`、`menu_items` 三张表。`menus.room_id` 唯一；图片和菜品按 `menu_id` 关联并记录非负展示位置；菜品名称不设唯一约束。
- **理由**：三类数据生命周期和可见性不同：菜单承担状态，图片只对组织者可见，菜品发布后对成员可见。规范化关系能由 RLS 独立保护，也便于后续 003 选择引用稳定菜品 ID。
- **替代方案**：把菜品放 JSON 会让后续选择无法稳定引用单菜；把图片只存在 Storage 而不记录元数据会难以限制数量和稳定排序；版本表和历史快照不属于 002。

## 决策 4：数据库强制草稿写入与发布前置条件

- **决定**：组织者可创建菜单并在草稿期写图片元数据和菜品。发布状态变化由数据库触发器校验：至少一张图片和一道完整菜品才能从 `draft` 进入 `published`；退回草稿后才允许继续修改。状态变化自动维护 `published_at` 与 `updated_at`。
- **理由**：页面按钮隐藏不能保护直接请求；将草稿条件放入写策略、将发布条件放入数据库，可让 Server Actions、Route Handler 和直接 Data API 请求遵守同一规则，又无需增加高权限 RPC。
- **替代方案**：仅在页面或 Server Action 校验可被直接调用绕过；`SECURITY DEFINER` 发布函数会新增高权限外部入口和 Advisor 告警；保存即发布违反人工确认边界。

## 决策 5：成员只读已发布菜品，原图始终只对组织者开放

- **决定**：组织者可读取自己的任何菜单状态、图片元数据和菜品；普通房间成员只在菜单为 `published` 时读取 `menus` 与 `menu_items`，从不读取 `menu_images` 或 Storage 原图。访问条件使用私有安全辅助函数检查当前 `auth.uid()` 的房间关系。
- **理由**：成员只需要双语菜单，不需要原始准备材料。私有辅助函数避免 RLS 递归，并沿用 001 的固定空 `search_path`、显式身份检查和收窄执行权限模式。
- **替代方案**：给成员签名原图 URL扩大数据面且没有当前用户价值；只按 `authenticated` 授权会形成跨房间越权；显示名和 metadata 都不是可信角色来源。

## 决策 6：短时签名链接只用于组织者预览

- **决定**：服务端读取组织者可见的图片元数据后，为每张私有对象生成短时预览链接，不持久化签名链接；成员页面不生成链接。
- **理由**：Supabase 私有桶文档将带 JWT 下载和短时签名链接列为受控读取方式。签名链接短时有效，页面刷新可重新生成，数据库不保存可复用访问凭证。
- **替代方案**：公开 URL绕过私密要求；把对象下载代理到应用增加不必要带宽和代码；长期签名链接接近公开凭证。

## 决策 7：纯人工链路，不预留虚假 AI 接口

- **决定**：002 仅实现图片、人工双语字段、排序和发布。页面不显示禁用的 AI 按钮，不创建 AI 表、占位接口或供应商抽象。
- **理由**：006 会在人工草稿之上新增菜单理解；当前直接人工链路必须在没有任何 AI 配置时完整可用。
- **替代方案**：灰色 AI 按钮会暗示不可用能力；提前创建通用生成层违反宪章的按需求直接实现原则。

## 文档与版本结论

- Supabase 当前相关 breaking change 仍要求新 `public` 表显式 GRANT；迁移必须同时启用 RLS，不能把 Data API 暴露与行权限混为一谈。
- 私有 Storage 桶的上传、读取和删除均受 `storage.objects` RLS 约束；`storage.foldername(name)` 可在策略中读取对象路径目录。
- 标准 Storage 上传建议用于不超过 6 MB 的文件，本阶段据此将规格上限固定为 6 MB。
- Next.js 16.3.1 的 Route Handler 非 GET 请求默认不缓存；动态 `params` 仍为 Promise；`revalidatePath` 可在 Route Handler 与 Server Action 中调用。
- Server Actions 和 Route Handlers都可能被直接请求，必须在每个入口重新检查当前用户和房间角色。
