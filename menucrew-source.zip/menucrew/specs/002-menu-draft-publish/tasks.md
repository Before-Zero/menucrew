# 任务：菜单草稿与发布

**输入**：`specs/002-menu-draft-publish/` 下的规格与设计文档

**前置文档**：`plan.md`、`spec.md`、`research.md`、`data-model.md`、`contracts/menu-draft-publish.md`、`quickstart.md`

**测试口径**：项目宪章不要求新增自动化测试；本阶段使用 `npm run verify`、数据库与 Storage Advisors、可重复测试数据和隔离浏览器人工验收。

## 格式：`[ID] [P?] [Story] 描述`

- **[P]**：可与同阶段其他标记任务并行，文件不冲突且不依赖未完成任务
- **[Story]**：映射到 `spec.md` 的用户故事

## Phase 1：准备

**目标**：建立 002 迁移与测试脚本位置，确认不新增依赖和 secret 配置。

- [x] T001 使用 Supabase CLI `migration new` 创建 `supabase/migrations/*_menu_draft_publish.sql`，不得手写迁移文件名
- [x] T002 [P] 审查 `.env.example`、`.gitignore` 与 `package.json`，确认 002 仅复用公开 Supabase 变量且不新增 AI 或 secret 依赖
- [x] T003 [P] 在 `package.json` 预留 `seed:menu` 命令并建立 `scripts/create-test-menu.mjs` 文件位置

---

## Phase 2：阻塞性基础

**目标**：完成所有菜单故事共享的数据模型、私有文件桶、状态约束、RLS、显式授权和读取基础。

**关键检查点**：本阶段完成前不得实现菜单页面写入。

- [x] T004 在 `supabase/migrations/*_menu_draft_publish.sql` 创建私有 `menu-images` 桶及 `menus`、`menu_images`、`menu_items` 表、约束和外键索引
- [x] T005 在 `supabase/migrations/*_menu_draft_publish.sql` 实现组织者与已发布成员读取辅助函数、草稿写策略、Storage 对象策略、图片数量与发布条件触发器及最小显式 GRANT
- [x] T006 将 002 迁移应用到 Supabase 项目 `xxbuibqbcqfozifrwors`，运行 Security/Performance Advisors，并更新 `lib/supabase/database.types.ts`
- [x] T007 [P] 在 `lib/menu-action-state.ts` 与 `lib/validation.ts` 定义菜单 action 状态、菜品字段、菜单 ID、图片类型、6 MB 和 4 张上限校验
- [x] T008 在 `lib/menus.ts` 实现按当前房间角色读取菜单、稳定排序菜品、组织者图片元数据和短时签名预览链接

---

## Phase 3：用户故事 1 — 组织者上传并预览菜单原图（P1）🎯 MVP

**目标**：组织者建立草稿，上传、刷新预览和精确删除 1–4 张私密菜单图片。

**独立验收**：组织者上传一张合规图片并刷新恢复预览；成员和非成员读取原图失败；无效、超大或第 5 张文件不破坏已有数据。

- [x] T009 [US1] 在 `app/rooms/[roomId]/menu/actions.ts` 实现幂等 `createMenuAction`，仅组织者可建立每房间唯一草稿
- [x] T010 [US1] 在 `app/api/rooms/[roomId]/menu-images/route.ts` 实现带当前会话的签名直传、整组校验、随机新路径、元数据写入和失败补偿
- [x] T011 [US1] 在 `app/api/rooms/[roomId]/menu-images/[imageId]/route.ts` 实现只按数据库精确路径删除草稿图片对象与元数据
- [x] T012 [P] [US1] 在 `components/menu-image-uploader.tsx` 实现本地选择预览、类型/大小/数量前置反馈、上传 pending、部分失败和刷新反馈
- [x] T013 [US1] 在 `app/rooms/[roomId]/menu/page.tsx` 实现组织者无菜单、草稿图片预览、私密说明、移除入口和真实空状态

**检查点**：US1 可在没有菜品和 AI 的情况下独立建立图片草稿，并由 Storage RLS 保护。

---

## Phase 4：用户故事 2 — 组织者人工维护双语菜单草稿（P1）

**目标**：组织者人工新增、编辑、删除并排序双语菜品，刷新后准确恢复。

**独立验收**：人工录入至少 8 道菜，修改、删除再补录、上移或下移，连续刷新三次后字段与顺序一致。

- [x] T014 [US2] 扩展 `app/rooms/[roomId]/menu/actions.ts`，实现草稿期 `saveMenuItemAction`、`deleteMenuItemAction` 与相邻项 `moveMenuItemAction`
- [x] T015 [P] [US2] 在 `components/menu-item-form.tsx` 实现新增与编辑复用表单、字段错误、pending 和保存反馈
- [x] T016 [P] [US2] 在 `components/menu-item-list.tsx` 实现稳定编号、编辑、删除、上移/下移边界和较长双语字段展示
- [x] T017 [US2] 扩展 `app/rooms/[roomId]/menu/page.tsx`，集成人工菜品表单、草稿列表、数量统计和刷新持久化状态

**检查点**：US1 与 US2 形成完全不依赖 AI 的私密菜单草稿。

---

## Phase 5：用户故事 3 — 组织者发布，成员查看同一份菜单（P1）

**目标**：组织者明确发布，成员只读看到同样的双语菜品和顺序，所有成员写入均被拒绝。

**独立验收**：草稿期成员看不到菜品；组织者发布后成员一次刷新看到至少 8 道完整菜品；成员直接写入和跨房间读取均失败。

- [x] T018 [US3] 扩展 `app/rooms/[roomId]/menu/actions.ts`，实现数据库最终校验图片和菜品数量的 `publishMenuAction`
- [x] T019 [P] [US3] 在 `components/menu-status-actions.tsx` 实现草稿发布确认、条件提示、pending、成功与失败反馈
- [x] T020 [US3] 扩展 `app/rooms/[roomId]/menu/page.tsx`，为普通成员渲染已发布双语菜单和草稿准备状态，且始终隐藏原图与管理入口
- [x] T021 [US3] 扩展 `app/rooms/[roomId]/page.tsx` 与 `lib/menus.ts`，显示菜单状态、已发布菜品数量及组织者管理/成员查看入口
- [x] T022 [US3] 审查 `app/rooms/[roomId]/menu/actions.ts`、两个图片 Route Handler 与迁移，确认成员写入、跨房间访问、发布绕过和 metadata 授权均被数据库拒绝

**检查点**：组织者与成员两个隔离浏览器可共享同一份真实已发布菜单。

---

## Phase 6：用户故事 4 — 组织者安全地重新编辑已发布菜单（P2）

**目标**：已发布菜单必须明确退回草稿才可修改，成员在草稿期不读取旧菜单，重新发布后看到完整修订结果。

**独立验收**：组织者退回草稿后成员立即回到准备状态；组织者修改一道菜并重新发布，成员看到完整新内容且无旧新混合。

- [x] T023 [US4] 扩展 `app/rooms/[roomId]/menu/actions.ts`，实现仅组织者可调用的 `reopenMenuDraftAction` 与状态错误反馈
- [x] T024 [US4] 扩展 `components/menu-status-actions.tsx` 和 `app/rooms/[roomId]/menu/page.tsx`，实现退回草稿确认、发布后只读组织者视图与重新编辑闭环

**检查点**：菜单发布边界明确，已发布状态无法直接写菜品或图片。

---

## Phase 7：用户故事 5 — 常见屏幕下清晰完成菜单准备（P3）

**目标**：组织者和成员在 360 与 1280 像素宽度清晰完成主要路径，无横向滚动或不可达操作。

**独立验收**：两种宽度下检查上传、图片预览、8 道菜维护、发布和成员浏览，长文本正常换行。

- [x] T025 [US5] 在 `app/globals.css`、`components/menu-image-uploader.tsx`、`components/menu-item-form.tsx`、`components/menu-item-list.tsx` 与 `app/rooms/[roomId]/menu/page.tsx` 完成 MenuCrew 响应式菜单布局、加载/空状态和移动端操作排列

**检查点**：所有 002 页面状态在目标宽度可见可用，且未出现 AI、价格或假菜单入口。

---

## Phase 8：测试数据、验证与收尾

**目标**：生成真实可重复测试数据，执行质量与权限门槛并同步阶段台账。

- [x] T026 在 `scripts/create-test-menu.mjs` 与 `package.json` 实现通过正式匿名身份、Storage 和 Data API 创建房间、成员、私密图片、8 道固定菜品并发布的 `npm run seed:menu`
- [x] T027 运行 `npm run seed:menu` 与只读 SQL 验证每房间唯一菜单、1–4 张图片、8 道菜、稳定顺序、状态时间和草稿/发布 RLS，记录测试房间与菜单 ID
- [x] T028 运行 `npm run verify` 并修复所有 Biome 与 TypeScript 问题
- [x] T029 按 `specs/002-menu-draft-publish/quickstart.md` 执行普通/隔离浏览器、失败保留、成员越权、跨房间、退回重发、无 AI 和 360/1280 宽度人工验收
- [x] T030 运行 Supabase Security/Performance Advisors，处理本迁移新增告警并确认私有 `menu-images` 桶限制与 Storage RLS 生效
- [x] T031 更新 `AGENTS.md` 的页面、表、Storage、命令和菜单发布约定，并在 `progress.md` 勾选实际完成项、填写证据、日期和交付 commit

---

## 依赖与执行顺序

### Phase 依赖

- Phase 1 无依赖。
- Phase 2 依赖 Phase 1，并阻塞所有用户故事。
- US1 依赖 Phase 2；US2 依赖已存在菜单草稿；US3 依赖 US1 图片与 US2 菜品。
- US4 依赖 US3 已发布状态；US5 在菜单页面结构稳定后进行。
- 收尾依赖所有选定用户故事完成。

### 用户故事依赖图

```text
基础设施 → US1 私密原图 → US2 人工草稿 → US3 发布与成员查看
                                              └──→ US4 退回草稿与重发
全部页面状态 ─────────────────────────────────────→ US5 响应式
全部故事 → 测试数据与验收收尾
```

### 并行机会

- T002 与 T003 可并行；T007 可在迁移云端应用前完成。
- US1 中上传 Route Handler 与客户端选择交互可在契约稳定后分文件推进。
- US2 的菜品表单与菜品列表组件可并行。
- US3 的状态操作组件可与成员只读页面分文件推进。

## 实现策略

1. 先完成私有文件桶、三表模型、数据库状态约束和 RLS，再开放任何页面写入。
2. 先使 US1 可独立上传与刷新预览，立即验证成员无法读取原图。
3. 再完成 US2 的纯人工 8 道菜草稿，确保 AI 完全缺席时仍可使用。
4. 在真实图片和菜品存在后开放发布，使用第二浏览器验证成员只读与越权边界。
5. 最后完成退回草稿、响应式、可重复测试数据、Advisors 和阶段台账。

## 格式校验

- 共 31 个任务，编号 T001–T031 连续。
- 所有任务均包含 checkbox、任务 ID 和具体文件路径或明确的验收文档。
- 用户故事阶段任务全部包含 `[US1]`–`[US5]` 标签；仅真正无文件冲突的任务标记 `[P]`。
