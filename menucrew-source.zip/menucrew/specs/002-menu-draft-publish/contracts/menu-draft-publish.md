# Phase 1 接口契约：菜单草稿与发布

## 页面契约

### `GET /rooms/[roomId]`

- 保留 001 的房间身份和成员列表。
- 组织者看到当前菜单状态，以及“开始准备菜单”或“管理菜单”入口。
- 普通成员在草稿或无菜单时看到准备状态；已发布时看到“查看菜单”入口和菜品数量。
- 不得为了显示状态而泄露其他房间或草稿菜品。

### `GET /rooms/[roomId]/menu`

- 必须有当前匿名身份和该房间成员关系。
- 组织者无菜单时看到建立草稿入口；草稿期看到私密图片预览、上传、菜品维护、排序与发布；发布后看到只读菜单和“继续编辑”入口。
- 普通成员只在菜单已发布时看到按顺序排列的原文、简体中文名和解释；其他状态统一显示菜单正在准备。
- 房间外访问、不存在房间和无身份使用不泄露数据的统一拒绝状态。

## 图片 Route Handler 契约

### `POST /api/rooms/[roomId]/menu-images`

**输入**：JSON `{ originalName, mimeType, byteSize }`。

**前置条件**：当前用户是该房间组织者；房间已有 `draft` 菜单；现有数量未达到 4。

**校验**：文件信息非空；类型为 JPEG、PNG 或 WebP；单张不超过 6 MB。

**成功**：返回由服务端生成的全新私有对象 `path` 与两小时有效的 `token`；浏览器仅可用它调用 Supabase `uploadToSignedUrl`。

### `PUT /api/rooms/[roomId]/menu-images`

**输入**：上传完成后的 JSON `{ originalName, mimeType, byteSize, storagePath }`。

**成功**：重新验证组织者、草稿、路径前缀、数量及精确对象存在性后登记元数据；单文件失败不影响请求前图片，登记失败尝试清理刚上传对象。

**拒绝**：非组织者、非草稿、超数量、不合规文件或非本菜单路径返回 400/403/409；成员与非成员的响应不得包含菜单原图信息。

### `DELETE /api/rooms/[roomId]/menu-images/[imageId]`

**前置条件**：当前用户是该房间组织者；图片属于该房间当前菜单；菜单为 `draft`。

**成功**：按元数据中的精确路径删除私有对象，再删除元数据；返回 `{ status: "success", message }` 并重新验证页面。

**失败**：不接受请求提供任意 Storage 路径；显示可重试错误，不影响其他图片和菜品。

## Server Action 契约

### `createMenuAction(roomId, previousState, formData)`

- 校验房间 ID和当前组织者角色。
- 房间无菜单时建立 `draft` 菜单；已有菜单时安全复用。
- 成功后刷新房间和菜单页；失败返回可序列化状态。

### `saveMenuItemAction(roomId, itemId, previousState, formData)`

**输入**：`originalName`、`zhName`、`description`。

- 三个字段去除首尾空白并按 120/120/240 字符限制验证。
- `itemId` 为空时追加到草稿末尾；存在时只能修改同一房间当前菜单内的目标菜品。
- 已发布、成员、跨房间或无效 ID 请求不得写入。
- 成功返回明确反馈并刷新当前菜单页。

### `deleteMenuItemAction(roomId, itemId)`

- 只删除当前房间草稿中的目标菜品。
- 成功后允许位置出现间隙；不影响其他菜品。

### `moveMenuItemAction(roomId, itemId, direction)`

- `direction` 仅为 `up` 或 `down`。
- 与当前稳定顺序中的相邻菜品交换位置；第一项上移和最后一项下移安全无变化。
- 只允许组织者在草稿期执行。

### `publishMenuAction(roomId, previousState, formData)`

- 当前用户必须是组织者，菜单必须为草稿。
- 数据库最终确认至少一张图片和一道完整菜品，再切换为已发布。
- 成功后组织者和成员下一次页面读取都得到已发布菜单；任何保存动作都不得隐式调用发布。

### `reopenMenuDraftAction(roomId, previousState, formData)`

- 当前用户必须是组织者，菜单必须已发布。
- 明确确认后退回草稿；成员随即不再读取菜品。

## 数据读取契约

### `getRoomMenu(roomId)`

- 先复用当前房间访问读取，无法访问时返回统一空结果。
- 组织者获得菜单、私密图片元数据与短时预览链接、全部菜品。
- 普通成员仅在已发布时获得菜单与菜品，图片数组始终为空。
- 菜品按 `position`、`id` 稳定排序；图片按 `position`、`id` 稳定排序。

## 错误文案类别

| 类别 | 对用户展示 | 是否可重试 |
| --- | --- | --- |
| 字段验证 | 指明原文、中文名或解释的要求 | 修正后可重试 |
| 文件限制 | 仅支持 JPEG/PNG/WebP，单张不超过 6 MB，总数不超过 4 张 | 更换文件后可重试 |
| 非草稿 | 请先将菜单退回草稿再修改 | 组织者变更状态后可重试 |
| 无权访问 | 无法访问或修改这个菜单 | 需要正确房间身份 |
| 发布条件 | 至少上传一张图片并录入一道完整菜品 | 补齐后可重试 |
| 连接或服务失败 | 暂时无法完成，请稍后重试 | 是 |
