# 研究：AI 整桌建议

## 决策 1：复用确定性汇总，不让 AI 重新计算

- **选择**：服务端调用现有 `getRoomAggregation`，把已经算好的总数、成员贡献、单菜备注和整体饮食信息转换为建议输入。
- **理由**：004 已通过固定数据验证精确求和；007 的职责是解释风险，不得出现第二套汇总算法。
- **替代方案**：把原始选择交给模型求和会产生不可复现误差，违反确定性边界。

## 决策 2：Gemini 结构化输出

- **选择**：调用 `models/{model}:generateContent`，设置 `responseMimeType: application/json` 和 `responseSchema`，要求返回 1–12 条具有 `type`、`risk`、`title`、`detail`、`evidence` 的提示。
- **理由**：Google 当前官方文档支持用响应 Schema 约束 JSON；应用仍执行枚举、数量和长度二次校验。
- **模型**：默认复用已完成真实验收的 `gemini-3.6-flash`，允许 `GEMINI_ADVICE_MODEL` 仅在服务端覆盖。

## 决策 3：稳定临时编号匿名化

- **选择**：按聚合成员的稳定顺序映射为 `M1`、`M2`；发送菜品总数、临时编号贡献、备注与饮食信息，不发送显示名、用户 ID、房间名或邀请信息。
- **理由**：模型判断成员自己的过敏信息与所选菜品之间的冲突需要关联键，但不需要真实身份。
- **生命周期**：映射只在单次可信服务端请求内存中存在，不写入数据库。

## 决策 4：来源修订与过期展示

- **选择**：每条记录保存生成时的 `rooms.selection_revision`；页面以其是否等于当前修订号计算“当前/已过期”。
- **理由**：成员保存选择以及组织者关闭或重开收集都已原子递增该修订号，足以覆盖建议输入变化。
- **替代方案**：时间戳比较可能碰撞且不能表达业务版本；新增第二套修订号会增加同步风险。

## 决策 5：数据库去重与频率限制

- **选择**：匿名快照的规范 JSON 计算 SHA-256。`start_room_advice` 锁房间并重新鉴权，优先复用同摘要的成功结果，否则检查每房间滚动 24 小时最多 5 条新记录。
- **理由**：在数据库边界执行可避免多实例并发绕过，同时相同输入不会浪费免费额度。
- **状态**：`processing` 只能由请求者通过收窄 RPC 完成到 `succeeded` 或 `failed`。

## 决策 6：独立持久化与最小错误信息

- **选择**：建议写入独立 `room_advice` 表；只保存严格结构化结果、稳定错误码、安全错误摘要和可选供应商响应标识。
- **理由**：生成成功或失败都不触碰选择、汇总、收集状态、菜单或订单；完整供应商响应和提示词无需持久化。

## 决策 7：显式 Data API 权限

- **选择**：新表显式授权 `authenticated` 读取，启用 RLS 且只允许组织者；撤销匿名与浏览器直接写权限。RPC 从 `PUBLIC`、`anon` 撤销执行，仅授予 `authenticated`，`security definer` 函数使用空 `search_path`。
- **理由**：Supabase 当前的新项目不再自动把新表暴露给 Data API；授权与 RLS 是两层独立控制，必须同时配置。

## 官方依据

- `https://ai.google.dev/gemini-api/docs/structured-output`
- `https://ai.google.dev/gemini-api/docs/models`
- `https://supabase.com/docs/guides/database/postgres/row-level-security`
- `https://supabase.com/docs/guides/database/functions`
- `https://supabase.com/changelog/45329-breaking-change-tables-not-exposed-to-data-and-graphql-api-automatically`
