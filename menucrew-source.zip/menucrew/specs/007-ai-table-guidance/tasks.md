# 任务：AI 整桌建议

**输入**：`spec.md`、`plan.md`、`research.md`、`data-model.md`、`contracts/`、`quickstart.md`

## 阶段 1：准备

- [x] T001 确认 006 完成状态、007 分支和 `.specify/feature.json`
- [x] T002 完成 `specs/007-ai-table-guidance/` 的规格、研究、计划、模型、契约和验收材料
- [x] T003 运行 Spec Kit 前置条件与规格检查清单

## 阶段 2：基础设施

- [x] T004 创建 `supabase/migrations/*_ai_table_guidance.sql`，包含 `room_advice`、RLS、显式授权和收窄 RPC
- [x] T005 应用云端迁移并更新 `lib/supabase/database.types.ts`
- [x] T006 [P] 在 `.env.example` 和服务端配置中增加可选 `GEMINI_ADVICE_MODEL`

## 阶段 3：用户故事 1——从当前汇总获得建议（P1）

**独立验收**：固定冲突数据可生成包含临时成员编号、菜品、依据和风险级别的结构化提示。

- [x] T007 [US1] 在 `lib/table-advice.ts` 实现匿名快照、稳定摘要、Gemini 结构化调用和严格结果校验
- [x] T008 [P] [US1] 在 `lib/table-advice-action-state.ts` 定义可序列化动作状态
- [x] T009 [US1] 在 `app/rooms/[roomId]/summary/advice-actions.ts` 实现组织者专用生成编排、复用和安全失败完成
- [x] T010 [US1] 在 `components/table-advice-panel.tsx` 实现生成、结果、风险级别、失败与免责声明界面
- [x] T011 [US1] 在 `app/rooms/[roomId]/summary/page.tsx` 读取组织者历史建议并接入面板

## 阶段 4：用户故事 2——建议不修改业务数据（P1）

**独立验收**：生成前后所有成员提交、逐菜总数、房间状态和订单数据完全一致，失败时仍可人工确认。

- [x] T012 [US2] 在数据库权限和 Server Action 中确认所有建议路径只写 `room_advice`
- [x] T013 [US2] 在 `components/table-advice-panel.tsx` 保持纯提示交互，不提供自动应用能力
- [x] T014 [US2] 在 `scripts/create-test-table-advice.mjs` 加入生成前后业务快照逐项不变和成员权限断言

## 阶段 5：用户故事 3——版本变化后显示过期（P2）

**独立验收**：成员修改后旧建议显示已过期，相同输入复用，最新建议对应当前修订号。

- [x] T015 [US3] 在 `lib/table-advice.ts` 和汇总读取中以 `source_revision` 对比当前修订号
- [x] T016 [US3] 在 `components/table-advice-panel.tsx` 展示“基于当前汇总”或“已过期”状态
- [x] T017 [US3] 扩展 `scripts/create-test-table-advice.mjs` 验证相同输入复用、成员修改后过期和 24 小时频控

## 阶段 6：收口

- [x] T018 更新 `package.json`、`AGENTS.md` 和 `progress.md` 的脚本、结构、限制与完成证据
- [x] T019 运行固定数据验收、Supabase 安全顾问、`npm run verify` 和 `npm run build`
- [x] T020 按 `quickstart.md` 使用组织者与隔离成员完成真实 Gemini 浏览器验收
- [x] T021 提交 007 实现并补记提交号，确认工作树仅剩下一阶段预期变更

## 依赖顺序

1. T001–T003 完成后进入数据库实现。
2. T004–T006 阻塞全部用户故事。
3. T007–T011 提供可用建议；T012–T014 证明非执行性；T015–T017 完成过期与复用。
4. T018–T021 依赖全部用户故事完成。
