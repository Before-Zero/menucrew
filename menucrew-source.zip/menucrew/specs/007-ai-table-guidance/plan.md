# 实施计划：AI 整桌建议

**分支**：`codex/007-ai-table-guidance` | **日期**：2026-08-21 | **规格**：[spec.md](spec.md)

## 摘要

在组织者确定性汇总页增加只读的 AI 整桌建议。可信服务端从现有汇总结果构建匿名快照，用稳定摘要和房间 `selection_revision` 标识输入；数据库完成组织者鉴权、复用、频率限制与结果持久化；Google Gemini 仅返回结构化提示，不参与计数，也不能修改成员选择、汇总、收集状态或最终订单。

## 技术上下文

**语言/版本**：TypeScript 5、SQL/PLpgSQL、Node.js 运行时  
**主要依赖**：Next.js 16.3.1、React 19.2.8、Supabase JS 2.112.3；Gemini Developer API 使用服务端原生 `fetch`  
**存储**：Supabase Postgres `room_advice`，复用 `rooms.selection_revision`  
**测试**：固定数据验收脚本、隔离浏览器会话、Biome、TypeScript、生产构建  
**目标平台**：Vercel Node.js Server Actions 与响应式浏览器  
**项目类型**：Next.js 全栈 Web 应用  
**性能目标**：相同输入立即复用；外部建议在单次请求期限内完成；数据变化后刷新即可显示过期  
**约束**：组织者专用、1–12 条建议、24 小时最多 5 次新调用、成员匿名化、最终订单确认后禁止新生成、不得写回业务数据  
**规模/范围**：每房间少量建议记录；Demo 级并发

## 宪章检查

- **核心路径优先**：直接服务汇总到人工确认的核心链路，不扩展聊天、自动下单或通用智能体，符合。
- **直接实现**：复用现有汇总、修订号、Server Action 与 RPC；不增加队列、SDK 或供应商抽象，符合。
- **真实数据闭环**：建议来自真实云端汇总并独立持久化，组织者仍通过现有人工确认产生订单，符合。
- **安全底线**：密钥仅服务端；外部输入去除姓名、用户 ID、房间名与邀请信息；数据库重新鉴权，符合。
- **质量门槛**：执行静态检查、构建、固定数据和真实隔离浏览器验收，符合。

研究与设计后复查：无宪章冲突，无需复杂度豁免。

## 项目结构

```text
app/rooms/[roomId]/summary/
├── advice-actions.ts
└── page.tsx
components/table-advice-panel.tsx
lib/table-advice.ts
lib/table-advice-action-state.ts
scripts/create-test-table-advice.mjs
supabase/migrations/*_ai_table_guidance.sql
```

**结构决策**：保持单一 Next.js 应用。`lib/table-advice.ts` 只负责匿名输入和 Gemini 结构校验；数据库 RPC 承担可信权限、去重、频控和状态转换；UI 只触发并展示建议。

## 复杂度跟踪

无宪章违规。
