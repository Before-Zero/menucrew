# 契约：整桌建议

## 服务端动作 `generateTableAdvice`

### 输入

- `roomId`：当前房间 UUID。

### 前置条件

- 当前匿名用户是该房间组织者。
- 房间存在已发布菜单、至少一份已提交选择，且聚合不为空。
- 最终订单尚未确认。

### 行为

1. 从现有确定性汇总构建匿名快照并计算稳定摘要。
2. 调用 `start_room_advice(roomId, sourceRevision, digest, model)`。
3. 若数据库返回既有成功记录，直接复用；否则调用 Gemini。
4. 严格校验结构化输出，并通过完成 RPC 保存成功或安全失败结果。
5. 刷新汇总页；不返回或修改任何业务数量。

### 用户可见结果

- 成功：展示类型、风险、标题、说明和依据。
- 复用：展示已有成功结果，不增加额度计数。
- 失败：展示可继续人工操作的安全提示。
- 频控：提示 24 小时新建议次数已用完。
- 无数据：提示先发布菜单并收集至少一份选择。
- 已确认订单：只展示历史建议，不显示生成入口。

## 数据库 RPC

### `start_room_advice`

返回：`advice_id`、`disposition`（`created` 或 `reused`）、`status`、`result`。

数据库必须重新验证组织者、当前修订号、最终订单状态、摘要格式、相同输入复用和滚动 24 小时上限。

### `finish_room_advice`

输入：记录 ID、状态、结果或安全错误、供应商响应标识。只有创建该记录的当前组织者可完成 `processing` 记录。

## Gemini 输出 Schema

顶层对象仅包含 `items`。数组 1–12 项，每项字段为：

- `type`：`balance`、`duplicate`、`quantity`、`allergy`
- `risk`：`info`、`warning`、`critical`
- `title`：最多 80 字符
- `detail`：最多 300 字符
- `evidence`：最多 240 字符

服务端拒绝未知枚举、空字段、超长文本、空数组或超过 12 项的结果。

## 不变量

- 动作前后 `member_selections`、菜品、房间状态和 `final_orders` 完全不变。
- 普通成员、非成员和匿名 Data API 无法读取建议或执行 RPC。
- 页面始终显示“AI 可能出错，食材与过敏原须向餐厅确认”。
