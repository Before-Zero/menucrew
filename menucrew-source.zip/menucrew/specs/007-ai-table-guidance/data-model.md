# 数据模型：AI 整桌建议

## `room_advice`

| 字段 | 类型 | 规则 |
| --- | --- | --- |
| `id` | uuid | 主键 |
| `room_id` | uuid | 关联房间，删除房间时级联删除 |
| `requested_by` | uuid | 发起请求的组织者 |
| `source_revision` | bigint | 生成时的 `rooms.selection_revision` |
| `input_digest` | text | 64 位 SHA-256 |
| `status` | text | `processing`、`succeeded`、`failed` |
| `model` | text | 实际模型 |
| `result` | jsonb/null | 严格建议对象 |
| `error_code` | text/null | 稳定错误码 |
| `error_message` | text/null | 安全摘要 |
| `provider_response_id` | text/null | 可选外部响应标识 |
| `created_at` | timestamptz | 创建时间 |
| `completed_at` | timestamptz/null | 完成时间 |

同一房间与输入摘要最多一个成功结果；只有组织者可读，浏览器没有直接写权限。

## 结构化结果

```text
result.items[1..12]
├── type: balance | duplicate | quantity | allergy
├── risk: info | warning | critical
├── title: 1..80
├── detail: 1..300
└── evidence: 1..240
```

`allergy` 项目只能引用 `M1`、`M2` 等临时编号。结果是非执行性提示，不含可被 UI 自动应用的修改指令。

## 状态转换

```text
processing -> succeeded
          \-> failed
```

开始与完成都由 RPC 锁定并重新验证请求者身份。成功或失败不修改任何业务表。

## 过期规则

```text
source_revision = rooms.selection_revision  -> 基于当前汇总
source_revision != rooms.selection_revision -> 已过期
```

历史记录不因过期删除。最终订单确认后可读历史，但 `start_room_advice` 拒绝创建新记录。
