# Implementation Plan: 面向普通用户的自动化点餐链路

**Branch**: `011-consumer-flow-polish` | **Date**: 2026-08-23 | **Spec**: [spec.md](spec.md)

**Input**: `specs/011-consumer-flow-polish/spec.md`

## Summary

在不增加数据库迁移和新基础设施的前提下，将 010 已有菜单识别、菜单助手、整桌建议和最终订单能力组合为更自动的消费者链路。图片整批上传成功后自动调用现有识别 Action；确认并发布后直接进入组织者点餐页。汇总页只在当前修订无记录时自动触发建议，依靠现有摘要复用防止重复消耗。菜单助手针对正式日志已确认的 `invalid_output` 修复结构化输出解析和安全降级。

## Technical Context

**Language/Version**: TypeScript 5，Next.js 16.3.1，React 19

**Primary Dependencies**: Next.js App Router/Server Actions，Supabase SSR，Google Gemini Developer API，shadcn/ui，lucide-react

**Storage**: 复用 `menu_ai_runs`、`menu_assistant_runs`、`room_advice` 与现有订单快照；无新表或迁移

**Testing**: Biome，TypeScript，生产构建，双隔离浏览器主链路，一次真实 Gemini 助手调用

**Target Platform**: 移动端优先的响应式 Web，Vercel Node.js Functions

**Project Type**: Next.js 单体 Web 应用

**Performance Goals**: 上传结束后立即显示识别状态；汇总首屏立即显示建议生成或复用状态；自动 AI 不阻塞确定性操作

**Constraints**: 菜单与最终订单仍需人工确认；自动触发复用摘要和限额；日志不记录 AI 问题、饮食信息或模型原文

**Scale/Scope**: 只修改菜单上传/识别、发布跳转、点餐 AI 助手、汇总建议/决策和主流程文案

## Constitution Check

- **MVP 核心路径优先**: 减少已上线主链路点击并修复已暴露 AI 失败；通过。
- **按需求直接实现**: 复用现有 Action、运行记录和 UI，不增加通用工作流框架；通过。
- **最小数据闭环**: 无新业务实体，仍围绕真实房间、菜单、提交、汇总和订单；通过。
- **安全底线**: 不暴露私有图片、密钥或他人上下文，保留两次最终人工确认；通过。
- **静态检查**: 完成后执行 `npm run verify` 并手工走通主链路；通过。

**设计后复核**: 无新依赖、数据库迁移或超出核心链路能力，所有门槛仍通过。

## Project Structure

### Documentation

```text
specs/011-consumer-flow-polish/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/ui-actions.md
└── tasks.md
```

### Source Code

```text
app/rooms/[roomId]/
├── menu/                    # 自动识别和发布跳转
├── selection/               # 菜单助手 Action
├── summary/                 # 自动建议和两选项决策
└── order/                   # 最终确认与恢复页

components/
├── menu-image-uploader.tsx
├── menu-ai-panel.tsx
├── menu-assistant-sheet.tsx
└── table-advice-panel.tsx

lib/
├── menu-assistant.ts
├── menu-ai.ts
└── table-advice.ts
```

**Structure Decision**: 保持现有 App Router 单体结构；小型客户端组件只负责触发，真实权限、去重、限额和写入仍位于现有 Server Action 和数据边界。

## Complexity Tracking

无宪章例外。
