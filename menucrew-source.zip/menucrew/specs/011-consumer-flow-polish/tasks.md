# Tasks: 面向普通用户的自动化点餐链路

**Input**: `specs/011-consumer-flow-polish/` 中的规格、计划、研究、数据模型和 UI Action 契约

## Phase 1: Setup

- [X] T001 核对 `specs/011-consumer-flow-polish/research.md` 中的正式 AI 失败证据与当前 `lib/menu-assistant.ts`
- [X] T002 [P] 检查 `.gitignore` 对 Next.js、环境变量与本地验收产物的覆盖

## Phase 2: Foundational

- [X] T003 在 `app/rooms/[roomId]/menu/ai-actions.ts` 中收敛手动与自动识别共用边界
- [X] T004 [P] 在 `app/rooms/[roomId]/summary/advice-actions.ts` 中收敛手动与自动建议共用边界
- [X] T005 [P] 在 `lib/menu-assistant.ts` 中定义不含用户原文的输出解析阶段和安全错误

## Phase 3: User Story 1 - 上传后自动识别并快速开放点餐 (P1)

**Goal**: 整批图片上传完成后自动识别，确认发布后组织者直接点餐。

**Independent Test**: 上传多图不点识别按钮即出现真实运行状态，确认后 URL 直接进入 `/selection`。

- [X] T006 [US1] 把自动识别 Action 传入 `components/menu-image-uploader.tsx` 并在整批成功后触发
- [X] T007 [US1] 在 `components/menu-image-uploader.tsx` 更新上传前告知、识别中和安全失败文案
- [X] T008 [US1] 在 `app/rooms/[roomId]/menu/page.tsx` 组合上传器与自动识别 Action
- [X] T009 [US1] 修改 `app/rooms/[roomId]/menu/actions.ts` 和 `app/rooms/[roomId]/menu/ai-actions.ts` 使两种发布成功都重定向 `/selection`

## Phase 4: User Story 2 - 默认简洁、需要时才修改菜单 (P1)

**Goal**: 人工编辑能力默认收起为一条次要入口。

**Independent Test**: 识别页首屏无大块编辑表单，点击一次可完整展开和收起。

- [X] T010 [US2] 在 `app/rooms/[roomId]/menu/page.tsx` 用可折叠容器包装人工录入、菜品列表和发布检查
- [X] T011 [US2] 在 `components/menu-ai-panel.tsx` 移除上传后的必经手动识别主按钮并收紧候选区

## Phase 5: User Story 3 - 点餐 AI 助手可稳定回答 (P1)

**Goal**: 修复正式环境 `invalid_output`，失败可重试且表单不丢。

**Independent Test**: 整菜单和单道菜问题均返回非空答案，重试与关闭不清空未保存点餐。

- [X] T012 [US3] 在 `lib/menu-assistant.ts` 修复 finishReason/JSON 提取、严格校验与菜品白名单过滤
- [X] T013 [US3] 在 `app/rooms/[roomId]/selection/assistant-actions.ts` 返回可重试的分类降级并安全记录失败阶段
- [X] T014 [US3] 在 `components/menu-assistant-sheet.tsx` 添加重试操作并移除工程化标题

## Phase 6: User Story 4 - 汇总页只留下最后决策 (P1)

**Goal**: AI 建议自动出现，页底只留继续调整或直接确认。

**Independent Test**: 首次打开汇总无需 AI 点击；两个决策分别返回点餐或生成唯一订单。

- [X] T015 [US4] 新建 `components/auto-table-advice.tsx` 只在需要时自动触发现有建议 Action
- [X] T016 [US4] 重构 `components/table-advice-panel.tsx` 为自动状态与当前建议优先展示
- [X] T017 [US4] 在 `app/rooms/[roomId]/summary/page.tsx` 计算自动触发条件并移除手动 AI 生成表单
- [X] T018 [US4] 在 `components/summary-final-decision.tsx` 实现继续调整与当前数量最终确认
- [X] T019 [US4] 在 `app/rooms/[roomId]/summary/page.tsx` 接入两选项并保留 `/order` 恢复入口

## Phase 7: User Story 5 - 隐藏开发工程痕迹 (P2)

**Goal**: 主流程只显示消费者文案，必要风险提醒仍在。

**Independent Test**: 主流程无功能编号、修订号、模型名或工程英文标题。

- [X] T020 [US5] 清理 `components/menu-ai-panel.tsx`、`components/menu-assistant-sheet.tsx`、`components/table-advice-panel.tsx` 的编号、模型和工程标题
- [X] T021 [US5] 清理 `app/rooms/[roomId]/summary/page.tsx`、`components/aggregation-dish-list.tsx`、`components/aggregation-member-status.tsx` 的修订与实现文案
- [X] T022 [US5] 走查 `app/page.tsx`、`app/join/[token]/page.tsx`、`app/rooms/[roomId]/page.tsx`、`app/rooms/[roomId]/selection/page.tsx`、`app/rooms/[roomId]/receipt/page.tsx`、`app/rooms/[roomId]/order/page.tsx` 并只移除工程痕迹

## Phase 8: Polish & Validation

- [X] T023 更新 `AGENTS.md` 和 `specs/011-consumer-flow-polish/quickstart.md` 记录实际结构与验收结果
- [X] T024 执行 `npm run check:fix`、`npm run verify` 和 `npm run build`
- [X] T025 按 `specs/011-consumer-flow-polish/quickstart.md` 完成本地双身份及真实 AI 主链路验收

## Dependencies & Execution Order

- Phase 1 → Phase 2 → 各用户故事 → Phase 8。
- US1 和 US2 共用菜单页，按 US1 → US2 顺序实施。
- US3 可在基础阶段后独立完成。
- US4 依赖现有最终确认 Action，不依赖 US1–US3。
- US5 在 US1–US4 完成后统一走查，避免文案重复修改。

## Parallel Opportunities

- T002 可与 T001 并行。
- T004、T005 与 T003 修改不同文件，可并行。
- US3 与 US4 在基础阶段后文件基本独立。

## Implementation Strategy

先完成 US3 的正式故障修复与 US1 的主链路减步，再收紧菜单编辑和汇总决策，最后统一清理工程文案并走通两个隔离身份。

