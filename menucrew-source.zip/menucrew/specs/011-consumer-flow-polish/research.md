# 研究决策

## 整批上传后调用现有识别 Action

- **Decision**: 只在当次全部图片登记成功后程序化调用现有识别 Action。
- **Rationale**: 复用权限、图片摘要、相同输入复用、限额和失败保护，不为每张图重复调用。
- **Alternatives considered**: 在图片 API 内同步调 AI 会拉长每张上传；新增后台队列超出 MVP。

## 发布成功由 Server Action 直接重定向

- **Decision**: 人工发布和 AI 确认发布成功后都重定向 `/selection`。
- **Rationale**: Next.js 16 官方建议在变更完成和重新验证后调用 `redirect`，且它应位于 `try` 之外。
- **Alternatives considered**: 由客户端根据成功文字猜测跳转时机容易留在旧页。

## 菜单助手保留结构化输出并增加安全容错

- **Decision**: 继续请求 JSON schema；先严格解析完整文本，必要时仅提取第一个完整 JSON 对象，再做字段长度和菜品 ID 白名单校验。错误日志只记 HTTP 状态、完成原因和解析阶段。
- **Rationale**: 正式环境同一房间已连续四次记录 `invalid_output`。Gemini 文档确认 `responseMimeType` 和 `responseSchema` 可约束 JSON，但应用端仍须校验。
- **Alternatives considered**: 改为不受约束纯文本会降低引用可靠性；接受任意 JSON 会削弱安全边界。

## 汇总只在当前修订无记录时自动触发

- **Decision**: 只有存在正数量汇总、未确认订单且当前修订无 processing/succeeded/failed 记录时，渲染一次性客户端协调器。
- **Rationale**: 避免刷新和开发模式重复 effect 制造多余请求，数据库摘要复用仍是最终并发保护。
- **Alternatives considered**: Server Component 渲染期写数据违反渲染纯度；每次无条件触发会闪动。

## 汇总页直接确认或返回点餐

- **Decision**: 用当前汇总正数量调用现有原子确认 Action；继续调整则返回本人点餐页。原 `/order` 页保留为恢复和精细调整入口。
- **Rationale**: 实现用户提出的两选项决策，同时不删除恢复能力。
- **Alternatives considered**: 删除最终调整页会扩大回归范围；继续把它作为必经步骤不符合本次目标。

## 消费者文案与运行边界分离

- **Decision**: 移除功能编号、修订号、模型名和工程英文标题；保留 AI 可能出错、图片用途、过敏原确认和订单不可逆说明。
- **Rationale**: 用户需要决策风险，不需要实现编号和内部状态。
- **Alternatives considered**: 全部删除提示会违反 AI 和最终订单安全底线。
