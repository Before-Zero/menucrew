# 数据模型：角色导向的顺畅产品链路

## 1. 房间旅程快照（派生，不持久化）

用于让工作台、导航和成功跳转对同一组事实作一致判断。

### 输入事实

- `role`：`organizer` 或 `member`
- `menuStatus`：不存在、`draft` 或 `published`
- `selectionStatus`：`open` 或 `reviewing`
- `orderConfirmed`：布尔值
- `mySubmitted`：布尔值
- `memberCount`：房间成员总数
- `submittedCount`：已提交成员总数

### 派生字段

- `stage`：`preparing`、`collecting`、`reviewing`、`completed`
- `stageLabel`：准备中、收集中、核对中、已完成
- `primaryAction`：当前角色最主要操作的标签和目标
- `navigationItems`：本角色的可用、等待或隐藏导航项
- `pendingCount`：`max(memberCount - submittedCount, 0)`

### 阶段规则

| 优先级 | 条件 | 阶段 |
|---|---|---|
| 1 | `orderConfirmed = true` | `completed` |
| 2 | `selectionStatus = reviewing` | `reviewing` |
| 3 | `menuStatus = published` | `collecting` |
| 4 | 其他 | `preparing` |

阶段不得单独写回数据库。

## 2. 提交进度摘要（RPC 返回值）

### 字段

- `member_count`：目标房间当前成员数，非负整数
- `submitted_count`：目标房间存在提交记录的成员数，非负整数且不大于成员数
- `my_submitted`：当前身份是否存在本人提交

### 安全规则

- 调用者必须是目标房间成员。
- 非成员得到拒绝，不得通过响应确认房间是否存在。
- 返回值不含用户 ID、显示名、选择、备注、忌口、过敏信息或提交时间。
- 发起人需要成员明细时仍使用既有组织者 RLS 汇总路径。

## 3. 状态转移与目标

### 发起人

| 当前阶段/本人状态 | 主要目标 |
|---|---|
| 准备中 | 菜单准备页 |
| 收集中且本人未提交 | 我的选择 |
| 收集中且本人已提交 | 邀请与收集工作台；可结束收集 |
| 核对中且无最终订单 | 汇总与最终数量调整 |
| 已完成 | 最终订单 |

### 参与者

| 当前阶段/本人状态 | 主要目标 |
|---|---|
| 准备中 | 房间等待状态 |
| 收集中且未提交 | 我的选择 |
| 收集中且已提交 | 提交完成与聚餐进度 |
| 核对中 | 聚餐进度；本人选择只读 |
| 已完成 | 最终订单 |

## 4. 既有实体影响

- `rooms`：不新增字段；继续提供收集状态与修订号。
- `menus`：不新增字段；继续提供草稿/发布状态。
- `member_submissions`：不改变 RLS；只用于计算汇总数量和本人状态。
- `orders`：不改变结构和不可变规则；是否存在即为完成阶段依据。
