# 实施计划：角色导向的顺畅产品链路

**功能标识**：`009-role-guided-journeys` | **日期**：2026-08-22 | **规格**：[spec.md](spec.md)

## 摘要

在不改变既有房间、菜单、选择、汇总和订单业务规则的前提下，把当前按 001–005 模块组织的页面改为角色与状态导向的连续旅程。新增一个纯派生的房间旅程模型，为房间概览和持续导航提供统一阶段、主要下一步与可用目标；成功的关键 Server Action 直接进入下一任务，个人选择保存则留在原页显示完成状态。参与者只通过收窄汇总边界读取总人数和已提交人数，不读取其他人的提交明细。

## 技术上下文

**语言/版本**：TypeScript 5、Node.js 24  
**主要依赖**：Next.js 16.3.1 App Router、React 19.2.8、Supabase JS 2.112.3、Tailwind CSS 4、现有 shadcn/ui 与 lucide-react  
**存储**：复用 Supabase Postgres 现有房间、菜单、成员提交和订单表；增加一个只返回汇总人数的 security-definer RPC，不新增持久化业务状态  
**测试**：遵循宪章，不新增自动化测试；使用既有演示数据、两个隔离浏览器进行人工角色链路验收，并执行 `npm run verify`  
**目标平台**：Vercel 上的现代手机与桌面浏览器  
**项目类型**：单根目录 Next.js 全栈 Web 应用  
**性能目标**：房间概览在一次服务端渲染内给出阶段和下一步；不增加轮询、实时订阅或客户端瀑布请求  
**约束**：不重做视觉风格、不新增依赖、不改变邀请与权限边界、不暴露成员提交明细、不改变最终订单不可变规则  
**规模/范围**：首页、加入页、房间概览、菜单、个人选择、汇总、最终订单七个现有页面组及其共享壳层和 Server Actions

## 宪章检查

- **MVP 核心路径优先**：改造直接覆盖从菜单准备、成员选择到最终订单的核心路径，不扩展支付、通知、聊天或历史，符合。
- **按需求直接实现**：复用现有路由、组件与数据读取，只增加一个小型派生模块和一个收窄汇总 RPC，不引入状态机框架、全局状态库或新依赖，符合。
- **最小可用数据闭环**：所有阶段继续来自真实 Supabase 数据；旅程阶段只派生、不保存副本，符合。
- **安全底线**：参与者只得到计数和本人状态；邀请、RLS、原子保存、AI 人工确认和最终订单不可变边界保持不变，符合。
- **静态检查即质量门槛**：任务只要求 `npm run verify` 和人工双角色链路，不增加自动化测试前置，符合。

研究与设计后复查：收窄 RPC 仅验证当前用户是房间成员并返回成员总数、已提交数和本人是否提交，不返回身份或健康信息；没有宪章冲突。

## 项目结构

### 本功能文档

```text
specs/009-role-guided-journeys/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── room-journey-ui.md
├── checklists/
│   └── requirements.md
└── tasks.md
```

### 源码变更范围

```text
app/
├── actions.ts
├── join/[token]/page.tsx
└── rooms/[roomId]/
    ├── page.tsx
    ├── menu/{page.tsx,actions.ts}
    ├── selection/page.tsx
    ├── summary/{page.tsx,actions.ts}
    └── order/{page.tsx,actions.ts}
components/
├── room-shell.tsx
├── room-journey-nav.tsx                 # 新增
├── organizer-room-dashboard.tsx         # 新增
├── member-room-dashboard.tsx            # 新增
├── member-selection-form.tsx
├── menu-status-actions.tsx
├── collection-status-action.tsx
└── final-order-form.tsx
lib/
├── room-journey.ts                      # 新增：纯阶段与目标派生
├── room-progress.ts                     # 新增：角色安全的进度读取
├── rooms.ts
├── menus.ts
├── selections.ts
└── supabase/database.types.ts
supabase/migrations/
└── <timestamp>_room_submission_progress.sql
AGENTS.md
```

**结构决策**：保留全部现有 URL，避免路由迁移和失效链接。`lib/room-journey.ts` 只把已有事实转换为阶段、标签和目标，不访问数据库；页面继续在服务端读取真实数据。共享导航作为可选房间上下文接入 `RoomShell`，首页、邀请页和拒绝页仍可复用同一壳层。

## 复杂度跟踪

无宪章违规。
