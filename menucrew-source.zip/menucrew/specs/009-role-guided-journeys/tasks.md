---

description: "角色导向产品链路的依赖有序实施任务"
---

# 任务：角色导向的顺畅产品链路

**输入**：`specs/009-role-guided-journeys/` 下的 `spec.md`、`plan.md`、`research.md`、`data-model.md`、`contracts/room-journey-ui.md` 与 `quickstart.md`  
**测试策略**：遵循项目宪章，不新增自动化测试；每个用户故事通过独立人工场景验收，最终执行 `npm run verify`  
**组织方式**：任务按用户故事分组，使发起人链路、参与者链路和恢复导航可以分别实现与验收

## 格式：`[ID] [P?] [Story] 描述`

- **[P]**：可与同阶段其他标记任务并行，涉及不同文件且不依赖未完成任务
- **[US1]–[US3]**：对应 `spec.md` 中的用户故事

## Phase 1：准备与基线

**目的**：确认当前完成版本是可靠改造起点

- [X] T001 在改造前运行 `npm run verify`，并把基线结果记录到 `specs/009-role-guided-journeys/quickstart.md` 的验收记录小节

---

## Phase 2：共享基础能力

**目的**：建立所有角色页面共同依赖的安全进度摘要和唯一旅程判断

**⚠️ 关键门槛**：本阶段完成前不得开始工作台、智能跳转或持续导航集成

- [X] T002 在 `supabase/migrations/20260822090000_room_submission_progress.sql` 新增只允许房间成员调用的 security-definer RPC，返回 `member_count`、`submitted_count`、`my_submitted` 且不返回任何成员明细
- [X] T003 应用 T002 的迁移并重新生成 `lib/supabase/database.types.ts`，确认 RPC 参数与返回类型可由服务端客户端安全调用
- [X] T004 在 `lib/room-progress.ts` 实现提交进度摘要读取，校验无效房间、非成员拒绝和 RPC 错误，同时只向调用方返回三个汇总字段
- [X] T005 [P] 在 `lib/room-journey.ts` 定义四阶段类型、中文阶段标签、优先级派生、角色主操作和角色导航可用性，确保该模块不访问数据库且不持久化阶段
- [X] T006 在 `lib/room-progress.ts` 组合现有房间访问、菜单摘要、本人选择摘要、最终订单存在性和 T004 进度，输出供页面使用的统一房间旅程快照

**检查点**：同一组房间事实能够稳定派生唯一阶段、一个主要下一步和不泄露成员明细的进度摘要

---

## Phase 3：用户故事 1——发起人沿一条主线完成整桌订单（P1）🎯

**目标**：发起人从创建房间到最终订单始终沿当前主要任务前进，不再回到功能目录寻找入口

**独立验收**：使用一个发起人会话和演示成员数据完成创建、菜单发布、本人提交、结束收集、汇总核对和订单确认；不输入 URL、不依赖浏览器后退，也不把“返回房间”作为前进步骤

### 实施任务

- [X] T007 [P] [US1] 修改 `app/actions.ts`，让创建房间成功后在 `try/catch` 外重定向至 `/rooms/[roomId]/menu`，错误继续返回现有表单状态
- [X] T008 [P] [US1] 修改 `app/rooms/[roomId]/menu/actions.ts` 和 `components/menu-status-actions.tsx`，让发布成功后进入房间邀请与收集工作台，并把主要按钮改为“发布菜单并邀请成员”
- [X] T009 [P] [US1] 在 `components/organizer-room-dashboard.tsx` 实现发起人工作台，展示邀请入口、成员数、提交数、本人提交状态、当前阶段和唯一主要下一步
- [X] T010 [US1] 重构 `app/rooms/[roomId]/page.tsx` 的发起人分支，使用统一旅程快照和 `components/organizer-room-dashboard.tsx` 取代菜单、选择、汇总、订单并列的功能目录
- [X] T011 [P] [US1] 修改 `components/collection-status-action.tsx` 与 `app/rooms/[roomId]/summary/actions.ts`，在待提交人数大于零时显示具体确认提示，并在成功进入核对后重定向至 `/rooms/[roomId]/summary`
- [X] T012 [US1] 调整 `app/rooms/[roomId]/summary/page.tsx`，使开放收集时的主要动作是“结束收集并开始核对”，核对中主要动作是“调整并确认最终订单”，重新开放保持次要操作
- [X] T013 [P] [US1] 修改 `app/rooms/[roomId]/order/actions.ts`、`components/final-order-form.tsx` 与 `app/rooms/[roomId]/order/page.tsx`，让确认成功后直接进入不可变订单视图，并统一“确认并生成最终订单”的不可逆文案
- [X] T014 [US1] 按 `specs/009-role-guided-journeys/quickstart.md` 场景 A 人工验收发起人链路，并在该文件的验收记录小节记录结果与发现

**检查点**：发起人主线可以独立演示，页面始终突出当前任务而非功能入口集合

---

## Phase 4：用户故事 2——参与者从邀请直接完成个人选择（P1）

**目标**：参与者加入后直接到达可执行任务，保存后明确知道已完成、是否可修改以及接下来等待什么

**独立验收**：独立浏览器打开已发布菜单的邀请，输入称呼后直接选菜并保存；无需访问成员目录即可确认提交完成，并且进度页不泄露其他成员明细

### 实施任务

- [X] T015 [US2] 修改 `app/actions.ts` 的加入成功分支，读取最新旅程阶段并分别重定向到等待工作台、个人选择、聚餐进度或最终订单，保持邀请凭证从地址中移除
- [X] T016 [P] [US2] 在 `components/member-room-dashboard.tsx` 实现参与者工作台，只展示房间阶段、总人数、已提交人数、本人提交状态和一个主要下一步，不渲染其他成员选择或健康信息
- [X] T017 [US2] 重构 `app/rooms/[roomId]/page.tsx` 的参与者分支，使用统一旅程快照与 `components/member-room-dashboard.tsx` 呈现准备等待、已提交等待、核对中和已完成状态
- [X] T018 [P] [US2] 修改 `components/member-selection-form.tsx`，保存成功后在原页显示“已成功提交”、菜品数、总份数、当前可修改性、“继续修改”和“查看聚餐进度”入口
- [X] T019 [US2] 调整 `app/rooms/[roomId]/selection/page.tsx`，把理解菜单与填写个人选择合成一个任务语境，并在核对或完成阶段保持本人内容只读和状态明确
- [X] T020 [US2] 调整 `app/rooms/[roomId]/order/page.tsx` 的参与者分支，使核对中显示简洁等待状态、已完成时最终双语订单成为最突出内容
- [X] T021 [US2] 按 `specs/009-role-guided-journeys/quickstart.md` 场景 B 与场景 C 人工验收已发布和准备中两种加入流程，并在该文件的验收记录小节记录结果与隐私检查

**检查点**：参与者从邀请到提交完成无需学习房间结构，且只能看到允许的聚合进度和本人数据

---

## Phase 5：用户故事 3——任何成员都能立即恢复当前任务（P2）

**目标**：所有房间页面持续显示房间、角色、业务阶段与角色导航，刷新或重开后可以立即继续

**独立验收**：在准备中、收集中、核对中、已完成四种状态分别以两种角色打开房间；每页能识别当前阶段与主要下一步，房间内品牌入口保留房间上下文，页面不再出现 001–005

### 实施任务

- [X] T022 [P] [US3] 在 `components/room-journey-nav.tsx` 实现角色收窄导航，区分可用链接、带等待条件的禁用项和不属于当前角色的隐藏项
- [X] T023 [US3] 修改 `components/room-shell.tsx`，接收可选房间旅程上下文、渲染中文阶段与 `components/room-journey-nav.tsx`，并让房间内品牌入口返回 `/rooms/[roomId]`
- [X] T024 [P] [US3] 在 `app/rooms/[roomId]/menu/page.tsx` 接入房间旅程壳层，移除“返回房间”必经按钮和 `Menu draft · 002`、`Menu view · 002` 标签
- [X] T025 [P] [US3] 在 `app/rooms/[roomId]/selection/page.tsx` 接入房间旅程壳层，移除“返回房间”必经按钮和 `My order · 003` 标签
- [X] T026 [P] [US3] 在 `app/rooms/[roomId]/summary/page.tsx` 与 `app/rooms/[roomId]/order/page.tsx` 接入房间旅程壳层，移除返回中转依赖及 `Table check · 004`、`Final order · 005` 标签
- [X] T027 [US3] 更新 `app/page.tsx`、`app/join/[token]/page.tsx` 和各房间拒绝状态，使非房间页面保留首页品牌入口，但所有用户文案不再暴露开发阶段编号或内部英文阶段名
- [X] T028 [US3] 扫描 `app/` 与 `components/` 中的 `001`–`005`、`Room access`、`Menu draft`、`Menu view`、`My order`、`Table check`、`Final order`，清理剩余面向用户的内部标签并按 `specs/009-role-guided-journeys/contracts/room-journey-ui.md` 核对导航契约

**检查点**：两种角色在四种阶段均能恢复上下文，并通过持续导航直接前往有意义的页面

---

## Phase 6：收口与交付

**目的**：同步协作文档并完整验证双角色真实数据闭环

- [X] T029 [P] 更新 `AGENTS.md` 的项目速览、迁移说明与核心页面职责，记录 `lib/room-journey.ts`、`lib/room-progress.ts`、角色工作台、持续导航和 009 提交进度 RPC
- [X] T030 运行 `npm run verify`，修复本功能涉及文件的 Biome 与 TypeScript 问题，并把结果记录到 `specs/009-role-guided-journeys/quickstart.md`
- [X] T031 按 `specs/009-role-guided-journeys/quickstart.md` 完成场景 D、隐私回归和双隔离浏览器完整链路，把最终人工验收结果记录到该文件

---

## 依赖与执行顺序

### 阶段依赖

- **Phase 1**：无依赖，先建立可靠基线。
- **Phase 2**：依赖 Phase 1，阻塞所有用户故事。
- **Phase 3（US1）**：依赖 Phase 2；可先独立交付发起人主线。
- **Phase 4（US2）**：依赖 Phase 2；组件任务可与 US1 并行，但 `app/actions.ts` 和房间根页集成在同一工作区执行时应排在 T007、T010 之后。
- **Phase 5（US3）**：依赖 US1 与 US2 的最终工作台结构，统一接入持续导航并清理内部编号。
- **Phase 6**：依赖计划交付的所有用户故事。

### 用户故事依赖

- **US1（P1）**：共享基础完成后可独立实现与验收。
- **US2（P1）**：共享基础完成后可独立开发参与者组件；最终合并房间根页时依赖 US1 已完成的发起人分支。
- **US3（P2）**：依赖 US1、US2 提供的最终角色工作台和页面状态，负责跨页面恢复体验。

### 故事内部顺序

- 先完成独立 Server Action、纯组件和数据读取任务。
- 再把组件接入页面并连接成功跳转。
- 最后按该故事的独立验收场景手工验证。
- 带 `[P]` 的任务只在不同文件、无未完成前置时并行。

## 并行机会示例

### 共享基础

```text
并行：T002 数据库收窄 RPC
并行：T005 纯房间旅程派生模型
汇合：T003 → T004 → T006
```

### 用户故事 1

```text
并行：T007 创建成功跳转
并行：T008 菜单发布成功跳转
并行：T009 发起人工作台组件
并行：T011 结束收集交互
并行：T013 最终订单确认跳转
汇合：T010、T012 → T014
```

### 用户故事 2

```text
并行：T016 参与者工作台组件
并行：T018 选择保存完成状态
顺序：T015 → T017、T019、T020 → T021
```

### 用户故事 3

```text
先完成：T022 → T023
并行：T024 菜单页接入
并行：T025 选择页接入
并行：T026 汇总与订单页接入
汇合：T027 → T028
```

## 实施策略

### 建议 MVP

本功能的最小可信范围是 **Phase 1 + Phase 2 + US1 + US2**。只完成 US1 会让发起人更顺，但参与者仍保留原有折返，因此两个 P1 故事应一起作为本轮 MVP。

### 增量交付

1. 完成基线与共享旅程模型。
2. 交付 US1，验证发起人无需功能目录即可完成主线。
3. 交付 US2，验证一次性参与者直接加入、选择和确认完成。
4. 交付 US3，把恢复、持续导航和编号清理覆盖到全部页面。
5. 完成协作文档、静态检查和双浏览器真实数据验收。

## 说明

- 所有任务都复用现有依赖、路由和业务数据。
- 本任务清单不包含 Stitch 页面接入或整体视觉装修。
- 不新增自动化测试任务；人工验收必须记录结果，不能仅凭静态检查宣称链路完成。
- 数据库任务只增加汇总读取边界，不改变普通成员读取提交明细的 RLS。
